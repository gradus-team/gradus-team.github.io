import pygame
import math
import os
import sys
import traceback

from gradus_rc import Engine, LightSource, Sprite, load_image
from gradus_rc.examples import MenuExample, GameExample
from gradus_rc import achievements
from gradus_rc.enemy import EnemyAI
from gradus_rc.gun import Gun, Bullet, GunManager
from gradus_rc.hud.pause import PauseMenu
from gradus_rc.multiplayer_firebase import FirebaseLobbyClient


achievements.define_achievements({
    "l2": {"title": "Первый хардкор", "description": "Пройди второй уровень"},
    "l3": {"title": "Настоящий боец", "description": "Пройди третий уровень"},
    "l4": {"title": "Мясник", "description": "Пройди четвертый уровень"},
    "l5": {"title": "Последний выживший", "description": "Пройди пятый уровень", "hidden": True},
})


# ========== КАРТЫ ==========
LEVEL1 = """
[COLLISION]
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
1 0 0<floor_h:0.3> 0 0 0 0 1 0 0 0 0 0 0 0 1
1 0 1<material:silver> 1 1<material:silver> 0 0 1 0 1 1 1 0 0 0 1
1 0 0 0 1 0 0<enemy:type=dragon;hp:30> 0<floor_h:0.3> 0<floor_h:0.3> 0<floor_h:0.3> 0<floor_h:0.3> 1 0 0 0 1
1 0 0 0 1 0 0 0 0 0 0 1 0 0 0 1
1 3<destructible:true> 1 1 1 0 0 0 0 0 0 1 0 0 0 1
1 0 0 0 0 0 0 1 1 1 0 1 0 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
1 0 1 0 0 0 0 1 0 0 0 0 0 0 0 1
1 0 1 0 0 0 0 1 0 1 1 1 0 0 0 1
1 0 1 0 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 0 0 0 0 1 0 0 0 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
1 1 1 1 1 0 0 0 0 0 0 0 0 0 0 1
1 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 0 0 0 0 0 0 0 0 0 0 6<path:models/model.gbj;destructible:true;addcollision:true> 0 0 1
1 0 0 0 0 6<path:models/model.gbj;addcollision:true;interactive:true;on_press:scream;radius:64> 0 6<path:models/model.gbj;pushable:true;mass:20;friction:0.85;bounciness:0.2> 0 0 0 0 0 9<level:1,isvisible:1,material:glass> 0 1
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1

[SPAWN=0.5,0.5]
[AMBIENT=0.15]
[FLOOR_COLOR=333333]
[CEILING_COLOR=111111]
[LIGHTS=2.5,2.5,0.5,200;7.5,4.5,0.6,250;12.5,12.5,0.7,300]
[FOG_COLOR=303040]
[FOG_START=400]
[FOG_END=1200]
"""

LEVEL2 = """
[COLLISION]
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
1 0 0 0 1 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 0 0 0 0 0 0 0 0 0 1
1 0 1 0 1 0 1 1 1 0 1 1 1 0 0 1
1 0 1 0 0 0 0 0 1 0 0 0 1 0 0 1
1 0 1 1 1 0 1 0 1 0 1 0 1 0 0 1
1 0 0 0 1 0 1 0 0 0 1 0 0 0 0 1
1 1 1 0 1 0 1 1 1 0 1 1 1 0 0 1
1 0 0 0 1 0 0 0 0 0 0 0 0 0 0 1
1 <enemy:type=chase,hp=40,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 0 1 1 1 0 1 0 0 0 0 0 0 1
1 0 0 0 0 0 0 0 1 0 0 0 0 0 0 1
1 0 0<enemy:type=chase,hp=80,aim=15,shoot_delay=0.8,shoot_intensity=30,attack_type=ranged,detect_radius=7,attack_radius=5,speed=70> 0 0 0 1 0 0 0 0 0 1
1 0 0 0 0 0 0 1 0 0 0 0 0 0 1
1 1 1 1 1 0 0 1 0 0 0 0 0 0 1
1 0 0 0 0 0 0 0 0 0 <enemy:type=chase,hp=40,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 6<path:models/model.gbj> 0 1
1 0 <enemy:type=chase,hp=40,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 0 0 0 0 0 0 0 0 0 9<level:2,isvisible:1,material:glass> 1
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1

[SPAWN=0.5,0.5]
[AMBIENT=0.15]
[FLOOR_COLOR=333333]
[CEILING_COLOR=111111]
[LIGHTS=2.5,2.5,0.5,200;7.5,4.5,0.6,250;12.5,12.5,0.7,300]
"""

LEVEL3 = """
[COLLISION]
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
1 0 0 0 0 0 1 0 0 0 0 0 0 0 0 1
1 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1
1 0 0 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 1 0 0 0 0 0 1 0 0 0 0 1
1 0 0 0 1 1 1 1 1 0 1 0 0 0 0 1
1 0 0 0 0 0 0 0 1 0 0 0 0 0 0 1
1 0 1 1 1 0 0 0 1 1 1 0 0 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 0 0 1
1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1
1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1
1 0 0<enemy:type=patrol,hp=100,aim=5,shoot_delay=1.2,shoot_intensity=10,attack_type=melee,detect_radius=5,attack_radius=3,speed=50> 0 0 0 1 0 0 0 0 0 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
1 1 1 1 0 0 0 0 0 0 0 0 0 6<path:models/model.gbj> 0 1
1 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 0 0 0 0 0 0 0 0 0 0 0 0 9<level:3,isvisible:1,material:glass> 1
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1

[SPAWN=0.5,0.5]
[AMBIENT=0.15]
[FLOOR_COLOR=333333]
[CEILING_COLOR=111111]
[LIGHTS=2.5,2.5,0.5,200;7.5,4.5,0.6,250;12.5,12.5,0.7,300]
"""

LEVEL4 = """
[COLLISION]
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
1 0 0 0 0 0 1 0 0 0 0 0 0 0 0 1
1 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1
1 0 0 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 1 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 0 0 0 0 1 0 0 0 0 1
1 0 0 0 1 1 1 1 1 0 1 0 <enemy:type=chase,hp=80,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 0 1
1 0 0 0 0 0 0 0 1 0 0 0 0 0 0 1
1 0 1 1 1 0 0 0 1 1 1 0 0 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1
1 0 0 0 0 0 0 1 0 <enemy:type=chase,hp=80,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 0 0 0 0 1
1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1
1 0 0 0 0 0 0 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 0 0 0 0 <enemy:type=chase,hp=150,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
1 1 1 1 0 0 <enemy:type=chase,hp=80,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 0 0 0 0 0 6<path:models/model.gbj> 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 9<level:4,isvisible:1,material:glass> 1
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1

[SPAWN=0.5,0.5]
[AMBIENT=0.15]
[FLOOR_COLOR=333333]
[CEILING_COLOR=111111]
[LIGHTS=2.5,2.5,0.5,200;7.5,4.5,0.6,250;12.5,12.5,0.7,300]
"""

LEVEL5 = """
[COLLISION]
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1
1 0 1 1 1 0 0 1 0 1 1 1 0 0 0 1
1 0 0 0 1 0 0 0 0 0 0 1 0 0 0 1
1 0 0 0 1 0 0<enemy:type=chase,hp=150,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 0 0 0 1 0 0 1
1 0 1 1 1 0 0 0 0 0 0 1 0 0 1
1 0 0 0 0 0 0 1 1 1 0 1 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 1
1 0 1 0 0 0 0 1 0 0 0 <enemy:type=chase,hp=150,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 0 1
1 0 1 0 0 0 0 1 0 1 1 1 0 0 1
1 0 1 0 0<enemy:type=patrol,hp=120,aim=10,shoot_delay=0.9,shoot_intensity=20,attack_type=ranged,detect_radius=8,attack_radius=6,speed=70> 0 0 0 0 1 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 1
1 1 1 1 1 0 0 0 0 0 0 0 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 6<path:models/model.gbj> 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 9<level:5,isvisible:1,material:glass> 1
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1

[SPAWN=0.5,0.5]
[AMBIENT=0.15]
[FLOOR_COLOR=333333]
[CEILING_COLOR=111111]
[LIGHTS=2.5,2.5,0.5,200;7.5,4.5,0.6,250;12.5,12.5,0.7,300]
"""


# ========== ДВИЖОК ==========
class MyDoomEngine(Engine):
    def __init__(self, clock, *args, **kwargs):
        super().__init__(clock, *args, **kwargs)
        self.i = pygame.display.Info()
        self.shotgun = Gun(
            name='shotgun', damage=39, fire_rate=0.8, ammo=6, max_ammo=24,
            texture=load_image('shotgun', 'assets/shotgun.png',
                               size=(self.i.current_w // 3, self.i.current_h // 3)),
            animation_fire=[load_image('shotgun_fire', 'assets/shotgun_fire.png',
                                       size=(self.i.current_w // 3, self.i.current_h // 3))],
            key='shotgun')
        self.rpg = Gun(
            name='rpg', damage=80, fire_rate=1.5, ammo=3, max_ammo=10,
            animation_fire=[load_image('rpg_fire', 'assets/rpg_shot.png',
                                       size=(self.i.current_w // 3, self.i.current_h // 3))],
            texture=load_image('rpg', 'assets/rpg.png',
                               size=(self.i.current_w // 3, self.i.current_h // 3)),
            key='rpg', explosive=True,
            explosion_radius=180.0, explosion_damage=150.0)
        self.api.set_player_light(radius=300, intensity=1.0, color=(255, 255, 255))
        self.gun_manager.add_gun(self.shotgun)
        self.gun_manager.add_gun(self.rpg)
        self.gun_manager.switch_gun('shotgun')
        self.player.on_death = self._on_player_death
        self.game_over = False
        self.scream_image = None
        self.scream_sound = None
        self.scream_timer = 0.0
        self.scream_duration = 1.5
        try:
            if os.path.exists("scary_face.jfif"):
                img = pygame.image.load("scary_face.jfif").convert()
                self.scream_image = pygame.transform.smoothscale(
                    img, (self.screen_width, self.screen_height))
        except Exception as e:
            print(f"[Scream] image load failed: {e}")
        try:
            if os.path.exists("scream.wav"):
                self.scream_sound = pygame.mixer.Sound("scream.wav")
        except Exception as e:
            print(f"[Scream] sound load failed: {e}")

    def on_interactive_press(self, action_name, obj):
        if action_name == 'scream':
            self.scream_timer = self.scream_duration
            if self.scream_sound is not None:
                self.scream_sound.play()

    def update(self, dt, keys):
        super().update(dt, keys)
        if self.scream_timer > 0:
            self.scream_timer -= dt

    def render(self, screen):
        super().render(screen)
        if self.scream_timer > 0 and self.scream_image is not None:
            screen.blit(self.scream_image, (0, 0))

    def _on_player_death(self, leave=True):
        if self.split_mode:
            return
        self.game_over = True
        self.show_message("GAME OVER", duration=3.0)

    def enemy_shoot(self, enemy, angle):
        damage = enemy.current_gun.damage if enemy.current_gun else 10
        b = Bullet(enemy.x, enemy.y, angle, damage=damage, speed=300, owner=enemy)
        self.bullets.append(b)

    def handle_event(self, event):
        if self._process_key_debug(event):
            return


class DoomGameExample(GameExample):
    def __init__(self, engine_class, levels, current_level, width, height,
                 player_speed=48.0, **kwargs):
        super().__init__(engine_class, levels, current_level, width, height,
                         player_speed, **kwargs)
        self.sm5l = True
        self.l1 = self.l2 = self.l3 = self.l4 = True
        self.pause_menu = PauseMenu(width, height)
        self.paused = False
        self.engine.font = pygame.font.SysFont('Arial', 18)

    def run(self):
        font_hp = pygame.font.SysFont('Arial', 36)
        font_ammo = pygame.font.SysFont('Arial', 36)
        font_fps = pygame.font.SysFont('Arial', 36)
        clock = pygame.time.Clock()
        running = True

        def _apply_pause(state):
            if state:
                self.paused = True
                self.pause_menu.active = True
                pygame.mouse.set_visible(True)
                pygame.event.set_grab(False)
                self.engine.mouse_captured = False
            else:
                self.paused = False
                self.pause_menu.active = False

        while running:
            dt = clock.tick(self.fps) / 1000.0
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    break
                imap = self.engine.player.input_map
                if event.type == pygame.KEYDOWN and event.key == imap.get('interact'):
                    self.engine.api.try_interact()
                    continue
                if self.paused:
                    r = self.pause_menu.handle_event(event)
                    if r == 'resume':
                        _apply_pause(False)
                    elif r == 'exit':
                        running = False
                        break
                    continue
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    _apply_pause(True)
                    continue
                if hasattr(self.engine, 'handle_event'):
                    self.engine.handle_event(event)
                if hasattr(self.engine, 'handle_mouse'):
                    self.engine.handle_mouse(event)

            if not running:
                break

            if not self.paused:
                if self.engine.current_level == 0 and self.l1:
                    self.engine.show_message(
                        "Ищи порталы ввиде голубых стен\nWASD — движение, ПКМ — захват мыши, ЛКМ — стрельба",
                        10, size=24)
                    self.l1 = False
                elif self.engine.current_level == 1 and self.l2:
                    self.engine.show_message(
                        "У врагов разное ХП. Патроны пополняются автоматом.\nСовет: стреляй зажимом",
                        10, size=24)
                    self.l2 = False
                elif self.engine.current_level == 2 and self.l3:
                    self.engine.api.unlock_achievement("l2")
                    self.engine.show_message(
                        "Совет: прячься за стенами, ХП восстанавливается",
                        10, size=24)
                    self.l3 = False
                elif self.engine.current_level == 3 and self.l4:
                    self.engine.api.unlock_achievement("l3")
                    self.engine.show_message(
                        "Здесь много врагов. Убивай постепенно.",
                        10, size=24)
                    self.l4 = False
                elif self.engine.current_level == 4 and self.sm5l:
                    self.engine.api.unlock_achievement("l4")
                    self.engine.show_message("Финальный уровень!", 10, size=24)
                    self.sm5l = False
                    self.l1 = self.l2 = self.l3 = self.l4 = True

                keys = pygame.key.get_pressed()
                im = self.engine.player.input_map

                if self.engine.split_mode and self.engine._split_players:
                    for p in self.engine._split_players:
                        if not getattr(p, 'alive', True):
                            continue
                        fire_key = p.input_map.get('fire')
                        wants = fire_key is not None and keys[fire_key]
                        if p is self.engine.player and pygame.mouse.get_pressed()[0]:
                            wants = True
                        if wants:
                            self.engine.api.fire_current_gun(p)
                    for p in self.engine._split_players:
                        sw_key = p.input_map.get('switch_gun')
                        if sw_key is not None and keys[sw_key]:
                            gm = self.engine.get_gun_manager(p)
                            cur = gm.current_gun_key
                            gm.switch_gun('rpg' if cur == 'shotgun' else 'shotgun')
                else:
                    if keys[im.get('fire', pygame.K_SPACE)] or pygame.mouse.get_pressed()[0]:
                        self.engine.api.fire_current_gun()
                    if keys[im.get('switch_gun', pygame.K_q)]:
                        cur = self.engine.gun_manager.current_gun_key
                        self.engine.gun_manager.switch_gun(
                            'rpg' if cur == 'shotgun' else 'shotgun')

                if keys[pygame.K_1]:
                    self.engine.get_gun_manager(self.engine.player).switch_gun('shotgun')
                elif keys[pygame.K_2]:
                    self.engine.get_gun_manager(self.engine.player).switch_gun('rpg')

                self.engine.update(dt, keys)
                if self.engine.split_mode:
                    self.engine.render_split(self.screen)
                else:
                    self.engine.render(self.screen)

                if self.engine.enemies or self.engine.gun_manager.guns:
                    if self.engine.player.alive:
                        hp = font_hp.render(f"HP: {int(self.engine.player.hp)}",
                                            True, (255, 0, 0))
                        self.screen.blit(hp, (10, 10))
                        gun = self.engine.gun_manager.get_current_gun()
                        if gun:
                            a = font_ammo.render(
                                f"Ammo: {gun.ammo}/{gun.max_ammo}",
                                True, (255, 255, 0))
                            self.screen.blit(a, (10, 40))

                if self.show_fps:
                    fps = clock.get_fps() * (1.07 if self.engine.use_raycaster_async else 1.0)
                    t = font_fps.render(f"FPS: {int(fps)}", True, (255, 255, 0))
                    self.screen.blit(t, (self.width - 120, self.height - 40))

                if self.engine.game_over and self.engine.message_timer <= 0:
                    running = False
                self.engine.hud.draw(self.screen)
            else:
                self.pause_menu.draw(self.screen)

            pygame.display.flip()

        pygame.quit()


# ========== MAIN ==========
def main():
    pygame.init()

    # ---- CLI ----
    args = sys.argv[1:]
    cli_port = None
    cli_client = False
    cli_name = None
    cli_host_ip = None
    cli_fb_lobby = None
    i = 0
    while i < len(args):
        if args[i] == '--port' and i + 1 < len(args):
            cli_port = int(args[i + 1]); i += 2
        elif args[i] == '--client':
            cli_client = True; i += 1
        elif args[i] == '--name' and i + 1 < len(args):
            cli_name = args[i + 1]; i += 2
        elif args[i] == '--host-ip' and i + 1 < len(args):
            cli_host_ip = args[i + 1]; i += 2
        elif args[i] == '--fb-lobby' and i + 1 < len(args):
            cli_fb_lobby = args[i + 1]; i += 2
        else:
            i += 1

    if os.environ.get('MP_WINDOW') == '1' or cli_client or cli_port:
        WIDTH, HEIGHT = 960, 540
    else:
        info = pygame.display.Info()
        WIDTH, HEIGHT = info.current_w, info.current_h

    screen = pygame.display.set_mode((WIDTH, HEIGHT))

    # ---- Firebase клиент ----
    fb_client = None
    fb_account = "AccountService.json"
    if os.path.isfile(fb_account):
        try:
            fb_client = FirebaseLobbyClient(fb_account, base_path="/gradus_mp")
            print("[Game] Firebase-клиент готов")
        except Exception as e:
            print(f"[Game] Firebase init failed: {e}")

    # ---- Меню ----
    menu = MenuExample(
        width=WIDTH, height=HEIGHT, button_align='center',
        only_online=False,
        online_min_players=2,
        online_min_team_size=0,
        online_default_mode='pvp',
        online_backends=['ip', 'firebase'],
        fb_client=fb_client,
    )
    settings = None

    # CLI-подключение к FB — минуем меню
    if cli_fb_lobby and fb_client:
        settings = {
            'rays': 120, 'fov': 60, 'fps': 60, 'mcfi': False, 'mcfi_level': 0,
            'async_raycast': True, 'render_scale': 1, 'player_rot_speed': 3.0,
            'graphic': 'Medium', 'show_fps': True, 'rt': 0,
            'rt_quality': 'balanced', 'particles_mode': 'optimal',
            '_start_action': 'fb_match_start',
            '_fb_lobby_id': cli_fb_lobby,
            '_serv_mode': 'firebase',
        }
        menu.running = False

    while menu.running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                menu.running = False
            result = menu.handle_event(event)
            if isinstance(result, dict):
                settings = result
                break
        if not menu.running:
            break
        menu.render(screen)
        pygame.display.flip()

    if not settings:
        pygame.quit()
        return

    start_action   = settings.pop('_start_action', 'new')
    load_path      = settings.pop('_load_path', None)
    mp_ip          = settings.pop('_mp_ip', None)
    mp_port        = settings.pop('_mp_port', 50007)
    mp_signature   = settings.pop('_mp_signature', 'default')
    mp_mode        = settings.pop('_mp_mode', 'pvp')
    mp_min_players = settings.pop('_mp_min_players', 2)
    mp_min_team    = settings.pop('_mp_min_team_size', 0)
    serv_mode      = settings.pop('_serv_mode', 'offline')
    fb_lobby_id    = settings.pop('_fb_lobby_id', None)

    levels = [LEVEL1, LEVEL2, LEVEL3, LEVEL4, LEVEL5]

    # ---- Engine init ----
    try:
        game = DoomGameExample(
            engine_class=MyDoomEngine,
            levels=levels, current_level=0,
            width=WIDTH, height=HEIGHT,
            player_speed=48.0, tile_size=64, proj_coeff=50000,
            **settings)
    except Exception as e:
        print(f"[Game] Engine init failed: {e}")
        traceback.print_exc()
        pygame.quit()
        return

    # ---- Post-init actions ----
    if start_action == 'load' and load_path:
        try:
            game.engine.load_from_file(load_path)
        except Exception as e:
            print(f"[Game] load failed: {e}")

    game.api.set_minimap(
        enabled=True, mode='color', size=15, tile_px=20,
        position=(WIDTH - 5 * 20 - 20, 20), alpha=160,
        show_enemies=True, enemy_instant_hide_delay=5.0,
        show_models=True, show_doors=True, show_player_arrow=True)
    game.api.set_player_light_mode('circle', range=40.0, cone_angle=7.0)

    # ---- Онлайн-инициализация ----
    mp = game.engine.mp

    if serv_mode == 'ip':
        if start_action == 'host':
            ok = mp.start_host(port=mp_port, signature=mp_signature,
                               mode=mp_mode, host_name=cli_name or 'Host')
            print(f"[Game][IP] host: {ok}")
        elif start_action == 'join':
            ok = mp.connect(ip=mp_ip, port=mp_port,
                            signature=mp_signature,
                            name=cli_name or 'Player')
            print(f"[Game][IP] join: {ok}")

    elif serv_mode == 'firebase':
        if not fb_client:
            print("[Game][FB] клиент не готов, играем офлайн")
        else:
            # Создаём или присоединяемся
            if start_action == 'host':
                # Меню уже вызвало create_lobby до закрытия, поэтому lobby_id
                # хранится в клиенте
                if fb_client.lobby_id:
                    fb_lobby_id = fb_client.lobby_id
                    print(f"[Game][FB] host lobby: {fb_lobby_id}")
            elif start_action == 'fb_match_start' or start_action == 'join':
                if fb_lobby_id:
                    # Клиент уже в комнате, listener уже висит
                    print(f"[Game][FB] match join: {fb_lobby_id}")

            # Привязываем mp к fb-клиенту
            mp.backend = 'firebase'
            mp._fb = fb_client
            mp.connected = True
            mp.is_host = fb_client.am_i_host() if hasattr(fb_client, 'am_i_host') else False
            mp.lobby_id = fb_lobby_id
            mp.fb_lobby_id = fb_lobby_id
            mp.fb_client = fb_client

            print(f"[Game][FB] backend=firebase, host={mp.is_host}, lobby={fb_lobby_id}")

        # Локальный split-screen
    if start_action == 'local_split':
        game.engine.setup_split((WIDTH, HEIGHT), direction='horizontal')

        # --- Запуск игры ---
    try:
        game.run()
    except Exception as e:
        print(f"[Game] Runtime error: {e}")
        traceback.print_exc()
    finally:
        pygame.quit()

if __name__ == "__main__":
    main()