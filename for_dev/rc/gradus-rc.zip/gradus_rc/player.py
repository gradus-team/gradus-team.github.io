import pygame
import math


# ============================================================
# Пресет 1: КЛАССИКА — одиночка + сетевая на разных устройствах
# W/S ходьба, A/D стрейф, ←/→ поворот, PageUp/Down наклон,
# мышь для всего остального.
# ============================================================
INPUT_WASD = {
    'forward':       pygame.K_w,
    'backward':      pygame.K_s,
    'strafe_left':   pygame.K_a,
    'strafe_right':  pygame.K_d,
    'rotate_left':   pygame.K_LEFT,
    'rotate_right':  pygame.K_RIGHT,
    'pitch_up':      pygame.K_PAGEUP,
    'pitch_down':    pygame.K_PAGEDOWN,
    'fire':          pygame.K_SPACE,
    'switch_gun':    pygame.K_q,
    'interact':      pygame.K_e,
}

# ============================================================
# Пресет 2: СПЛИТ — Игрок 1 (клавиатура, без мыши)
# W/S ходьба, A/D поворот, Space огонь, Q смена, E взаимодействие
# ============================================================
INPUT_SPLIT_P1 = {
    'forward':       pygame.K_w,
    'backward':      pygame.K_s,
    'strafe_left':   None,
    'strafe_right':  None,
    'rotate_left':   pygame.K_a,
    'rotate_right':  pygame.K_d,
    'pitch_up':      pygame.K_r,
    'pitch_down':    pygame.K_f,
    'fire':          pygame.K_SPACE,
    'switch_gun':    pygame.K_q,
    'interact':      pygame.K_e,
}

# ============================================================
# Пресет 3: СПЛИТ — Игрок 2 (стрелки, без мыши)
# ↑/↓ ходьба, ←/→ поворот, Home/End наклон, Enter огонь
# ============================================================
INPUT_SPLIT_P2 = {
    'forward':       pygame.K_UP,
    'backward':      pygame.K_DOWN,
    'strafe_left':   None,
    'strafe_right':  None,
    'rotate_left':   pygame.K_LEFT,
    'rotate_right':  pygame.K_RIGHT,
    'pitch_up':      pygame.K_HOME,
    'pitch_down':    pygame.K_END,
    'fire':          pygame.K_RETURN,
    'switch_gun':    pygame.K_RSHIFT,
    'interact':      pygame.K_SLASH,
}


class Player:
    def __init__(self, x, y, angle=0.0, speed=4.0, rot_speed=0.08,
                 hp=100, regeneration_speed=40, regeneration_value=1,
                 input_map=None):
        self.pos = pygame.math.Vector2(x, y)
        self.angle = angle
        self.speed = speed
        self.rot_speed = rot_speed
        self.input_map = dict(input_map) if input_map else dict(INPUT_WASD)

        self.vel = pygame.math.Vector2(0, 0)
        self.max_hp = hp
        self.rs = regeneration_speed
        self.rv = regeneration_value

        self.pitch = 0.0
        self.pitch_speed = rot_speed
        self.max_pitch = math.radians(30)

        self.rtimer = 0
        self.hp = self.max_hp
        self.alive = True
        self.on_death = None

        self.invulnerable = False
        self.invuln_timer = 0.0

        # ---- Мультиплеер / spectator ----
        self.is_spectator = False
        self.team = None            # 'blue' | 'red' | 'spectator' | None
        self.respawn_timer = 0.0
        self.score = 0
        self.kills = 0
        self.deaths = 0
        # Способность ходить сквозь стены — включается Engine'ом
        self._noclip_original = False

    def update(self, keys, dt):
        if self.invuln_timer > 0:
            self.invuln_timer -= dt
            if self.invuln_timer <= 0:
                self.invuln_timer = 0.0
                self.invulnerable = False

        self.rtimer += 1
        if self.rtimer >= self.rs:
            self.rtimer = 0
            if self.hp < self.max_hp:
                self.hp = min(self.hp + self.rv, self.max_hp)

        im = self.input_map

        # --- Поворот (клавиши) ---
        if im.get('rotate_left')  and keys[im['rotate_left']]:
            self.angle -= self.rot_speed * dt
        if im.get('rotate_right') and keys[im['rotate_right']]:
            self.angle += self.rot_speed * dt

        # --- Pitch (клавиши) ---
        if im.get('pitch_up')   and keys[im['pitch_up']]:
            self.pitch -= self.pitch_speed * dt
        if im.get('pitch_down') and keys[im['pitch_down']]:
            self.pitch += self.pitch_speed * dt
        if self.pitch > self.max_pitch:
            self.pitch = self.max_pitch
        elif self.pitch < -self.max_pitch:
            self.pitch = -self.max_pitch

        # --- Движение ---
        forward = pygame.math.Vector2(math.cos(self.angle),
                                      math.sin(self.angle))
        side = pygame.math.Vector2(-math.sin(self.angle),
                                   math.cos(self.angle))
        self.vel = pygame.math.Vector2(0, 0)
        if keys[im['forward']]:
            self.vel += forward * self.speed
        if keys[im['backward']]:
            self.vel -= forward * self.speed
        if im.get('strafe_left')  and keys[im['strafe_left']]:
            self.vel -= side * self.speed
        if im.get('strafe_right') and keys[im['strafe_right']]:
            self.vel += side * self.speed

        if self.vel.length() > self.speed:
            self.vel.scale_to_length(self.speed)

    def take_damage(self, damage):
        if not self.alive:
            return
        if self.invulnerable:
            return
        self.hp -= damage
        if self.hp <= 0:
            self.hp = 0
            self.alive = False
            if self.on_death:
                self.on_death()

    def add_pitch(self, delta):
        self.pitch += delta
        if self.pitch > self.max_pitch:
            self.pitch = self.max_pitch
        elif self.pitch < -self.max_pitch:
            self.pitch = -self.max_pitch