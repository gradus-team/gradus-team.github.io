"""
Cutscene runtime для Gradus RC.
Формат .gs3 — JSON с кадрами-снимками.
Между кадрами камера и объекты интерполируются.
Карта берётся из кадра, в котором мы находимся.
"""
import json
import os
import math
import pygame


class Cutscene:
    def __init__(self, data):
        self.version = data.get('version', 1)
        self.name = data.get('name', 'unnamed')
        self.background_music = data.get('background_music')
        self.frames = data.get('frames', [])
        self.events = data.get('events', [])

        # Тайминги кадров
        self._frame_times = []
        t = 0.0
        for f in self.frames:
            self._frame_times.append(t)
            t += float(f.get('duration', 1.0))
        self.total_duration = t

    @classmethod
    def load(cls, path):
        with open(path, 'r', encoding='utf-8') as f:
            return cls(json.load(f))

    def save(self, path):
        data = {
            'version': self.version,
            'name': self.name,
            'background_music': self.background_music,
            'frames': self.frames,
            'events': self.events,
        }
        parent = os.path.dirname(path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    @staticmethod
    def _lerp(a, b, t):
        return a + (b - a) * t

    @staticmethod
    def _ease(t, mode='linear'):
        if mode == 'ease_in':
            return t * t
        if mode == 'ease_out':
            return 1.0 - (1.0 - t) ** 2
        if mode == 'ease_in_out':
            return t * t * (3.0 - 2.0 * t)
        return t

    def segment_at(self, time):
        if not self.frames:
            return 0
        if time < 0:
            time = 0
        for i in range(len(self._frame_times) - 1):
            if self._frame_times[i + 1] > time:
                return i
        return len(self.frames) - 1

    def frame_map_data(self, frame_index):
        """Возвращает map_data (список dict-клеток) для указанного кадра."""
        if not (0 <= frame_index < len(self.frames)):
            return []
        f = self.frames[frame_index]
        grid = f.get('map', [])
        wprops = f.get('wall_props', {}) or {}
        result = []
        for y, row in enumerate(grid):
            out_row = []
            for x, cell_id in enumerate(row):
                props = {}
                wp = wprops.get(f"{x},{y}")
                if wp and int(cell_id) != 0:
                    props = dict(wp)
                out_row.append({
                    'base_id': int(cell_id),
                    'properties': props,
                })
            result.append(out_row)
        return result

    def state_at(self, time):
        """Состояние сцены на момент времени time."""
        if not self.frames:
            return None
        if time < 0:
            time = 0

        seg = self.segment_at(time)
        f0 = self.frames[seg]
        t0 = self._frame_times[seg]

        # Последний кадр — статичная сцена
        if seg + 1 >= len(self.frames):
            return {
                'frame_index': seg,
                'camera': dict(f0.get('camera', {})),
                'objects': {o['key']: dict(o) for o in f0.get('objects', [])},
            }

        f1 = self.frames[seg + 1]
        dt = float(f0.get('duration', 1.0))
        local = max(0.0, min(1.0, (time - t0) / max(dt, 1e-6)))
        e = self._ease(local, f0.get('ease', 'linear'))

        # Камера — интерполируется
        c0, c1 = f0.get('camera', {}), f1.get('camera', {})
        cam = {}
        for k in ('x', 'y', 'angle', 'pitch'):
            cam[k] = self._lerp(float(c0.get(k, 0)),
                                float(c1.get(k, 0)), e)

        # Объекты — БЕРЁМ ТОЛЬКО ИЗ f0 (текущий кадр)
        # Если key есть и в f1 — интерполируем.
        o1 = {o['key']: o for o in f1.get('objects', [])}
        objs = {}
        for o0 in f0.get('objects', []):
            key = o0['key']
            merged = dict(o0)
            if key in o1:
                ob = o1[key]
                # Числовые поля — интерполируются
                for field in ('x', 'y', 'roty', 'rotx', 'rotz', 'scale'):
                    if field in o0 or field in ob:
                        merged[field] = self._lerp(
                            float(o0.get(field, 0)),
                            float(ob.get(field, 0)), e)
                # Строковые — берутся как есть
                for field in ('path', 'sprite_path', 'enemy_type', 'hp'):
                    if field in o0:
                        merged[field] = o0[field]
                    elif field in ob:
                        merged[field] = ob[field]
            objs[key] = merged

        return {'frame_index': seg, 'camera': cam, 'objects': objs}


class CutscenePlayer:
    def __init__(self, engine, cutscene, on_end=None):
        self.engine = engine
        self.cs = cutscene
        self.time = 0.0
        self.playing = False
        self._fired = set()
        self._spawned = {}      # key -> obj
        self._spawned_types = {}  # key -> type
        self._current_seg = -1
        self._on_end = on_end
        self._prev_modes = {}

    def start(self):
        e = self.engine
        self._prev_modes = {
            'cutscene_mode': getattr(e, 'cutscene_mode', False),
            'enemy_ai_paused': getattr(e, 'enemy_ai_paused', False),
            'mouse_captured': getattr(e, 'mouse_captured', False),
            'hud_visible': getattr(e.hud, 'show_hud', True),
        }
        e.cutscene_mode = True
        e.enemy_ai_paused = True
        e.mouse_captured = False
        e.hud.show_hud = False
        try:
            pygame.mouse.set_visible(False)
            pygame.event.set_grab(False)
        except Exception:
            pass

        # === СОХРАНЯЕМ И ОЧИЩАЕМ ВСЁ ЛИШНЕЕ ===
        self._saved_world = {
            'pos_x': e.player.pos.x,
            'pos_y': e.player.pos.y,
            'angle': e.player.angle,
            'map_data': e.map_data,
            'map_width': e.map_width,
            'map_height': e.map_height,
            'enemies': list(e.enemies),
            'sprites': list(e.sprite_manager.sprites),
            'bullets': list(e.bullets),
            'particles': list(e.particles.particles),
            'debris': list(e.particles.debris_particles),
            'decals': list(e.decals.decals),
        }
        e.enemies = []
        e.sprite_manager.sprites = []
        e.bullets = []
        e.particles.particles = []
        e.particles.debris_particles = []
        e.decals.decals = []
        # Скрыть ворлд-рендереры (мебель от модов и т.п.)
        if hasattr(e, '_world_renderer_objects'):
            self._saved_world['world_renderer_objects'] = list(e._world_renderer_objects)
            e._world_renderer_objects = []

        if self.cs.background_music:
            try:
                e.api.play_music(self.cs.background_music, loop=True)
            except Exception as ex:
                print(f"[Cutscene] music failed: {ex}")

        # Устанавливаем карту первого кадра
        self._current_seg = -1
        self._apply_frame_map(0)

        state = self.cs.state_at(0.0)
        if state:
            self._sync_objects(state['objects'])
            self._apply_camera(state['camera'])
            self._apply_object_positions(state['objects'])

        self.playing = True
        self.time = 0.0

    # ---------- Карта кадра ----------
    def _apply_frame_map(self, seg):
        e = self.engine
        new_map = self.cs.frame_map_data(seg)
        if not new_map:
            return
        e.map_data = new_map
        e.map_height = len(new_map)
        e.map_width = len(new_map[0]) if new_map else 0
        try:
            e.raycaster.map_data = new_map
            e.raycaster.update_dimensions()
        except Exception:
            pass
        try:
            e.light_tracer.map_data = new_map
        except Exception:
            pass
        if e.use_gpu and e.gpu_raycaster:
            try:
                e.gpu_raycaster.mark_map_dirty()
            except Exception:
                pass

    # ---------- Объекты ----------
    def _spawn_one(self, key, o):
        e = self.engine
        obj = None
        try:
            t = o.get('type', 'model')
            wx = float(o.get('x', 0)) * e.tile_size
            wy = float(o.get('y', 0)) * e.tile_size
            if t == 'enemy':
                obj = e.api.spawn_enemy(
                    x=wx, y=wy,
                    enemy_type=o.get('enemy_type', 'static'),
                    hp=float(o.get('hp', 100)),
                    sprite=o.get('sprite_path'),
                    key=f"cutscene_{key}")
            elif t == 'sprite':
                obj = e.api.spawn_sprite(
                    x=wx, y=wy,
                    texture=o.get('sprite_path', ''),
                    key=f"cutscene_{key}",
                    world_radius=float(o.get('scale', 1.0)) * 32)
            else:
                obj = e.api.spawn_model(
                    x=wx, y=wy,
                    model_path=o.get('path', ''),
                    scale=float(o.get('scale', 1.0)),
                    rot_y=float(o.get('roty', 0)),
                    rot_x=float(o.get('rotx', 0)),
                    rot_z=float(o.get('rotz', 0)),
                    key=f"cutscene_{key}")
        except Exception as ex:
            print(f"[Cutscene] spawn '{key}' failed: {ex}")
        if obj is not None:
            self._spawned[key] = obj
            self._spawned_types[key] = o.get('type', 'model')

    def _despawn_one(self, key):
        e = self.engine
        obj = self._spawned.pop(key, None)
        self._spawned_types.pop(key, None)
        if obj is None:
            return
        try:
            if hasattr(obj, 'alive'):
                obj.alive = False
            if obj in e.enemies:
                e.enemies.remove(obj)
            if obj in e.sprite_manager.sprites:
                e.sprite_manager.sprites.remove(obj)
        except Exception:
            pass

    def _sync_objects(self, objs):
        desired = set(objs.keys())
        for key in list(self._spawned.keys()):
            if key not in desired:
                self._despawn_one(key)
        for key in desired:
            if key not in self._spawned:
                self._spawn_one(key, objs[key])

    def _apply_camera(self, cam):
        e = self.engine
        e.player.pos.x = float(cam.get('x', 0)) * e.tile_size
        e.player.pos.y = float(cam.get('y', 0)) * e.tile_size
        e.player.angle = float(cam.get('angle', 0))
        if hasattr(e.player, 'pitch'):
            e.player.pitch = float(cam.get('pitch', 0))

    def _apply_object_positions(self, objs):
        e = self.engine
        for key, o in objs.items():
            obj = self._spawned.get(key)
            if obj is None:
                continue
            try:
                obj.x = float(o.get('x', 0)) * e.tile_size
                obj.y = float(o.get('y', 0)) * e.tile_size
                if hasattr(obj, 'rot_y') and 'roty' in o:
                    obj.rot_y = math.radians(float(o['roty']))
                if hasattr(obj, 'rot_x') and 'rotx' in o:
                    obj.rot_x = math.radians(float(o['rotx']))
            except Exception:
                pass

    # ---------- Update ----------
    def update(self, dt):
        if not self.playing:
            return
        self.time += dt

        # События
        for i, ev in enumerate(self.cs.events):
            if i in self._fired:
                continue
            if self.time >= float(ev.get('t', 0)):
                self._fire_event(ev)
                self._fired.add(i)

        # Смена сегмента → смена карты и синхронизация объектов
        seg = self.cs.segment_at(self.time)
        if seg != self._current_seg:
            self._current_seg = seg
            self._apply_frame_map(seg)

        state = self.cs.state_at(self.time)
        if state:
            self._sync_objects(state['objects'])
            self._apply_camera(state['camera'])
            self._apply_object_positions(state['objects'])

        if self.time >= self.cs.total_duration:
            self.stop()

    def _fire_event(self, ev):
        e = self.engine
        a = ev.get('action', '')
        try:
            if a == 'play_sound':
                e.api.play_sound(ev.get('key', ''))
            elif a == 'play_music':
                e.api.play_music(ev.get('file', ''),
                                 loop=bool(ev.get('loop', True)))
            elif a == 'stop_music':
                e.api.stop_music()
            elif a == 'show_subtitle':
                e.api.show_subtitle(ev.get('text', ''),
                                    duration=float(ev.get('duration', 2.0)))
            elif a == 'show_message':
                e.show_message(ev.get('text', ''),
                               duration=float(ev.get('duration', 2.0)))
            elif a == 'flash_screen':
                c = ev.get('color', [255, 255, 255])
                e.api.flash_screen(color=(int(c[0]), int(c[1]), int(c[2])),
                                   alpha=int(ev.get('alpha', 200)),
                                   duration=float(ev.get('duration', 0.3)))
            elif a == 'spawn_explosion':
                e.api.spawn_explosion(
                    float(ev.get('x', 0)) * e.tile_size,
                    float(ev.get('y', 0)) * e.tile_size,
                    radius=float(ev.get('radius', 120)),
                    damage=float(ev.get('damage', 0)))
            elif a == 'end':
                self.stop()
        except Exception as ex:
            print(f"[Cutscene] event '{a}' failed: {ex}")

    def stop(self):
        if not self.playing:
            return
        self.playing = False
        e = self.engine

        e.cutscene_mode = self._prev_modes.get('cutscene_mode', False)
        e.enemy_ai_paused = self._prev_modes.get('enemy_ai_paused', False)
        e.mouse_captured = self._prev_modes.get('mouse_captured', False)
        e.hud.show_hud = self._prev_modes.get('hud_visible', True)

        for key in list(self._spawned.keys()):
            self._despawn_one(key)

        try:
            e.api.stop_music(fade_ms=800)
        except Exception:
            pass

        # Возвращаем прежний уровень (перезагружаем настоящую карту)
        try:
            # Возвращаем всё, что было до катсцены
            s = getattr(self, '_saved_world', None)
            if s:
                e.player.pos.x = s['pos_x']
                e.player.pos.y = s['pos_y']
                e.player.angle = s['angle']
                e.map_data = s['map_data']
                e.map_width = s['map_width']
                e.map_height = s['map_height']
                e.enemies = s['enemies']
                e.sprite_manager.sprites = s['sprites']
                e.bullets = s['bullets']
                e.particles.particles = s['particles']
                e.particles.debris_particles = s['debris']
                e.decals.decals = s['decals']
                if 'world_renderer_objects' in s:
                    e._world_renderer_objects = s['world_renderer_objects']

                # Пересинхронизируем raycaster на восстановленную карту
                try:
                    e.raycaster.map_data = e.map_data
                    e.raycaster.update_dimensions()
                except Exception:
                    pass
                try:
                    e.light_tracer.map_data = e.map_data
                except Exception:
                    pass
                if e.use_gpu and e.gpu_raycaster:
                    try:
                        e.gpu_raycaster.mark_map_dirty()
                    except Exception:
                        pass
                self._saved_world = None
        except Exception as ex:
            print(f"[Cutscene] restore level failed: {ex}")

        if self._on_end:
            try:
                # Даём игроку 3 секунды бессмертия после катсцены
                try:
                    e.player.invulnerable = True
                    e.player.invuln_timer = 3.0
                    print("[Cutscene] Игрок получил 3 сек бессмертия")
                except Exception as e:
                    print(f"[Cutscene] on_end.player.invuln failed: {e}")
                self._on_end()
            except Exception as ex:
                print(f"[Cutscene] on_end failed: {ex}")