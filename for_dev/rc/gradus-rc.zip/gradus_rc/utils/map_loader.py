# gradus_rc/utils/map_loader.py
"""
Загрузчик карт: принимает .json (новый формат) или .txt (старый формат).
Возвращает текст карты в старом формате — его уже умеет читать MapParser.
"""

import os
import json


def load_map_file(path):
    """
    Возвращает текст карты для MapParser.
    Если path — существующий файл, читает его.
    Если path — строка с текстом карты, возвращает как есть.
    """
    if not isinstance(path, str):
        return path

    if os.path.isfile(path):
        ext = os.path.splitext(path)[1].lower()
        if ext == '.json':
            return _json_to_text(path)
        elif ext in ('.txt', '.map', '.grm'):
            with open(path, 'r', encoding='utf-8') as f:
                return f.read()
    return path


def _json_to_text(path):
    """Читает .json и конвертирует в текстовый формат карты."""
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    w, h = data.get('size', [16, 16])
    lines = ["[COLLISION]"]

    grid = [[0] * w for _ in range(h)]
    cell_props = {}

    for cell in data.get('cells', []):
        try:
            x, y = int(cell['x']), int(cell['y'])
        except (KeyError, TypeError, ValueError):
            continue
        if not (0 <= x < w and 0 <= y < h):
            continue
        grid[y][x] = int(cell.get('id', 0))
        props = cell.get('props')
        if props:
            cell_props[(x, y)] = dict(props)

    for y in range(h):
        row = []
        for x in range(w):
            base = grid[y][x]
            props = cell_props.get((x, y))
            if props:
                prop_str = _props_to_string(props)
                row.append(f"{base}<{prop_str}>")
            else:
                row.append(str(base))
        lines.append(" ".join(row))

    params = data.get('params', {})
    if 'floor_color' in params:
        lines.append(f"[FLOOR_COLOR={params['floor_color']}]")
    if 'ceiling_color' in params:
        lines.append(f"[CEILING_COLOR={params['ceiling_color']}]")
    if 'ambient' in params:
        lines.append(f"[AMBIENT={params['ambient']}]")
    if 'fog_color' in params:
        lines.append(f"[FOG_COLOR={params['fog_color']}]")
    if 'fog_start' in params:
        lines.append(f"[FOG_START={params['fog_start']}]")
    if 'fog_end' in params:
        lines.append(f"[FOG_END={params['fog_end']}]")
    if 'use_lt' in params:
        lines.append(f"[USE_LT={1 if params['use_lt'] else 0}]")

    if 'spawn' in data:
        try:
            sx, sy = data['spawn']
            lines.append(f"[SPAWN={sx},{sy}]")
        except (TypeError, ValueError):
            pass

    if 'lights' in data and data['lights']:
        light_strs = []
        for L in data['lights']:
            try:
                c = L.get('color', [255, 255, 255])
                light_strs.append(
                    f"{L['x']},{L['y']},{L['intensity']},{L['radius']},"
                    f"{c[0]},{c[1]},{c[2]}"
                )
            except (KeyError, TypeError, IndexError):
                continue
        if light_strs:
            lines.append(f"[LIGHTS={';'.join(light_strs)}]")

    if 'bilboards' in data and data['bilboards']:
        bb_strs = []
        for b in data['bilboards']:
            try:
                bb_strs.append(f"{b['x']},{b['y']},{b['key']}")
            except (KeyError, TypeError):
                continue
        if bb_strs:
            lines.append(f"[BILBOARDS={';'.join(bb_strs)}]")

    return "\n".join(lines)


def _props_to_string(props):
    """Собирает тег: 'material:brick;alpha:0.5'."""
    parts = []
    for k, v in props.items():
        if isinstance(v, bool):
            v_str = "true" if v else "false"
        elif isinstance(v, float):
            v_str = f"{v:.4g}"
        else:
            v_str = str(v)
        parts.append(f"{k}:{v_str}")
    return ";".join(parts)


# ============================================================
# Экспорт из текстового формата в JSON (для редактора)
# ============================================================

def text_to_json(text, name="untitled"):
    """Разбирает текст карты и возвращает словарь JSON."""
    from .parser import MapParser

    parser = MapParser()
    layers = parser.parse_layers(text)
    collision = layers.get('collision', [])
    params_raw = layers.get('_params', {})

    h = len(collision)
    w = max((len(r) for r in collision), default=0)

    cells = []
    for y, row in enumerate(collision):
        for x, cell in enumerate(row):
            bid = int(cell.get('base_id', 0))
            props = cell.get('properties') or {}
            # Пустые клетки не сохраняем
            if bid == 0 and not props:
                continue
            # Очищаем служебные поля
            props = {k: v for k, v in props.items()
                     if k not in ('isvisible', 'open')}
            entry = {'x': x, 'y': y, 'id': bid}
            if props:
                entry['props'] = props
            cells.append(entry)

    data = {
        'format_version': 1,
        'name': name,
        'size': [w, h],
        'params': {},
        'lights': [],
        'bilboards': [],
        'cells': cells,
    }

    # Параметры карты
    p = data['params']
    for key in ('floor_color', 'ceiling_color', 'fog_color'):
        if key in params_raw:
            p[key] = params_raw[key]
    if 'ambient' in params_raw:
        try:
            p['ambient'] = float(params_raw['ambient'])
        except (TypeError, ValueError):
            pass
    if 'fog_start' in params_raw:
        p['fog_start'] = params_raw['fog_start']
    if 'fog_end' in params_raw:
        p['fog_end'] = params_raw['fog_end']
    if 'use_lt' in params_raw:
        p['use_lt'] = str(params_raw['use_lt']).lower() in ('true', '1', 'yes')
    if 'spawn' in params_raw:
        try:
            sx, sy = params_raw['spawn'].split(',')
            data['spawn'] = [float(sx), float(sy)]
        except (ValueError, AttributeError):
            pass

    # Свет
    lights_str = params_raw.get('lights', '')
    if lights_str:
        for light_str in lights_str.split(';'):
            parts = light_str.split(',')
            if len(parts) >= 4:
                try:
                    L = {
                        'x': float(parts[0]), 'y': float(parts[1]),
                        'intensity': float(parts[2]),
                        'radius': float(parts[3]),
                    }
                    if len(parts) >= 7:
                        L['color'] = [int(parts[4]), int(parts[5]), int(parts[6])]
                    data['lights'].append(L)
                except (ValueError, IndexError):
                    pass

    # Билборды
    bb_str = params_raw.get('bilboards', '')
    if bb_str:
        for b_str in bb_str.split(';'):
            parts = b_str.split(',')
            if len(parts) >= 3:
                try:
                    data['bilboards'].append({
                        'x': float(parts[0]),
                        'y': float(parts[1]),
                        'key': parts[2].strip(),
                    })
                except (ValueError, IndexError):
                    pass

    return data


def save_json_file(data, path):
    """Сохраняет словарь в .json."""
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def load_team_spawns(path):
    """Читает team_spawns из .json карты. Возвращает {'blue': [...], 'red': [...]}."""
    if not isinstance(path, str) or not os.path.isfile(path):
        return {}
    if not path.lower().endswith('.json'):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        ts = data.get('team_spawns', {}) or {}
        return {
            'blue': [list(p) for p in ts.get('blue', []) if len(p) == 2],
            'red':  [list(p) for p in ts.get('red',  []) if len(p) == 2],
        }
    except Exception as e:
        print(f"[map_loader] team_spawns load failed: {e}")
        return {}