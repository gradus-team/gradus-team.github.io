import re

class MapParser:
    def parse_layers(self, raw_data):
        try:
            raw_data = raw_data.lower()
        except Exception as e:
            print(f"Parse Layers (parser.py) ERROR: {e}")
        if isinstance(raw_data, str):
            lines = raw_data.strip().split('\n')
        else:
            lines = raw_data

        layers = {}
        current_layer = 'collision'
        current_data = []
        level_params = {}

        for line in lines:
            line = line.strip()
            if not line:
                continue

            if line.startswith('[') and line.endswith(']'):
                if current_data:
                    layers[current_layer] = self._parse_grid(current_data)
                    current_data = []

                section = line[1:-1]
                if '=' in section:
                    # Разбираем на подпараметры: KEY=v1,v2,SUBKEY=subval
                    parsed = self._parse_section_params(section)
                    for k, v in parsed.items():
                        level_params[k] = v
                else:
                    current_layer = section.lower()
            else:
                current_data.append(line)

        if current_data:
            layers[current_layer] = self._parse_grid(current_data)

        layers['_params'] = level_params
        return layers

    @staticmethod
    def _parse_section_params(section):
        """
        Разбирает 'KEY=val1,val2,SUBKEY=subval' в dict.
        Значения без '=' присоединяются к предыдущему ключу через ','.
        """
        result = {}
        parts = section.split(',')
        current_key = None
        current_vals = []

        for part in parts:
            part = part.strip()
            if '=' in part:
                if current_key is not None:
                    result[current_key] = ','.join(current_vals)
                k, v = part.split('=', 1)
                current_key = k.strip().lower()
                current_vals = [v.strip()]
            else:
                if current_key is not None:
                    current_vals.append(part)

        if current_key is not None:
            result[current_key] = ','.join(current_vals)

        return result

    def _parse_grid(self, grid_lines):
        # try: grid_lines = grid_lines.lower()
        # except Exception as e: print(f"Parse Grid (parser.py) ERROR: {e}")
        parsed = []
        for line in grid_lines:
            if isinstance(line, str):
                cells = line.split()
            else:
                try: cells = line.lower()
                except Exception as e: print(f"Parse Grid (parser.py) ERROR: {e}")
            row = []
            for cell in cells:
                cell = cell.strip()
                if not cell:
                    continue
                base_id, props = self._parse_cell(cell)
                row.append({'base_id': base_id, 'properties': props})
            parsed.append(row)
        return parsed

    def _parse_cell(self, cell_str):
        try:
            cell_str.lower()
            match = re.search(r'<([^>]+)>', cell_str)
        except Exception as e: print(f"Parse Cell (parser.py) ERROR: {e}")
        base_id_str = cell_str[:match.start()] if match else cell_str
        base_id = int(base_id_str) if base_id_str.isdigit() else 0

        props = {}
        if match:
            tag_content = match.group(1)
            # Сплитим по ; и , — оба разделителя равнозначны
            parts = re.split(r'[;,]\s*', tag_content)
            for part in parts:
                part = part.strip()
                if not part:
                    continue
                # Ищем ПЕРВЫЙ разделитель : или =
                sep_pos = -1
                for i, ch in enumerate(part):
                    if ch in (':', '='):
                        sep_pos = i
                        break
                if sep_pos == -1:
                    continue
                key = part[:sep_pos].strip().lower()
                value = part[sep_pos + 1:].strip()
                if value.lower() == 'true':
                    value = True
                elif value.lower() == 'false':
                    value = False
                else:
                    try:
                        value = float(value) if '.' in value else int(value)
                    except ValueError:
                        pass
                props[key] = value
        return base_id, props