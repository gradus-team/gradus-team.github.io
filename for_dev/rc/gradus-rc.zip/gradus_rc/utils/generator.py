"""
Процедурная генерация карт для Gradus RC.

Типы: labirint, random, corridors, city
Кастомные через register_generator('name', fn)
"""
from __future__ import annotations
import random

_generators = {}

def register_generator(name, fn):
    _generators[name.lower()] = fn

def get_generator(name):
    return _generators.get(name.lower())

def generate_map(gen_type, w, h, seed=None, params=None):
    if params is None:
        params = {}
    rng = random.Random(seed)
    gen_type = gen_type.lower()

    if gen_type in ('labirint', 'labyrinth', 'maze'):
        return _gen_labyrinth(w, h, rng)
    if gen_type in ('random', 'cave', 'caves'):
        return _gen_random(w, h, rng)
    if gen_type in ('corridors', 'rooms'):
        return _gen_corridors(w, h, rng)
    if gen_type in ('city',):
        return _gen_city(w, h, rng)

    custom = get_generator(gen_type)
    if custom:
        return custom(w, h, rng, params)
    print(f"[Gen] Unknown type '{gen_type}', fallback to random")
    return _gen_random(w, h, rng)

def _grid_to_map(grid):
    h = len(grid); w = len(grid[0]) if h else 0
    return [[{'base_id': grid[y][x], 'properties': {}} for x in range(w)]
            for y in range(h)]

def _make_border(grid, w, h):
    for x in range(w):
        grid[0][x] = 1; grid[h-1][x] = 1
    for y in range(h):
        grid[y][0] = 1; grid[y][w-1] = 1

def _gen_labyrinth(w, h, rng):
    w = w if w % 2 == 1 else w - 1
    h = h if h % 2 == 1 else h - 1
    if w < 7 or h < 7:
        return _gen_random(w, h, rng)
    grid = [[1] * w for _ in range(h)]
    stack = [(1, 1)]; grid[1][1] = 0; visited = {(1, 1)}
    dirs = [(2, 0), (-2, 0), (0, 2), (0, -2)]
    while stack:
        x, y = stack[-1]
        rng.shuffle(dirs)
        moved = False
        for dx, dy in dirs:
            nx, ny = x + dx, y + dy
            if (0 < nx < w - 1 and 0 < ny < h - 1
                    and (nx, ny) not in visited):
                grid[y + dy // 2][x + dx // 2] = 0
                grid[ny][nx] = 0
                visited.add((nx, ny)); stack.append((nx, ny))
                moved = True; break
        if not moved:
            stack.pop()
    return _grid_to_map(grid)

def _gen_random(w, h, rng):
    grid = [[1 if rng.random() < 0.45 else 0 for _ in range(w)]
            for _ in range(h)]
    _make_border(grid, w, h)
    for _ in range(5):
        new = [[0] * w for _ in range(h)]
        for y in range(h):
            for x in range(w):
                n = 0
                for dy in (-1, 0, 1):
                    for dx in (-1, 0, 1):
                        if dx == 0 and dy == 0: continue
                        nx, ny = x + dx, y + dy
                        n += (grid[ny][nx] if 0 <= nx < w and 0 <= ny < h else 1)
                if grid[y][x]:
                    new[y][x] = 1 if n >= 4 else 0
                else:
                    new[y][x] = 1 if n >= 5 else 0
        grid = new
    _make_border(grid, w, h)
    return _grid_to_map(grid)

def _gen_corridors(w, h, rng):
    grid = [[1] * w for _ in range(h)]
    n_rooms = max(6, (w * h) // 400)
    rooms = []
    attempts = 0
    while len(rooms) < n_rooms and attempts < n_rooms * 8:
        attempts += 1
        rw = rng.randint(4, 10); rh = rng.randint(4, 10)
        if rw + 4 >= w or rh + 4 >= h: continue
        rx = rng.randint(1, w - rw - 2); ry = rng.randint(1, h - rh - 2)
        ok = True
        for (ox, oy, ow, oh) in rooms:
            if not (rx + rw + 2 < ox or rx > ox + ow + 2
                    or ry + rh + 2 < oy or ry > oy + oh + 2):
                ok = False; break
        if not ok: continue
        rooms.append((rx, ry, rw, rh))
        for y in range(ry, ry + rh):
            for x in range(rx, rx + rw):
                grid[y][x] = 0
    if len(rooms) < 2:
        return _grid_to_map(grid)
    rng.shuffle(rooms)
    for i in range(len(rooms) - 1):
        x1, y1, rw1, rh1 = rooms[i]
        x2, y2, rw2, rh2 = rooms[i + 1]
        cx1, cy1 = x1 + rw1 // 2, y1 + rh1 // 2
        cx2, cy2 = x2 + rw2 // 2, y2 + rh2 // 2
        if rng.random() < 0.5:
            for x in range(min(cx1, cx2), max(cx1, cx2) + 1):
                grid[cy1][x] = 0
            for y in range(min(cy1, cy2), max(cy1, cy2) + 1):
                grid[y][cx2] = 0
        else:
            for y in range(min(cy1, cy2), max(cy1, cy2) + 1):
                grid[y][cx1] = 0
            for x in range(min(cx1, cx2), max(cx1, cx2) + 1):
                grid[cy2][x] = 0
    return _grid_to_map(grid)

def _gen_city(w, h, rng):
    grid = [[0] * w for _ in range(h)]
    block_w = rng.randint(5, 9); block_h = rng.randint(5, 9)
    street_w = rng.randint(2, 3)
    for by in range(1, h - 2, block_h + street_w):
        for bx in range(1, w - 2, block_w + street_w):
            ex = min(bx + block_w, w - 2); ey = min(by + block_h, h - 2)
            if ex - bx < 3 or ey - by < 3: continue
            for y in range(by, ey):
                for x in range(bx, ex):
                    grid[y][x] = 1
            for _ in range(rng.randint(1, 2)):
                if rng.random() < 0.5:
                    grid[rng.randint(by + 1, ey - 2)][bx] = 0
                else:
                    grid[rng.randint(by + 1, ey - 2)][ex - 1] = 0
    _make_border(grid, w, h)
    return _grid_to_map(grid)