"""
Компактный формат чанков (регионов) карты.

- Один чанк = прямоугольник клеток с offset.
- Разреженный формат: сохраняются только непустые клетки (сжатие в 10-100x).
- Совместим с любым map_data (list[list[dict]]).
"""
from __future__ import annotations
import os
import json


def _cell_to_dict(cell):
    return {
        'base_id': int(cell.get('base_id', 0)),
        'properties': dict(cell.get('properties', {}) or {}),
    }


def _empty_cell():
    return {'base_id': 0, 'properties': {}}


def save_region(map_data, x1, y1, x2, y2, path, sparse=True):
    """Сохранить прямоугольный регион карты в файл. Возвращает path."""
    x1, x2 = sorted((int(x1), int(x2)))
    y1, y2 = sorted((int(y1), int(y2)))
    w = x2 - x1 + 1
    h = y2 - y1 + 1

    if sparse:
        cells = {}
        for ty in range(y1, y2 + 1):
            if ty < 0 or ty >= len(map_data):
                continue
            row = map_data[ty]
            for tx in range(x1, x2 + 1):
                if tx < 0 or tx >= len(row):
                    continue
                cell = row[tx]
                bid = int(cell.get('base_id', 0))
                props = cell.get('properties', {}) or {}
                if bid == 0 and not props:
                    continue
                cells[f"{tx - x1},{ty - y1}"] = _cell_to_dict(cell)
        payload = {
            'version': 1,
            'offset_x': x1, 'offset_y': y1,
            'width': w, 'height': h,
            'sparse': True,
            'cells': cells,
        }
    else:
        grid = []
        for ty in range(y1, y2 + 1):
            row_out = []
            if 0 <= ty < len(map_data):
                row = map_data[ty]
                for tx in range(x1, x2 + 1):
                    if 0 <= tx < len(row):
                        row_out.append(_cell_to_dict(row[tx]))
                    else:
                        row_out.append(_empty_cell())
            else:
                row_out = [_empty_cell() for _ in range(w)]
            grid.append(row_out)
        payload = {
            'version': 1,
            'offset_x': x1, 'offset_y': y1,
            'width': w, 'height': h,
            'sparse': False,
            'cells': grid,
        }

    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False, default=str)
    return path


def load_chunk(path):
    """Загрузить чанк из файла. Возвращает dict."""
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def paste_region(map_data, region, offset_x=None, offset_y=None):
    """Вставить чанк в map_data. Возвращает (map_data, w, h)."""
    ox = offset_x if offset_x is not None else region['offset_x']
    oy = offset_y if offset_y is not None else region['offset_y']
    w = region['width']
    h = region['height']

    # Расширяем число строк
    while len(map_data) < oy + h:
        w0 = len(map_data[0]) if map_data else w
        map_data.append([_empty_cell() for _ in range(w0)])

    # Расширяем каждую нужную строку
    for ty in range(oy, oy + h):
        row = map_data[ty]
        while len(row) <= ox + w - 1:
            row.append(_empty_cell())

    if region.get('sparse'):
        for key, cell in region['cells'].items():
            cx_s, cy_s = key.split(',')
            cx, cy = int(cx_s), int(cy_s)
            map_data[oy + cy][ox + cx] = {
                'base_id': int(cell.get('base_id', 0)),
                'properties': dict(cell.get('properties', {}) or {}),
            }
    else:
        cells = region['cells']
        for cy in range(h):
            if cy >= len(cells):
                continue
            crow = cells[cy]
            for cx in range(w):
                if cx >= len(crow):
                    continue
                cell = crow[cx]
                map_data[oy + cy][ox + cx] = {
                    'base_id': int(cell.get('base_id', 0)),
                    'properties': dict(cell.get('properties', {}) or {}),
                }

    # Финальная нормализация — все строки одной длины
    max_w = max(len(r) for r in map_data) if map_data else 0
    for row in map_data:
        while len(row) < max_w:
            row.append(_empty_cell())

    return map_data, max_w, len(map_data)


def list_chunks(directory):
    """Список файлов чанков в папке."""
    if not os.path.isdir(directory):
        return []
    out = []
    for f in sorted(os.listdir(directory)):
        if f.endswith('.chunk.json') or f.endswith('.chunk'):
            out.append(os.path.join(directory, f))
    return out


def build_map_from_chunks(directory, w=None, h=None):
    """
    Собрать карту из всех чанков в папке.
    w/h — минимальные размеры (если нужно зарезервировать место).
    """
    paths = list_chunks(directory)
    if not paths:
        return None, 0, 0

    if w is None:
        w = 0
    if h is None:
        h = 0
    regions = [load_chunk(p) for p in paths]

    for r in regions:
        w = max(w, r['offset_x'] + r['width'])
        h = max(h, r['offset_y'] + r['height'])

    map_data = [[_empty_cell() for _ in range(w)] for _ in range(h)]
    for r in regions:
        paste_region(map_data, r)
    return map_data, w, h