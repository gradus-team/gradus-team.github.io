"""
Всплывающие карточки о разблокированных достижениях.
Обычные: золотая карточка.
Скрытые: радужная карточка + конфетти на весь экран.
"""
import pygame
import random


class AchievementToast:
    def __init__(self, achievement, duration=5.0):
        self.achievement = achievement
        self.duration = duration
        self.age = 0.0
        self.alive = True
        self.is_hidden = bool(getattr(achievement, 'hidden', False))
        self.confetti = []
        if self.is_hidden:
            self._spawn_confetti()

    def _spawn_confetti(self):
        for _ in range(70):
            self.confetti.append({
                'x': random.uniform(0.0, 1.0),
                'y': random.uniform(-0.3, 0.0),
                'vx': random.uniform(-0.15, 0.15),
                'vy': random.uniform(0.25, 0.55),
                'size': random.randint(6, 14),
                'rot': random.uniform(0, 360),
                'rot_speed': random.uniform(-360, 360),
                'color': random.choice([
                    (255, 90, 90), (255, 170, 60), (255, 240, 90),
                    (120, 230, 130), (100, 190, 255), (190, 120, 255),
                ]),
            })

    def update(self, dt):
        self.age += dt
        if self.age >= self.duration:
            self.alive = False
        for c in self.confetti:
            c['x'] += c['vx'] * dt
            c['y'] += c['vy'] * dt
            c['rot'] += c['rot_speed'] * dt

    @property
    def alpha(self):
        fade_in = 0.3
        fade_out = 0.6
        if self.age < fade_in:
            return self.age / fade_in
        if self.age > self.duration - fade_out:
            return max(0.0, (self.duration - self.age) / fade_out)
        return 1.0

    @property
    def slide_offset(self):
        t = min(1.0, self.age / 0.4)
        t = 1.0 - (1.0 - t) ** 3
        return int(80 * (1.0 - t))


class AchievementToastManager:
    CARD_W = 420
    CARD_H = 112
    MARGIN = 20
    SPACING = 10
    MAX_VISIBLE = 4
    DURATION = 5.0

    def __init__(self, engine):
        self.engine = engine
        self.queue = []
        self.active = []

        self.font_header = pygame.font.SysFont('Arial', 13, bold=True)
        self.font_title = pygame.font.SysFont('Arial', 22, bold=True)
        self.font_desc = pygame.font.SysFont('Arial', 15, bold=True)

    def push(self, achievement):
        self.queue.append(achievement)

    def update(self, dt):
        for t in self.active:
            t.update(dt)
        self.active = [t for t in self.active if t.alive]

        while self.queue and len(self.active) < self.MAX_VISIBLE:
            ach = self.queue.pop(0)
            self.active.append(AchievementToast(ach, duration=self.DURATION))

    def draw(self, screen):
        if not self.active:
            return

        # Конфетти снизу — только для скрытых
        for toast in self.active:
            if toast.is_hidden:
                self._draw_confetti(screen, toast)

        # Карточки справа-сверху
        sw = screen.get_width()
        x_base = sw - self.CARD_W - self.MARGIN
        y = self.MARGIN
        for toast in self.active:
            self._draw_card(screen, toast, x_base + toast.slide_offset, y)
            y += self.CARD_H + self.SPACING

    def _draw_confetti(self, screen, toast):
        sw, sh = screen.get_size()
        alpha = toast.alpha
        for c in toast.confetti:
            x = int(c['x'] * sw)
            y = int(c['y'] * sh)
            if not (-30 < x < sw + 30 and -30 < y < sh + 30):
                continue
            size = c['size']
            surf = pygame.Surface((size, size), pygame.SRCALPHA)
            surf.fill((*c['color'], int(255 * alpha)))
            rotated = pygame.transform.rotate(surf, c['rot'])
            screen.blit(rotated, (x - rotated.get_width() // 2,
                                   y - rotated.get_height() // 2))

    def _draw_card(self, screen, toast, x, y):
        ach = toast.achievement
        w, h = self.CARD_W, self.CARD_H
        alpha = toast.alpha
        card = pygame.Surface((w, h), pygame.SRCALPHA)

        is_hidden = toast.is_hidden

        if is_hidden:
            bg = pygame.Surface((w - 4, h - 4), pygame.SRCALPHA)
            bg.fill((28, 22, 48, 240))
            card.blit(bg, (2, 2))
            self._draw_rainbow_frame(card, w, h, toast.age)
            header_text_col = (25, 25, 60)
            title_col = (255, 250, 255)
            desc_col = (220, 215, 255)
        else:
            pygame.draw.rect(card, (16, 20, 30), (0, 0, w, h), border_radius=12)
            pygame.draw.rect(card, (220, 180, 80), (0, 0, w, h), 2, border_radius=12)
            header_text_col = (35, 25, 8)
            title_col = (255, 240, 200)
            desc_col = (190, 200, 215)

        header_h = 26
        header_rect = pygame.Rect(2, 2, w - 4, header_h - 2)

        if is_hidden:
            self._draw_rainbow_header(card, header_rect, toast.age)
        else:
            pygame.draw.rect(card, (220, 180, 80), header_rect,
                             border_top_left_radius=10,
                             border_top_right_radius=10)

        header_txt = ("★ СКРЫТОЕ ДОСТИЖЕНИЕ РАЗБЛОКИРОВАНО ★" if is_hidden
                      else "РАЗБЛОКИРОВАНО НОВОЕ ДОСТИЖЕНИЕ")
        header_text = self.font_header.render(header_txt, True, header_text_col)
        card.blit(header_text,
                  (w // 2 - header_text.get_width() // 2,
                   2 + (header_h - 2 - header_text.get_height()) // 2))

        icon_size = 56
        icon_x = 16
        icon_y = header_h + (h - header_h - icon_size) // 2

        icon_drawn = False
        icon_path = getattr(ach, 'icon', None)
        if icon_path:
            try:
                img = pygame.image.load(icon_path).convert_alpha()
                img = pygame.transform.scale(img, (icon_size, icon_size))
                card.blit(img, (icon_x, icon_y))
                icon_drawn = True
            except Exception:
                pass

        if not icon_drawn:
            if is_hidden:
                for i in range(icon_size):
                    col = self._hsv_to_rgb(
                        ((toast.age * 60 + i * 4) % 360) / 360.0, 0.75, 1.0)
                    pygame.draw.line(card, col,
                                     (icon_x, icon_y + i),
                                     (icon_x + icon_size, icon_y + i))
                pygame.draw.rect(card, (255, 255, 255),
                                 (icon_x, icon_y, icon_size, icon_size), 2,
                                 border_radius=8)
                sym = "★"
                sym_col = (255, 255, 255)
            else:
                pygame.draw.rect(card, (220, 180, 80),
                                 (icon_x, icon_y, icon_size, icon_size),
                                 border_radius=8)
                sym = "✓"
                sym_col = (35, 25, 8)
            check = pygame.font.SysFont('Arial', 34, bold=True).render(sym, True, sym_col)
            card.blit(check,
                      (icon_x + icon_size // 2 - check.get_width() // 2,
                       icon_y + icon_size // 2 - check.get_height() // 2))

        text_x = icon_x + icon_size + 14
        text_max_w = w - text_x - 16

        title_text = getattr(ach, 'title', 'Достижение')
        title_surf = self.font_title.render(title_text, True, title_col)
        if title_surf.get_width() > text_max_w:
            title_surf = title_surf.subsurface(
                (0, 0, text_max_w, title_surf.get_height()))

        desc_text = getattr(ach, 'description', '')
        desc_surf = self.font_desc.render(desc_text, True, desc_col)
        if desc_surf.get_width() > text_max_w:
            desc_surf = desc_surf.subsurface(
                (0, 0, text_max_w, desc_surf.get_height()))

        text_area_top = header_h + 6
        text_area_h = h - text_area_top - 12
        block_h = title_surf.get_height() + 4 + desc_surf.get_height()
        ty = text_area_top + (text_area_h - block_h) // 2

        card.blit(title_surf, (text_x, ty))
        card.blit(desc_surf, (text_x, ty + title_surf.get_height() + 4))

        if alpha < 1.0:
            card.set_alpha(int(255 * max(0.0, min(1.0, alpha))))

        screen.blit(card, (x, y))

    def _draw_rainbow_frame(self, card, w, h, age):
        thickness = 3
        perimeter = 2 * (w + h)
        t_offset = age * 0.3
        for i in range(0, perimeter, thickness):
            t = (i / perimeter + t_offset) % 1.0
            col = self._hsv_to_rgb(t, 0.85, 1.0)
            if i < w:
                x, y = i, 0
            elif i < w + h:
                x, y = w - thickness, i - w
            elif i < 2 * w + h:
                x, y = (2 * w + h - i - thickness), h - thickness
            else:
                x, y = 0, (2 * h + 2 * w - i - thickness)
            pygame.draw.rect(card, col, (x, y, thickness, thickness))

    def _draw_rainbow_header(self, card, rect, age):
        for x in range(rect.width):
            t = (x / max(1, rect.width) + age * 0.2) % 1.0
            col = self._hsv_to_rgb(t, 0.55, 1.0)
            pygame.draw.line(card, col,
                             (rect.x + x, rect.y),
                             (rect.x + x, rect.y + rect.height))

    @staticmethod
    def _hsv_to_rgb(h, s, v):
        if s == 0:
            c = int(v * 255)
            return (c, c, c)
        h6 = h * 6.0
        i = int(h6)
        f = h6 - i
        p = v * (1 - s)
        q = v * (1 - s * f)
        t = v * (1 - s * (1 - f))
        i = i % 6
        if i == 0:   r, g, b = v, t, p
        elif i == 1: r, g, b = q, v, p
        elif i == 2: r, g, b = p, v, t
        elif i == 3: r, g, b = p, q, v
        elif i == 4: r, g, b = t, p, v
        else:        r, g, b = v, p, q
        return (int(r * 255), int(g * 255), int(b * 255))