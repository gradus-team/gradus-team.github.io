"""
Универсальная система тостов.
Типы:
  - 'achievement'         — золотая карточка
  - 'achievement_hidden'  — радужная + конфетти
  - 'info'                — компактная (скриншоты, запись, события)
"""
import pygame
import random


class Toast:
    def __init__(self, kind, title='', description='',
                 icon=None, color=(80, 180, 255),
                 duration=5.0):
        self.kind = kind
        self.title = title
        self.description = description
        self.icon = icon
        self.color = color
        self.duration = duration
        self.age = 0.0
        self.alive = True
        self.confetti = []
        if kind == 'achievement_hidden':
            self._spawn_confetti()

    def _spawn_confetti(self):
        for _ in range(70):
            self.confetti.append({
                'x': random.uniform(0, 1), 'y': random.uniform(-0.3, 0),
                'vx': random.uniform(-0.15, 0.15),
                'vy': random.uniform(0.25, 0.55),
                'size': random.randint(6, 14),
                'rot': random.uniform(0, 360),
                'rot_speed': random.uniform(-360, 360),
                'color': random.choice([
                    (255, 90, 90), (255, 170, 60), (255, 240, 90),
                    (120, 230, 130), (100, 190, 255), (190, 120, 255)]),
            })

    def update(self, dt):
        self.age += dt
        if self.age >= self.duration:
            self.alive = False
        for c in self.confetti:
            c['x'] += c['vx'] * dt
            c['y'] += c['vy'] * dt
            c['rot'] += c['rot_speed'] * dt

    @property
    def alpha(self):
        fade_in, fade_out = 0.3, 0.6
        if self.age < fade_in:
            return self.age / fade_in
        if self.age > self.duration - fade_out:
            return max(0.0, (self.duration - self.age) / fade_out)
        return 1.0

    @property
    def slide(self):
        t = min(1.0, self.age / 0.4)
        t = 1.0 - (1.0 - t) ** 3
        return int(80 * (1.0 - t))


class ToastManager:
    CARD_W = 420
    INFO_W = 320
    CARD_H = 112
    INFO_H = 76
    MARGIN = 20
    SPACING = 10
    MAX_VISIBLE = 5

    def __init__(self):
        self.queue = []
        self.active = []
        self.font_header = pygame.font.SysFont('Arial', 13, bold=True)
        self.font_title = pygame.font.SysFont('Arial', 22, bold=True)
        self.font_desc = pygame.font.SysFont('Arial', 15, bold=True)

    # ---------- PUBLIC ----------

    def push_achievement(self, ach):
        """ach — объект с .title, .description, .icon, .hidden."""
        kind = 'achievement_hidden' if getattr(ach, 'hidden', False) else 'achievement'
        t = Toast(kind=kind,
                  title=getattr(ach, 'title', 'Достижение'),
                  description=getattr(ach, 'description', ''),
                  icon=getattr(ach, 'icon', None),
                  duration=5.0)
        self.queue.append(t)

    def push_info(self, title, description='', icon=None,
                  color=(80, 180, 255), duration=3.0):
        t = Toast(kind='info', title=title, description=description,
                  icon=icon, color=color, duration=duration)
        self.queue.append(t)

    def update(self, dt):
        for t in self.active:
            t.update(dt)
        self.active = [t for t in self.active if t.alive]
        while self.queue and len(self.active) < self.MAX_VISIBLE:
            self.active.append(self.queue.pop(0))

    def draw(self, screen):
        if not self.active:
            return
        sw = screen.get_width()
        y = self.MARGIN
        for t in self.active:
            if t.kind == 'info':
                w = self.INFO_W
                h = self.INFO_H
            else:
                w = self.CARD_W
                h = self.CARD_H
            x = sw - w - self.MARGIN + t.slide
            self._draw_card(screen, t, x, y, w, h)
            y += h + self.SPACING

    # ---------- DRAW ----------

    def _draw_card(self, screen, t, x, y, w, h):
        # Конфетти для скрытых
        if t.kind == 'achievement_hidden':
            self._draw_confetti(screen, t)

        card = pygame.Surface((w, h), pygame.SRCALPHA)

        if t.kind == 'info':
            self._draw_info(card, t, w, h)
        elif t.kind == 'achievement_hidden':
            self._draw_ach_hidden(card, t, w, h)
        else:
            self._draw_ach_normal(card, t, w, h)

        alpha = t.alpha
        if alpha < 1.0:
            card.set_alpha(int(255 * max(0.0, min(1.0, alpha))))
        screen.blit(card, (x, y))

    def _draw_info(self, card, t, w, h):
        pygame.draw.rect(card, (16, 22, 32), (0, 0, w, h), border_radius=10)
        pygame.draw.rect(card, t.color, (0, 0, w, h), 2, border_radius=10)
        # Полоска слева
        pygame.draw.rect(card, t.color, (0, 0, 4, h),
                         border_top_left_radius=10,
                         border_bottom_left_radius=10)

        icon_size = 48
        icon_x = 14
        icon_y = (h - icon_size) // 2
        if t.icon:
            try:
                img = pygame.image.load(t.icon).convert_alpha()
                img = pygame.transform.scale(img, (icon_size, icon_size))
                card.blit(img, (icon_x, icon_y))
            except Exception:
                pygame.draw.rect(card, t.color,
                                 (icon_x, icon_y, icon_size, icon_size),
                                 border_radius=6)
        else:
            pygame.draw.rect(card, t.color,
                             (icon_x, icon_y, icon_size, icon_size),
                             border_radius=6)
            sym = pygame.font.SysFont('Arial', 26, bold=True).render(
                "i", True, (20, 20, 30))
            card.blit(sym, (icon_x + icon_size // 2 - sym.get_width() // 2,
                            icon_y + icon_size // 2 - sym.get_height() // 2))

        tx = icon_x + icon_size + 12
        title = self.font_title.render(t.title, True, (240, 245, 255))
        card.blit(title, (tx, 14))
        if t.description:
            desc = self.font_desc.render(t.description, True, (180, 195, 215))
            card.blit(desc, (tx, 42))

    def _draw_ach_normal(self, card, t, w, h):
        pygame.draw.rect(card, (16, 20, 30), (0, 0, w, h), border_radius=12)
        pygame.draw.rect(card, (220, 180, 80), (0, 0, w, h), 2, border_radius=12)
        header_h = 26
        pygame.draw.rect(card, (220, 180, 80),
                         (2, 2, w - 4, header_h - 2),
                         border_top_left_radius=10,
                         border_top_right_radius=10)
        hdr = self.font_header.render(
            "РАЗБЛОКИРОВАНО НОВОЕ ДОСТИЖЕНИЕ", True, (35, 25, 8))
        card.blit(hdr, (w // 2 - hdr.get_width() // 2, 6))

        self._draw_icon(card, t, 16, header_h + (h - header_h - 56) // 2,
                        56, (220, 180, 80), (35, 25, 8))
        self._draw_texts(card, t, 16 + 56 + 14, header_h + 6, w - 16 - 14,
                         (255, 240, 200), (190, 200, 215))

    def _draw_ach_hidden(self, card, t, w, h):
        pygame.draw.rect(card, (28, 22, 48), (0, 0, w, h), border_radius=12)
        self._draw_rainbow_frame(card, w, h, t.age)
        header_h = 26
        self._draw_rainbow_header(card, pygame.Rect(2, 2, w - 4, header_h - 2),
                                  t.age)
        hdr = self.font_header.render(
            "★ СКРЫТОЕ ДОСТИЖЕНИЕ РАЗБЛОКИРОВАНО ★", True, (25, 25, 60))
        card.blit(hdr, (w // 2 - hdr.get_width() // 2, 6))

        self._draw_icon(card, t, 16, header_h + (h - header_h - 56) // 2,
                        56, (255, 255, 255), (25, 25, 60), rainbow=True)
        self._draw_texts(card, t, 16 + 56 + 14, header_h + 6, w - 16 - 14,
                         (255, 250, 255), (220, 215, 255))

    def _draw_icon(self, card, t, x, y, size, frame_col, sym_col,
                   rainbow=False):
        if t.icon:
            try:
                img = pygame.image.load(t.icon).convert_alpha()
                img = pygame.transform.scale(img, (size, size))
                card.blit(img, (x, y))
                return
            except Exception:
                pass
        if rainbow:
            for i in range(size):
                c = self._hsv(((t.age * 60 + i * 4) % 360) / 360.0, 0.75, 1.0)
                pygame.draw.line(card, c, (x, y + i), (x + size, y + i))
            pygame.draw.rect(card, (255, 255, 255),
                             (x, y, size, size), 2, border_radius=8)
            sym = "★"
        else:
            pygame.draw.rect(card, frame_col, (x, y, size, size), border_radius=8)
            sym = "✓"
        s = pygame.font.SysFont('Arial', 34, bold=True).render(sym, True, sym_col)
        card.blit(s, (x + size // 2 - s.get_width() // 2,
                      y + size // 2 - s.get_height() // 2))

    def _draw_texts(self, card, t, tx, top, max_w, title_col, desc_col):
        title = self.font_title.render(t.title, True, title_col)
        if title.get_width() > max_w:
            title = title.subsurface((0, 0, max_w, title.get_height()))
        desc = self.font_desc.render(t.description, True, desc_col)
        if desc.get_width() > max_w:
            desc = desc.subsurface((0, 0, max_w, desc.get_height()))
        block = title.get_height() + 4 + desc.get_height()
        ty = top + (100 - block) // 2 + 6
        card.blit(title, (tx, ty))
        card.blit(desc, (tx, ty + title.get_height() + 4))

    def _draw_confetti(self, screen, t):
        sw, sh = screen.get_size()
        a = t.alpha
        for c in t.confetti:
            x, y = int(c['x'] * sw), int(c['y'] * sh)
            if not (-30 < x < sw + 30 and -30 < y < sh + 30):
                continue
            s = c['size']
            surf = pygame.Surface((s, s), pygame.SRCALPHA)
            surf.fill((*c['color'], int(255 * a)))
            rot = pygame.transform.rotate(surf, c['rot'])
            screen.blit(rot, (x - rot.get_width() // 2,
                              y - rot.get_height() // 2))

    def _draw_rainbow_frame(self, card, w, h, age):
        th = 3
        per = 2 * (w + h)
        off = age * 0.3
        for i in range(0, per, th):
            t = (i / per + off) % 1.0
            c = self._hsv(t, 0.85, 1.0)
            if i < w:
                x, y = i, 0
            elif i < w + h:
                x, y = w - th, i - w
            elif i < 2 * w + h:
                x, y = (2 * w + h - i - th), h - th
            else:
                x, y = 0, (2 * h + 2 * w - i - th)
            pygame.draw.rect(card, c, (x, y, th, th))

    def _draw_rainbow_header(self, card, rect, age):
        for x in range(rect.width):
            t = (x / max(1, rect.width) + age * 0.2) % 1.0
            c = self._hsv(t, 0.55, 1.0)
            pygame.draw.line(card, c,
                             (rect.x + x, rect.y),
                             (rect.x + x, rect.y + rect.height))

    @staticmethod
    def _hsv(h, s, v):
        if s == 0:
            c = int(v * 255)
            return (c, c, c)
        h6 = h * 6.0
        i = int(h6)
        f = h6 - i
        p, q, t = v * (1 - s), v * (1 - s * f), v * (1 - s * (1 - f))
        i %= 6
        if i == 0: r, g, b = v, t, p
        elif i == 1: r, g, b = q, v, p
        elif i == 2: r, g, b = p, v, t
        elif i == 3: r, g, b = p, q, v
        elif i == 4: r, g, b = t, p, v
        else: r, g, b = v, p, q
        return (int(r * 255), int(g * 255), int(b * 255))