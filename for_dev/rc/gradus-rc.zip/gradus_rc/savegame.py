"""
Сохранения и загрузки игры. Всё в JSON — карта, игрок, враги,
двери, ключи, оружие, достижения, RTE, время.

Использование:
    engine.save_to_file('saves/quicksave.json')
    engine.load_from_file('saves/quicksave.json')

Или через MicroAPI:
    api.save_game('saves/my_save.json')
    api.load_game('saves/my_save.json')
"""
from __future__ import annotations

import os
import json
import datetime


SAVE_VERSION = 1


# =========================================================================
# map_data → текстовая карта (обратная конвертация)
# =========================================================================

def _cell_to_tag(cell):
    """
    Одна клетка → строка '<base_id><k:v;k:v>'.
    Тег 'enemy' вырезается — враги хранятся отдельно.
    Тег 'open' тоже (состояние двери хранится отдельно).
    """
    bid = cell.get('base_id', 0)
    props = cell.get('properties', {}) or {}
    props_clean = {k: v for k, v in props.items()
                   if k not in ('enemy', 'open')}
    if not props_clean:
        return str(bid)
    parts = []
    for k, v in props_clean.items():
        if isinstance(v, bool):
            v = 'true' if v else 'false'
        parts.append(f"{k}:{v}")
    return f"{bid}<{';'.join(parts)}>"


def map_data_to_string(map_data):
    """[[{cell}]] → текстовая карта."""
    if not map_data:
        return ""
    return '\n'.join(
        ' '.join(_cell_to_tag(c) for c in row)
        for row in map_data
    )


# =========================================================================
# Сериализация сущностей
# =========================================================================

def _serialize_enemy(e):
    return {
        'x': float(e.x),
        'y': float(e.y),
        'hp': float(getattr(e, 'hp', 100)),
        'max_hp': float(getattr(e, 'max_hp', 100)),
        'type': getattr(e, 'type', 'static'),
        'aim': float(getattr(e, 'aim', 10)),
        'speed': float(getattr(e, 'speed', 50)),
        'shoot_delay': float(getattr(e, 'shoot_delay', 1.0)),
        'shoot_intensity': float(getattr(e, 'shoot_intensity', 0)),
        'attack_type': getattr(e, 'attack_type', 'ranged'),
        'detect_radius': float(getattr(e, 'detect_radius', 5)),
        'attack_radius': float(getattr(e, 'attack_radius', 3)),
        'key': getattr(e, 'key', None),
        'alive': bool(getattr(e, 'alive', True)),
    }


def _serialize_bullet(b):
    owner = getattr(b, 'owner', None)
    owner_str = 'player' if owner == 'player' else (
        'enemy' if owner not in (None, 'player') else 'script')
    return {
        'x': float(b.x), 'y': float(b.y),
        'angle': float(b.angle),
        'damage': float(b.damage),
        'speed': float(b.speed),
        'owner': owner_str,
        'explosive': bool(getattr(b, 'explosive', False)),
        'explosion_radius': float(getattr(b, 'explosion_radius', 0)),
        'explosion_damage': float(getattr(b, 'explosion_damage', 0)),
    }


# =========================================================================
# SAVE
# =========================================================================

def save_game(engine, path):
    """Сохранить игру. Возвращает path."""

    # Уровни: все как строки + текущий с модификациями
    all_levels = list(engine.levels) if engine.levels else []
    current_index = engine.current_level

    # Текущая карта — модифицированная (разбитые стены, открытые двери)
    current_text = map_data_to_string(engine.map_data)

    # Параметры уровня
    light_sources = []
    for L in engine.light_tracer.light_sources:
        col = getattr(L, 'color', (255, 255, 255))
        light_sources.append([
            float(L.x), float(L.y),
            float(getattr(L, 'intensity', 1.0)),
            float(getattr(L, 'radius', 200)),
            int(col[0]), int(col[1]), int(col[2]),
        ])

    data = {
        'version': SAVE_VERSION,
        'timestamp': datetime.datetime.now().isoformat(timespec='seconds'),
        'level': {
            'index': current_index,
            'all_levels': all_levels,
            'current_text': current_text,
            'params': {
                'spawn': engine.spawn,
                'floor_color': engine.floor_color,
                'ceiling_color': engine.ceiling_color,
                'ambient': engine.ambient,
                'fog_enabled': engine.fog_enabled,
                'fog_color': list(engine.fog_color) if engine.fog_color else None,
                'fog_start': engine.fog_start,
                'fog_end': engine.fog_end,
                'lights': light_sources,
            },
        },
        'player': {
            'x': float(engine.player.pos.x),
            'y': float(engine.player.pos.y),
            'angle': float(engine.player.angle),
            'pitch': float(getattr(engine.player, 'pitch', 0.0)),
            'hp': float(engine.player.hp),
            'max_hp': float(engine.player.max_hp),
            'vel_x': float(engine.player.vel.x),
            'vel_y': float(engine.player.vel.y),
            'speed': float(engine.player.speed),
            'rot_speed': float(engine.player.rot_speed),
            'alive': bool(engine.player.alive),
        },
        'enemies': [_serialize_enemy(e) for e in engine.enemies],
        'bullets': [_serialize_bullet(b) for b in engine.bullets],
        'doors': {
            did: {'open': bool(d.get('open', False))}
            for did, d in engine.doors.items()
        },
        'keys': {
            kid: {'collected': bool(k.get('collected', False))}
            for kid, k in engine.keys.items()
        },
        'guns': {
            k: {'ammo': int(g.ammo), 'max_ammo': int(g.max_ammo)}
            for k, g in engine.gun_manager.guns.items()
        },
        'current_gun': engine.gun_manager.current_gun_key,
        'achievements': engine.achievements.to_dict(),
        'world': {
            'elapsed_time': float(engine._elapsed_time),
            'frame_counter': int(engine._frame_counter),
            'time_scale': float(engine.time_scale),
        },
        'rt': {
            'enabled': bool(engine.rt_enabled),
            'quality': engine.rt_quality,
            'max_lights': int(engine.rt_max_lights),
            'reflections': bool(engine.rt_reflections),
        },
    }

    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    size_kb = os.path.getsize(path) // 1024
    print(f"[Save] Saved to {path} ({size_kb} KB)")
    return path


# =========================================================================
# LOAD
# =========================================================================

def _build_level_string(current_text, params):
    """Собирает единую строку уровня с параметрами."""
    sections = ['[COLLISION]', current_text, '']

    if params.get('spawn'):
        sections.append(f"[SPAWN={params['spawn']}]")
    if params.get('floor_color'):
        sections.append(f"[FLOOR_COLOR={params['floor_color']}]")
    if params.get('ceiling_color'):
        sections.append(f"[CEILING_COLOR={params['ceiling_color']}]")
    if params.get('ambient') is not None:
        sections.append(f"[AMBIENT={params['ambient']}]")

    if params.get('fog_enabled') and params.get('fog_color'):
        c = params['fog_color']
        try:
            r, g, b = int(c[0]), int(c[1]), int(c[2])
            sections.append(f"[FOG_COLOR={r:02X}{g:02X}{b:02X}]")
        except Exception:
            pass
        sections.append(f"[FOG_START={params.get('fog_start', 400)}]")
        sections.append(f"[FOG_END={params.get('fog_end', 1200)}]")

    lights = params.get('lights') or []
    if lights:
        light_str = ';'.join(
            ','.join(str(x) for x in L) for L in lights)
        sections.append(f"[LIGHTS={light_str}]")

    return '\n'.join(sections)


def load_game(engine, path):
    """Загрузить игру. Возвращает True при успехе."""
    if not os.path.isfile(path):
        print(f"[Load] File not found: {path}")
        return False

    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    version = data.get('version', 0)
    if version != SAVE_VERSION:
        print(f"[Load] Warning: save version {version} != {SAVE_VERSION}")

    lvl = data['level']
    params = lvl.get('params', {})
    current_text = lvl['current_text']
    all_levels = lvl.get('all_levels', [])
    current_index = int(lvl['index'])

    # Собираем уровень с параметрами
    current_level_str = _build_level_string(current_text, params)

    # Собираем список уровней
    if all_levels:
        levels = list(all_levels)
        if current_index < len(levels):
            levels[current_index] = current_level_str
        else:
            levels.append(current_level_str)
            current_index = len(levels) - 1
    else:
        levels = [current_level_str]
        current_index = 0

    engine.levels = levels
    engine.current_level = current_index

    # Сброс состояния перед загрузкой
    engine.enemies.clear()
    engine.bullets.clear()
    engine.doors.clear()
    engine.keys.clear()

    # Загружаем уровень
    engine.load_level(engine.current_level)

    # ----- Игрок -----
    p = data.get('player', {})
    engine.player.pos.x = float(p.get('x', 0))
    engine.player.pos.y = float(p.get('y', 0))
    engine.player.angle = float(p.get('angle', 0))
    engine.player.hp = float(p.get('hp', engine.player.max_hp))
    engine.player.max_hp = float(p.get('max_hp', engine.player.max_hp))
    engine.player.vel.x = float(p.get('vel_x', 0))
    engine.player.vel.y = float(p.get('vel_y', 0))
    engine.player.speed = float(p.get('speed', engine.player.speed))
    engine.player.rot_speed = float(p.get('rot_speed', engine.player.rot_speed))
    engine.player.alive = bool(p.get('alive', True))
    if hasattr(engine.player, 'pitch'):
        engine.player.pitch = float(p.get('pitch', 0.0))

    # ----- Двери -----
    for did, state in (data.get('doors') or {}).items():
        if did in engine.doors and state.get('open'):
            try:
                engine.api.open_door(did)
            except Exception as e:
                print(f"[Load] open_door({did}) failed: {e}")

    # ----- Ключи -----
    for kid, state in (data.get('keys') or {}).items():
        if state.get('collected') and kid in engine.keys:
            if not engine.keys[kid]['collected']:
                try:
                    engine.api.collect_key(kid)
                except Exception as e:
                    print(f"[Load] collect_key({kid}) failed: {e}")

    # ----- Враги -----
    from .enemy import EnemyAI
    for ed in (data.get('enemies') or []):
        if not ed.get('alive', True):
            continue
        try:
            # Если мод зарегистрировал кастомный класс — используем его
            cls = None
            try:
                cls = engine.mods_manager.get_enemy_class(ed.get('type', 'static'))
            except Exception:
                cls = None
            if cls is None:
                cls = EnemyAI

            enemy = cls(
                x=float(ed['x']), y=float(ed['y']),
                hp=float(ed.get('hp', 100)),
                aim=float(ed.get('aim', 10)),
                shoot_delay=float(ed.get('shoot_delay', 1.0)),
                shoot_intensity=float(ed.get('shoot_intensity', 0)),
                enemy_type=ed.get('type', 'static'),
                attack_type=ed.get('attack_type', 'ranged'),
                detect_radius=float(ed.get('detect_radius', 5)),
                attack_radius=float(ed.get('attack_radius', 3)),
                speed=float(ed.get('speed', 50)),
                key=ed.get('key'),
                texture=None,
            )
            enemy.max_hp = float(ed.get('max_hp', ed.get('hp', 100)))
            engine.enemies.append(enemy)
        except Exception as e:
            print(f"[Load] Enemy restore failed: {e}")

    # ----- Пули -----
    from .gun import Bullet
    for bd in (data.get('bullets') or []):
        try:
            owner = bd.get('owner', 'script')
            if owner not in ('player', 'enemy', 'script'):
                owner = 'script'
            b = Bullet(
                x=float(bd['x']), y=float(bd['y']),
                angle=float(bd['angle']),
                damage=float(bd.get('damage', 10)),
                speed=float(bd.get('speed', 800)),
                owner=owner,
                explosive=bool(bd.get('explosive', False)),
                explosion_radius=float(bd.get('explosion_radius', 0)),
                explosion_damage=float(bd.get('explosion_damage', 0)),
            )
            engine.bullets.append(b)
        except Exception as e:
            print(f"[Load] Bullet restore failed: {e}")

    # ----- Оружие -----
    guns = data.get('guns', {})
    for k, g in guns.items():
        if k in engine.gun_manager.guns:
            engine.gun_manager.guns[k].ammo = int(g.get('ammo', 0))
            engine.gun_manager.guns[k].max_ammo = int(g.get('max_ammo', 0))
    cur = data.get('current_gun')
    if cur and cur in engine.gun_manager.guns:
        engine.gun_manager.current_gun_key = cur

    # ----- Достижения -----
    ach = data.get('achievements')
    if ach:
        try:
            engine.achievements.load_from_dict(ach)
        except Exception as e:
            print(f"[Load] Achievements restore failed: {e}")

    # ----- Мир -----
    w = data.get('world', {})
    engine._elapsed_time = float(w.get('elapsed_time', 0))
    engine._frame_counter = int(w.get('frame_counter', 0))
    engine.time_scale = float(w.get('time_scale', 1.0))

    # ----- RTE -----
    rt = data.get('rt', {})
    if 'enabled' in rt:
        engine.rt_enabled = bool(rt['enabled'])
    if rt.get('quality') in ('fast', 'balanced', 'high', 'ultra', 'reference'):
        engine.rt_quality = rt['quality']
        if engine.use_gpu and engine.gpu_raycaster:
            try:
                engine.gpu_raycaster.set_rt_quality(engine.rt_quality)
            except Exception:
                pass
    if 'max_lights' in rt:
        engine.rt_max_lights = int(rt['max_lights'])
    if 'reflections' in rt:
        engine.rt_reflections = bool(rt['reflections'])

    print(f"[Load] Loaded from {path}")
    return True