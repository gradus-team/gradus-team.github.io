"""
Firebase Realtime Database backend для лобби Gradus RC.
Использует SSE (Server-Sent Events) вместо polling — сервер сам
присылает изменения, не надо тянуть весь узел.

Установка: pip install google-auth requests
"""
from __future__ import annotations

import os
import json
import time
import uuid
import hashlib
import threading
import requests


DEFAULT_BASE_PATH = "/gradus_mp"
HEARTBEAT_TIMEOUT = 15.0
LOBBY_TIMEOUT     = 30.0


class FirebaseLobbyClient:
    def __init__(self, account_json_path=None, base_path=DEFAULT_BASE_PATH,
                 database_url=None, use_auth=True):
        self.base_path = base_path.strip('/')
        self._use_auth = bool(use_auth)
        self._access_token = None
        self._token_expiry = 0.0
        self._creds = None

        self.player_id = str(uuid.uuid4())[:12]
        self.lobby_id = None
        self.player_name = "Player"

        # SSE
        self._sse_thread = None
        self._sse_stop = threading.Event()
        self._sse_session = None
        self._lobby_cache = {}
        self._cache_lock = threading.Lock()
        self._on_change_callbacks = []

        if not database_url and account_json_path:
            database_url = self._extract_db_url(account_json_path)
        if not database_url:
            raise ValueError("databaseURL не определён")
        self.database_url = database_url.rstrip('/')

        if self._use_auth and account_json_path:
            self._setup_auth(account_json_path)

    # ---------- AUTH ----------
    def _extract_db_url(self, path):
        if not os.path.isfile(path):
            return None
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if data.get('databaseURL'):
                return data['databaseURL']
            pid = data.get('project_id', '')
            if pid:
                return f"https://{pid}-default-rtdb.firebaseio.com"
        except Exception as e:
            print(f"[FB] parse json failed: {e}")
        return None

    def _setup_auth(self, path):
        try:
            from google.oauth2 import service_account
            from google.auth.transport.requests import Request
        except ImportError:
            print("[FB] google-auth нет — работаю без auth. pip install google-auth")
            self._use_auth = False
            return
        try:
            scopes = [
                'https://www.googleapis.com/auth/firebase.database',
                'https://www.googleapis.com/auth/userinfo.email',
            ]
            self._creds = service_account.Credentials.from_service_account_file(
                path, scopes=scopes)
            self._creds.refresh(Request())
            self._access_token = self._creds.token
            self._token_expiry = time.time() + 3500
        except Exception as e:
            print(f"[FB] auth setup failed: {e}")
            self._use_auth = False

    def _refresh_token(self):
        if not self._use_auth or self._creds is None:
            return
        if time.time() > self._token_expiry - 60:
            try:
                from google.auth.transport.requests import Request
                self._creds.refresh(Request())
                self._access_token = self._creds.token
                self._token_expiry = time.time() + 3500
            except Exception as e:
                print(f"[FB] token refresh failed: {e}")

    def _auth_suffix(self):
        if self._use_auth and self._access_token:
            self._refresh_token()
            return f"?auth={self._access_token}"
        return ""

    # ---------- HTTP ----------
    def _url(self, subpath):
        sub = subpath.strip('/')
        url = f"{self.database_url}/{self.base_path}"
        if sub:
            url += f"/{sub}"
        url += ".json"
        return url

    def _get(self, subpath, timeout=10):
        try:
            r = requests.get(self._url(subpath) + self._auth_suffix(),
                             timeout=timeout)
            if r.status_code == 200:
                return r.json()
        except Exception as e:
            print(f"[FB] GET {subpath}: {e}")
        return None

    def _put(self, subpath, data, timeout=10):
        try:
            r = requests.put(self._url(subpath) + self._auth_suffix(),
                             json=data, timeout=timeout)
            return r.status_code == 200
        except Exception as e:
            print(f"[FB] PUT {subpath}: {e}")
            return False

    def _post(self, subpath, data, timeout=10):
        try:
            r = requests.post(self._url(subpath) + self._auth_suffix(),
                              json=data, timeout=timeout)
            if r.status_code == 200:
                return r.json()
        except Exception as e:
            print(f"[FB] POST {subpath}: {e}")
        return None

    def _delete(self, subpath, timeout=10):
        try:
            r = requests.delete(self._url(subpath) + self._auth_suffix(),
                                timeout=timeout)
            return r.status_code == 200
        except Exception as e:
            print(f"[FB] DELETE {subpath}: {e}")
            return False

    # ---------- LOBBY LIST ----------
    def list_lobbies(self):
        """Читаем один раз весь список (для показа), потом обновляем по SSE."""
        data = self._get("lobbies") or {}
        now = time.time()
        out = []
        for lid, lobby in data.items():
            if not isinstance(lobby, dict):
                continue
            hb = float(lobby.get('heartbeat', 0))
            if now - hb > LOBBY_TIMEOUT:
                continue
            players = lobby.get('players', {}) or {}
            alive = [pid for pid, p in players.items()
                     if isinstance(p, dict)
                     and now - float(p.get('last_seen', 0)) < HEARTBEAT_TIMEOUT]
            out.append({
                'id': lid,
                'name': lobby.get('name', 'Unnamed'),
                'host': lobby.get('host_name', 'Host'),
                'players': len(alive),
                'max_players': int(lobby.get('max_players', 4)),
                'mode': lobby.get('mode', 'pvp'),
                'has_password': bool(lobby.get('password_hash')),
                'state': lobby.get('state', 'lobby'),
                'backend': 'firebase',
            })
        out.sort(key=lambda x: (-x['players'], x['name'].lower()))
        return out

    # ---------- SSE LISTENER ----------
    def start_global_listener(self, on_lobbies_changed=None):
        """Слушает /lobbies — для списка в меню."""
        self._start_sse("lobbies", on_lobbies_changed)

    def start_lobby_listener(self, on_lobby_changed=None):
        """Слушает конкретное лобби — для комнаты."""
        if not self.lobby_id:
            return
        self._start_sse(f"lobbies/{self.lobby_id}", on_lobby_changed)

    def stop_listener(self):
        self._sse_stop.set()
        if self._sse_session is not None:
            try:
                self._sse_session.close()
            except Exception:
                pass

    def _start_sse(self, path, callback):
        self.stop_listener()
        self._sse_stop = threading.Event()
        self._sse_session = requests.Session()
        self._sse_thread = threading.Thread(
            target=self._sse_loop, args=(path, callback), daemon=True)
        self._sse_thread.start()

    def _sse_loop(self, path, callback):
        """Читает text/event-stream от Firebase и зовёт callback."""
        url = self._url(path) + self._auth_suffix()
        headers = {'Accept': 'text/event-stream'}
        backoff = 1.0
        while not self._sse_stop.is_set():
            try:
                with self._sse_session.get(url, headers=headers,
                                           stream=True, timeout=(10, None)) as r:
                    if r.status_code != 200:
                        time.sleep(backoff)
                        backoff = min(backoff * 2, 30)
                        continue
                    backoff = 1.0
                    event = None
                    for raw in r.iter_lines():
                        if self._sse_stop.is_set():
                            return
                        if raw is None or raw == b'':
                            continue
                        line = raw.decode('utf-8', errors='replace')
                        if line.startswith('event: '):
                            event = line[7:].strip()
                        elif line.startswith('data: '):
                            payload = line[6:]
                            if event == 'keep-alive':
                                continue
                            try:
                                obj = json.loads(payload)
                            except json.JSONDecodeError:
                                continue
                            if callback:
                                try:
                                    callback(event, obj)
                                except Exception as e:
                                    print(f"[FB SSE cb] {e}")
                            with self._cache_lock:
                                if isinstance(obj, dict):
                                    self._lobby_cache.update(obj)
            except Exception as e:
                if self._sse_stop.is_set():
                    return
                print(f"[FB SSE] disconnect: {e}")
            time.sleep(backoff)
            backoff = min(backoff * 2, 30)

    # ---------- CREATE / JOIN / LEAVE ----------
    def create_lobby(self, name, host_name="Host", password=None,
                     max_players=4, mode='pvp'):
        lobby_id = f"lobby_{int(time.time())}_{uuid.uuid4().hex[:6]}"
        pw_hash = (hashlib.sha256(password.encode()).hexdigest()[:32]
                   if password else None)
        self.lobby_id = lobby_id
        self.player_name = host_name

        data = {
            'name': str(name)[:64],
            'host_name': host_name,
            'host_id': self.player_id,
            'max_players': int(max_players),
            'mode': mode,
            'password_hash': pw_hash,
            'state': 'lobby',
            'created_at': time.time(),
            'heartbeat': time.time(),
        }
        if not self._put(f"lobbies/{lobby_id}", data):
            self.lobby_id = None
            return None

        self._put(f"lobbies/{lobby_id}/players/{self.player_id}", {
            'name': host_name,
            'team': 'spectator',
            'ready': True,
            'alive': True,
            'hp': 100, 'max_hp': 100,
            'x': 0.0, 'y': 0.0, 'angle': 0.0,
            'is_spectator': True,
            'last_seen': time.time(),
        })
        return lobby_id

    def join_lobby(self, lobby_id, player_name="Player", password=None):
        data = self._get(f"lobbies/{lobby_id}")
        if not isinstance(data, dict):
            return False, "Лобби не найдено"
        pw_hash = data.get('password_hash')
        if pw_hash:
            if not password:
                return False, "Требуется пароль"
            check = hashlib.sha256(password.encode()).hexdigest()[:32]
            if check != pw_hash:
                return False, "Неверный пароль"
        players = data.get('players', {}) or {}
        if len(players) >= int(data.get('max_players', 4)):
            return False, "Заполнено"

        self.lobby_id = lobby_id
        self.player_name = player_name
        self._put(f"lobbies/{lobby_id}/players/{self.player_id}", {
            'name': player_name,
            'team': None,
            'ready': False,
            'alive': True,
            'hp': 100, 'max_hp': 100,
            'x': 0.0, 'y': 0.0, 'angle': 0.0,
            'is_spectator': False,
            'last_seen': time.time(),
        })
        return True, "OK"

    def leave_lobby(self):
        if not self.lobby_id:
            return
        lid = self.lobby_id
        self._delete(f"lobbies/{lid}/players/{self.player_id}")
        data = self._get(f"lobbies/{lid}")
        if isinstance(data, dict):
            if data.get('host_id') == self.player_id:
                players = data.get('players', {}) or {}
                remaining = [pid for pid in players if pid != self.player_id]
                if not remaining:
                    self._delete(f"lobbies/{lid}")
                else:
                    new_host = remaining[0]
                    self._put(f"lobbies/{lid}/host_id", new_host)
                    self._put(f"lobbies/{lid}/host_name",
                              players[new_host].get('name', 'Host'))
        self.lobby_id = None
        self.stop_listener()

    # ---------- STATE ----------
    def heartbeat(self):
        if not self.lobby_id:
            return
        self._put(f"lobbies/{self.lobby_id}/heartbeat", time.time())
        self._put(
            f"lobbies/{self.lobby_id}/players/{self.player_id}/last_seen",
            time.time())

    def get_lobby_state(self):
        if not self.lobby_id:
            return None
        return self._get(f"lobbies/{self.lobby_id}")

    def update_player_state(self, **fields):
        if not self.lobby_id:
            return
        fields['last_seen'] = time.time()
        for k, v in fields.items():
            self._put(
                f"lobbies/{self.lobby_id}/players/{self.player_id}/{k}", v)

    def set_lobby_state(self, state):
        if not self.lobby_id:
            return
        self._put(f"lobbies/{self.lobby_id}/state", state)

    def am_i_host(self):
        if not self.lobby_id:
            return False
        data = self._get(f"lobbies/{self.lobby_id}")
        if isinstance(data, dict):
            return data.get('host_id') == self.player_id
        return False

    # ---------- EVENT BUS ----------
    def send_message(self, kind, data):
        if not self.lobby_id:
            return
        self._post(f"lobbies/{self.lobby_id}/messages", {
            'ts': time.time(),
            'from': self.player_id,
            'kind': kind,
            'data': data,
        })

    def poll_messages(self, since_ts=0.0):
        if not self.lobby_id:
            return [], since_ts
        data = self._get(f"lobbies/{self.lobby_id}/messages") or {}
        out, new_ts = [], since_ts
        for _, m in data.items():
            if not isinstance(m, dict):
                continue
            ts = float(m.get('ts', 0))
            if ts <= since_ts:
                continue
            if m.get('from') == self.player_id:
                new_ts = max(new_ts, ts)
                continue
            out.append({
                'ts': ts,
                'from': m.get('from'),
                'kind': m.get('kind'),
                'data': m.get('data', {}),
            })
            new_ts = max(new_ts, ts)
        out.sort(key=lambda x: x['ts'])
        return out, new_ts

    def cleanup_messages(self, older_than=30.0):
        if not self.lobby_id:
            return
        data = self._get(f"lobbies/{self.lobby_id}/messages") or {}
        cutoff = time.time() - older_than
        for mid, m in data.items():
            if isinstance(m, dict) and float(m.get('ts', 0)) < cutoff:
                self._delete(f"lobbies/{self.lobby_id}/messages/{mid}")