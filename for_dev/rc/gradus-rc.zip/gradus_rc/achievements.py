"""
Achievements API для Gradus RC.

- Достижения регистрируются через register() из движка или мода.
- Состояние сохраняется в achievements.json.
- Путь по умолчанию — рядом с пакетом gradus_rc (в корне проекта).
- Можно указать свой путь: относительный или абсолютный.
"""
from __future__ import annotations

import os
import json
import datetime
from typing import Optional, Callable



# =========================================================
# Глобальный реестр определений (module-level).
# Работает ДО создания Engine.
# =========================================================

_GLOBAL_DEFINITIONS: dict[str, dict] = {}


def define_achievement(id: str, title: str, description: str = "",
                       icon: str = None, hidden: bool = False,
                       max_progress: int = 1):
    """
    Зарегистрировать достижение на уровне модуля.
    Работает до создания Engine, поэтому видно в меню с первого запуска.

    Пример:
        define_achievement("first_shot", "Первый выстрел",
                           "Сделай первый выстрел")
    """
    _GLOBAL_DEFINITIONS[id] = {
        'title': title,
        'description': description,
        'icon': icon,
        'hidden': bool(hidden),
        'max_progress': max(1, int(max_progress)),
    }
    return id


def define_achievements(definitions):
    """
    Массовая регистрация. Принимает dict или список dict.

    Пример с dict:
        define_achievements({
            "first_shot": {"title": "Первый выстрел",
                           "description": "Сделай первый выстрел"},
            "kill_10":    {"title": "Охотник",
                           "description": "Убей 10 врагов",
                           "max_progress": 10},
            "secret":     {"title": "Тайная комната",
                           "description": "Найди секрет",
                           "hidden": True},
        })

    Пример со списком кортежей:
        define_achievements([
            ("first_shot", "Первый выстрел", "Сделай первый выстрел"),
            ("kill_10",    "Охотник",        "Убей 10 врагов", None, False, 10),
        ])
    """
    if isinstance(definitions, dict):
        for id, d in definitions.items():
            if isinstance(d, dict):
                define_achievement(id, **d)
            elif isinstance(d, (tuple, list)):
                define_achievement(id, *d)
            else:
                define_achievement(id, str(d))
    elif isinstance(definitions, (list, tuple)):
        for item in definitions:
            if isinstance(item, (list, tuple)):
                define_achievement(*item)
            elif isinstance(item, dict):
                id = item.pop('id', None)
                if id:
                    define_achievement(id, **item)


def get_global_definitions() -> dict:
    """Возвращает копию глобального реестра."""
    return {k: dict(v) for k, v in _GLOBAL_DEFINITIONS.items()}


def clear_global_definitions():
    """Очистить реестр (в основном для тестов)."""
    _GLOBAL_DEFINITIONS.clear()


def sync_achievements_file(path: str = None):
    """
    Синхронизирует JSON-файл с глобальным реестром, НЕ затрагивая
    существующий прогресс. Можно вызывать до старта Engine, чтобы
    меню сразу видело достижения.

    Если path=None — берётся get_default_save_path().
    """
    if path is None:
        path = get_default_save_path()

    # Загружаем существующий файл, если есть
    existing = {}
    if os.path.isfile(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            raw = data.get("achievements", {})
            if isinstance(raw, dict):
                existing = raw
        except Exception:
            existing = {}

    # Обновляем из глобального реестра
    for id, d in _GLOBAL_DEFINITIONS.items():
        current = existing.get(id, {})
        existing[id] = {
            'title': d['title'],
            'description': d['description'],
            'icon': d['icon'],
            'hidden': d['hidden'],
            'max_progress': d['max_progress'],
            # прогресс сохраняем если был
            'current_progress': current.get('current_progress', 0),
            'unlocked': current.get('unlocked', False),
            'unlocked_at': current.get('unlocked_at'),
        }

    try:
        parent = os.path.dirname(path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump({
                "version": 1,
                "achievements": existing,
            }, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"[Achievements] sync_achievements_file failed: {e}")
        return False


def get_default_save_path() -> str:
    """
    Путь по умолчанию: achievements.json в корне проекта,
    то есть рядом с пакетом gradus_rc.
    """
    package_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(package_dir)
    return os.path.join(project_root, "achievements.json")


class Achievement:
    """Одно достижение с прогрессом."""

    def __init__(self, id: str, title: str, description: str = "",
                 icon: Optional[str] = None, hidden: bool = False,
                 max_progress: int = 1):
        self.id = id
        self.title = title
        self.description = description
        self.icon = icon
        self.hidden = hidden
        self.max_progress = max(1, int(max_progress))
        self.current_progress = 0
        self.unlocked = False
        self.unlocked_at: Optional[str] = None


    def add_progress(self, amount: int = 1) -> bool:
        """True если разблокировалось именно сейчас."""
        if self.unlocked:
            return False
        self.current_progress = min(self.max_progress,
                                     self.current_progress + amount)
        if self.current_progress >= self.max_progress:
            self.unlocked = True
            self.unlocked_at = datetime.datetime.now().isoformat(timespec="seconds")
            return True
        return False

    def set_progress(self, value: int) -> bool:
        if self.unlocked:
            return False
        self.current_progress = max(0, min(self.max_progress, int(value)))
        if self.current_progress >= self.max_progress:
            self.unlocked = True
            self.unlocked_at = datetime.datetime.now().isoformat(timespec="seconds")
            return True
        return False

    def unlock(self) -> bool:
        if self.unlocked:
            return False
        self.current_progress = self.max_progress
        self.unlocked = True
        self.unlocked_at = datetime.datetime.now().isoformat(timespec="seconds")
        return True

    @property
    def progress_ratio(self) -> float:
        return self.current_progress / max(1, self.max_progress)

    @property
    def progress_str(self) -> str:
        if self.max_progress <= 1:
            return "✓" if self.unlocked else ""
        return f"{self.current_progress}/{self.max_progress}"

    def to_dict(self) -> dict:
        return {
            "title": self.title,
            "description": self.description,
            "icon": self.icon,
            "hidden": self.hidden,
            "max_progress": self.max_progress,
            "current_progress": self.current_progress,
            "unlocked": self.unlocked,
            "unlocked_at": self.unlocked_at,
        }

    @classmethod
    def from_dict(cls, id: str, d: dict) -> "Achievement":
        a = cls(
            id=id,
            title=d.get("title", id),
            description=d.get("description", ""),
            icon=d.get("icon"),
            hidden=d.get("hidden", False),
            max_progress=d.get("max_progress", 1),
        )
        a.current_progress = int(d.get("current_progress", 0))
        a.unlocked = bool(d.get("unlocked", False))
        a.unlocked_at = d.get("unlocked_at")
        return a


class AchievementsManager:
    """Менеджер достижений движка."""

    VERSION = 1

    def __init__(self, save_path: Optional[str] = None):
        self.save_path = self._resolve_path(save_path)
        self._achievements: dict[str, Achievement] = {}
        self._event_callbacks: list[Callable] = []
        self.load()  # сначала прогресс из файла
        self._apply_global_definitions()  # потом метаданные из реестра
        self.save()  # синхронизируем файл

    def _apply_global_definitions(self):
        """
        Подтягивает определения из глобального реестра модуля.
        Прогресс уже загруженных достижений НЕ сбрасывается —
        register() обновляет только метаданные.
        """
        for id, d in _GLOBAL_DEFINITIONS.items():
            try:
                self.register_from_dict(id, d)
            except Exception as e:
                print(f"[Achievements] apply global '{id}' failed: {e}")

    def _resolve_path(self, path: Optional[str]) -> str:
        if path is None:
            return get_default_save_path()
        if os.path.isabs(path):
            return path
        return os.path.abspath(path)

    # ---------- Регистрация ----------

    def register(self, id: str, title: str, description: str = "",
                 icon: Optional[str] = None, hidden: bool = False,
                 max_progress: int = 1) -> Achievement:
        """
        Объявить достижение. Если уже есть в сохранении — обновляет
        метаданные, но НЕ сбрасывает прогресс.
        """
        existing = self._achievements.get(id)
        if existing is not None:
            existing.title = title
            existing.description = description
            if icon is not None:
                existing.icon = icon
            existing.hidden = hidden
            existing.max_progress = max(1, int(max_progress))
            return existing
        a = Achievement(id, title, description, icon, hidden, max_progress)
        self._achievements[id] = a
        self._fire(a, "registered")
        return a

    def load_from_dict(self, data):
        """
        Загрузить состояние достижений из dict (из сохранения).
        Прогресс и метаданные перезаписываются.
        """
        raw = data.get('achievements', {})
        if not isinstance(raw, dict):
            return
        for id, d in raw.items():
            if isinstance(d, dict):
                self._achievements[id] = Achievement.from_dict(id, d)
        self.save()

    def register_from_dict(self, id: str, data: dict) -> Achievement:
        return self.register(
            id=id,
            title=data.get("title", id),
            description=data.get("description", ""),
            icon=data.get("icon"),
            hidden=data.get("hidden", False),
            max_progress=data.get("max_progress", 1),
        )

    def register_bulk(self, definitions: dict):
        """definitions: {id: {title, description, ...}}"""
        for id, d in definitions.items():
            self.register_from_dict(id, d)

    def unregister(self, id: str):
        self._achievements.pop(id, None)

    # ---------- Изменение ----------

    def unlock(self, id: str) -> bool:
        a = self._achievements.get(id)
        if a is None:
            return False
        if a.unlock():
            self._fire(a, "unlocked")
            self.save()
            return True
        return False

    def add_progress(self, id: str, amount: int = 1) -> bool:
        a = self._achievements.get(id)
        if a is None:
            return False
        if a.add_progress(amount):
            self._fire(a, "unlocked")
            self.save()
            return True
        self.save()
        return False

    def set_progress(self, id: str, value: int) -> bool:
        a = self._achievements.get(id)
        if a is None:
            return False
        if a.set_progress(value):
            self._fire(a, "unlocked")
            self.save()
            return True
        self.save()
        return False

    def reset(self, id: Optional[str] = None):
        if id is None:
            for a in self._achievements.values():
                a.current_progress = 0
                a.unlocked = False
                a.unlocked_at = None
        else:
            a = self._achievements.get(id)
            if a:
                a.current_progress = 0
                a.unlocked = False
                a.unlocked_at = None
        self.save()

    # ---------- Чтение ----------

    def get(self, id: str) -> Optional[Achievement]:
        return self._achievements.get(id)

    def is_unlocked(self, id: str) -> bool:
        a = self._achievements.get(id)
        return a.unlocked if a else False

    def get_all(self) -> list[Achievement]:
        """Все достижения с прогрессом."""
        return list(self._achievements.values())

    def get_unlocked(self) -> list[Achievement]:
        """Только полученные."""
        return [a for a in self._achievements.values() if a.unlocked]

    def get_locked(self) -> list[Achievement]:
        """Только неполученные (включая те, у которых прогресс частичный)."""
        return [a for a in self._achievements.values() if not a.unlocked]

    def get_progress(self, id: str) -> tuple[int, int]:
        """(current, max)."""
        a = self._achievements.get(id)
        if a is None:
            return (0, 0)
        return (a.current_progress, a.max_progress)

    @property
    def total_count(self) -> int:
        return len(self._achievements)

    @property
    def unlocked_count(self) -> int:
        return sum(1 for a in self._achievements.values() if a.unlocked)

    # ---------- События ----------

    def on_change(self, callback: Callable):
        """callback(achievement, event_type). event_type: 'registered'|'unlocked'."""
        self._event_callbacks.append(callback)

    def _fire(self, achievement: Achievement, event_type: str):
        for cb in self._event_callbacks:
            try:
                cb(achievement, event_type)
            except Exception as e:
                print(f"[Achievements] callback error: {e}")

    # ---------- Сохранение / загрузка ----------

    def to_dict(self) -> dict:
        return {
            "version": self.VERSION,
            "achievements": {
                a.id: a.to_dict() for a in self._achievements.values()
            },
        }

    def save(self):
        try:
            parent = os.path.dirname(self.save_path)
            if parent:
                os.makedirs(parent, exist_ok=True)
            with open(self.save_path, "w", encoding="utf-8") as f:
                json.dump(self.to_dict(), f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[Achievements] save failed: {e}")

    def load(self):
        if not os.path.isfile(self.save_path):
            return
        try:
            with open(self.save_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            print(f"[Achievements] load failed: {e}")
            return

        raw = data.get("achievements", {})
        if not isinstance(raw, dict):
            return
        for id, d in raw.items():
            if not isinstance(d, dict):
                continue
            self._achievements[id] = Achievement.from_dict(id, d)