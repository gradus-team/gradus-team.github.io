"""
Рендер .obj/.gbj моделей в спрайты-ракурсы.

ВАЖНО: геометрия (проекция, повороты, culling, сортировка, направление углов)
полностью соответствует старому рабочему obj_to_sprites. Добавлены только:
  • Парсер .obj с поддержкой v / vt / vn / mtllib / usemtl
  • Парсер .mtl → map_Kd (текстура), Kd (цвет), d (прозрачность)
  • Поиск текстуры по подпапкам (textures/, maps/, ...) и сменой расширения
  • Текстурированный растеризатор (nearest sampling) поверх pygame.Surface
  • Планарная проекция UV, если UV в OBJ нет, но текстура задана
  • texture_override — принудительная текстура для клетки
"""

import os
import math
import numpy as np
import pygame


# ============================================================
# КЭШ ТЕКСТУР
# ============================================================
_TEXTURE_CACHE = {}


def _load_texture_np(path):
    """Загружает картинку как numpy (H, W, 4) uint8."""
    try:
        surf = pygame.image.load(path).convert_alpha()
        rgb = pygame.surfarray.array3d(surf)      # (W, H, 3)
        a = pygame.surfarray.array_alpha(surf)    # (W, H)
        arr = np.dstack([rgb, a]).transpose(1, 0, 2).copy()  # (H, W, 4)
        return arr
    except Exception as e:
        print(f"[obj_to_sprites] Не удалось загрузить {path}: {e}")
        return None


def _get_texture(path):
    if path is None:
        return None
    if path in _TEXTURE_CACHE:
        return _TEXTURE_CACHE[path]
    tex = _load_texture_np(path)
    _TEXTURE_CACHE[path] = tex
    return tex


def clear_texture_cache():
    _TEXTURE_CACHE.clear()


# ============================================================
# ПАРСЕРЫ
# ============================================================
def _parse_obj_full(filepath):
    vertices, uvs, normals = [], [], []
    faces = []
    mtllibs = []
    current_mat = None

    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split()
            tag = parts[0]
            try:
                if tag == 'v':
                    vertices.append((float(parts[1]), float(parts[2]), float(parts[3])))
                elif tag == 'vt':
                    uvs.append((float(parts[1]), float(parts[2])))
                elif tag == 'vn':
                    normals.append((float(parts[1]), float(parts[2]), float(parts[3])))
                elif tag == 'mtllib':
                    mtllibs.append(' '.join(parts[1:]))
                elif tag == 'usemtl':
                    current_mat = parts[1] if len(parts) > 1 else None
                elif tag == 'f':
                    v_i, uv_i, vn_i = [], [], []
                    for p in parts[1:]:
                        if '/' in p:
                            sub = p.split('/')
                            v_i.append(int(sub[0]) - 1)
                            uv_i.append(int(sub[1]) - 1 if len(sub) > 1 and sub[1] else -1)
                            vn_i.append(int(sub[2]) - 1 if len(sub) > 2 and sub[2] else -1)
                        else:
                            v_i.append(int(p) - 1)
                            uv_i.append(-1)
                            vn_i.append(-1)
                    for k in range(1, len(v_i) - 1):
                        faces.append((
                            (v_i[0], v_i[k], v_i[k + 1]),
                            (uv_i[0], uv_i[k], uv_i[k + 1]),
                            (vn_i[0], vn_i[k], vn_i[k + 1]),
                            current_mat,
                        ))
            except (ValueError, IndexError):
                continue

    return {
        'vertices': vertices,
        'uvs': uvs,
        'normals': normals,
        'faces': faces,
        'mtllibs': mtllibs,
        'base_dir': os.path.dirname(os.path.abspath(filepath)),
    }


def _parse_gbj(filepath):
    vertices, faces, face_colors = [], [], []
    with open(filepath, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split()
            if parts[0] == 'v':
                vertices.append((float(parts[1]), float(parts[2]), float(parts[3])))
            elif parts[0] == 'f':
                color = None
                idx = []
                for p in parts[1:]:
                    if len(p) == 6 and all(c in '0123456789ABCDEFabcdef' for c in p):
                        r = int(p[0:2], 16) / 255.0
                        g = int(p[2:4], 16) / 255.0
                        b = int(p[4:6], 16) / 255.0
                        color = (r, g, b)
                    else:
                        idx.append(int(p.split('/')[0]) - 1)
                for k in range(1, len(idx) - 1):
                    faces.append((idx[0], idx[k], idx[k + 1]))
                    face_colors.append(color)
    return vertices, faces, face_colors


def _parse_mtl(filepath):
    materials = {}
    current = None
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split()
            tag = parts[0]
            if tag == 'newmtl':
                current = parts[1] if len(parts) > 1 else None
                if current:
                    materials[current] = {'Kd': (1.0, 1.0, 1.0),
                                          'map_Kd': None, 'd': 1.0}
            elif current is not None:
                try:
                    if tag == 'Kd':
                        materials[current]['Kd'] = (float(parts[1]),
                                                    float(parts[2]),
                                                    float(parts[3]))
                    elif tag == 'map_Kd':
                        materials[current]['map_Kd'] = ' '.join(parts[1:])
                    elif tag == 'd':
                        materials[current]['d'] = float(parts[1])
                    elif tag == 'Tr':
                        materials[current]['d'] = 1.0 - float(parts[1])
                except (ValueError, IndexError):
                    pass
    return materials


def _find_texture(base_dir, texture_path):
    """Ищет файл текстуры: рядом, в подпапках, со сменой расширения."""
    if not texture_path:
        return None
    clean = texture_path.replace('\\', '/').lstrip('./')
    name = os.path.basename(clean)
    stem, _ = os.path.splitext(name)

    subdirs = ['', 'textures', 'maps', 'tex', 'texture', 'materials',
               'Textures', 'Maps', 'Tex', 'Materials']
    exts = ['.png', '.jpg', '.jpeg', '.tga', '.bmp',
            '.PNG', '.JPG', '.JPEG', '.TGA']

    candidates = [
        os.path.normpath(os.path.join(base_dir, texture_path)),
        os.path.join(base_dir, name),
    ]
    for sub in subdirs:
        candidates.append(os.path.join(base_dir, sub, name))
    for sub in subdirs:
        for ext in exts:
            candidates.append(os.path.join(base_dir, sub, stem + ext))

    for cand in candidates:
        if os.path.isfile(cand):
            return cand

    # Рекурсивный fallback
    for root, _, files in os.walk(base_dir):
        if name in files:
            return os.path.join(root, name)
    return None


# ============================================================
# КОНВЕРТАЦИЯ NUMPY → SURFACE (без surfarray.blit_array)
# ============================================================
def _np_to_surface(rgba_hw):
    """
    rgba_hw: (H, W, 4) uint8.
    Возвращает pygame.Surface (W, H) с alpha.
    """
    H, W = rgba_hw.shape[0], rgba_hw.shape[1]
    surf = pygame.Surface((W, H), pygame.SRCALPHA)
    # RGB через blit_array с транспонированием в (W, H, 3)
    rgb_wh = np.ascontiguousarray(np.transpose(rgba_hw[..., :3], (1, 0, 2)))
    try:
        pygame.surfarray.blit_array(surf, rgb_wh)
    except Exception as e:
        print(f"[obj_to_sprites] blit_array RGB failed: {e}")
        return surf
    # Alpha отдельно
    try:
        a_wh = np.ascontiguousarray(np.transpose(rgba_hw[..., 3], (1, 0)))
        alpha_view = pygame.surfarray.pixels_alpha(surf)
        alpha_view[:] = a_wh
        del alpha_view
    except Exception as e:
        print(f"[obj_to_sprites] pixels_alpha failed: {e}")
    return surf


# ============================================================
# РИСОВАНИЕ ОДНОГО ТРЕУГОЛЬНИКА
# ============================================================
def _draw_triangle(surf, p1, p2, p3, uv1, uv2, uv3, texture,
                   base_color, intensity, alpha=1.0):
    """
    Если текстура есть и UV — рисует текстурированный треугольник (nearest).
    Иначе — заливка цветом с освещением.
    """
    SW, SH = surf.get_size()

    if texture is None or uv1 is None or uv2 is None or uv3 is None:
        col = (int(min(255, max(0, base_color[0] * 255 * intensity))),
               int(min(255, max(0, base_color[1] * 255 * intensity))),
               int(min(255, max(0, base_color[2] * 255 * intensity))))
        pygame.draw.polygon(surf, col, [(p1[0], p1[1]),
                                        (p2[0], p2[1]),
                                        (p3[0], p3[1])])
        return

    min_x = int(min(p1[0], p2[0], p3[0]))
    max_x = int(max(p1[0], p2[0], p3[0]))
    min_y = int(min(p1[1], p2[1], p3[1]))
    max_y = int(max(p1[1], p2[1], p3[1]))
    min_x = max(0, min_x)
    min_y = max(0, min_y)
    max_x = min(SW - 1, max_x)
    max_y = min(SH - 1, max_y)
    if max_x < min_x or max_y < min_y:
        return

    denom = ((p2[1] - p3[1]) * (p1[0] - p3[0]) +
             (p3[0] - p2[0]) * (p1[1] - p3[1]))
    if abs(denom) < 1e-9:
        return

    ys, xs = np.mgrid[min_y:max_y + 1, min_x:max_x + 1]
    px = xs.astype(np.float32) + 0.5
    py = ys.astype(np.float32) + 0.5

    w1 = ((p2[1] - p3[1]) * (px - p3[0]) +
          (p3[0] - p2[0]) * (py - p3[1])) / denom
    w2 = ((p3[1] - p1[1]) * (px - p3[0]) +
          (p1[0] - p3[0]) * (py - p3[1])) / denom
    w3 = 1.0 - w1 - w2

    inside = (w1 >= -1e-3) & (w2 >= -1e-3) & (w3 >= -1e-3)
    if not inside.any():
        return

    # UV интерполяция
    u = w1 * uv1[0] + w2 * uv2[0] + w3 * uv3[0]
    v = w1 * uv1[1] + w2 * uv2[1] + w3 * uv3[1]
    u = np.clip(u, 0.0, 1.0)
    v = np.clip(v, 0.0, 1.0)

    th, tw = texture.shape[:2]
    tx = np.clip((u * (tw - 1)).astype(np.int32), 0, tw - 1)
    ty = np.clip((v * (th - 1)).astype(np.int32), 0, th - 1)
    colors = texture[ty, tx]  # (h, w, 4)

    r = colors[..., 0].astype(np.float32) * intensity
    g = colors[..., 1].astype(np.float32) * intensity
    b = colors[..., 2].astype(np.float32) * intensity
    a = colors[..., 3].astype(np.float32) * alpha

    sub = np.zeros((ys.shape[0], ys.shape[1], 4), dtype=np.uint8)
    sub[..., 0] = np.clip(r, 0, 255).astype(np.uint8)
    sub[..., 1] = np.clip(g, 0, 255).astype(np.uint8)
    sub[..., 2] = np.clip(b, 0, 255).astype(np.uint8)
    sub[..., 3] = np.clip(a, 0, 255).astype(np.uint8)
    sub[~inside, 3] = 0

    sub_surf = _np_to_surface(sub)
    surf.blit(sub_surf, (min_x, min_y))


# ============================================================
# ГЛАВНАЯ ФУНКЦИЯ
# ============================================================
def obj_to_sprites(filepath, num_angles=64, sprite_size=(512, 512), scale=1.0,
                   color=(200, 100, 100), tilt_angle=30,
                   model_rot_x=0.0, model_rot_y=0.0, model_rot_z=0.0,
                   texture_override=None):
    if not os.path.exists(filepath):
        print(f"[obj_to_sprites] Файл не найден: {filepath}")
        return []

    if isinstance(color, tuple) and max(color) > 1.0:
        color = tuple(c / 255.0 for c in color)

    is_gbj = 'gbj' in filepath.lower()
    print(f"[obj_to_sprites] {filepath} | angles={num_angles} | size={sprite_size}")

    # -------- Парсинг --------
    per_face_uv = []
    per_face_tex = []
    per_face_tint = []
    per_face_alpha = []

    if is_gbj:
        verts_list, faces_list, face_colors_list = _parse_gbj(filepath)
        if not verts_list or not faces_list:
            print("[obj_to_sprites] GBJ пуст или битый")
            return []
        vertices = np.array(verts_list, dtype=np.float32)
        faces = np.array(faces_list, dtype=np.int32)
        for fc in face_colors_list:
            per_face_uv.append(None)
            per_face_tex.append(None)
            per_face_tint.append(fc if fc is not None else color)
            per_face_alpha.append(1.0)
    else:
        data = _parse_obj_full(filepath)
        if not data['vertices'] or not data['faces']:
            print("[obj_to_sprites] OBJ пуст или битый")
            return []
        vertices = np.array(data['vertices'], dtype=np.float32)
        uvs = np.array(data['uvs'], dtype=np.float32) if data['uvs'] else None

        # Загружаем MTL
        materials = {}
        for mtllib in data['mtllibs']:
            mtl_path = _find_texture(data['base_dir'], mtllib)
            if mtl_path and os.path.isfile(mtl_path):
                materials.update(_parse_mtl(mtl_path))
                print(f"[obj_to_sprites] MTL: {os.path.basename(mtl_path)} "
                      f"({len(materials)} материалов)")

        # Текстуры материалов
        mat_tex = {}
        mat_alpha = {}
        for name, mat in materials.items():
            tex_path = None
            if texture_override:
                tex_path = texture_override
            elif mat.get('map_Kd'):
                tex_path = _find_texture(data['base_dir'], mat['map_Kd'])
            if tex_path:
                tex = _get_texture(tex_path)
                if tex is not None:
                    mat_tex[name] = tex
                    print(f"[obj_to_sprites] Текстура '{name}' → "
                          f"{os.path.basename(tex_path)} {tex.shape}")
            mat_alpha[name] = mat.get('d', 1.0)

        if texture_override and not mat_tex:
            tex = _get_texture(texture_override)
            if tex is not None:
                mat_tex['__override__'] = tex
                mat_alpha['__override__'] = 1.0
                print(f"[obj_to_sprites] Override текстура: "
                      f"{os.path.basename(texture_override)} {tex.shape}")

        # Планарная проекция UV, если UV нет, но есть текстура
        has_any_uv = any(all(i >= 0 for i in f[1]) for f in data['faces'])
        use_planar = (not has_any_uv) and bool(mat_tex)
        planar_uvs = None
        if use_planar:
            vmin = vertices.min(axis=0)
            vmax = vertices.max(axis=0)
            rng = vmax - vmin
            rng[rng < 1e-6] = 1.0
            planar_uvs = np.zeros((len(vertices), 2), dtype=np.float32)
            planar_uvs[:, 0] = (vertices[:, 0] - vmin[0]) / rng[0]
            planar_uvs[:, 1] = 1.0 - (vertices[:, 1] - vmin[1]) / rng[1]
            print("[obj_to_sprites] Планарная проекция UV")

        faces = np.array([f[0] for f in data['faces']], dtype=np.int32)
        for f_uv_idx, mat_name in zip([f[1] for f in data['faces']],
                                       [f[3] for f in data['faces']]):
            # UV
            if all(i >= 0 for i in f_uv_idx) and uvs is not None:
                per_face_uv.append((uvs[f_uv_idx[0]], uvs[f_uv_idx[1]], uvs[f_uv_idx[2]]))
            elif use_planar and planar_uvs is not None:
                per_face_uv.append((
                    planar_uvs[f_uv_idx[0]] if f_uv_idx[0] >= 0 else (0, 0),
                    planar_uvs[f_uv_idx[1]] if f_uv_idx[1] >= 0 else (0, 0),
                    planar_uvs[f_uv_idx[2]] if f_uv_idx[2] >= 0 else (0, 0),
                ))
            else:
                per_face_uv.append(None)

            # Текстура
            if mat_name in mat_tex:
                per_face_tex.append(mat_tex[mat_name])
            elif '__override__' in mat_tex:
                per_face_tex.append(mat_tex['__override__'])
            else:
                per_face_tex.append(None)

            # Тинт — Kd или общий color
            if mat_name in materials:
                per_face_tint.append(materials[mat_name]['Kd'])
            else:
                per_face_tint.append((1.0, 1.0, 1.0))

            # Alpha
            per_face_alpha.append(mat_alpha.get(mat_name, 1.0))

    # -------- Геометрия (как в старом коде) --------
    center = np.mean(vertices, axis=0)

    rx = math.radians(model_rot_x)
    ry = math.radians(model_rot_y)
    rz = math.radians(model_rot_z)
    tilt = math.radians(tilt_angle)

    # ВАЖНО: имена переменных сохранены как в старом коде
    rot_x_effect = np.array([[math.cos(rx), 0, math.sin(rx)],
                             [0, 1, 0],
                             [-math.sin(rx), 0, math.cos(rx)]])
    rot_y_effect = np.array([[1, 0, 0],
                             [0, math.cos(ry), -math.sin(ry)],
                             [0, math.sin(ry), math.cos(ry)]])
    rot_z_effect = np.array([[math.cos(rz), -math.sin(rz), 0],
                             [math.sin(rz), math.cos(rz), 0],
                             [0, 0, 1]])

    rot_model = rot_z_effect @ rot_y_effect @ rot_x_effect

    rot_tilt = np.array([[1, 0, 0],
                         [0, math.cos(tilt), -math.sin(tilt)],
                         [0, math.sin(tilt), math.cos(tilt)]])

    # Нормали граней
    normals = []
    for f in faces:
        v1 = vertices[f[0]]
        v2 = vertices[f[1]]
        v3 = vertices[f[2]]
        edge1 = v2 - v1
        edge2 = v3 - v1
        n = np.cross(edge1, edge2)
        ln = np.linalg.norm(n)
        normals.append(n / ln if ln > 0 else np.array([0, 0, 1]))
    normals = np.array(normals)

    # -------- Рендер по углам --------
    sprites = []
    SW, SH = sprite_size

    for i in range(num_angles):
        # направление угла: как в старом коде
        if is_gbj:
            angle = -(i / num_angles) * 2 * math.pi
        else:
            angle = (i / num_angles) * 2 * math.pi

        surf = pygame.Surface(sprite_size, pygame.SRCALPHA)
        surf.fill((0, 0, 0, 0))

        cos_a = math.cos(angle)
        sin_a = math.sin(angle)
        rot_view = np.array([[cos_a, 0, sin_a],
                             [0, 1, 0],
                             [-sin_a, 0, cos_a]])

        rot_mat = rot_view @ rot_tilt @ rot_model

        # Трансформируем вершины (как в старом коде)
        transformed = []
        for v in vertices:
            v_centered = v - center
            v_rot = rot_mat.dot(v_centered)
            v_scaled = v_rot * scale
            transformed.append(v_scaled)

        # Отбор и сортировка
        tri_data = []
        for idx, f in enumerate(faces):
            p1 = transformed[f[0]]
            p2 = transformed[f[1]]
            p3 = transformed[f[2]]
            normal = normals[idx] if idx < len(normals) else np.array([0, 0, 1])
            n_rot = rot_mat.dot(normal)
            if n_rot[2] < 0:
                continue
            cz = (p1[2] + p2[2] + p3[2]) / 3
            tri_data.append((cz, p1, p2, p3, idx, n_rot))

        tri_data.sort(key=lambda x: x[0], reverse=True)

        # Размеры для scale_fit
        all_pts = []
        for _, p1, p2, p3, _, _ in tri_data:
            all_pts.extend([p1, p2, p3])
        if not all_pts:
            sprites.append(surf)
            continue

        min_x = min(p[0] for p in all_pts)
        max_x = max(p[0] for p in all_pts)
        min_y = min(p[1] for p in all_pts)
        max_y = max(p[1] for p in all_pts)

        margin = 0.1
        fit_w = sprite_size[0] * (1 - 2 * margin)
        fit_h = sprite_size[1] * (1 - 2 * margin)
        dx = (max_x - min_x) if max_x != min_x else 1e-3
        dy = (max_y - min_y) if max_y != min_y else 1e-3
        scale_fit = min(fit_w / dx, fit_h / dy)
        if scale_fit < 0.1:
            scale_fit = 0.1

        cx_screen = (min_x + max_x) / 2
        cy_screen = (min_y + max_y) / 2

        light_dir = np.array([0, 0, 1])

        for _, p1, p2, p3, idx, n_rot in tri_data:
            # ВАЖНО: как в старом коде — БЕЗ инверсии Y
            def to_screen(p):
                x = (p[0] - cx_screen) * scale_fit + sprite_size[0] / 2
                y = (p[1] - cy_screen) * scale_fit + sprite_size[1] / 2
                return (x, y)

            scr1 = to_screen(p1)
            scr2 = to_screen(p2)
            scr3 = to_screen(p3)

            # Освещение
            nlen = np.linalg.norm(n_rot)
            n = n_rot / nlen if nlen > 0 else np.array([0, 0, 1])
            diff = np.dot(n, light_dir)
            intensity = 0.3 + 0.7 * max(0.0, float(diff))

            base_color = per_face_tint[idx] if idx < len(per_face_tint) else color
            if base_color is None:
                base_color = color

            uv = per_face_uv[idx] if idx < len(per_face_uv) else None
            tex = per_face_tex[idx] if idx < len(per_face_tex) else None
            a = per_face_alpha[idx] if idx < len(per_face_alpha) else 1.0

            if tex is not None and uv is not None:
                _draw_triangle(surf, scr1, scr2, scr3,
                               uv[0], uv[1], uv[2],
                               tex, base_color, intensity, a)
            else:
                col = (int(min(255, max(0, base_color[0] * 255 * intensity))),
                       int(min(255, max(0, base_color[1] * 255 * intensity))),
                       int(min(255, max(0, base_color[2] * 255 * intensity))))
                pygame.draw.polygon(surf, col, [(scr1[0], scr1[1]),
                                                (scr2[0], scr2[1]),
                                                (scr3[0], scr3[1])])

        sprites.append(surf)

    return sprites