"""
Мультиплеер Gradus RC v2 — TCP, до 8 игроков.
Сервер авторитетен по игре. Клиент зеркалит.

Новое:
  - Лобби до старта: список игроков, команды, готовность, кнопка Start у хоста
  - Команды: blue / red / spectator
  - Наблюдатель (spectator): невидим для врагов, ходит сквозь стены,
    пули не задевают, игра его игнорирует
  - Режимы респавна: 'off' | 'seconds' | 'match'
    off      — смерть → уход в spectator
    seconds  — смерть → respawn через N секунд
    match    — смерть → respawn в следующем раунде (когда одна команда
               полностью мертва — раунд рестартует, счёт сохраняется)
  - Передача хоста при выходе owner'а (ручная через mp_transfer_host,
    авто через successor_pid, если клиенты указали public_ip)
  - LAN discovery (UDP broadcast) для поиска лобби в сети
"""
from __future__ import annotations

import socket
import threading
import json
import time
import math


DEFAULT_PORT = 50007
LAN_DISCOVERY_PORT = 50008
PROTOCOL_VERSION = 3
TICK_HZ = 30
ENEMY_SYNC_HZ = 10
OBJECTS_SYNC_HZ = 6
LOBBY_SYNC_HZ = 4
HEARTBEAT_HZ = 1.0


# ============================================================
# MESSAGES
# ============================================================

class NetworkMessage:
    def __init__(self, kind, **data):
        self.kind = kind
        self.data = data

    def encode(self):
        return (json.dumps({'k': self.kind, **self.data},
                           ensure_ascii=False) + '\n').encode('utf-8')

    @staticmethod
    def decode(raw):
        try:
            payload = json.loads(raw.decode('utf-8').strip())
            kind = payload.pop('k', None)
            return NetworkMessage(kind, **payload)
        except Exception:
            return None


# ============================================================
# REMOTE ENTITIES
# ============================================================

class RemotePlayer:
    def __init__(self, pid):
        self.pid = pid
        self.x = 0.0
        self.y = 0.0
        self.angle = 0.0
        self.pitch = 0.0
        self.hp = 100.0
        self.max_hp = 100.0
        self.ammo = 0
        self.gun = ''
        self.alive = True
        self.is_spectator = False
        self.team = None       # 'blue' | 'red' | 'spectator' | None
        self.ready = False
        self.texture = None
        self.key = f"remote_{pid}"
        self.last_update = time.time()
        self.respawn_timer = 0.0
        self.score = 0
        self.deaths = 0
        self.kills = 0


class RemoteEnemy:
    def __init__(self, key):
        self.key = key
        self.x = 0.0
        self.y = 0.0
        self.hp = 100.0
        self.max_hp = 100.0
        self.alive = True
        self.type = 'chase'
        self.texture = None
        self.world_radius = 24.0
        self.key_orig = key


class LobbyEntry:
    """Одна строка в списке лобби (для LAN discovery)."""
    def __init__(self, addr, name, players, max_players, mode, signature):
        self.addr = addr
        self.name = name
        self.players = int(players)
        self.max_players = int(max_players)
        self.mode = mode
        self.signature = signature
        self.last_seen = time.time()


# ============================================================
# MULTIPLAYER MANAGER
# ============================================================

class MultiplayerManager:
    def __init__(self, engine):
        self.engine = engine

        self.is_host = False
        self.is_client = False
        self.connected = False

        # Backend: 'tcp' | 'firebase'
        self.backend = 'tcp'
        self._fb = None
        self._fb_poll_ts = 0.0
        self._fb_lobby_info = None

        # Game state
        self.state = 'idle'          # 'idle' | 'lobby' | 'playing'
        self.match_started = False
        self.match_round = 0
        self.round_scores = {'blue': 0, 'red': 0}
        self.respawn_mode = 'seconds'  # 'off' | 'seconds' | 'match'
        self.respawn_seconds = 5.0

        # Identity
        self.signature = None
        self.mode = 'pvp'            # 'pvp' | 'coop' | 'team'
        self.my_pid = 0
        self.next_pid = 1
        self.max_players = 4
        self.lobby_name = "Gradus Server"

        # Peers
        self.server_socket = None
        self.client_socket = None
        self.peers = {}              # pid -> socket
        self.peer_addrs = {}         # pid -> (ip, port)
        self.remote_players = {}
        self.remote_enemies = []
        self.custom_data = {}
        self.data_handlers = {}

        # Players
        self.player_names = {0: "Host"}
        self.teams = {}              # pid -> 'blue' | 'red' | 'spectator'
        self.my_team = None
        self.ready_state = {}        # pid -> bool

        # Team constraints
        self.min_players_to_start = 2
        self.min_team_size = 1
        # Автоматический старт матча когда все готовы (настраивается хостом)
        self.auto_start_if_ready = True
        # Successor for host migration
        self.successor_pid = None

        # LAN discovery
        self._lan_socket = None
        self._lan_thread = None
        self._lan_stop = threading.Event()
        self.known_lobbies = {}      # addr_str -> LobbyEntry

        # Threading
        self._lock = threading.Lock()
        self._last_tick = 0.0
        self._last_enemy_sync = 0.0
        self._last_objects_sync = 0.0
        self._last_lobby_sync = 0.0
        self._last_heartbeat = 0.0

        self._cached_objects = {}

        # Respawn timers (host authority)
        self._respawn_timers = {}    # pid -> seconds_left

    # ============================================================
    # HOST
    # ============================================================

    def start_host(self, port=DEFAULT_PORT, signature="default",
                   mode='pvp', max_players=4, host_name="Host",
                   lobby_name="Gradus Server"):
        if self.connected or self.server_socket:
            return False
        self.signature = str(signature)
        self.mode = mode
        self.is_host = True
        self.my_pid = 0
        self.next_pid = 1
        self.max_players = max(1, min(8, int(max_players)))
        self.player_names = {0: str(host_name)}
        self.lobby_name = str(lobby_name)
        self.state = 'lobby'
        self.teams[0] = 'spectator'
        self.ready_state[0] = True

        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind(('0.0.0.0', int(port)))
            self.server_socket.listen(self.max_players)
        except Exception as e:
            print(f"[MP] bind fail {port}: {e}")
            self.server_socket = None
            self.is_host = False
            self.state = 'idle'
            return False

        self.connected = True
        threading.Thread(target=self._accept_loop, daemon=True).start()
        self._start_lan_beacon()
        print(f"[MP] Host up: port={port}, sig='{self.signature}', "
              f"mode={self.mode}, max={self.max_players}")
        return True

    def _accept_loop(self):
        while self.connected:
            try:
                cli, addr = self.server_socket.accept()
            except Exception:
                break
            if len(self.peers) + 1 >= self.max_players:
                try:
                    cli.sendall(NetworkMessage(
                        'reject', reason='Server full').encode())
                    cli.close()
                except Exception:
                    pass
                continue
            threading.Thread(target=self._handshake_host,
                             args=(cli, addr), daemon=True).start()

    def _handshake_host(self, cli, addr):
        cli.settimeout(5.0)
        try:
            raw = cli.recv(8192)
        except Exception:
            cli.close(); return
        msg = NetworkMessage.decode(raw)
        if msg is None or msg.kind != 'hello':
            try: cli.sendall(NetworkMessage('reject', reason='Bad hello').encode())
            except: pass
            cli.close(); return

        if msg.data.get('signature') != self.signature:
            print(f"[MP] reject: wrong sig "
                  f"('{msg.data.get('signature')}' vs '{self.signature}')")
            try:
                cli.sendall(NetworkMessage('reject',
                                           reason='Wrong signature').encode())
            except: pass
            cli.close(); return

        if msg.data.get('protocol') != PROTOCOL_VERSION:
            try:
                cli.sendall(NetworkMessage('reject',
                                           reason='Protocol mismatch').encode())
            except: pass
            cli.close(); return

        pid = self.next_pid
        self.next_pid += 1
        self.peers[pid] = cli
        self.peer_addrs[pid] = (addr[0], addr[1])
        cli.settimeout(None)
        name = str(msg.data.get('name', f'Player{pid}'))
        self.player_names[pid] = name
        self.teams[pid] = None
        self.ready_state[pid] = False

        e = self.engine
        level_text = None
        if e.levels:
            level_text = e.levels[e.current_level]

        existing = self._build_players_snapshot(exclude=pid)

        response = NetworkMessage(
            'welcome', pid=pid, mode=self.mode,
            level_text=level_text,
            host_name=self.player_names[0],
            lobby_name=self.lobby_name,
            existing_players=existing,
            teams=dict(self.teams),
            ready=dict(self.ready_state),
            respawn_mode=self.respawn_mode,
            respawn_seconds=self.respawn_seconds,
            min_players=self.min_players_to_start,
            min_team_size=self.min_team_size,
            max_players=self.max_players,
            state=self.state,
        )
        try:
            cli.sendall(response.encode())
        except Exception:
            cli.close()
            self.peers.pop(pid, None)
            self.teams.pop(pid, None)
            self.ready_state.pop(pid, None)
            return

        rp = RemotePlayer(pid)
        rp.max_hp = 100.0
        rp.team = self.teams.get(pid)
        self.remote_players[pid] = rp

        # Уведомляем остальных
        self._send_to_all(NetworkMessage(
            'player_joined', pid=pid, name=name,
            team=None, ready=False), skip_pid=pid)

        # Снимок лобби для всех
        self._broadcast_lobby_state()

        if getattr(e, 'enable_mp_messages', True) and self.state == 'lobby':
            try:
                e.toasts.push_info(f"{name} подключился",
                                   color=(100, 200, 120), duration=3.0)
            except Exception:
                pass

        threading.Thread(target=self._recv_loop,
                         args=(pid, cli), daemon=True).start()
        print(f"[MP] Player {pid} joined from {addr[0]}:{addr[1]}")

    def _build_players_snapshot(self, exclude=None):
        e = self.engine
        out = [{
            'pid': 0, 'name': self.player_names[0],
            'x': e.player.pos.x, 'y': e.player.pos.y,
            'angle': e.player.angle, 'hp': e.player.hp,
            'max_hp': e.player.max_hp,
            'team': self.teams.get(0),
            'ready': self.ready_state.get(0, True),
            'is_spectator': (self.teams.get(0) == 'spectator'),
        }]
        for p, rp in self.remote_players.items():
            if p == exclude:
                continue
            out.append({
                'pid': p, 'name': self.player_names.get(p, f'P{p}'),
                'x': rp.x, 'y': rp.y, 'angle': rp.angle,
                'hp': rp.hp, 'max_hp': rp.max_hp,
                'team': self.teams.get(p),
                'ready': self.ready_state.get(p, False),
                'is_spectator': (self.teams.get(p) == 'spectator'),
            })
        return out

    # ============================================================
    # CLIENT
    # ============================================================

    def connect(self, ip, port=DEFAULT_PORT, signature="default",
                timeout=5.0, name=None):
        if self.connected or self.client_socket:
            return False
        self.signature = str(signature)
        self.is_client = True
        if name is None:
            name = 'Player'

        try:
            self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.client_socket.settimeout(timeout)
            self.client_socket.connect((ip, int(port)))
        except Exception as e:
            print(f"[MP] connect fail {ip}:{port}: {e}")
            self.client_socket = None
            self.is_client = False
            return False

        try:
            self.client_socket.sendall(NetworkMessage(
                'hello', protocol=PROTOCOL_VERSION,
                signature=self.signature, name=name).encode())
            raw = self.client_socket.recv(65536)
            msg = NetworkMessage.decode(raw)
            if msg is None or msg.kind == 'reject':
                reason = msg.data.get('reason', '?') if msg else 'no response'
                print(f"[MP] rejected: {reason}")
                self.client_socket.close()
                self.client_socket = None
                self.is_client = False
                return False
            if msg.kind != 'welcome':
                print(f"[MP] unexpected: {msg.kind}")
                self.client_socket.close()
                self.client_socket = None
                self.is_client = False
                return False

            self.my_pid = msg.data.get('pid', 1)
            self.mode = msg.data.get('mode', 'pvp')
            self.connected = True
            self.max_players = msg.data.get('max_players', 4)
            self.player_names[0] = msg.data.get('host_name', 'Host')
            self.player_names[self.my_pid] = name
            self.lobby_name = msg.data.get('lobby_name', 'Gradus Server')
            self.respawn_mode = msg.data.get('respawn_mode', 'seconds')
            self.respawn_seconds = float(msg.data.get('respawn_seconds', 5.0))
            self.min_players_to_start = int(msg.data.get('min_players', 2))
            self.min_team_size = int(msg.data.get('min_team_size', 1))

            # Команды и готовность
            for k, v in (msg.data.get('teams', {}) or {}).items():
                try:
                    self.teams[int(k)] = v
                except (TypeError, ValueError):
                    pass
            for k, v in (msg.data.get('ready', {}) or {}).items():
                try:
                    self.ready_state[int(k)] = bool(v)
                except (TypeError, ValueError):
                    pass

            # Загружаем уровень
            level_text = msg.data.get('level_text')
            if level_text:
                try:
                    self.engine.levels = [level_text]
                    self.engine.current_level = 0
                    self.engine.load_level(0)
                    self.engine.enemies = []
                except Exception as ex:
                    print(f"[MP] level load fail: {ex}")

            # Прочие игроки
            for p in msg.data.get('existing_players', []):
                pid = int(p['pid'])
                if pid == self.my_pid:
                    continue
                rp = RemotePlayer(pid)
                rp.x = float(p['x'])
                rp.y = float(p['y'])
                rp.angle = float(p['angle'])
                rp.hp = float(p.get('hp', 100))
                rp.max_hp = float(p.get('max_hp', 100))
                rp.team = p.get('team')
                rp.ready = bool(p.get('ready', False))
                rp.is_spectator = bool(p.get('is_spectator', False))
                self.remote_players[pid] = rp
                self.player_names[pid] = p.get('name', f'P{pid}')

            self.state = msg.data.get('state', 'lobby')
            self.match_started = (self.state == 'playing')

            self.client_socket.settimeout(None)
            threading.Thread(target=self._recv_loop,
                             args=(self.my_pid, self.client_socket),
                             daemon=True).start()
            print(f"[MP] Connected to {ip}:{port}, pid={self.my_pid}")
            return True

        except Exception as e:
            print(f"[MP] handshake fail: {e}")
            try: self.client_socket.close()
            except: pass
            self.client_socket = None
            self.is_client = False
            return False

    # ============================================================
    # RECV
    # ============================================================

    def _recv_loop(self, pid, sock):
        buf = b''
        while self.connected:
            try:
                chunk = sock.recv(16384)
            except Exception:
                break
            if not chunk:
                break
            buf += chunk
            while b'\n' in buf:
                raw, buf = buf.split(b'\n', 1)
                msg = NetworkMessage.decode(raw)
                if msg is not None:
                    self._handle_message(pid, msg)
        self._on_disconnect(pid)

    def _handle_message(self, from_pid, msg):
        e = self.engine
        k = msg.kind

        if k == 'state':
            with self._lock:
                rp = self.remote_players.get(from_pid)
                if rp is None:
                    rp = RemotePlayer(from_pid)
                    self.remote_players[from_pid] = rp
                rp.x = float(msg.data.get('x', rp.x))
                rp.y = float(msg.data.get('y', rp.y))
                rp.angle = float(msg.data.get('angle', rp.angle))
                rp.pitch = float(msg.data.get('pitch', 0))
                rp.hp = float(msg.data.get('hp', rp.hp))
                rp.max_hp = float(msg.data.get('max_hp', rp.max_hp))
                rp.ammo = int(msg.data.get('ammo', 0))
                rp.gun = msg.data.get('gun', '')
                rp.alive = bool(msg.data.get('alive', True))
                rp.is_spectator = bool(msg.data.get('is_spectator', False))
                rp.team = msg.data.get('team', rp.team)
                rp.respawn_timer = float(msg.data.get('respawn_timer', 0))
                rp.score = int(msg.data.get('score', rp.score))
                rp.kills = int(msg.data.get('kills', rp.kills))
                rp.deaths = int(msg.data.get('deaths', rp.deaths))
                rp.last_update = time.time()

        elif k == 'enemies':
            data = msg.data.get('list', [])
            if not hasattr(self, '_enemy_tex_cache'):
                self._enemy_tex_cache = {}
            new_list = []
            for ed in data:
                key = str(ed.get('key', '?'))
                re = RemoteEnemy(key)
                re.x = float(ed.get('x', 0))
                re.y = float(ed.get('y', 0))
                re.hp = float(ed.get('hp', 100))
                re.max_hp = float(ed.get('max_hp', re.hp))
                re.alive = bool(ed.get('alive', True))
                re.type = ed.get('type', 'chase')
                sprite = ed.get('sprite')
                if sprite:
                    if sprite not in self._enemy_tex_cache:
                        try:
                            from .image.cache import load_image
                            self._enemy_tex_cache[sprite] = load_image(
                                sprite, sprite, size=(64, 64))
                        except Exception:
                            self._enemy_tex_cache[sprite] = None
                    re.texture = self._enemy_tex_cache[sprite]
                new_list.append(re)
            self.remote_enemies = new_list

        elif k == 'objects':
            data = msg.data.get('list', [])
            for od in data:
                key = od.get('key')
                if not key:
                    continue
                self._cached_objects[key] = (float(od.get('x', 0)),
                                              float(od.get('y', 0)))
            for key, (x, y) in self._cached_objects.items():
                obj = e.interactive_objects.get(key)
                if obj:
                    obj.x = x
                    obj.y = y

        elif k == 'player_joined':
            p = int(msg.data.get('pid', 0))
            if p != self.my_pid and p not in self.remote_players:
                self.remote_players[p] = RemotePlayer(p)
                self.player_names[p] = msg.data.get('name', f'P{p}')
                if getattr(e, 'enable_mp_messages', True):
                    try:
                        e.toasts.push_info(
                            f"{self.player_names[p]} подключился",
                            color=(100, 200, 120), duration=3.0)
                    except Exception:
                        pass

        elif k == 'player_left':
            p = int(msg.data.get('pid', 0))
            self.remote_players.pop(p, None)
            if getattr(e, 'enable_mp_messages', True):
                nm = self.player_names.get(p, f'P{p}')
                try:
                    e.toasts.push_info(f"{nm} вышел",
                                        color=(220, 120, 120), duration=3.0)
                except Exception:
                    pass
            self.player_names.pop(p, None)

        elif k == 'shot':
            try:
                from .gun import Bullet
                b = Bullet(
                    float(msg.data.get('x', 0)),
                    float(msg.data.get('y', 0)),
                    float(msg.data.get('angle', 0)),
                    damage=float(msg.data.get('damage', 10)),
                    speed=800, owner='remote',
                    explosive=False,
                    explosion_radius=0.0,
                    explosion_damage=0.0)
                e.bullets.append(b)
            except Exception as ex:
                print(f"[MP] shot fail: {ex}")

        elif k == 'damage':
            target = int(msg.data.get('target', -1))
            if target == self.my_pid and self.is_client:
                if self.mode == 'coop':
                    return
                if self.mode == 'team':
                    source = int(msg.data.get('source', -1))
                    my_t = self.teams.get(self.my_pid)
                    src_t = self.teams.get(source)
                    if my_t is not None and my_t == src_t and my_t != 'spectator':
                        return
                dmg = float(msg.data.get('amount', 0))
                e.player.take_damage(dmg)

        elif k == 'team_assigned':
            p = int(msg.data.get('pid', -1))
            t = msg.data.get('team')
            self.teams[p] = t
            if p == self.my_pid:
                self.my_team = t
                # Если стал spectator — перевести игрока в spectator mode
                self.engine.set_spectator_mode(t == 'spectator')
            if p in self.remote_players:
                self.remote_players[p].team = t
                self.remote_players[p].is_spectator = (t == 'spectator')
            if getattr(e, 'enable_mp_messages', True) and p != self.my_pid:
                try:
                    nm = self.player_names.get(p, f'P{p}')
                    e.toasts.push_info(
                        f"{nm} → {t or 'без команды'}",
                        color=(100, 150, 220), duration=2.0)
                except Exception:
                    pass

        elif k == 'ready_changed':
            p = int(msg.data.get('pid', -1))
            r = bool(msg.data.get('ready', False))
            self.ready_state[p] = r
            if p in self.remote_players:
                self.remote_players[p].ready = r

        elif k == 'lobby_state':
            # Хост переслал обновлённое состояние
            for kk, vv in (msg.data.get('teams', {}) or {}).items():
                try:
                    self.teams[int(kk)] = vv
                except (TypeError, ValueError):
                    pass
            for kk, vv in (msg.data.get('ready', {}) or {}).items():
                try:
                    self.ready_state[int(kk)] = bool(vv)
                except (TypeError, ValueError):
                    pass
            self.min_players_to_start = int(msg.data.get('min_players', self.min_players_to_start))
            self.min_team_size = int(msg.data.get('min_team_size', self.min_team_size))
            self.respawn_mode = msg.data.get('respawn_mode', self.respawn_mode)
            self.respawn_seconds = float(msg.data.get('respawn_seconds', self.respawn_seconds))
            self.round_scores = dict(msg.data.get('round_scores', self.round_scores))
            self.match_round = int(msg.data.get('round', self.match_round))

        elif k == 'match_start':
            self.match_started = True
            self.state = 'playing'
            if getattr(e, 'enable_mp_messages', True):
                try:
                    e.toasts.push_info(
                        "Матч начался!",
                        description="Удачи!",
                        color=(120, 220, 120), duration=3.0)
                except Exception:
                    pass

        elif k == 'round_start':
            self.match_round = int(msg.data.get('round', 1))
            self.round_scores = dict(msg.data.get('scores', self.round_scores))
            # Респавн всех в начале раунда
            try:
                self.engine.respawn_all_players()
            except Exception:
                pass
            if getattr(e, 'enable_mp_messages', True):
                try:
                    e.toasts.push_info(
                        f"Раунд {self.match_round}",
                        description=f"Синие {self.round_scores.get('blue', 0)}"
                                    f" — {self.round_scores.get('red', 0)} Красные",
                        color=(180, 200, 255), duration=3.0)
                except Exception:
                    pass

        elif k == 'spectator_switch':
            # Хост переключил игрока в наблюдателя
            p = int(msg.data.get('pid', -1))
            sp = bool(msg.data.get('is_spectator', False))
            if p == self.my_pid:
                self.engine.set_spectator_mode(sp)
            if p in self.remote_players:
                self.remote_players[p].is_spectator = sp

        elif k == 'event':
            name = msg.data.get('name', '')
            who = msg.data.get('who', '?')
            if name == 'key_pickup':
                kid = msg.data.get('key_id')
                if kid and kid in e.keys and not e.keys[kid]['collected']:
                    e.keys[kid]['collected'] = True
                    sk = e.keys[kid].get('sprite_key')
                    if sk:
                        try:
                            e.sprite_manager.remove_by_key(sk)
                        except Exception:
                            pass
                    for did in e.keys[kid].get('linked_doors', []):
                        try:
                            e.api.open_door(did)
                        except Exception:
                            pass
            elif name == 'door_open':
                did = msg.data.get('door_id')
                try:
                    e.api.open_door(did)
                except Exception:
                    pass
            elif name == 'player_death':
                if getattr(e, 'enable_mp_messages', True):
                    try:
                        e.toasts.push_info(f"{who} погиб",
                                           color=(220, 80, 80),
                                           duration=2.5)
                    except Exception:
                        pass
            elif name == 'message':
                if getattr(e, 'enable_mp_messages', True):
                    try:
                        e.toasts.push_info(
                            msg.data.get('title', ''),
                            description=msg.data.get('text', ''),
                            color=(150, 180, 220), duration=3.0)
                    except Exception:
                        pass

        elif k == 'data':
            key = msg.data.get('key')
            value = msg.data.get('value')
            self.custom_data[key] = value
            for cb in self.data_handlers.get(key, []):
                try:
                    cb(value)
                except Exception as ex:
                    print(f"[MP] data cb '{key}': {ex}")

        elif k == 'kick':
            reason = msg.data.get('reason', 'Kicked')
            print(f"[MP] kicked: {reason}")
            try:
                e.toasts.push_info("Вас исключили", description=reason,
                                   color=(220, 80, 80), duration=5.0)
            except Exception:
                pass
            self.disconnect()

    def _on_disconnect(self, pid):
        if self.is_host:
            self.peers.pop(pid, None)
            self.peer_addrs.pop(pid, None)
            self.remote_players.pop(pid, None)
            self.teams.pop(pid, None)
            self.ready_state.pop(pid, None)
            self._respawn_timers.pop(pid, None)
            self._send_to_all(NetworkMessage('player_left', pid=pid))
            self._broadcast_lobby_state()
            print(f"[MP] Player {pid} disconnected")
        else:
            if self.connected:
                print("[MP] Connection lost")
                self.disconnect()

    # ============================================================
    # SEND
    # ============================================================

    def _send_to_all(self, msg, skip_pid=None):
        raw = msg.encode()
        for pid, sock in list(self.peers.items()):
            if pid == skip_pid:
                continue
            try:
                sock.sendall(raw)
            except Exception:
                pass

    def _send_to_host(self, msg):
        if self.client_socket:
            try:
                self.client_socket.sendall(msg.encode())
            except Exception:
                pass

    def broadcast(self, msg):
        if self.is_host:
            self._send_to_all(msg)
        elif self.is_client:
            self._send_to_host(msg)

    def _broadcast_lobby_state(self):
        if not self.is_host:
            return
        self._send_to_all(NetworkMessage(
            'lobby_state',
            teams=dict(self.teams),
            ready=dict(self.ready_state),
            min_players=self.min_players_to_start,
            min_team_size=self.min_team_size,
            respawn_mode=self.respawn_mode,
            respawn_seconds=self.respawn_seconds,
            round_scores=dict(self.round_scores),
            round=self.match_round))

    # ============================================================
    # UPDATE
    # ============================================================

    # ============================================================
    # FIREBASE BACKEND
    # ============================================================
    def start_firebase_host(self, account_json, base_path="/gradus_mp",
                            lobby_name="Gradus Server", host_name="Host",
                            password=None, max_players=4, mode='pvp',
                            database_url=None):
        from .multiplayer_firebase import FirebaseLobbyClient
        self.backend = 'firebase'
        try:
            self._fb = FirebaseLobbyClient(
                account_json_path=account_json,
                base_path=base_path,
                database_url=database_url)
        except Exception as e:
            print(f"[MP][FB] init fail: {e}")
            self.backend = 'tcp'
            return False
        lid = self._fb.create_lobby(
            name=lobby_name, host_name=host_name, password=password,
            max_players=max_players, mode=mode)
        if not lid:
            self.backend = 'tcp'
            return False
        self.lobby_name = lobby_name
        self.mode = mode
        self.max_players = max_players
        self.is_host = True
        self.is_client = False
        self.connected = True
        self.state = 'lobby'
        self.my_pid = 0
        self.player_names = {0: host_name}
        self.teams = {0: 'spectator'}
        self.ready_state = {0: True}
        self._fb.start_lobby_listener(self._on_fb_lobby_change)
        print(f"[MP][FB] Host up: {lid} ({mode})")
        return True

    def start_firebase_client(self, account_json, lobby_id,
                              player_name="Player", password=None,
                              base_path="/gradus_mp", database_url=None):
        from .multiplayer_firebase import FirebaseLobbyClient
        self.backend = 'firebase'
        try:
            self._fb = FirebaseLobbyClient(
                account_json_path=account_json,
                base_path=base_path,
                database_url=database_url)
        except Exception as e:
            print(f"[MP][FB] init fail: {e}")
            self.backend = 'tcp'
            return False, "init fail"
        ok, msg = self._fb.join_lobby(lobby_id, player_name=player_name,
                                      password=password)
        if not ok:
            self.backend = 'tcp'
            return False, msg
        info = self._fb.get_lobby_state() or {}
        self.lobby_name = info.get('name', 'Lobby')
        self.mode = info.get('mode', 'pvp')
        self.max_players = int(info.get('max_players', 4))
        self.is_host = False
        self.is_client = True
        self.connected = True
        self.state = 'lobby'
        self._fb.start_lobby_listener(self._on_fb_lobby_change)
        print(f"[MP][FB] Connected to {lobby_id}")
        return True, "OK"

    def list_firebase_lobbies(self, account_json, base_path="/gradus_mp",
                              database_url=None):
        from .multiplayer_firebase import FirebaseLobbyClient
        try:
            fb = FirebaseLobbyClient(
                account_json_path=account_json,
                base_path=base_path,
                database_url=database_url)
            return fb.list_lobbies()
        except Exception as e:
            print(f"[MP][FB] list fail: {e}")
            return []

    def _on_fb_lobby_change(self, event, obj):
        """Callback от SSE."""
        state = self._fb.get_lobby_state() if self._fb else None
        if state:
            self._fb_lobby_info = state
            # Обновим teams/ready по состоянию
            players = state.get('players', {}) or {}
            teams, ready, names = {}, {}, {}
            my_pid_str = self._fb.player_id
            pid_map = {pid: i for i, pid in enumerate(players.keys())}
            self.my_pid = pid_map.get(my_pid_str, 0)
            for pid_str, p in players.items():
                idx = pid_map.get(pid_str, 0)
                teams[idx] = p.get('team')
                ready[idx] = bool(p.get('ready'))
                names[idx] = p.get('name', f'P{idx}')
            self.teams = teams
            self.ready_state = ready
            self.player_names = names
            self.my_team = teams.get(self.my_pid)

    def _update_firebase(self, dt):
        """Heartbeat + polling event messages + sync team."""
        if not self._fb:
            return
        now = time.time()
        # Heartbeat раз в 3 сек
        if now - getattr(self, '_fb_last_hb', 0) > 3.0:
            self._fb_last_hb = now
            self._fb.heartbeat()
            if self.is_host:
                self._fb.set_lobby_state(self.state)

        # Update own state раз в 5 кадров
        if now - getattr(self, '_fb_last_state', 0) > 0.15:
            self._fb_last_state = now
            e = self.engine
            p = e.player
            self._fb.update_player_state(
                x=p.pos.x, y=p.pos.y, angle=p.angle,
                hp=p.hp, max_hp=p.max_hp,
                alive=getattr(p, 'alive', True),
                is_spectator=getattr(p, 'is_spectator', False),
                team=getattr(p, 'team', None),
            )

        # Poll events (быстрое обновление только новых)
        msgs, new_ts = self._fb.poll_messages(self._fb_poll_ts)
        self._fb_poll_ts = max(self._fb_poll_ts, new_ts)
        for m in msgs:
            self._handle_fb_event(m)

        # Хост чистит мусор раз в 10 сек
        if self.is_host and now - getattr(self, '_fb_last_cleanup', 0) > 10.0:
            self._fb_last_cleanup = now
            threading.Thread(
                target=self._fb.cleanup_messages, args=(30.0,),
                daemon=True).start()

    def _handle_fb_event(self, m):
        kind = m.get('kind')
        data = m.get('data', {})
        e = self.engine
        if kind == 'state':
            pid = data.get('pid')
            if pid is None or pid == self.my_pid:
                return
            rp = self.remote_players.get(pid)
            if rp is None:
                rp = RemotePlayer(pid)
                self.remote_players[pid] = rp
            for k in ('x', 'y', 'angle', 'pitch', 'hp', 'max_hp',
                      'respawn_timer', 'score', 'kills', 'deaths'):
                if k in data:
                    setattr(rp, k, float(data[k]))
            rp.alive = bool(data.get('alive', True))
            rp.is_spectator = bool(data.get('is_spectator', False))
            rp.team = data.get('team')
            rp.last_update = time.time()
        elif kind == 'shot':
            try:
                from .gun import Bullet
                e.bullets.append(Bullet(
                    float(data.get('x', 0)), float(data.get('y', 0)),
                    float(data.get('angle', 0)),
                    damage=float(data.get('damage', 10)),
                    speed=800, owner='remote'))
            except Exception:
                pass
        elif kind == 'event':
            name = data.get('name')
            if name == 'key_pickup':
                kid = data.get('key_id')
                if kid and kid in e.keys and not e.keys[kid]['collected']:
                    e.keys[kid]['collected'] = True
                    sk = e.keys[kid].get('sprite_key')
                    if sk:
                        try:
                            e.sprite_manager.remove_by_key(sk)
                        except Exception:
                            pass
                    for did in e.keys[kid].get('linked_doors', []):
                        try:
                            e.api.open_door(did)
                        except Exception:
                            pass
            elif name == 'door_open':
                try:
                    e.api.open_door(data.get('door_id'))
                except Exception:
                    pass

    # ---- Унифицированные обёртки для API, работают и через TCP, и через FB ----
    def fb_set_my_team(self, team):
        if self.backend == 'firebase' and self._fb:
            self._fb.update_player_state(team=team,
                                         is_spectator=(team == 'spectator'))
            self.teams[self.my_pid] = team
            self.my_team = team
            self.engine.set_spectator_mode(team == 'spectator')
            return True
        return self.set_team(self.my_pid, team)

    def fb_set_ready(self, ready):
        if self.backend == 'firebase' and self._fb:
            self._fb.update_player_state(ready=bool(ready))
            self.ready_state[self.my_pid] = bool(ready)
            return True
        self.set_ready(ready)
        return True

    def fb_start_match(self):
        if self.backend != 'firebase' or not self._fb:
            return self.start_match()
        if not self.is_host:
            return False
        ok, reason = self.is_ready_to_start()
        if not ok:
            print(f"[MP][FB] start failed: {reason}")
            return False
        self.state = 'playing'
        self.match_started = True
        self._fb.set_lobby_state('playing')
        self._fb.send_message('event', {'name': 'match_start'})
        return True

    def update(self, dt):
        if not self.connected:
            return
        now = time.time()
        e = self.engine

        if self.backend == 'firebase':
            self._update_firebase(dt)
            return

        # Своё состояние (все шлют своё)
        if now - self._last_tick >= 1.0 / TICK_HZ:
            self._last_tick = now
            cur_gun = e.gun_manager.get_current_gun()
            ammo = cur_gun.ammo if cur_gun else 0
            gun_key = cur_gun.key if cur_gun else ''
            my_team = self.teams.get(self.my_pid)
            is_spec = (my_team == 'spectator') or getattr(e.player, 'is_spectator', False)
            msg = NetworkMessage(
                'state', pid=self.my_pid,
                x=e.player.pos.x, y=e.player.pos.y,
                angle=e.player.angle,
                pitch=getattr(e.player, 'pitch', 0.0),
                hp=e.player.hp, max_hp=e.player.max_hp,
                ammo=ammo, gun=gun_key,
                alive=e.player.alive,
                is_spectator=is_spec,
                team=my_team,
                respawn_timer=getattr(e.player, 'respawn_timer', 0.0),
                score=getattr(e.player, 'score', 0),
                kills=getattr(e.player, 'kills', 0),
                deaths=getattr(e.player, 'deaths', 0))
            self.broadcast(msg)

        # Лобби-синк у хоста
        if self.is_host and self.state == 'lobby' and \
                now - self._last_lobby_sync >= 1.0 / LOBBY_SYNC_HZ:
            self._last_lobby_sync = now
            self._broadcast_lobby_state()

        # Враги у хоста
        if self.is_host and self.state == 'playing' and \
                now - self._last_enemy_sync >= 1.0 / ENEMY_SYNC_HZ:
            self._last_enemy_sync = now
            list_data = []
            for en in e.enemies:
                list_data.append({
                    'key': getattr(en, 'key', None) or f"enemy_{id(en)}",
                    'x': en.x, 'y': en.y,
                    'hp': en.hp, 'max_hp': getattr(en, 'max_hp', 100),
                    'alive': en.alive,
                    'type': getattr(en, 'type', 'chase'),
                    'sprite': getattr(en, 'sprite_path', None),
                })
            msg = NetworkMessage('enemies', list=list_data).encode()
            for pid, sock in list(self.peers.items()):
                try:
                    sock.sendall(msg)
                except Exception:
                    pass

        # Толкаемые объекты
        if self.is_host and self.state == 'playing' and \
                now - self._last_objects_sync >= 1.0 / OBJECTS_SYNC_HZ:
            self._last_objects_sync = now
            obj_list = []
            for key, obj in e.interactive_objects.items():
                if getattr(obj, 'pushable', False):
                    obj_list.append({
                        'key': key,
                        'x': obj.x, 'y': obj.y,
                    })
            if obj_list:
                msg = NetworkMessage('objects', list=obj_list).encode()
                for pid, sock in list(self.peers.items()):
                    try:
                        sock.sendall(msg)
                    except Exception:
                        pass

        # Респавны (только хост)
        if self.is_host and self.state == 'playing' and \
                self.respawn_mode == 'seconds':
            for pid in list(self._respawn_timers.keys()):
                self._respawn_timers[pid] -= dt
                if self._respawn_timers[pid] <= 0:
                    self._respawn_timers.pop(pid, None)
                    self._respawn_player(pid)

        # Автоматч (если настроен)
        if self.is_host and self.state == 'lobby' and self.auto_start_if_ready:
            ok, _ = self.is_ready_to_start()
            if ok:
                self.start_match()

    # ============================================================
    # TEAM / READY / LOBBY
    # ============================================================

    def set_team(self, pid, team):
        """Установить команду игрока."""
        if team not in (None, 'blue', 'red', 'spectator'):
            return False
        if not self.is_host:
            # Клиент может менять только свою команду
            if pid != self.my_pid:
                return False
            self._send_to_host(NetworkMessage('team_change',
                                              pid=pid, team=team))
            self.teams[pid] = team
            self.my_team = team
            self.engine.set_spectator_mode(team == 'spectator')
            return True

        # Хост-авторитет
        self.teams[pid] = team
        if pid == self.my_pid:
            self.my_team = team
            self.engine.set_spectator_mode(team == 'spectator')
        self._send_to_all(NetworkMessage('team_assigned', pid=pid, team=team))
        self._broadcast_lobby_state()
        return True

    def set_ready(self, ready):
        self.ready_state[self.my_pid] = bool(ready)
        if self.is_host:
            self._broadcast_lobby_state()
        else:
            self._send_to_host(NetworkMessage('ready_changed',
                                              pid=self.my_pid,
                                              ready=bool(ready)))

    def get_team(self, pid):
        return self.teams.get(pid)

    def get_team_players(self, team):
        return [pid for pid, t in self.teams.items() if t == team]

    def get_all_teams_info(self):
        return {
            'blue': self.get_team_players('blue'),
            'red': self.get_team_players('red'),
            'spectator': self.get_team_players('spectator'),
        }

    def is_ready_to_start(self):
        n = 1 + len(self.peers)
        if n < self.min_players_to_start:
            return False, f"Нужно {self.min_players_to_start} игроков (сейчас {n})"
        if self.mode == 'team' and self.min_team_size > 0:
            blue = len(self.get_team_players('blue'))
            red = len(self.get_team_players('red'))
            if blue < self.min_team_size or red < self.min_team_size:
                return False, (f"Нужно {self.min_team_size} в каждой команде "
                               f"(синие: {blue}, красные: {red})")
        # Проверка готовности (кроме spectator)
        not_ready = [p for p, r in self.ready_state.items()
                     if not r and self.teams.get(p) != 'spectator']
        if not_ready:
            return False, f"Не готовы: {len(not_ready)}"
        return True, "Готов"

    def start_match(self):
        if not self.is_host:
            return False
        ok, reason = self.is_ready_to_start()
        if not ok:
            print(f"[MP] start failed: {reason}")
            return False
        self.state = 'playing'
        self.match_started = True
        self.match_round = 1
        self.round_scores = {'blue': 0, 'red': 0}
        self._send_to_all(NetworkMessage('match_start'))
        self._send_to_all(NetworkMessage(
            'round_start', round=1, scores=self.round_scores))
        return True

    # ============================================================
    # RESPAWN
    # ============================================================

    def on_player_death(self, pid):
        """Хост вызывает при смерти игрока. Возвращает действие."""
        if pid not in self.remote_players and pid != 0:
            return None
        self._respawn_timers.pop(pid, None)
        if self.respawn_mode == 'off':
            # Уходим в spectator
            self.set_team(pid, 'spectator')
            self._send_to_all(NetworkMessage(
                'spectator_switch', pid=pid, is_spectator=True))
        elif self.respawn_mode == 'seconds':
            self._respawn_timers[pid] = self.respawn_seconds
        elif self.respawn_mode == 'match':
            # Смотрим, вымерла ли одна из команд
            self._check_round_end()

    def _respawn_player(self, pid):
        """Хост: респавн игрока."""
        if pid == 0:
            # Хост
            team = self.teams.get(0)
            if team in ('blue', 'red'):
                sx, sy = self.engine.get_team_spawn(team)
                self.engine.player.pos.x = sx
                self.engine.player.pos.y = sy
                self.engine.player.hp = self.engine.player.max_hp
                self.engine.player.alive = True
            return
        rp = self.remote_players.get(pid)
        if rp is None:
            return
        team = self.teams.get(pid)
        if team in ('blue', 'red'):
            sx, sy = self.engine.get_team_spawn(team)
            rp.x, rp.y = sx, sy
            rp.hp = rp.max_hp
            rp.alive = True

    def _check_round_end(self):
        """Проверка, закончился ли раунд (одна команда вся мертва)."""
        alive_blue = 0
        alive_red = 0
        for pid, team in self.teams.items():
            if team == 'blue':
                alive = self._is_player_alive(pid)
                if alive:
                    alive_blue += 1
            elif team == 'red':
                alive = self._is_player_alive(pid)
                if alive:
                    alive_red += 1
        if alive_blue == 0 and alive_red > 0:
            self.round_scores['red'] += 1
            self._start_new_round()
        elif alive_red == 0 and alive_blue > 0:
            self.round_scores['blue'] += 1
            self._start_new_round()

    def _is_player_alive(self, pid):
        if pid == 0:
            return self.engine.player.alive
        rp = self.remote_players.get(pid)
        return rp.alive if rp else False

    def _start_new_round(self):
        self.match_round += 1
        self._send_to_all(NetworkMessage(
            'round_start', round=self.match_round,
            scores=dict(self.round_scores)))
        # Респавн всех
        for pid, team in self.teams.items():
            if team in ('blue', 'red'):
                self._respawn_player(pid)

    # ============================================================
    # HOST MIGRATION
    # ============================================================

    def set_successor(self, pid):
        """Назначить следующего хоста. None — отключить."""
        if not self.is_host:
            return False
        self.successor_pid = pid
        # Сообщаем всем
        self._send_to_all(NetworkMessage('successor_set', pid=pid))
        return True

    def _on_host_lost(self):
        """Клиент: хост отвалился. Если я successor — становлюсь хостом."""
        if self.is_host:
            return
        if self.my_pid == self.successor_pid:
            print("[MP] Я — новый хост. Пробую подняться.")
            # Закрываем клиентский сокет
            try:
                if self.client_socket:
                    self.client_socket.close()
            except Exception:
                pass
            self.client_socket = None
            was_signature = self.signature
            was_mode = self.mode
            was_max = self.max_players
            was_name = self.player_names.get(self.my_pid, "Host")
            self.is_client = False
            self.connected = False
            # Стартуем как хост на том же порту
            ok = self.start_host(
                port=DEFAULT_PORT, signature=was_signature,
                mode=was_mode, max_players=was_max,
                host_name=was_name, lobby_name=self.lobby_name)
            if ok:
                # Перешлём свой pid как 0 (host)
                self.my_pid = 0
                self.teams[0] = self.teams.pop(self.my_pid, 'red')
                try:
                    self.engine.toasts.push_info(
                        "Вы — новый хост",
                        description="Дождитесь переподключения игроков",
                        color=(120, 220, 120), duration=5.0)
                except Exception:
                    pass
        else:
            try:
                self.engine.toasts.push_info(
                    "Хост отвалился",
                    description="Ждём переподключения",
                    color=(220, 120, 120), duration=5.0)
            except Exception:
                pass
            self.disconnect()

    # ============================================================
    # LAN DISCOVERY
    # ============================================================

    def _start_lan_beacon(self):
        if self._lan_socket is not None:
            return
        try:
            self._lan_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self._lan_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._lan_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            self._lan_socket.settimeout(0.5)
            self._lan_stop.clear()
            self._lan_thread = threading.Thread(
                target=self._lan_loop, daemon=True)
            self._lan_thread.start()
        except Exception as e:
            print(f"[MP LAN] start fail: {e}")
            self._lan_socket = None

    def _lan_loop(self):
        """Хост шлёт beacon, слушает requests."""
        beacon_interval = 1.0
        last_beacon = 0.0
        while not self._lan_stop.is_set():
            now = time.time()
            # Шлём beacon если хост
            if self.is_host and self.state == 'lobby' and \
                    now - last_beacon >= beacon_interval:
                last_beacon = now
                try:
                    payload = json.dumps({
                        'kind': 'lobby_beacon',
                        'name': self.lobby_name,
                        'players': 1 + len(self.peers),
                        'max': self.max_players,
                        'mode': self.mode,
                        'signature': self.signature,
                    }).encode('utf-8')
                    self._lan_socket.sendto(
                        payload, ('<broadcast>', LAN_DISCOVERY_PORT))
                except Exception:
                    pass
            # Слушаем
            try:
                data, addr = self._lan_socket.recvfrom(4096)
                if not data:
                    continue
                msg = json.loads(data.decode('utf-8'))
                if msg.get('kind') == 'lobby_beacon':
                    key = f"{addr[0]}:{DEFAULT_PORT}"
                    self.known_lobbies[key] = LobbyEntry(
                        addr=(addr[0], DEFAULT_PORT),
                        name=msg.get('name', 'Lobby'),
                        players=msg.get('players', 0),
                        max_players=msg.get('max', 4),
                        mode=msg.get('mode', 'pvp'),
                        signature=msg.get('signature', ''),
                    )
                elif msg.get('kind') == 'lobby_discover':
                    # Кто-то ищет — если мы хост, ответим beacon
                    if self.is_host and self.state == 'lobby':
                        try:
                            payload = json.dumps({
                                'kind': 'lobby_beacon',
                                'name': self.lobby_name,
                                'players': 1 + len(self.peers),
                                'max': self.max_players,
                                'mode': self.mode,
                                'signature': self.signature,
                            }).encode('utf-8')
                            self._lan_socket.sendto(
                                payload, (addr[0], LAN_DISCOVERY_PORT))
                        except Exception:
                            pass
            except socket.timeout:
                continue
            except Exception:
                continue
        try:
            self._lan_socket.close()
        except Exception:
            pass

    def request_lan_scan(self):
        """Клиент: попросить у сети список лобби."""
        if self._lan_socket is None:
            self._start_lan_beacon()
        if self._lan_socket is None:
            return
        try:
            payload = json.dumps({'kind': 'lobby_discover'}).encode('utf-8')
            self._lan_socket.sendto(
                payload, ('<broadcast>', LAN_DISCOVERY_PORT))
        except Exception as e:
            print(f"[MP LAN] scan fail: {e}")

    def get_lan_lobbies(self):
        """Список найденных лобби."""
        now = time.time()
        # Отсеиваем старые (>5 сек без beacon)
        for key in list(self.known_lobbies.keys()):
            if now - self.known_lobbies[key].last_seen > 5.0:
                del self.known_lobbies[key]
        return list(self.known_lobbies.values())

    # ============================================================
    # PUBLIC API
    # ============================================================

    def disconnect(self):
        if not self.connected and not self.server_socket and not self.client_socket:
            return
        self.connected = False
        self._lan_stop.set()
        try:
            if self.client_socket: self.client_socket.close()
        except Exception: pass
        try:
            if self.server_socket: self.server_socket.close()
        except Exception: pass
        for sock in self.peers.values():
            try: sock.close()
            except Exception: pass
        self.client_socket = None
        self.server_socket = None
        self.peers.clear()
        self.peer_addrs.clear()
        self.remote_players.clear()
        self.remote_enemies.clear()
        self.teams.clear()
        self.ready_state.clear()
        self._respawn_timers.clear()
        self.is_host = False
        self.is_client = False
        self.state = 'idle'
        self.match_started = False
        print("[MP] Disconnected")

    def is_connected(self):
        return self.connected

    def get_remote_players(self):
        return list(self.remote_players.values())

    def get_remote_enemies(self):
        return list(self.remote_enemies)

    def set_data(self, key, value):
        key = str(key)
        self.custom_data[key] = value
        self.broadcast(NetworkMessage('data', key=key, value=value))

    def get_data(self, key, default=None):
        return self.custom_data.get(key, default)

    def on_data(self, key, callback):
        key = str(key)
        self.data_handlers.setdefault(key, []).append(callback)

    def notify_shot(self, x, y, angle, damage):
        if not self.connected:
            return
        self.broadcast(NetworkMessage('shot', pid=self.my_pid,
                                       x=x, y=y, angle=angle,
                                       damage=damage))

    def notify_damage(self, target_pid, amount, source_pid=None):
        if not self.is_host:
            return
        if source_pid is None:
            source_pid = self.my_pid
        if target_pid in self.peers:
            try:
                self.peers[target_pid].sendall(
                    NetworkMessage('damage', target=target_pid,
                                   amount=amount,
                                   source=source_pid).encode())
            except Exception:
                pass

    def notify_event(self, name, **data):
        if not self.connected:
            return
        who = self.player_names.get(self.my_pid, f'P{self.my_pid}')
        if self.is_host:
            self._send_to_all(NetworkMessage('event', name=name,
                                              who=who, **data))
        else:
            self._send_to_host(NetworkMessage('event', name=name,
                                               who=who, **data))