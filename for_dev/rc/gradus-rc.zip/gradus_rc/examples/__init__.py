"""
MenuExample и GameExample для Gradus RC.
Поддерживает выбор бэкенда: ip / firebase / server.
"""
import sys
import os
import json
import time
import pygame


# Список доступных онлайн-бэкендов. Порядок = порядок в меню.
ONLINE_BACKENDS = [
    {
        'id': 'ip',
        'title': 'По IP',
        'desc': 'Прямое подключение к хосту по адресу',
        'icon': '🌐',
    },
    {
        'id': 'firebase',
        'title': 'Firebase',
        'desc': 'Лобби через Firebase Realtime DB (список серверов)',
        'icon': '☁',
    },
    {
        'id': 'server',
        'title': 'Свой сервер',
        'desc': 'Подключение к кастомному серверу разработчика',
        'icon': '🖥',
    },
]


class MenuExample:
    """Меню с настройками, достижениями, онлайном (ip/firebase/server)."""

    def __init__(self, width=800, height=600,
                 background_image=None,
                 button_align='left',
                 about_text="Gradus RC Example",
                 achievements_path=None,
                 enable_achievements=True,
                 enable_online=True,
                 only_online=False,
                 online_min_players=2,
                 online_min_team_size=0,
                 online_default_mode='pvp',
                 online_backends=None,           # список id для отображения
                 fb_client=None, **kwargs):                # готовый FirebaseLobbyClient
        self.width = width
        self.height = height
        self.about_text = about_text
        self.button_align = button_align
        self.running = True
        self.state = 'main'
        self.achievements_path = achievements_path
        self.enable_achievements = bool(enable_achievements)
        self.enable_online = bool(enable_online)
        self.only_online = bool(only_online)
        self.online_min_players = int(online_min_players)
        self.online_min_team_size = int(online_min_team_size)
        self.online_default_mode = online_default_mode
        if self.only_online:
            self.enable_online = True

        # ---- Backends ----
        if online_backends:
            self.online_backends = [b for b in ONLINE_BACKENDS
                                    if b['id'] in online_backends]
        else:
            self.online_backends = list(ONLINE_BACKENDS)
        self.fb = fb_client

        # ---- IP-подключение ----
        self.online_ip = "127.0.0.1"
        self.online_port = "50007"
        self.online_signature = "default"
        self.editing_online_field = None
        self.online_buf = ""

        # ---- Свой сервер ----
        self.server_url = ""
        self.server_token = ""
        self.editing_server_field = None
        self.server_buf = ""

        # ---- Firebase: список лобби ----
        self._fb_lobbies = []
        self._fb_lobby_scroll = 0
        self._fb_lobby_rects = []
        self._fb_lobby_selected = None
        self._fb_refresh_timer = 0.0
        self._fb_last_auto_refresh = 0.0
        self._fb_create_name = "Мой сервер"
        self._fb_create_pass = ""
        self._fb_create_max = 4
        self._fb_create_mode = "pvp"
        self._fb_create_lobby_name_field = False
        self._fb_create_pass_field = False
        self._fb_create_buf = ""
        self._fb_password_input = ""
        self._fb_password_lobby_id = None
        self._fb_password_field = False

        # ---- FB-комната лобби (после join) ----
        self._fb_room_lobby_id = None
        self._fb_room_state = {}
        self._fb_room_player_rects = []
        self._fb_room_am_host = False
        self._fb_room_ready = False
        self._fb_room_my_team = None

        # ---- Достижения / сохранения ----
        self._achievements_cache = None
        self._achievements_scroll = 0
        self._achievements_max_scroll = 0
        self._save_files = []
        self._save_rects = []

        # ---- Настройки ----
        self.particles_mode = 'optimal'
        self.particles_options = [('Off', 'off'), ('Main', 'main'),
                                  ('Optimal', 'optimal'), ('All', 'all')]
        self.particles_idx = 2
        self.rt_mode = 0
        self.rt_options = [('Off', 0), ('4x', 4), ('6x', 6), ('8x', 8),
                           ('12x', 12), ('16x', 16), ('24x', 24), ('32x', 32),
                           ('42x', 42), ('48x', 48), ('52x', 52), ('64x', 64)]
        self.rt_idx = 0
        self.rt_quality = 'balanced'
        self.rt_quality_options = [
            ('Fast', 'fast'), ('Balanced', 'balanced'),
            ('High', 'high'), ('Ultra', 'ultra'), ('Reference', 'reference'),
        ]
        self.rt_quality_idx = 1
        self.rays = 120
        self.fov = 60
        self.fps = 60
        self.mcfi = False
        self.mcfi_options = [('Off', 0), ('1x', 1), ('2x', 2), ('3x', 3)]
        self.mcfi_idx = 0
        self.async_raycast = True
        self.render_scale = 1
        self.sensitivity = 3.0
        self.show_fps = True

        self.background = None
        if background_image:
            try:
                self.background = pygame.image.load(background_image).convert()
                self.background = pygame.transform.scale(self.background,
                                                         (width, height))
            except Exception:
                self.background = None

        # ---- Шрифты ----
        self.font_title    = pygame.font.SysFont('Arial', 52, bold=True)
        self.font_button   = pygame.font.SysFont('Arial', 32, bold=True)
        self.font_small    = pygame.font.SysFont('Arial', 24)
        self.font_tiny     = pygame.font.SysFont('Arial', 18)
        self.font_ach_title = pygame.font.SysFont('Arial', 22, bold=True)
        self.font_ach_desc = pygame.font.SysFont('Arial', 17)
        self.mcfi_level = 0

        # ---- Кнопки главного меню ----
        idx = 0
        self.btn_play_rect = self._create_button_rect(width, height, idx, 220, 50); idx += 1
        self.btn_settings_rect = self._create_button_rect(width, height, idx, 220, 50); idx += 1
        if self.enable_achievements:
            self.btn_achievements_rect = self._create_button_rect(width, height, idx, 220, 50); idx += 1
        else:
            self.btn_achievements_rect = None
        if self.enable_online:
            self.btn_online_rect = self._create_button_rect(width, height, idx, 220, 50); idx += 1
        else:
            self.btn_online_rect = None
        self.btn_quit_rect = self._create_button_rect(width, height, idx, 220, 50)

        # ---- Play choice ----
        self.btn_new_game_rect    = pygame.Rect(width // 2 - 150, height // 2 - 105, 300, 55)
        self.btn_load_game_rect   = pygame.Rect(width // 2 - 150, height // 2 - 40,  300, 55)
        self.btn_local_split_rect = pygame.Rect(width // 2 - 150, height // 2 + 25,  300, 55)
        self.btn_play_back_rect   = pygame.Rect(width // 2 - 150, height // 2 + 90,  300, 55)

        # ---- IP-меню ----
        self.btn_online_host_rect = pygame.Rect(width // 2 - 150, height // 2 - 100, 300, 55)
        self.btn_online_join_rect = pygame.Rect(width // 2 - 150, height // 2 - 35,  300, 55)
        self.btn_online_back_rect = pygame.Rect(width // 2 - 150, height // 2 + 30,  300, 55)
        self.online_field_rects = {
            'ip':   pygame.Rect(width // 2 - 150, height // 2 + 100, 200, 36),
            'port': pygame.Rect(width // 2 + 60,  height // 2 + 100, 90,  36),
            'sig':  pygame.Rect(width // 2 - 150, height // 2 + 145, 300, 36),
        }
        # ---- Свой сервер: кнопки ----
        self.btn_server_host_rect    = pygame.Rect(width // 2 - 150, height // 2 + 90,  300, 50)
        self.btn_server_connect_rect = pygame.Rect(width // 2 - 150, height // 2 + 150, 300, 50)
        self.btn_server_back_rect    = pygame.Rect(width // 2 - 150, height // 2 + 210, 300, 50)
        # ---- Список бэкендов онлайн ----
        self._backend_rects = []
        self.btn_backend_back_rect = pygame.Rect(width // 2 - 80, height - 70, 160, 46)

        # ---- Firebase: список лобби ----
        self.btn_fb_refresh_rect = pygame.Rect(40, height - 70, 200, 46)
        self.btn_fb_create_rect  = pygame.Rect(width // 2 - 100, height - 70, 200, 46)
        self.btn_fb_back_rect    = pygame.Rect(width - 240, height - 70, 200, 46)

        # ---- Firebase: создание лобби ----
        self.btn_fb_create_confirm = pygame.Rect(width // 2 - 100, height - 140, 200, 50)
        self.btn_fb_create_cancel  = pygame.Rect(width // 2 - 100, height - 80,  200, 50)
        self.fb_create_field_rects = {
            'name': pygame.Rect(width // 2 - 200, height // 2 - 30, 400, 40),
            'pass': pygame.Rect(width // 2 - 200, height // 2 + 30, 400, 40),
            'max':  pygame.Rect(width // 2 - 200, height // 2 + 90, 120, 40),
            'mode': pygame.Rect(width // 2 + 60,  height // 2 + 90, 140, 40),
        }

        # ---- Firebase: ввод пароля ----
        self.btn_fb_pass_ok_rect = pygame.Rect(width // 2 - 100, height // 2 + 40, 200, 50)
        self.btn_fb_pass_cancel  = pygame.Rect(width // 2 - 100, height // 2 + 100, 200, 50)
        self._fb_pass_field_rect = pygame.Rect(width // 2 - 200, height // 2 - 20, 400, 40)

        # ---- Firebase: комната лобби ----
        self.btn_fb_room_ready  = pygame.Rect(40, height - 70, 180, 46)
        self.btn_fb_room_start  = pygame.Rect(width // 2 - 90, height - 70, 180, 46)
        self.btn_fb_room_leave  = pygame.Rect(width - 220, height - 70, 180, 46)
        self.fb_room_team_rects = {
            'blue':      pygame.Rect(40, 130, 160, 40),
            'red':       pygame.Rect(210, 130, 160, 40),
            'spectator': pygame.Rect(380, 130, 160, 40),
        }

        # ---- Общее ----
        self.btn_back_rect = pygame.Rect(width // 2 - 80, height - 80, 160, 50)
        self.rays_options = [('Lite', width // 4), ('Medium', width // 3),
                             ('High', width // 2), ('Ultra', width)]
        self.fov_options = [60, 75, 90]
        self.fps_options = [30, 60, 120]
        self.render_scale_options = [1, 2, 3, 4]
        self.sensitivity_min = 0.1
        self.sensitivity_max = 10.0
        self.sensitivity_step = 0.5
        self.rays_idx = 1
        self.fov_idx = 0
        self.fps_idx = 1
        self.scale_idx = 0
        self.setting_rects = []

        # ---- FB auto-refresh ----
        if self.fb and hasattr(self.fb, 'start_global_listener'):
            try:
                self.fb.start_global_listener()
            except Exception:
                pass

    def _create_button_rect(self, width, height, index, bw, bh):
        if self.button_align == 'center':
            x = width // 2 - bw // 2
        elif self.button_align == 'right':
            x = width - bw - 20
        else:
            x = 20
        y = height // 2 - 130 + index * 70
        return pygame.Rect(x, y, bw, bh)

    # ============================================================
    # Achievements
    # ============================================================
    def _get_achievements_json_path(self):
        path = self.achievements_path
        if path is None:
            try:
                from ..achievements import get_default_save_path
                return get_default_save_path()
            except Exception:
                return os.path.join(os.getcwd(), 'achievements.json')
        return path if os.path.isabs(path) else os.path.abspath(path)

    def _load_achievements(self):
        saved = {}
        path = self._get_achievements_json_path()
        if os.path.isfile(path):
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                raw = data.get('achievements', {})
                if isinstance(raw, dict):
                    saved = raw
            except Exception as e:
                print(f"[Menu] achievements load failed: {e}")
        try:
            from ..achievements import get_global_definitions
            globals_defs = get_global_definitions()
        except Exception:
            globals_defs = {}
        merged = {}
        for id, d in globals_defs.items():
            merged[id] = {
                'title': d['title'], 'description': d['description'],
                'icon': d.get('icon'), 'hidden': d.get('hidden', False),
                'max_progress': d.get('max_progress', 1),
                'current_progress': 0, 'unlocked': False,
            }
        for id, d in saved.items():
            if isinstance(d, dict):
                merged[id] = d
        out = []
        for id, d in merged.items():
            hidden = bool(d.get('hidden', False))
            unlocked = bool(d.get('unlocked', False))
            if hidden and not unlocked:
                continue
            out.append({
                'id': id, 'title': d.get('title', id),
                'description': d.get('description', ''),
                'icon': d.get('icon'), 'hidden': hidden,
                'max_progress': int(d.get('max_progress', 1)),
                'current_progress': int(d.get('current_progress', 0)),
                'unlocked': unlocked,
            })
        out.sort(key=lambda a: (not a['unlocked'], a['title'].lower()))
        return out

    def _ensure_achievements_loaded(self):
        if self._achievements_cache is None:
            self._achievements_cache = self._load_achievements()

    def reload_achievements(self):
        self._achievements_cache = None

    # ============================================================
    # Saves
    # ============================================================
    def _refresh_save_list(self):
        self._save_files, self._save_rects = [], []
        save_dir = 'saves'
        if os.path.isdir(save_dir):
            for f in sorted(os.listdir(save_dir)):
                if f.endswith('.json'):
                    self._save_files.append((f, os.path.join(save_dir, f)))
        base_y = self.height // 2 - 100
        for i in range(len(self._save_files)):
            self._save_rects.append(
                pygame.Rect(self.width // 2 - 250, base_y + i * 60, 500, 50))

    # ============================================================
    # Events
    # ============================================================
    def handle_event(self, event):
        # ---- Edits ----
        if event.type == pygame.KEYDOWN:
            if self.state == 'online_menu' and self.editing_online_field:
                return self._edit_online(event)
            if self.state == 'server_menu' and self.editing_server_field:
                return self._edit_server(event)
            if self.state == 'fb_create' and (
                    self._fb_create_lobby_name_field or self._fb_create_pass_field):
                return self._edit_fb_create(event)
            if self.state == 'fb_password' and self._fb_password_field:
                return self._edit_fb_password(event)

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            return self._handle_click(event.pos)

        if event.type == pygame.MOUSEWHEEL:
            if self.state == 'achievements':
                self._achievements_scroll -= event.y * 40
                if self._achievements_scroll < 0:
                    self._achievements_scroll = 0
                if self._achievements_scroll > self._achievements_max_scroll:
                    self._achievements_scroll = self._achievements_max_scroll
            elif self.state == 'fb_lobbies':
                self._fb_lobby_scroll -= event.y * 40
                if self._fb_lobby_scroll < 0:
                    self._fb_lobby_scroll = 0

        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.editing_online_field = None
            self.editing_server_field = None
            self._fb_create_lobby_name_field = False
            self._fb_create_pass_field = False
            self._fb_password_field = False
            back_map = {
                'play_choice': 'main',
                'online_menu': 'main',
                'backend_choice': 'online_menu',
                'server_menu': 'backend_choice',
                'fb_lobbies': 'backend_choice',
                'fb_create': 'fb_lobbies',
                'fb_password': 'fb_lobbies',
                'fb_room': 'fb_lobbies',
                'settings': 'main',
                'load_list': 'play_choice',
                'achievements': 'main',
            }
            if self.state in back_map:
                self.state = back_map[self.state]
            return None
        return None

    def _edit_online(self, event):
        if event.key == pygame.K_RETURN:
            buf = self.online_buf
            if self.editing_online_field == 'ip':
                self.online_ip = buf
            elif self.editing_online_field == 'port':
                self.online_port = buf
            elif self.editing_online_field == 'sig':
                self.online_signature = buf
            self.editing_online_field = None
        elif event.key == pygame.K_BACKSPACE:
            self.online_buf = self.online_buf[:-1]
        else:
            ch = event.unicode
            if ch and ch.isprintable():
                self.online_buf += ch
        return None

    def _edit_server(self, event):
        if event.key == pygame.K_RETURN:
            if self.editing_server_field == 'url':
                self.server_url = self.server_buf
            elif self.editing_server_field == 'token':
                self.server_token = self.server_buf
            self.editing_server_field = None
        elif event.key == pygame.K_BACKSPACE:
            self.server_buf = self.server_buf[:-1]
        else:
            ch = event.unicode
            if ch and ch.isprintable():
                self.server_buf += ch
        return None

    def _edit_fb_create(self, event):
        if event.key == pygame.K_RETURN:
            if self._fb_create_lobby_name_field:
                self._fb_create_name = self._fb_create_buf[:48] or "Сервер"
                self._fb_create_lobby_name_field = False
            elif self._fb_create_pass_field:
                self._fb_create_pass = self._fb_create_buf
                self._fb_create_pass_field = False
        elif event.key == pygame.K_BACKSPACE:
            self._fb_create_buf = self._fb_create_buf[:-1]
        else:
            ch = event.unicode
            if ch and ch.isprintable():
                self._fb_create_buf += ch
        return None

    def _edit_fb_password(self, event):
        if event.key == pygame.K_RETURN:
            self._fb_password_field = False
            self._try_join_fb_lobby(self._fb_password_lobby_id,
                                    password=self._fb_password_input)
        elif event.key == pygame.K_BACKSPACE:
            self._fb_password_input = self._fb_password_input[:-1]
        else:
            ch = event.unicode
            if ch and ch.isprintable():
                self._fb_password_input += ch
        return None

    # ============================================================
    # Clicks
    # ============================================================
    def _handle_click(self, pos):
        st = self.state

        # ---------- IP ----------
        if st == 'online_menu':
            for field, r in self.online_field_rects.items():
                if r.collidepoint(pos):
                    self.editing_online_field = field
                    self.online_buf = {'ip': self.online_ip,
                                       'port': self.online_port,
                                       'sig': self.online_signature}[field]
                    return None
            if self.btn_online_host_rect.collidepoint(pos):
                return self._finish('host', mode='ip')
            if self.btn_online_join_rect.collidepoint(pos):
                return self._finish('join', mode='ip')
            if self.btn_online_back_rect.collidepoint(pos):
                self.state = 'backend_choice'
            return None

        # ---------- Выбор бэкенда ----------
        if st == 'backend_choice':
            for i, r in enumerate(self._backend_rects):
                if r.collidepoint(pos) and i < len(self.online_backends):
                    bid = self.online_backends[i]['id']
                    if bid == 'ip':
                        self.state = 'online_menu'
                    elif bid == 'firebase':
                        self.state = 'fb_lobbies'
                        self._refresh_fb_lobbies()
                    elif bid == 'server':
                        self.state = 'server_menu'
                    return None
            if self.btn_backend_back_rect.collidepoint(pos):
                self.state = 'main'
            return None

        # ---------- Свой сервер ----------
        if st == 'server_menu':
            for key, r in self._server_field_rects().items():
                if r.collidepoint(pos):
                    self.editing_server_field = key
                    self.server_buf = self.server_url if key == 'url' else self.server_token
                    return None
            if self.btn_server_connect_rect.collidepoint(pos):
                return self._finish('join', mode='server')
            if self.btn_server_host_rect.collidepoint(pos):
                return self._finish('host', mode='server')
            if self.btn_server_back_rect.collidepoint(pos):
                self.state = 'backend_choice'
            return None

        # ---------- Firebase: список ----------
        if st == 'fb_lobbies':
            if self.btn_fb_refresh_rect.collidepoint(pos):
                self._refresh_fb_lobbies()
                return None
            if self.btn_fb_create_rect.collidepoint(pos):
                self.state = 'fb_create'
                self._fb_create_buf = ""
                return None
            if self.btn_fb_back_rect.collidepoint(pos):
                self.state = 'backend_choice'
                return None
            for i, r in enumerate(self._fb_lobby_rects):
                if r.collidepoint(pos) and i < len(self._fb_lobbies):
                    lobby = self._fb_lobbies[i]
                    if lobby.get('has_password'):
                        self._fb_password_lobby_id = lobby['id']
                        self._fb_password_input = ""
                        self._fb_password_field = True
                        self.state = 'fb_password'
                    else:
                        self._try_join_fb_lobby(lobby['id'])
                    return None
            return None

        # ---------- Firebase: создание ----------
        if st == 'fb_create':
            for key, r in self.fb_create_field_rects.items():
                if r.collidepoint(pos):
                    if key == 'name':
                        self._fb_create_lobby_name_field = True
                        self._fb_create_buf = self._fb_create_name
                    elif key == 'pass':
                        self._fb_create_pass_field = True
                        self._fb_create_buf = self._fb_create_pass
                    elif key == 'max':
                        self._fb_create_max = 2 if self._fb_create_max >= 8 else self._fb_create_max + 2
                    elif key == 'mode':
                        modes = ['pvp', 'coop', 'team']
                        i = modes.index(self._fb_create_mode) if self._fb_create_mode in modes else 0
                        self._fb_create_mode = modes[(i + 1) % len(modes)]
                    return None
            if self.btn_fb_create_confirm.collidepoint(pos):
                return self._do_fb_create()
            if self.btn_fb_create_cancel.collidepoint(pos):
                self.state = 'fb_lobbies'
            return None

        # ---------- Firebase: пароль ----------
        if st == 'fb_password':
            if self._fb_pass_field_rect.collidepoint(pos):
                self._fb_password_field = True
                return None
            if self.btn_fb_pass_ok_rect.collidepoint(pos):
                self._fb_password_field = False
                self._try_join_fb_lobby(self._fb_password_lobby_id,
                                        password=self._fb_password_input)
                return None
            if self.btn_fb_pass_cancel.collidepoint(pos):
                self._fb_password_field = False
                self.state = 'fb_lobbies'
            return None

        # ---------- Firebase: комната ----------
        if st == 'fb_room':
            for team, r in self.fb_room_team_rects.items():
                if r.collidepoint(pos):
                    self._fb_room_set_team(team)
                    return None
            if self.btn_fb_room_ready.collidepoint(pos):
                self._fb_room_ready = not self._fb_room_ready
                if self.fb:
                    try:
                        self.fb.update_player_state(ready=self._fb_room_ready)
                    except Exception:
                        pass
                return None
            if self.btn_fb_room_start.collidepoint(pos) and self._fb_room_am_host:
                return self._fb_room_start_match()
            if self.btn_fb_room_leave.collidepoint(pos):
                self._fb_room_leave()
                return None
            return None

        # ---------- Play choice ----------
        if st == 'play_choice':
            if self.btn_new_game_rect.collidepoint(pos):
                return self._finish('new', mode='offline')
            if self.btn_load_game_rect.collidepoint(pos):
                self._refresh_save_list()
                self.state = 'load_list'
                return None
            if self.btn_local_split_rect.collidepoint(pos):
                return self._finish('local_split', mode='offline')
            if self.btn_play_back_rect.collidepoint(pos):
                self.state = 'main'
            return None

        if st == 'load_list':
            if self.btn_back_rect.collidepoint(pos):
                self.state = 'play_choice'
                return None
            for i, r in enumerate(self._save_rects):
                if r.collidepoint(pos) and i < len(self._save_files):
                    path = self._save_files[i][1]
                    s = self.get_settings()
                    s['_start_action'] = 'load'
                    s['_load_path'] = path
                    self.running = False
                    return s
            return None

        # ---------- Main ----------
        if st == 'main':
            if self.btn_play_rect.collidepoint(pos):
                self.state = 'online_menu' if self.only_online else 'play_choice'
            elif self.btn_settings_rect.collidepoint(pos):
                self.state = 'settings'
            elif self.btn_achievements_rect and self.btn_achievements_rect.collidepoint(pos):
                self.reload_achievements()
                self._ensure_achievements_loaded()
                self._achievements_scroll = 0
                self.state = 'achievements'
            elif self.btn_online_rect and self.btn_online_rect.collidepoint(pos):
                self.state = 'backend_choice'
            elif self.btn_quit_rect.collidepoint(pos):
                self.running = False
                return None
            return None

        # ---------- Settings ----------
        if st == 'settings':
            for rect, action in self.setting_rects:
                if rect.collidepoint(pos):
                    self._handle_setting_click(action)
                    return None
            if self.btn_back_rect.collidepoint(pos):
                self.state = 'main'
            return None

        # ---------- Achievements ----------
        if st == 'achievements':
            if self.btn_back_rect.collidepoint(pos):
                self.state = 'main'
            return None
        return None

    def _server_field_rects(self):
        return {
            'url': pygame.Rect(self.width // 2 - 200, self.height // 2 - 40, 400, 40),
            'token': pygame.Rect(self.width // 2 - 200, self.height // 2 + 30, 400, 40),
        }

    # ============================================================
    # Finish actions (return settings dict to game.py)
    # ============================================================
    def _finish(self, action, mode='offline'):
        self.running = False
        s = self.get_settings()
        s['_start_action'] = action
        s['_online_mode'] = mode
        s['_mp_signature'] = self.online_signature
        try:
            s['_mp_port'] = int(self.online_port)
        except ValueError:
            s['_mp_port'] = 50007
        s['_mp_ip'] = self.online_ip
        s['_server_url'] = self.server_url
        s['_server_token'] = self.server_token
        s['_serv_mode'] = mode  # 'ip' | 'firebase' | 'server' | 'offline'
        return s

    def get_settings(self):
        return {
            'rays': self.rays, 'fov': self.fov, 'fps': self.fps,
            'mcfi': self.mcfi, 'mcfi_level': self.mcfi_level,
            'async_raycast': self.async_raycast,
            'render_scale': self.render_scale,
            'player_rot_speed': self.sensitivity,
            'graphic': self.rays_options[self.rays_idx][0],
            'show_fps': self.show_fps,
            'rt': self.rt_mode, 'rt_quality': self.rt_quality,
            'particles_mode': self.particles_mode,
            'achievements_path': self.achievements_path,
            '_online_min_players': self.online_min_players,
            '_online_min_team_size': self.online_min_team_size,
            '_online_default_mode': self.online_default_mode,
        }

    # ============================================================
    # FIREBASE helpers
    # ============================================================
    def _refresh_fb_lobbies(self):
        if not self.fb:
            return
        try:
            self._fb_lobbies = self.fb.list_lobbies()
        except Exception as e:
            print(f"[Menu][FB] refresh failed: {e}")
            self._fb_lobbies = []

    def _try_join_fb_lobby(self, lobby_id, password=None):
        if not self.fb:
            return
        ok, msg = self.fb.join_lobby(lobby_id,
                                     player_name="Player",
                                     password=password)
        if not ok:
            print(f"[Menu][FB] join fail: {msg}")
            self.state = 'fb_lobbies'
            return
        self._fb_room_lobby_id = lobby_id
        self._fb_room_ready = False
        self._fb_room_my_team = None
        self._fb_room_am_host = False
        self.state = 'fb_room'
        # запустим listener на комнату
        if hasattr(self.fb, 'start_lobby_listener'):
            try:
                self.fb.start_lobby_listener()
            except Exception:
                pass

    def _do_fb_create(self):
        if not self.fb:
            return None
        lid = self.fb.create_lobby(
            name=self._fb_create_name or "Сервер",
            host_name="Host",
            password=self._fb_create_pass or None,
            max_players=self._fb_create_max,
            mode=self._fb_create_mode,
        )
        if not lid:
            return None
        self._fb_room_lobby_id = lid
        self._fb_room_am_host = True
        self._fb_room_ready = True
        self._fb_room_my_team = 'spectator'
        self.state = 'fb_room'
        if hasattr(self.fb, 'start_lobby_listener'):
            try:
                self.fb.start_lobby_listener()
            except Exception:
                pass
        return None

    def _fb_room_set_team(self, team):
        if not self.fb:
            return
        try:
            self.fb.update_player_state(
                team=team, is_spectator=(team == 'spectator'))
            self._fb_room_my_team = team
        except Exception:
            pass

    def _fb_room_start_match(self):
        """Отдаём в game.py сигнал, что хост стартовал матч в FB."""
        self.running = False
        s = self.get_settings()
        s['_start_action'] = 'fb_match_start'
        s['_fb_lobby_id'] = self._fb_room_lobby_id
        s['_serv_mode'] = 'firebase'
        return s

    def _fb_room_leave(self):
        if self.fb:
            try:
                self.fb.leave_lobby()
            except Exception:
                pass
        self._fb_room_lobby_id = None
        self.state = 'fb_lobbies'
        self._refresh_fb_lobbies()

    # ============================================================
    # Настройки
    # ============================================================
    def _handle_setting_click(self, action):
        if action == 'rays':
            self.rays_idx = (self.rays_idx + 1) % len(self.rays_options)
            self.rays = self.rays_options[self.rays_idx][1]
        elif action == 'fov':
            self.fov_idx = (self.fov_idx + 1) % len(self.fov_options)
            self.fov = self.fov_options[self.fov_idx]
        elif action == 'fps':
            self.fps_idx = (self.fps_idx + 1) % len(self.fps_options)
            self.fps = self.fps_options[self.fps_idx]
        elif action == 'mcfi':
            self.mcfi_idx = (self.mcfi_idx + 1) % len(self.mcfi_options)
            self.mcfi = self.mcfi_options[self.mcfi_idx][1] > 0
            self.mcfi_level = self.mcfi_options[self.mcfi_idx][1]
        elif action == 'async':
            self.async_raycast = not self.async_raycast
        elif action == 'scale':
            self.scale_idx = (self.scale_idx + 1) % len(self.render_scale_options)
            self.render_scale = self.render_scale_options[self.scale_idx]
        elif action == 'sensitivity':
            self.sensitivity += self.sensitivity_step
            if self.sensitivity > self.sensitivity_max:
                self.sensitivity = self.sensitivity_min
        elif action == 'show_fps':
            self.show_fps = not self.show_fps
        elif action == 'particles':
            self.particles_idx = (self.particles_idx + 1) % len(self.particles_options)
            self.particles_mode = self.particles_options[self.particles_idx][1]
        elif action == 'rt':
            self.rt_idx = (self.rt_idx + 1) % len(self.rt_options)
            self.rt_mode = self.rt_options[self.rt_idx][1]
        elif action == 'rt_quality':
            self.rt_quality_idx = (self.rt_quality_idx + 1) % len(self.rt_quality_options)
            self.rt_quality = self.rt_quality_options[self.rt_quality_idx][1]

    # ============================================================
    # Render
    # ============================================================
    def render(self, screen):
        if self.background:
            screen.blit(self.background, (0, 0))
        else:
            screen.fill((20, 20, 40))

        st = self.state
        if st == 'main':
            self._render_main(screen)
        elif st == 'play_choice':
            self._render_play_choice(screen)
        elif st == 'online_menu':
            self._render_ip_menu(screen)
        elif st == 'backend_choice':
            self._render_backend_choice(screen)
        elif st == 'server_menu':
            self._render_server_menu(screen)
        elif st == 'fb_lobbies':
            self._render_fb_lobbies(screen)
        elif st == 'fb_create':
            self._render_fb_create(screen)
        elif st == 'fb_password':
            self._render_fb_password(screen)
        elif st == 'fb_room':
            self._render_fb_room(screen)
        elif st == 'load_list':
            self._render_load_list(screen)
        elif st == 'settings':
            self._render_settings(screen)
        elif st == 'achievements':
            self._draw_achievements_screen(screen)

    def _render_main(self, screen):
        title = self.font_title.render("Gradus RC", True, (255, 200, 100))
        screen.blit(title, (self.width // 2 - title.get_width() // 2, 40))
        if self.only_online:
            if self.btn_online_rect:
                self._draw_button(screen, self.btn_online_rect, "Онлайн", (100, 60, 140))
            self._draw_button(screen, self.btn_settings_rect, "Настройки", (70, 70, 200))
            if self.btn_achievements_rect:
                self._draw_button(screen, self.btn_achievements_rect, "Достижения", (150, 100, 50))
            self._draw_button(screen, self.btn_quit_rect, "Выход", (150, 50, 50))
        else:
            self._draw_button(screen, self.btn_play_rect, "Играть", (0, 150, 0))
            self._draw_button(screen, self.btn_settings_rect, "Настройки", (70, 70, 200))
            if self.btn_achievements_rect:
                self._draw_button(screen, self.btn_achievements_rect, "Достижения", (150, 100, 50))
            if self.btn_online_rect:
                self._draw_button(screen, self.btn_online_rect, "Сетевая игра", (100, 60, 140))
            self._draw_button(screen, self.btn_quit_rect, "Выход", (150, 50, 50))

    def _render_play_choice(self, screen):
        title = self.font_title.render("Играть", True, (255, 200, 100))
        screen.blit(title, (self.width // 2 - title.get_width() // 2, 40))
        self._draw_button(screen, self.btn_new_game_rect, "Новая игра", (0, 140, 0))
        self._draw_button(screen, self.btn_load_game_rect, "Загрузить", (70, 90, 200))
        self._draw_button(screen, self.btn_local_split_rect, "Сплит (2 игрока)", (140, 80, 180))
        self._draw_button(screen, self.btn_play_back_rect, "Назад", (150, 50, 50))

    def _render_backend_choice(self, screen):
        title = self.font_title.render("Выбор режима", True, (255, 200, 100))
        screen.blit(title, (self.width // 2 - title.get_width() // 2, 40))

        w = 500
        h = 80
        x = self.width // 2 - w // 2
        y0 = 150
        self._backend_rects = []
        for i, b in enumerate(self.online_backends):
            r = pygame.Rect(x, y0 + i * (h + 20), w, h)
            self._backend_rects.append(r)
            hov = r.collidepoint(pygame.mouse.get_pos())
            bg = (80, 100, 160) if hov else (60, 75, 120)
            pygame.draw.rect(screen, bg, r, border_radius=12)
            pygame.draw.rect(screen, (200, 220, 255), r, 2, border_radius=12)
            t = self.font_button.render(f"{b['icon']}  {b['title']}", True, (240, 245, 255))
            screen.blit(t, (r.x + 24, r.y + 14))
            d = self.font_small.render(b['desc'], True, (200, 210, 230))
            screen.blit(d, (r.x + 24, r.y + 46))

        self._draw_button(screen, self.btn_backend_back_rect, "Назад", (150, 50, 50))

    def _render_ip_menu(self, screen):
        title = self.font_title.render("По IP", True, (255, 200, 100))
        screen.blit(title, (self.width // 2 - title.get_width() // 2, 40))
        self._draw_button(screen, self.btn_online_host_rect, "Создать игру", (0, 140, 0))
        self._draw_button(screen, self.btn_online_join_rect, "Подключиться", (0, 100, 180))
        self._draw_button(screen, self.btn_online_back_rect, "Назад", (150, 50, 50))

        def draw_field(key, label):
            r = self.online_field_rects[key]
            active = (self.editing_online_field == key)
            pygame.draw.rect(screen, (60, 80, 120), r, border_radius=4)
            pygame.draw.rect(screen, (200, 230, 255) if active else (140, 170, 220),
                             r, 2, border_radius=4)
            txt = self.online_buf + "_" if active else {
                'ip': self.online_ip, 'port': self.online_port,
                'sig': self.online_signature}[key]
            s = self.font_small.render(txt, True, (240, 240, 240))
            screen.blit(s, (r.x + 8, r.y + 5))

        draw_field('ip', 'IP')
        draw_field('port', 'Порт')
        draw_field('sig', 'Подпись')
        screen.blit(self.font_small.render("IP:", True, (200, 210, 230)),
                    (self.online_field_rects['ip'].x - 40, self.online_field_rects['ip'].y + 5))
        screen.blit(self.font_small.render("Порт:", True, (200, 210, 230)),
                    (self.online_field_rects['port'].x - 55, self.online_field_rects['port'].y + 5))
        screen.blit(self.font_small.render("Подпись игры:", True, (200, 210, 230)),
                    (self.online_field_rects['sig'].x, self.online_field_rects['sig'].y - 28))

    def _render_server_menu(self, screen):
        title = self.font_title.render("Свой сервер", True, (255, 200, 100))
        screen.blit(title, (self.width // 2 - title.get_width() // 2, 40))
        screen.blit(self.font_small.render(
            "URL и токен задаёт разработчик. Меню только рендерит поля.",
            True, (200, 210, 230)),
            (self.width // 2 - 260, 110))
        rects = self._server_field_rects()

        for key, r in rects.items():
            active = (self.editing_server_field == key)
            pygame.draw.rect(screen, (60, 80, 120), r, border_radius=4)
            pygame.draw.rect(screen, (200, 230, 255) if active else (140, 170, 220),
                             r, 2, border_radius=4)
            val = (self.server_buf + "_" if active else
                   (self.server_url if key == 'url' else self.server_token))
            s = self.font_small.render(val or f"— {key} —", True, (240, 240, 240))
            screen.blit(s, (r.x + 8, r.y + 6))

        self._draw_button(screen, self.btn_server_host_rect, "Хостить", (0, 140, 0))
        self._draw_button(screen, self.btn_server_connect_rect, "Подключиться", (0, 100, 180))
        self._draw_button(screen, self.btn_server_back_rect, "Назад", (150, 50, 50))

    def _render_fb_lobbies(self, screen):
        title = self.font_title.render("Firebase — список лобби", True, (255, 200, 100))
        screen.blit(title, (40, 30))

        if not self.fb:
            info = self.font_small.render(
                "Firebase-клиент не подключён. Проверь AccountService.json.",
                True, (240, 120, 120))
            screen.blit(info, (40, 100))
            self._draw_button(screen, self.btn_fb_back_rect, "Назад", (150, 50, 50))
            return

        # Автообновление раз в 3 сек
        now = time.time()
        if now - self._fb_last_auto_refresh > 3.0:
            self._fb_last_auto_refresh = now
            self._refresh_fb_lobbies()

        # Список
        w = self.width - 80
        h = 70
        y0 = 110
        max_y = self.height - 100
        self._fb_lobby_rects = []

        if not self._fb_lobbies:
            empty = self.font_small.render("Лобби не найдены", True, (180, 190, 210))
            screen.blit(empty, (40, y0 + 20))
        else:
            for i, lob in enumerate(self._fb_lobbies):
                y = y0 + i * (h + 8) - self._fb_lobby_scroll
                if y + h < y0 or y > max_y:
                    continue
                r = pygame.Rect(40, y, w, h)
                self._fb_lobby_rects.append(r)
                hov = r.collidepoint(pygame.mouse.get_pos())
                bg = (80, 100, 160) if hov else (60, 75, 120)
                pygame.draw.rect(screen, bg, r, border_radius=10)
                pygame.draw.rect(screen, (200, 220, 255), r, 2, border_radius=10)
                name = lob['name']
                host = lob['host']
                players = lob['players']
                mx = lob['max_players']
                mode = lob['mode']
                pw = ' 🔒' if lob.get('has_password') else ''
                line1 = self.font_button.render(
                    f"{name}{pw}", True, (240, 245, 255))
                line2 = self.font_small.render(
                    f"Хост: {host}  ·  {players}/{mx}  ·  режим: {mode}",
                    True, (200, 210, 230))
                screen.blit(line1, (r.x + 18, r.y + 8))
                screen.blit(line2, (r.x + 18, r.y + 38))

        self._draw_button(screen, self.btn_fb_refresh_rect, "Обновить", (70, 90, 160))
        self._draw_button(screen, self.btn_fb_create_rect, "Создать", (0, 140, 0))
        self._draw_button(screen, self.btn_fb_back_rect, "Назад", (150, 50, 50))

    def _render_fb_create(self, screen):
        title = self.font_title.render("Создать лобби", True, (255, 200, 100))
        screen.blit(title, (self.width // 2 - title.get_width() // 2, 40))

        rects = self.fb_create_field_rects
        # Name
        active = self._fb_create_lobby_name_field
        pygame.draw.rect(screen, (60, 80, 120), rects['name'], border_radius=4)
        pygame.draw.rect(screen, (200, 230, 255) if active else (140, 170, 220),
                         rects['name'], 2, border_radius=4)
        val = self._fb_create_buf + "_" if active else self._fb_create_name
        screen.blit(self.font_small.render(val, True, (240, 240, 240)),
                    (rects['name'].x + 8, rects['name'].y + 8))
        screen.blit(self.font_small.render("Название:", True, (200, 210, 230)),
                    (rects['name'].x, rects['name'].y - 26))

        # Pass
        active = self._fb_create_pass_field
        pygame.draw.rect(screen, (60, 80, 120), rects['pass'], border_radius=4)
        pygame.draw.rect(screen, (200, 230, 255) if active else (140, 170, 220),
                         rects['pass'], 2, border_radius=4)
        val = self._fb_create_buf + "_" if active else (
            "*" * len(self._fb_create_pass) if self._fb_create_pass else "— без пароля —")
        screen.blit(self.font_small.render(val, True, (240, 240, 240)),
                    (rects['pass'].x + 8, rects['pass'].y + 8))
        screen.blit(self.font_small.render("Пароль (опционально):", True, (200, 210, 230)),
                    (rects['pass'].x, rects['pass'].y - 26))

        # Max
        pygame.draw.rect(screen, (60, 80, 120), rects['max'], border_radius=4)
        pygame.draw.rect(screen, (140, 170, 220), rects['max'], 2, border_radius=4)
        screen.blit(self.font_small.render(str(self._fb_create_max), True, (240, 240, 240)),
                    (rects['max'].x + 8, rects['max'].y + 8))
        screen.blit(self.font_small.render("Макс:", True, (200, 210, 230)),
                    (rects['max'].x, rects['max'].y - 26))

        # Mode
        pygame.draw.rect(screen, (60, 80, 120), rects['mode'], border_radius=4)
        pygame.draw.rect(screen, (140, 170, 220), rects['mode'], 2, border_radius=4)
        screen.blit(self.font_small.render(self._fb_create_mode, True, (240, 240, 240)),
                    (rects['mode'].x + 8, rects['mode'].y + 8))
        screen.blit(self.font_small.render("Режим:", True, (200, 210, 230)),
                    (rects['mode'].x, rects['mode'].y - 26))

        self._draw_button(screen, self.btn_fb_create_confirm, "Создать", (0, 140, 0))
        self._draw_button(screen, self.btn_fb_create_cancel, "Назад", (150, 50, 50))

    def _render_fb_password(self, screen):
        title = self.font_title.render("Введите пароль", True, (255, 200, 100))
        screen.blit(title, (self.width // 2 - title.get_width() // 2, 100))

        r = self._fb_pass_field_rect
        active = self._fb_password_field
        pygame.draw.rect(screen, (60, 80, 120), r, border_radius=4)
        pygame.draw.rect(screen, (200, 230, 255) if active else (140, 170, 220),
                         r, 2, border_radius=4)
        txt = self._fb_password_input + "_" if active else (
            "*" * len(self._fb_password_input) or "—")
        screen.blit(self.font_small.render(txt, True, (240, 240, 240)),
                    (r.x + 8, r.y + 8))

        self._draw_button(screen, self.btn_fb_pass_ok_rect, "Войти", (0, 140, 0))
        self._draw_button(screen, self.btn_fb_pass_cancel, "Отмена", (150, 50, 50))

    def _render_fb_room(self, screen):
        if not self.fb:
            return
        state = self.fb.get_lobby_state() or {}
        self._fb_room_state = state
        lobby_name = state.get('name', '—')
        players = state.get('players', {}) or {}
        host_id = state.get('host_id')
        self._fb_room_am_host = (host_id == self.fb.player_id)

        title = self.font_title.render(
            f"Лобби: {lobby_name}", True, (255, 200, 100))
        screen.blit(title, (40, 30))

        info = self.font_small.render(
            f"Макс: {state.get('max_players', 4)}  ·  режим: {state.get('mode', 'pvp')}  ·  "
            f"{'Хост: вы' if self._fb_room_am_host else 'Хост: другой игрок'}",
            True, (200, 210, 230))
        screen.blit(info, (40, 80))

        # Кнопки команд
        labels = {'blue': '🔵 Синие', 'red': '🔴 Красные', 'spectator': '👁 Наблюдатель'}
        for team, r in self.fb_room_team_rects.items():
            active = (self._fb_room_my_team == team)
            bg = (80, 130, 200) if active else (60, 75, 120)
            pygame.draw.rect(screen, bg, r, border_radius=8)
            pygame.draw.rect(screen, (200, 220, 255), r, 2, border_radius=8)
            t = self.font_small.render(labels[team], True, (240, 245, 255))
            screen.blit(t, (r.x + 12, r.y + 8))

        # Список игроков
        self._fb_room_player_rects = []
        y0 = 190
        row_h = 60
        for i, (pid, p) in enumerate(players.items()):
            r = pygame.Rect(40, y0 + i * (row_h + 6), self.width - 80, row_h)
            self._fb_room_player_rects.append(r)
            is_me = (pid == self.fb.player_id)
            is_host = (pid == host_id)
            hov = r.collidepoint(pygame.mouse.get_pos())
            bg = (70, 90, 140) if hov else (55, 68, 105)
            pygame.draw.rect(screen, bg, r, border_radius=8)
            pygame.draw.rect(screen, (200, 220, 255), r, 2, border_radius=8)
            name = p.get('name', 'Player') + (" (вы)" if is_me else "")
            host_mark = " 👑" if is_host else ""
            ready_mark = " ✓" if p.get('ready') else " ..."
            team = p.get('team') or '—'
            line1 = self.font_button.render(name + host_mark, True, (240, 245, 255))
            line2 = self.font_small.render(
                f"команда: {team}  ·  готовность: {ready_mark}",
                True, (200, 210, 230))
            screen.blit(line1, (r.x + 18, r.y + 6))
            screen.blit(line2, (r.x + 18, r.y + 34))

        # Кнопки
        ready_label = "Не готов" if self._fb_room_ready else "Готов"
        self._draw_button(screen, self.btn_fb_room_ready, ready_label,
                          (60, 140, 90) if not self._fb_room_ready else (140, 90, 60))
        if self._fb_room_am_host:
            self._draw_button(screen, self.btn_fb_room_start, "Начать матч", (0, 140, 0))
        self._draw_button(screen, self.btn_fb_room_leave, "Выйти", (150, 50, 50))

    def _render_load_list(self, screen):
        title = self.font_title.render("Выбор сохранения", True, (255, 200, 100))
        screen.blit(title, (self.width // 2 - title.get_width() // 2, 40))
        if not self._save_files:
            empty = self.font_button.render("Нет сохранений", True, (150, 150, 150))
            screen.blit(empty, (self.width // 2 - empty.get_width() // 2, self.height // 2))
        else:
            for i, r in enumerate(self._save_rects):
                if i >= len(self._save_files):
                    break
                name, _ = self._save_files[i]
                self._draw_button(screen, r, name, (60, 80, 130))
        self._draw_button(screen, self.btn_back_rect, "Назад", (150, 50, 50))

    def _render_settings(self, screen):
        title = self.font_title.render("Настройки", True, (255, 200, 100))
        screen.blit(title, (self.width // 2 - title.get_width() // 2, 30))
        self.setting_rects.clear()
        left_x, right_x = 50, self.width // 2 + 20
        y0, step = 130, 60
        self._draw_setting_row(screen, "Графика:", self.rays_options[self.rays_idx][0], left_x, y0, 'rays')
        self._draw_setting_row(screen, "Particles:", self.particles_options[self.particles_idx][0], left_x, y0 + step, 'particles')
        self._draw_setting_row(screen, "FOV:", str(self.fov), left_x, y0 + step*2, 'fov')
        self._draw_setting_row(screen, "FPS:", str(self.fps), left_x, y0 + step*3, 'fps')
        self._draw_setting_row(screen, "Render Scale:",
                               f"{self.render_scale}x" if self.render_scale > 1 else "Off",
                               left_x, y0 + step*4, 'scale')
        self._draw_setting_row(screen, "MCFI:", self.mcfi_options[self.mcfi_idx][0], right_x, y0, 'mcfi')
        self._draw_setting_row(screen, "Async:", "On" if self.async_raycast else "Off", right_x, y0 + step, 'async')
        self._draw_setting_row(screen, "Sensitivity:", f"{self.sensitivity:.1f}", right_x, y0 + step*2, 'sensitivity')
        self._draw_setting_row(screen, "Show FPS:", "On" if self.show_fps else "Off", right_x, y0 + step*3, 'show_fps')
        self._draw_setting_row(screen, "RTE:", self.rt_options[self.rt_idx][0], right_x, y0 + step*4, 'rt')
        self._draw_setting_row(screen, "RTE Quality:",
                               self.rt_quality_options[self.rt_quality_idx][0],
                               right_x, y0 + step*5, 'rt_quality')
        self._draw_button(screen, self.btn_back_rect, "Назад", (150, 50, 50))

    def _draw_setting_row(self, screen, label_text, value_text, x, y, action):
        lbl = self.font_small.render(label_text, True, (255, 255, 255))
        screen.blit(lbl, (x, y))
        r = pygame.Rect(x + 220, y - 8, 200, 40)
        self._draw_button(screen, r, value_text, (70, 70, 200))
        self.setting_rects.append((r, action))

    def _draw_button(self, screen, rect, text, bg_color, text_color=(255, 255, 255)):
        pygame.draw.rect(screen, bg_color, rect, border_radius=10)
        pygame.draw.rect(screen, (255, 255, 255), rect, 2, border_radius=10)
        t = self.font_button.render(text, True, text_color)
        screen.blit(t, (rect.x + (rect.width - t.get_width()) // 2,
                        rect.y + (rect.height - t.get_height()) // 2))

    def _draw_achievements_screen(self, screen):
        self._ensure_achievements_loaded()
        total = len(self._achievements_cache)
        unlocked = sum(1 for a in self._achievements_cache if a['unlocked'])
        title = self.font_title.render(f"Достижения — {unlocked}/{total}",
                                       True, (255, 200, 100))
        screen.blit(title, (self.width // 2 - title.get_width() // 2, 30))
        margin_x, list_y = 60, 100
        list_w = self.width - margin_x * 2
        list_h = self.height - list_y - 100
        if not self._achievements_cache:
            empty = self.font_button.render("Пока нет достижений", True, (150, 150, 150))
            screen.blit(empty, (self.width // 2 - empty.get_width() // 2, list_y + list_h // 2))
        else:
            item_h = 78
            total_h = len(self._achievements_cache) * item_h
            self._achievements_max_scroll = max(0, total_h - list_h)
            clip = screen.subsurface((margin_x, list_y, list_w, list_h))
            clip.fill((15, 20, 30))
            for i, a in enumerate(self._achievements_cache):
                y = i * item_h - self._achievements_scroll
                if y + item_h < 0 or y > list_h:
                    continue
                self._draw_achievement_item(clip, a, 0, y, list_w, item_h)
            if self._achievements_max_scroll > 0:
                bx = margin_x + list_w - 8
                bh = max(30, int(list_h * list_h / total_h))
                by = list_y + int((list_h - bh) * self._achievements_scroll / self._achievements_max_scroll)
                pygame.draw.rect(screen, (60, 70, 90), (bx, list_y, 6, list_h), border_radius=3)
                pygame.draw.rect(screen, (140, 180, 240), (bx, by, 6, bh), border_radius=3)
        self._draw_button(screen, self.btn_back_rect, "Назад", (150, 50, 50))

    def _draw_achievement_item(self, surface, a, x, y, w, h):
        unlocked = a['unlocked']
        hidden = a['hidden']
        bg = (30, 45, 30) if unlocked else (25, 25, 35)
        border = (120, 200, 120) if unlocked else (60, 60, 80)
        pygame.draw.rect(surface, bg, (x + 4, y + 4, w - 8, h - 8), border_radius=8)
        pygame.draw.rect(surface, border, (x + 4, y + 4, w - 8, h - 8), 2, border_radius=8)
        icon_x, icon_size = x + 20, 50
        icon_y = y + (h - icon_size) // 2
        if a['icon']:
            try:
                ic = pygame.image.load(a['icon']).convert_alpha()
                ic = pygame.transform.scale(ic, (icon_size, icon_size))
                surface.blit(ic, (icon_x, icon_y))
            except Exception:
                pass
        else:
            col = (100, 200, 100) if unlocked else (60, 60, 80)
            pygame.draw.rect(surface, col, (icon_x, icon_y, icon_size, icon_size), border_radius=6)
            sym = "✓" if unlocked else ("?" if hidden else "·")
            f = pygame.font.SysFont('Arial', 28, bold=True)
            t = f.render(sym, True, (255, 255, 255))
            surface.blit(t, (icon_x + icon_size // 2 - t.get_width() // 2,
                             icon_y + icon_size // 2 - t.get_height() // 2))
        tx = icon_x + icon_size + 20
        title = "???" if (hidden and not unlocked) else a['title']
        desc = "Скрытое достижение" if (hidden and not unlocked) else a['description']
        c1 = (200, 255, 200) if unlocked else (170, 180, 200)
        c2 = (180, 200, 180) if unlocked else (130, 140, 160)
        surface.blit(self.font_ach_title.render(title, True, c1), (tx, y + 14))
        surface.blit(self.font_ach_desc.render(desc, True, c2), (tx, y + 44))

class GameExample:
    """Игровой цикл с использованием движка."""

    def __init__(self, engine_class, levels=None, current_level=0,
                 width=800, height=600, fullscreen=False,
                 rays=120, fov=60, fps=60,
                 mcfi=True, mcfi_level=1, async_raycast=True, render_scale=1,
                 player_speed=48.0, player_rot_speed=3.0,
                 show_fps=False,
                 graphic="medium",
                 particles_mode='optimal',
                 rt_quality='balanced',
                 achievements_path=None,
                 rt=0,
                 tile_size=64, max_depth=1000, proj_coeff=20000,
                 on_trigger_callback=None,
                 _online_min_players=2, _online_min_team_size=0,
                 _online_default_mode='coop',
                 _mp_mode='coop', _mp_min_players=2, _mp_min_team_size=0,
                 **kwargs):
        self.engine_class = engine_class
        if self.engine_class is None:
            print("Ошибка: GameExample не получил Engine-класса")
            print("Выход...")
            sys.exit()

        self.levels = levels if levels else []
        self.current_level = current_level
        self.width = width
        self.height = height
        self.fullscreen = fullscreen
        self.fps = fps
        self.show_fps = show_fps
        self.on_trigger_callback = on_trigger_callback
        self.graphics = graphic.lower()

        # Онлайн-параметры (пробрасываются в game.py)
        self._online_min_players = _online_min_players
        self._online_min_team_size = _online_min_team_size
        self._online_default_mode = _online_default_mode
        self._mp_mode = _mp_mode
        self._mp_min_players = _mp_min_players
        self._mp_min_team_size = _mp_min_team_size

        pygame.init()
        flags = pygame.FULLSCREEN if fullscreen else 0
        self.screen = pygame.display.set_mode((width, height), flags)
        pygame.display.set_caption("Gradus RC Game")
        self.clock = pygame.time.Clock()

        self.rt = False
        self.rt_mode = rt or 0
        try:
            if rt > 0:
                self.rt = True
                self.rt_mode = rt
                if self.rt_mode > 64:
                    self.rt_mode = 64
        except Exception as e:
            print(f"GameExample error in __init__ of RT settings: {e}")
            self.rt = False

        self.engine = self.engine_class(
            clock=self.clock,
            levels=self.levels,
            current_level=current_level,
            width=width,
            height=height,
            fov=fov,
            rays=rays,
            graphics_level=self.graphics,
            tile_size=tile_size,
            max_depth=max_depth,
            proj_coeff=proj_coeff,
            player_speed=player_speed,
            player_rot_speed=player_rot_speed,
            render_scale=render_scale,
            async_raycast=async_raycast,
            mcfi=mcfi,
            use_rt=self.rt,
            rt_level=self.rt_mode or 0,
            mcfi_level=mcfi_level,
            use_example=True,
            rt_quality=rt_quality or 'balanced',
            particles_mode=particles_mode,
            achievements_path=achievements_path,
            **kwargs,
        )
        self.api = self.engine.MicroAPI(self.engine)
        self.engine.prepare_models(self.screen)

    def run(self):
        font_fps = pygame.font.SysFont('Arial', 24)
        running = True
        while running:
            dt = self.clock.tick(self.fps) / 1000.0
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if hasattr(self.engine, 'handle_event'):
                    self.engine.handle_event(event)
                if hasattr(self.engine, 'handle_mouse'):
                    self.engine.handle_mouse(event)

            keys = pygame.key.get_pressed()
            self.engine.update(dt, keys)
            self.engine.render(self.screen)

            if self.show_fps:
                fps = self.clock.get_fps()
                if getattr(self.engine, 'use_raycaster_async', False):
                    fps = fps * 1.07
                fps_text = font_fps.render(f"FPS: {int(fps)}", True, (255, 255, 0))
                self.screen.blit(fps_text, (self.width - 120, self.height - 40))

            pygame.display.flip()

        pygame.quit()