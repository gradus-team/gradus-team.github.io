"""
Запись видео 720p / 30fps / mp4 (H.264).
Пишет кадры в отдельном потоке, чтобы не фризить игру.

Использование:
    engine.video_recorder.start()         # начать
    engine.video_recorder.push_frame(screen)  # каждый кадр
    engine.video_recorder.stop()          # закончить
"""
import os
import queue
import threading
import datetime

import pygame

try:
    import numpy as np
    import imageio
    _VIDEO_OK = True
except ImportError:
    _VIDEO_OK = False


class VideoRecorder:
    def __init__(self, target_size=(1280, 720), fps=30, max_duration=60.0):
        self.target_size = target_size
        self.fps = fps
        self.max_duration = max_duration

        self.writer = None
        self.thread = None
        self.frames_queue = None
        self.recording = False
        self.frames_written = 0
        self.path = None

    @property
    def duration(self):
        return self.frames_written / max(1, self.fps)

    @property
    def available(self):
        return _VIDEO_OK

    def start(self, path=None):
        if not _VIDEO_OK:
            print("[Video] imageio/numpy не установлены")
            return None
        if self.recording:
            return None

        if path is None:
            os.makedirs("replays", exist_ok=True)
            fn = datetime.datetime.now().strftime(
                "replays/%Y-%m-%d_%H-%M-%S.mp4")
            path = fn

        try:
            self.writer = imageio.get_writer(
                path, fps=self.fps, codec="libx264", quality=7,
                macro_block_size=1)
        except Exception as e:
            print(f"[Video] writer error: {e}")
            return None

        self.path = path
        self.recording = True
        self.frames_written = 0
        self.frames_queue = queue.Queue(maxsize=120)
        self.thread = threading.Thread(target=self._worker, daemon=True)
        self.thread.start()
        print(f"[Video] Запись начата: {path}")
        return path

    def _worker(self):
        while self.recording or (self.frames_queue and not self.frames_queue.empty()):
            try:
                frame = self.frames_queue.get(timeout=0.15)
            except queue.Empty:
                continue
            try:
                self.writer.append_data(frame)
                self.frames_written += 1
            except Exception as e:
                print(f"[Video] append failed: {e}")

    def push_frame(self, surface):
        if not self.recording:
            return
        try:
            scaled = pygame.transform.smoothscale(surface, self.target_size)
            arr = pygame.surfarray.array3d(scaled)
            arr = arr.swapaxes(0, 1)  # pygame (W,H,3) → numpy (H,W,3)
            try:
                self.frames_queue.put_nowait(arr)
            except queue.Full:
                pass
        except Exception:
            pass

    def stop(self):
        if not self.recording:
            return None
        self.recording = False
        if self.thread:
            self.thread.join(timeout=3.0)
        if self.writer:
            try:
                self.writer.close()
            except Exception:
                pass
        path = self.path
        self.writer = None
        self.thread = None
        self.path = None
        print(f"[Video] Запись завершена: {path} "
              f"({self.frames_written} кадров, {self.duration:.1f}s)")
        return path