# gradus_rc/tools/gbj_editor.py
"""
Gradus GBJ Editor — редактор мешей в стиле редактора кат-сцен.

Управление:
  ЛКМ (зажать)          — вращение вида
  ПКМ (зажать)          — панорамирование
  Колесо                — зум
  Стрелки               — панорамирование
  ЛКМ по грани          — выбрать грань
  SHIFT + ЛКМ по грани  — добавить грань к выделению
  Ctrl + Z / Ctrl + Y   — undo / redo
  Delete                — удалить выделенные грани
  Ctrl + C / Ctrl + V   — копировать / вставить объект
  Ctrl + D              — дублировать объект
  F                     — сфокусироваться на выделении
  H                     — показать/скрыть сетку
  X                     — показать/скрыть оси
  W                     — каркасный режим
  S                     — плавное освещение
  Tab                   — переключить активную панель
  ESC                   — выход (с диалогом)
"""
import pygame
import os
import sys
import json
import math
import copy
import glob

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# ============================================================
# ПАЛИТРА (как в cutscene_editor)
# ============================================================
COL_BG          = (25, 28, 38)
COL_TOOLBAR     = (40, 45, 60)
COL_PANEL       = (40, 45, 60)
COL_PANEL_SOFT  = (30, 34, 44)
COL_BTN         = (70, 90, 130)
COL_BTN_HOVER   = (100, 130, 180)
COL_BTN_ACTIVE  = (100, 140, 200)
COL_BTN_DANGER  = (140, 70, 70)
COL_BTN_SUCCESS = (60, 140, 70)
COL_BORDER      = (140, 170, 220)
COL_BORDER_SOFT = (60, 65, 80)
COL_TEXT        = (240, 240, 240)
COL_TEXT_DIM    = (180, 190, 210)
COL_TEXT_MUTE   = (120, 130, 150)
COL_ACCENT      = (255, 200, 100)
COL_SELECT      = (255, 80, 80)
COL_HIGHLIGHT   = (255, 220, 100)
COL_GRID        = (60, 65, 80)
COL_GRID_AXIS   = (90, 90, 110)

# ============================================================
# ПРЕСЕТЫ ЦВЕТОВ
# ============================================================
COLOR_PRESETS = [
    ((1.0, 0.3, 0.3), "Красный"),
    ((1.0, 0.6, 0.2), "Оранжевый"),
    ((1.0, 1.0, 0.3), "Жёлтый"),
    ((0.3, 0.9, 0.3), "Зелёный"),
    ((0.3, 0.8, 1.0), "Голубой"),
    ((0.3, 0.4, 1.0), "Синий"),
    ((0.8, 0.4, 1.0), "Фиолетовый"),
    ((1.0, 0.5, 0.8), "Розовый"),
    ((0.6, 0.6, 0.6), "Серый"),
    ((1.0, 1.0, 1.0), "Белый"),
    ((0.05, 0.05, 0.05), "Чёрный"),
    ((0.5, 0.35, 0.2), "Коричневый"),
]


# ============================================================
# УТИЛИТЫ
# ============================================================
def rgb_to_hex(rgb):
    r, g, b = rgb
    return f"{int(max(0, min(1, r)) * 255):02X}{int(max(0, min(1, g)) * 255):02X}{int(max(0, min(1, b)) * 255):02X}"


def hex_to_rgb(h):
    h = h.lstrip('#')
    try:
        return (int(h[0:2], 16) / 255.0,
                int(h[2:4], 16) / 255.0,
                int(h[4:6], 16) / 255.0)
    except Exception:
        return (0.5, 0.5, 0.8)


def lerp(a, b, t):
    return a + (b - a) * t


# ============================================================
# МЕШ
# ============================================================
class MeshObject:
    def __init__(self, name="object"):
        self.name = name
        self.vertices = []   # [(x, y, z)]
        self.faces = []      # [(i, j, k)]
        self.colors = []     # [(r, g, b)] 0..1
        self.selected_faces = set()
        self.pos = [0.0, 0.0, 0.0]   # трансформация объекта
        self.rot = [0.0, 0.0, 0.0]
        self.scale_v = [1.0, 1.0, 1.0]

    # --- базовая геометрия ---
    def add_vertices(self, verts):
        base = len(self.vertices)
        self.vertices.extend(verts)
        return base

    def add_face(self, face_indices, color=(0.5, 0.5, 0.8)):
        self.faces.append(tuple(face_indices))
        self.colors.append(tuple(color))

    def face_normal(self, idx):
        f = self.faces[idx]
        v0, v1, v2 = self.vertices[f[0]], self.vertices[f[1]], self.vertices[f[2]]
        u = (v1[0] - v0[0], v1[1] - v0[1], v1[2] - v0[2])
        v = (v2[0] - v0[0], v2[1] - v0[1], v2[2] - v0[2])
        n = (u[1] * v[2] - u[2] * v[1],
             u[2] * v[0] - u[0] * v[2],
             u[0] * v[1] - u[1] * v[0])
        ln = math.sqrt(n[0] ** 2 + n[1] ** 2 + n[2] ** 2)
        return (n[0] / ln, n[1] / ln, n[2] / ln) if ln > 0 else (0, 0, 1)

    def face_center(self, idx):
        f = self.faces[idx]
        return tuple(sum(self.vertices[i][k] for i in f) / 3 for k in range(3))

    # --- операции ---
    def move(self, dx, dy, dz):
        self.pos[0] += dx
        self.pos[1] += dy
        self.pos[2] += dz

    def scale(self, factor):
        for i in range(3):
            self.scale_v[i] *= factor

    def rotate(self, rx, ry, rz):
        self.rot[0] += rx
        self.rot[1] += ry
        self.rot[2] += rz

    def paint_all(self, color):
        """Красит все грани объекта одним цветом."""
        self.colors = [tuple(color)] * len(self.faces)

    def paint_faces(self, indices, color):
        for i in indices:
            if 0 <= i < len(self.colors):
                self.colors[i] = tuple(color)

    def delete_faces(self, indices):
        for i in sorted(indices, reverse=True):
            if 0 <= i < len(self.faces):
                del self.faces[i]
                del self.colors[i]
        self.selected_faces.clear()

    def extrude_face(self, face_idx, amount=0.3):
        if not (0 <= face_idx < len(self.faces)):
            return False
        face = self.faces[face_idx]
        if len(face) < 3:
            return False
        n = self.face_normal(face_idx)
        offset = tuple(d * amount for d in n)
        new_verts = []
        for idx in face:
            old = self.vertices[idx]
            new_verts.append((old[0] + offset[0],
                              old[1] + offset[1],
                              old[2] + offset[2]))
        new_base = self.add_vertices(new_verts)
        new_indices = [new_base + i for i in range(len(new_verts))]
        old_indices = list(face)
        # Боковые стенки
        for i in range(len(face)):
            j = (i + 1) % len(face)
            self.add_face((old_indices[i], old_indices[j], new_indices[i]),
                          (0.5, 0.5, 0.8))
            self.add_face((old_indices[j], new_indices[j], new_indices[i]),
                          (0.5, 0.5, 0.8))
        # Заменяем исходную грань на верхнюю
        self.faces[face_idx] = tuple(new_indices)
        self.colors[face_idx] = (1.0, 0.8, 0.2)
        return True

    def mirror(self, axis):
        ai = {'x': 0, 'y': 1, 'z': 2}[axis]
        for i, v in enumerate(self.vertices):
            new_v = list(v)
            new_v[ai] *= -1
            self.vertices[i] = tuple(new_v)
        # Переворачиваем winding
        self.faces = [tuple(reversed(f)) for f in self.faces]

    def bounding_box(self):
        if not self.vertices:
            return None
        mn = [min(v[i] for v in self.vertices) for i in range(3)]
        mx = [max(v[i] for v in self.vertices) for i in range(3)]
        return (mn, mx)

    def transform_matrix(self):
        """Возвращает матрицу трансформации 4x4 (в виде списка списков)."""
        rx, ry, rz = self.rot
        sx, sy, sz = self.scale_v
        cx, sx_ = math.cos(rx), math.sin(rx)
        cy, sy_ = math.cos(ry), math.sin(ry)
        cz, sz_ = math.cos(rz), math.sin(rz)

        # Rotation X
        mx = [[1, 0, 0, 0],
              [0, cx, -sx_, 0],
              [0, sx_, cx, 0],
              [0, 0, 0, 1]]
        # Rotation Y
        my = [[cy, 0, sy_, 0],
              [0, 1, 0, 0],
              [-sy_, 0, cy, 0],
              [0, 0, 0, 1]]
        # Rotation Z
        mz = [[cz, -sz_, 0, 0],
              [sz_, cz, 0, 0],
              [0, 0, 1, 0],
              [0, 0, 0, 1]]
        # Scale
        ms = [[sx, 0, 0, 0],
              [0, sy, 0, 0],
              [0, 0, sz, 0],
              [0, 0, 0, 1]]
        # Translate
        mt = [[1, 0, 0, self.pos[0]],
              [0, 1, 0, self.pos[1]],
              [0, 0, 1, self.pos[2]],
              [0, 0, 0, 1]]

        def mm(a, b):
            r = [[0] * 4 for _ in range(4)]
            for i in range(4):
                for j in range(4):
                    for k in range(4):
                        r[i][j] += a[i][k] * b[k][j]
            return r

        return mm(mt, mm(mz, mm(my, mm(mx, ms))))


def make_cube(size=1.0):
    obj = MeshObject("cube")
    h = size / 2
    v = [(-h, -h, -h), (h, -h, -h), (h, h, -h), (-h, h, -h),
         (-h, -h, h), (h, -h, h), (h, h, h), (-h, h, h)]
    obj.add_vertices(v)
    for f in [(0, 1, 2), (0, 2, 3), (4, 6, 5), (4, 7, 6),
              (0, 4, 5), (0, 5, 1), (3, 2, 6), (3, 6, 7),
              (0, 3, 7), (0, 7, 4), (1, 5, 6), (1, 6, 2)]:
        obj.add_face(f, (0.5, 0.5, 0.8))
    return obj


def make_sphere(radius=1.0, segments=16):
    obj = MeshObject("sphere")
    verts = []
    for i in range(segments + 1):
        theta = i * math.pi / segments
        for j in range(segments + 1):
            phi = j * 2 * math.pi / segments
            verts.append((radius * math.sin(theta) * math.cos(phi),
                          radius * math.cos(theta),
                          radius * math.sin(theta) * math.sin(phi)))
    obj.add_vertices(verts)
    for i in range(segments):
        for j in range(segments):
            a = i * (segments + 1) + j
            b = a + 1
            c = (i + 1) * (segments + 1) + j
            d = c + 1
            obj.add_face((a, b, c), (0.5, 0.8, 0.5))
            obj.add_face((b, d, c), (0.5, 0.8, 0.5))
    return obj


def make_cylinder(radius=0.8, height=1.5, segments=16):
    obj = MeshObject("cylinder")
    bottom, top = [], []
    for i in range(segments):
        th = i * 2 * math.pi / segments
        x, z = radius * math.cos(th), radius * math.sin(th)
        bottom.append((x, -height / 2, z))
        top.append((x, height / 2, z))
    base = obj.add_vertices(bottom + top)
    for i in range(segments):
        a, b = base + i, base + (i + 1) % segments
        c, d = base + segments + i, base + segments + (i + 1) % segments
        obj.add_face((a, b, c), (0.8, 0.5, 0.5))
        obj.add_face((b, d, c), (0.8, 0.5, 0.5))
    tc = obj.add_vertices([(0, height / 2, 0)])
    bc = obj.add_vertices([(0, -height / 2, 0)])
    for i in range(segments):
        a = base + i
        b = base + (i + 1) % segments
        obj.add_face((a, b, tc), (0.8, 0.5, 0.8))
        obj.add_face((b, a, bc), (0.8, 0.5, 0.8))
    return obj


def make_plane(size=2.0):
    obj = MeshObject("plane")
    h = size / 2
    b = obj.add_vertices([(-h, 0, -h), (h, 0, -h), (h, 0, h), (-h, 0, h)])
    obj.add_face((b, b + 1, b + 2), (0.6, 0.6, 0.6))
    obj.add_face((b, b + 2, b + 3), (0.6, 0.6, 0.6))
    return obj


def make_cone(radius=0.8, height=1.5, segments=16):
    obj = MeshObject("cone")
    verts = []
    for i in range(segments):
        th = i * 2 * math.pi / segments
        verts.append((radius * math.cos(th), -height / 2, radius * math.sin(th)))
    base = obj.add_vertices(verts)
    apex = obj.add_vertices([(0, height / 2, 0)])
    bottom_c = obj.add_vertices([(0, -height / 2, 0)])
    for i in range(segments):
        a = base + i
        b = base + (i + 1) % segments
        obj.add_face((a, b, apex), (0.9, 0.7, 0.5))
        obj.add_face((b, a, bottom_c), (0.6, 0.4, 0.3))
    return obj


def make_torus(R=0.8, r=0.3, seg_major=16, seg_minor=8):
    obj = MeshObject("torus")
    verts = []
    for i in range(seg_major):
        u = i * 2 * math.pi / seg_major
        for j in range(seg_minor):
            v = j * 2 * math.pi / seg_minor
            x = (R + r * math.cos(v)) * math.cos(u)
            y = r * math.sin(v)
            z = (R + r * math.cos(v)) * math.sin(u)
            verts.append((x, y, z))
    obj.add_vertices(verts)
    for i in range(seg_major):
        for j in range(seg_minor):
            a = i * seg_minor + j
            b = i * seg_minor + (j + 1) % seg_minor
            c = ((i + 1) % seg_major) * seg_minor + j
            d = ((i + 1) % seg_major) * seg_minor + (j + 1) % seg_minor
            obj.add_face((a, b, c), (0.7, 0.7, 0.9))
            obj.add_face((b, d, c), (0.7, 0.7, 0.9))
    return obj


PRIMITIVES = {
    'cube':     make_cube,
    'sphere':   make_sphere,
    'cylinder': make_cylinder,
    'plane':    make_plane,
    'cone':     make_cone,
    'torus':    make_torus,
}


# ============================================================
# РЕДАКТОР
# ============================================================
class GBJEditor:
    TOOLBAR_H = 60
    BOTTOM_H  = 130
    PAD       = 20

    def __init__(self, width=1400, height=744):
        pygame.init()
        self.w, self.h = width, height
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption("Gradus GBJ Editor")
        self.clock = pygame.time.Clock()

        self.font_sm = pygame.font.SysFont('Arial', 14)
        self.font_md = pygame.font.SysFont('Arial', 16, bold=True)
        self.font_lg = pygame.font.SysFont('Arial', 20, bold=True)
        self.font_ttl = pygame.font.SysFont('Arial', 22, bold=True)

        # Объекты
        self.objects = []
        self.current_object_index = -1
        self.selected_faces = set()
        self.clipboard = None

        # Undo / redo
        self.undo_stack = []
        self.redo_stack = []

        # Вид
        self.view_rot_x = 20.0
        self.view_rot_y = 30.0
        self.view_zoom = 1.0
        self.view_pan = [0.0, 0.0]

        # Mouse
        self.drag_mode = None       # 'rotate' | 'pan' | None
        self.drag_last = (0, 0)

        # Настройки инструмента
        self.current_color = (0.8, 0.4, 0.4)
        self.paint_mode = 'face'
        self.show_grid = True
        self.show_axes = True
        self.wireframe = False
        self.smooth_light = True
        self.hovered_face = None

        # Дефолтные величины для операций
        self.move_step = 0.2  # шаг стрелок
        self.scale_step = 1.1  # множитель Ctrl+wheel
        self.rotate_step = 15.0  # градусов за клик поворота
        self.extrude_amount = 0.3  # величина экструзии

        # Скролл панели обучения
        self.help_scroll = 0
        self.help_scroll_max = 0
        self.help_rect = pygame.Rect(0, 0, 0, 0)

        # Файл
        self.filename = "model.gbj"
        self.editing_filename = False
        self.filename_buf = ""

        # Примитив
        self.prim_size = 1.0
        self.prim_segments = 16

        # Диалог выхода
        self.exit_dialog = False
        self._should_quit = False  # ← НОВОЕ: реальный флаг выхода

        # Сообщение
        self.message = "Готово. ЛКМ по грани — выбрать, ПКМ+тяни — панорама."
        self.message_t = 5.0

        # Кнопки
        self.buttons = {}          # name -> {'rect', 'label', 'cb'}
        self._build_buttons()

        # Стартовый куб
        self.add_object(make_cube(1.0))

    def add_object(self, obj):
        """Добавляет готовый MeshObject и делает его активным."""
        self.objects.append(obj)
        self.current_object_index = len(self.objects) - 1
        self.selected_faces.clear()
        return obj
    def cmd_rotate_faces(self, axis, sign=1):
        """Поворачивает выделенные грани вокруг их общего центра."""
        if self.current_object_index < 0 or not self.selected_faces:
            self.show_msg("Сначала выберите грани")
            return
        self.push_undo()
        obj = self.objects[self.current_object_index]

        # Центр выделения
        all_vidx = set()
        for fi in self.selected_faces:
            if 0 <= fi < len(obj.faces):
                all_vidx.update(obj.faces[fi])
        if not all_vidx:
            return
        cx = sum(obj.vertices[i][0] for i in all_vidx) / len(all_vidx)
        cy = sum(obj.vertices[i][1] for i in all_vidx) / len(all_vidx)
        cz = sum(obj.vertices[i][2] for i in all_vidx) / len(all_vidx)

        ang = math.radians(self.rotate_step * sign)
        ca, sa = math.cos(ang), math.sin(ang)
        for i in all_vidx:
            x, y, z = obj.vertices[i]
            dx, dy, dz = x - cx, y - cy, z - cz
            if axis == 'x':
                ny = dy * ca - dz * sa
                nz = dy * sa + dz * ca
                obj.vertices[i] = (cx + dx, cy + ny, cz + nz)
            elif axis == 'y':
                nx = dx * ca + dz * sa
                nz = -dx * sa + dz * ca
                obj.vertices[i] = (cx + nx, cy + dy, cz + nz)
            elif axis == 'z':
                nx = dx * ca - dy * sa
                ny = dx * sa + dy * ca
                obj.vertices[i] = (cx + nx, cy + ny, cz + dz)
        self.show_msg(f"Поворот граней вокруг {axis.upper()}: {self.rotate_step}°")

    def cmd_move_object(self, dx, dy, dz):
        """Смещает активный объект целиком."""
        if self.current_object_index < 0:
            return
        obj = self.objects[self.current_object_index]
        obj.pos[0] += dx
        obj.pos[1] += dy
        obj.pos[2] += dz

    def cmd_scale_object(self, factor):
        """Масштабирует активный объект целиком."""
        if self.current_object_index < 0:
            return
        obj = self.objects[self.current_object_index]
        for i in range(3):
            obj.scale_v[i] *= factor
    # --------------------------------------------------------
    # UI / кнопки
    # --------------------------------------------------------
    def _build_buttons(self):
        self.buttons = {}

        # Верхний тулбар
        self.buttons['new']    = {'rect': pygame.Rect(20, 15, 90, 32),
                                  'label': 'Новая',    'cb': self.cmd_new}
        self.buttons['open']   = {'rect': pygame.Rect(118, 15, 100, 32),
                                  'label': 'Открыть',  'cb': self.cmd_open}
        self.buttons['save']   = {'rect': pygame.Rect(226, 15, 100, 32),
                                  'label': 'Сохранить','cb': self.cmd_save}
        self.buttons['exit']   = {'rect': pygame.Rect(334, 15, 80, 32),
                                  'label': 'Выход',    'cb': self.cmd_exit}

        # Название файла
        self.name_rect = pygame.Rect(430, 18, 320, 26)

        # Правые верхние переключатели
        self.toggle_rects = {
            'grid':      pygame.Rect(780, 15, 90, 32),
            'axes':      pygame.Rect(878, 15, 90, 32),
            'wire':      pygame.Rect(976, 15, 90, 32),
            'smooth':    pygame.Rect(1074, 15, 100, 32),
        }

        # Правые нижние кнопки (панель)
        px = self.w - 380
        py = self.TOOLBAR_H + 20
        bw, bh = 110, 30
        gap = 8

        def place_row(y, items):
            x = px + 8
            for label, cb in items:
                self.buttons[label.lower().replace(' ', '_').replace('+', '_p')] = {
                    'rect': pygame.Rect(x, y, bw, bh),
                    'label': label,
                    'cb': cb,
                }
                x += bw + gap

        # Ряд примитивов
        place_row(py + 40, [
            ('Куб',      lambda: self.spawn('cube')),
            ('Сфера',    lambda: self.spawn('sphere')),
            ('Цилиндр',  lambda: self.spawn('cylinder')),
        ])
        place_row(py + 40 + bh + gap, [
            ('Плоскость', lambda: self.spawn('plane')),
            ('Конус',     lambda: self.spawn('cone')),
            ('Тор',       lambda: self.spawn('torus')),
        ])

        # Операции объекта
        op_y = py + 190
        place_row(op_y, [
            ('Дублир.',   self.cmd_duplicate),
            ('Удалить',   self.cmd_delete_object),
            ('Центр',     self.cmd_center_object),
        ])
        place_row(op_y + bh + gap, [
            ('Зеркало X', lambda: self.cmd_mirror('x')),
            ('Зеркало Y', lambda: self.cmd_mirror('y')),
            ('Зеркало Z', lambda: self.cmd_mirror('z')),
        ])

        # Операции над гранями
        # Операции над гранями
        f_y = op_y + 2 * (bh + gap) + 10
        place_row(f_y, [
            ('Экструзия', self.cmd_extrude),
            ('Удалить грань', self.cmd_delete_faces),
            ('Все грани', self.cmd_select_all_faces),
        ])
        place_row(f_y + bh + gap, [
            ('Красить грани', self.cmd_paint_selected),
            ('Красить объект', self.cmd_paint_object),
            ('Красить всё', self.cmd_paint_everything),
        ])

        # Повороты граней
        place_row(f_y + 2 * (bh + gap), [
            ('Rot X', lambda: self.cmd_rotate_faces('x', +1)),
            ('Rot Y', lambda: self.cmd_rotate_faces('y', +1)),
            ('Rot Z', lambda: self.cmd_rotate_faces('z', +1)),
        ])

        # Undo / redo
        place_row(f_y + 3 * (bh + gap), [
            ('Undo', self.cmd_undo),
            ('Redo', self.cmd_redo),
            ('Сброс выдел.', self.cmd_clear_selection),
        ])
    def cmd_paint_selected(self):
        """Красит только выделенные грани (по кнопке)."""
        if self.current_object_index < 0 or not self.selected_faces:
            self.show_msg("Сначала выберите грани")
            return
        self.push_undo()
        obj = self.objects[self.current_object_index]
        obj.paint_faces(list(self.selected_faces), self.current_color)
        self.show_msg(f"Граней окрашено: {len(self.selected_faces)}")

    def cmd_paint_object(self):
        """Красит активный объект целиком."""
        if self.current_object_index < 0:
            return
        self.push_undo()
        obj = self.objects[self.current_object_index]
        obj.paint_all(self.current_color)
        self.show_msg(f"Объект '{obj.name}' окрашен целиком")

    def cmd_paint_everything(self):
        """Красит ВСЕ объекты на сцене."""
        if not self.objects:
            return
        self.push_undo()
        for obj in self.objects:
            obj.paint_all(self.current_color)
        self.show_msg(f"Все объекты ({len(self.objects)}) окрашены")

    # --------------------------------------------------------
    # Команды
    # --------------------------------------------------------
    def show_msg(self, text, t=3.0):
        self.message = text
        self.message_t = t
        print(f"[GBJ] {text}")

    def push_undo(self):
        snapshot = [copy.deepcopy(o) for o in self.objects]
        self.undo_stack.append(snapshot)
        if len(self.undo_stack) > 50:
            self.undo_stack.pop(0)
        self.redo_stack.clear()

    def cmd_undo(self):
        if not self.undo_stack:
            self.show_msg("Нечего отменять")
            return
        self.redo_stack.append([copy.deepcopy(o) for o in self.objects])
        self.objects = self.undo_stack.pop()
        if self.current_object_index >= len(self.objects):
            self.current_object_index = len(self.objects) - 1
        self.selected_faces.clear()
        self.show_msg("Отменено")

    def cmd_redo(self):
        if not self.redo_stack:
            self.show_msg("Нечего повторять")
            return
        self.undo_stack.append([copy.deepcopy(o) for o in self.objects])
        self.objects = self.redo_stack.pop()
        if self.current_object_index >= len(self.objects):
            self.current_object_index = len(self.objects) - 1
        self.selected_faces.clear()
        self.show_msg("Повторено")

    def cmd_new(self):
        self.objects = []
        self.current_object_index = -1
        self.selected_faces.clear()
        self.add_object(make_cube(1.0))
        self.show_msg("Новая модель")

    def cmd_open(self):
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk()
            root.withdraw()
            root.attributes('-topmost', True)
            path = filedialog.askopenfilename(
                title="Открыть .gbj",
                initialdir="models",
                filetypes=[("GBJ model", "*.gbj"), ("Все файлы", "*.*")],
            )
            root.destroy()
            if path:
                self.load_gbj(path)
        except Exception as e:
            self.show_msg(f"Ошибка диалога: {e}")

    def cmd_save(self):
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk()
            root.withdraw()
            root.attributes('-topmost', True)
            os.makedirs("models", exist_ok=True)
            path = filedialog.asksaveasfilename(
                title="Сохранить .gbj",
                initialdir="models",
                initialfile=self.filename,
                defaultextension=".gbj",
                filetypes=[("GBJ model", "*.gbj"), ("Все файлы", "*.*")],
            )
            root.destroy()
            if path:
                self.save_gbj(path)
        except Exception as e:
            self.show_msg(f"Ошибка диалога: {e}")

    def cmd_exit(self):
        self.exit_dialog = True

    def cmd_duplicate(self):
        if self.current_object_index < 0:
            return
        self.push_undo()
        obj = copy.deepcopy(self.objects[self.current_object_index])
        obj.pos[0] += 1.0
        self.objects.append(obj)
        self.current_object_index = len(self.objects) - 1
        self.show_msg("Объект дублирован")

    def cmd_delete_object(self):
        if self.current_object_index < 0:
            return
        self.push_undo()
        del self.objects[self.current_object_index]
        if not self.objects:
            self.current_object_index = -1
        else:
            self.current_object_index = max(0, self.current_object_index - 1)
        self.selected_faces.clear()
        self.show_msg("Объект удалён")

    def cmd_center_object(self):
        if self.current_object_index < 0:
            return
        obj = self.objects[self.current_object_index]
        bbox = obj.bounding_box()
        if not bbox:
            return
        mn, mx = bbox
        obj.pos = [-(mn[i] + mx[i]) / 2 for i in range(3)]
        self.show_msg("Объект центрирован")

    def cmd_mirror(self, axis):
        if self.current_object_index < 0:
            return
        self.push_undo()
        self.objects[self.current_object_index].mirror(axis)
        self.show_msg(f"Зеркало по {axis.upper()}")

    def cmd_extrude(self):
        if self.current_object_index < 0 or not self.selected_faces:
            self.show_msg("Сначала выберите грань")
            return
        self.push_undo()
        obj = self.objects[self.current_object_index]
        count = 0
        for fi in list(self.selected_faces):
            if obj.extrude_face(fi, amount=0.3 * max(obj.scale_v)):
                count += 1
        self.selected_faces.clear()
        self.show_msg(f"Экструзия граней: {count}")

    def cmd_delete_faces(self):
        if self.current_object_index < 0 or not self.selected_faces:
            return
        self.push_undo()
        obj = self.objects[self.current_object_index]
        obj.delete_faces(list(self.selected_faces))
        self.selected_faces.clear()
        self.show_msg("Грани удалены")

    def cmd_select_all_faces(self):
        if self.current_object_index < 0:
            return
        obj = self.objects[self.current_object_index]
        self.selected_faces = set(range(len(obj.faces)))
        self.show_msg(f"Выделено граней: {len(self.selected_faces)}")

    def cmd_clear_selection(self):
        self.selected_faces.clear()
        self.show_msg("Выделение сброшено")

    def spawn(self, kind):
        self.push_undo()
        maker = PRIMITIVES.get(kind)
        if not maker:
            return
        if kind in ('sphere', 'cylinder', 'cone', 'torus'):
            obj = maker(segments=self.prim_segments) if kind != 'torus' \
                else maker(seg_major=self.prim_segments, seg_minor=max(4, self.prim_segments // 2))
        else:
            obj = maker(self.prim_size) if kind in ('cube', 'plane') else maker()
        # Небольшой сдвиг, чтобы новый объект был виден
        obj.pos[0] = len(self.objects) * 0.5
        self.add_object(obj)
        self.show_msg(f"Добавлен: {kind}")

    # --------------------------------------------------------
    # Загрузка / сохранение
    # --------------------------------------------------------
    def save_gbj(self, path):
        all_v, all_f, all_c = [], [], []
        for obj in self.objects:
            base = len(all_v)
            all_v.extend(obj.vertices)
            for i, face in enumerate(obj.faces):
                all_f.append(tuple(idx + base for idx in face))
                all_c.append(obj.colors[i])
        try:
            parent = os.path.dirname(path)
            if parent:
                os.makedirs(parent, exist_ok=True)
            with open(path, 'w', encoding='utf-8') as f:
                f.write(f"# Gradus GBJ model\n")
                f.write(f"# objects: {len(self.objects)}\n")
                for v in all_v:
                    f.write(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")
                for i, face in enumerate(all_f):
                    r, g, b = all_c[i]
                    hx = rgb_to_hex((r, g, b))
                    f.write(f"f {face[0] + 1} {face[1] + 1} {face[2] + 1} {hx}\n")
            self.filename = os.path.basename(path)
            self.show_msg(f"Сохранено: {path}")
        except Exception as e:
            self.show_msg(f"Ошибка сохранения: {e}")

    def load_gbj(self, path):
        try:
            obj = MeshObject(os.path.basename(path))
            with open(path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    parts = line.split()
                    if parts[0] == 'v':
                        obj.vertices.append((float(parts[1]),
                                             float(parts[2]),
                                             float(parts[3])))
                    elif parts[0] == 'f':
                        color = (0.5, 0.5, 0.8)
                        idx = []
                        for p in parts[1:]:
                            if len(p) == 6 and all(c in '0123456789ABCDEFabcdef' for c in p):
                                color = hex_to_rgb(p)
                            else:
                                idx.append(int(p.split('/')[0]) - 1)
                        for k in range(1, len(idx) - 1):
                            obj.add_face((idx[0], idx[k], idx[k + 1]), color)
            if not obj.faces:
                self.show_msg("Файл пуст или не содержит граней")
                return
            self.objects = [obj]
            self.current_object_index = 0
            self.selected_faces.clear()
            self.filename = os.path.basename(path)
            self.show_msg(f"Загружено: {len(obj.vertices)} в. / {len(obj.faces)} г.")
        except Exception as e:
            self.show_msg(f"Ошибка загрузки: {e}")

    # --------------------------------------------------------
    # Проекция / picking
    # --------------------------------------------------------
    def viewport_rect(self):
        return pygame.Rect(self.PAD, self.TOOLBAR_H + 10,
                           self.w - 400 - self.PAD,
                           self.h - self.TOOLBAR_H - self.BOTTOM_H - 20)

    def _get_view_matrix(self):
        rx = math.radians(self.view_rot_x)
        ry = math.radians(self.view_rot_y)
        cx, sx_ = math.cos(rx), math.sin(rx)
        cy, sy_ = math.cos(ry), math.sin(ry)

        def mat_mul3(a, b):
            r = [[0] * 3 for _ in range(3)]
            for i in range(3):
                for j in range(3):
                    for k in range(3):
                        r[i][j] += a[i][k] * b[k][j]
            return r

        mx = [[1, 0, 0], [0, cx, -sx_], [0, sx_, cx]]
        my = [[cy, 0, sy_], [0, 1, 0], [-sy_, 0, cy]]
        return mat_mul3(my, mx)

    def project(self, p_world):
        """p_world (x, y, z) -> (screen_x, screen_y, depth)."""
        vp = self.viewport_rect()
        m = self._get_view_matrix()
        x, y, z = p_world
        # Поворот
        rx = m[0][0] * x + m[0][1] * y + m[0][2] * z
        ry = m[1][0] * x + m[1][1] * y + m[1][2] * z
        rz = m[2][0] * x + m[2][1] * y + m[2][2] * z
        # Панорама
        rx += self.view_pan[0]
        ry += self.view_pan[1]
        # Камера
        scale = 200 * self.view_zoom
        cam_z = 4.5
        if cam_z + rz == 0: rz += 0.01
        persp = scale / (cam_z + rz)
        sx = vp.centerx + rx * persp
        sy = vp.centery - ry * persp
        return (sx, sy, rz)

    def get_all_world_verts(self):
        """Все вершины всех объектов в мировых координатах (с трансформ.)."""
        out = []
        for oi, obj in enumerate(self.objects):
            M = obj.transform_matrix()
            for vi, v in enumerate(obj.vertices):
                wx = M[0][0] * v[0] + M[0][1] * v[1] + M[0][2] * v[2] + M[0][3]
                wy = M[1][0] * v[0] + M[1][1] * v[1] + M[1][2] * v[2] + M[1][3]
                wz = M[2][0] * v[0] + M[2][1] * v[1] + M[2][2] * v[2] + M[2][3]
                out.append((oi, vi, (wx, wy, wz)))
        return out

    def pick_face(self, mouse_pos):
        """Возвращает (obj_index, face_index) или None."""
        obj = self.objects[self.current_object_index] if self.current_object_index >= 0 else None
        if not obj:
            return None
        mx, my = mouse_pos
        best = None
        best_depth = float('inf')
        M = obj.transform_matrix()
        for fi, face in enumerate(obj.faces):
            pts = []
            for v in face:
                vv = obj.vertices[v]
                wx = M[0][0] * vv[0] + M[0][1] * vv[1] + M[0][2] * vv[2] + M[0][3]
                wy = M[1][0] * vv[0] + M[1][1] * vv[1] + M[1][2] * vv[2] + M[1][3]
                wz = M[2][0] * vv[0] + M[2][1] * vv[1] + M[2][2] * vv[2] + M[2][3]
                sx, sy, d = self.project((wx, wy, wz))
                pts.append((sx, sy, d))
            # Триангуляция fan
            for k in range(1, len(pts) - 1):
                p1, p2, p3 = pts[0], pts[k], pts[k + 1]
                if point_in_triangle((mx, my), (p1[0], p1[1]),
                                     (p2[0], p2[1]), (p3[0], p3[1])):
                    d = (p1[2] + p2[2] + p3[2]) / 3
                    if d < best_depth:
                        best_depth = d
                        best = fi
        if best is None:
            return None
        return (self.current_object_index, best)

    # --------------------------------------------------------
    # Рендер
    # --------------------------------------------------------
    def render(self):
        self.screen.fill(COL_BG)
        self._render_viewport()
        self._render_toolbar()
        self._render_right_panel()
        self._render_bottom_bar()
        self._render_message()
        if self.exit_dialog:
            self._render_exit_dialog()
        pygame.display.flip()

    def _render_viewport(self):
        vp = self.viewport_rect()
        pygame.draw.rect(self.screen, (18, 20, 28), vp, border_radius=8)
        pygame.draw.rect(self.screen, COL_BORDER_SOFT, vp, 1, border_radius=8)

        # Сетка
        if self.show_grid:
            self._draw_ground_grid(vp)

        # Оси
        if self.show_axes:
            self._draw_axes()

        # Все объекты (сортировка по глубине)
        self._draw_objects()

    def _draw_ground_grid(self, vp):
        # Сетка на "полу" y = -0.5
        y0 = -0.5
        n = 10
        step = 0.5
        for i in range(-n, n + 1):
            x = i * step
            p1 = self.project((x, y0, -n * step))
            p2 = self.project((x, y0, n * step))
            p3 = self.project((-n * step, y0, x))
            p4 = self.project((n * step, y0, x))
            col = COL_GRID_AXIS if i == 0 else COL_GRID
            self._line(vp, p1, p2, col, 1)
            self._line(vp, p3, p4, col, 1)

    def _draw_axes(self):
        vp = self.viewport_rect()
        origin = self.project((0, 0, 0))
        x_end = self.project((1.5, 0, 0))
        y_end = self.project((0, 1.5, 0))
        z_end = self.project((0, 0, 1.5))
        self._line(vp, origin, x_end, (255, 80, 80), 2)
        self._line(vp, origin, y_end, (80, 255, 80), 2)
        self._line(vp, origin, z_end, (80, 120, 255), 2)

    def _line(self, vp, p1, p2, color, w=1):
        pygame.draw.line(self.screen, color,
                         (int(p1[0]), int(p1[1])),
                         (int(p2[0]), int(p2[1])), w)

    def _draw_objects(self):
        vp = self.viewport_rect()
        old_clip = self.screen.get_clip()
        self.screen.set_clip(vp)

        # Собираем все грани
        all_faces = []  # (depth, oi, fi, screen_pts, color, normal_world)
        for oi, obj in enumerate(self.objects):
            M = obj.transform_matrix()
            for fi, face in enumerate(obj.faces):
                pts = []
                world_pts = []
                for v in face:
                    vv = obj.vertices[v]
                    wx = M[0][0] * vv[0] + M[0][1] * vv[1] + M[0][2] * vv[2] + M[0][3]
                    wy = M[1][0] * vv[0] + M[1][1] * vv[1] + M[1][2] * vv[2] + M[1][3]
                    wz = M[2][0] * vv[0] + M[2][1] * vv[1] + M[2][2] * vv[2] + M[2][3]
                    world_pts.append((wx, wy, wz))
                    sx, sy, d = self.project((wx, wy, wz))
                    pts.append((sx, sy, d))
                if len(pts) < 3:
                    continue
                depth = sum(p[2] for p in pts) / len(pts)
                # Нормаль
                if len(world_pts) >= 3:
                    v0, v1, v2 = world_pts[0], world_pts[1], world_pts[2]
                    u = (v1[0] - v0[0], v1[1] - v0[1], v1[2] - v0[2])
                    vv2 = (v2[0] - v0[0], v2[1] - v0[1], v2[2] - v0[2])
                    n = (u[1] * vv2[2] - u[2] * vv2[1],
                         u[2] * vv2[0] - u[0] * vv2[2],
                         u[0] * vv2[1] - u[1] * vv2[0])
                    ln = math.sqrt(sum(c * c for c in n))
                    if ln > 0:
                        n = tuple(c / ln for c in n)
                else:
                    n = (0, 0, 1)
                all_faces.append((depth, oi, fi, pts, obj.colors[fi], n))

        all_faces.sort(key=lambda t: t[0], reverse=True)

        # Light dir
        light_dir = (0.4, 0.7, -0.5)
        ln = math.sqrt(sum(c * c for c in light_dir))
        light_dir = tuple(c / ln for c in light_dir)

        for depth, oi, fi, pts, color, normal in all_faces:
            if self.wireframe:
                poly = [(int(p[0]), int(p[1])) for p in pts]
                if len(poly) >= 3:
                    pygame.draw.polygon(self.screen, color_to_int(color), poly, 1)
                continue
            # Освещение
            if self.smooth_light:
                diff = max(0, sum(normal[i] * light_dir[i] for i in range(3)))
                intensity = 0.3 + 0.7 * diff
            else:
                intensity = 1.0
            base = tuple(int(c * 255 * intensity) for c in color)
            base = tuple(max(0, min(255, c)) for c in base)
            poly = [(int(p[0]), int(p[1])) for p in pts]
            if len(poly) >= 3:
                pygame.draw.polygon(self.screen, base, poly)

            # Обводка выделенных граней
            is_selected = (oi == self.current_object_index and fi in self.selected_faces)
            is_hovered = (self.hovered_face == (oi, fi))
            if is_selected:
                pygame.draw.polygon(self.screen, COL_SELECT, poly, 2)
            elif is_hovered:
                pygame.draw.polygon(self.screen, COL_HIGHLIGHT, poly, 2)

        # Вершины активного объекта
        if self.current_object_index >= 0:
            obj = self.objects[self.current_object_index]
            M = obj.transform_matrix()
            for v in obj.vertices:
                wx = M[0][0] * v[0] + M[0][1] * v[1] + M[0][2] * v[2] + M[0][3]
                wy = M[1][0] * v[0] + M[1][1] * v[1] + M[1][2] * v[2] + M[1][3]
                wz = M[2][0] * v[0] + M[2][1] * v[1] + M[2][2] * v[2] + M[2][3]
                sx, sy, _ = self.project((wx, wy, wz))
                pygame.draw.circle(self.screen, (255, 255, 255),
                                   (int(sx), int(sy)), 3)

        self.screen.set_clip(old_clip)

    def _render_toolbar(self):
        pygame.draw.rect(self.screen, COL_TOOLBAR, (0, 0, self.w, self.TOOLBAR_H))
        pygame.draw.line(self.screen, COL_BORDER_SOFT,
                         (0, self.TOOLBAR_H), (self.w, self.TOOLBAR_H), 1)

        for name, btn in self.buttons.items():
            rect = btn['rect']
            if rect.y > 100:  # пропускаем нижние кнопки
                continue
            col = COL_BTN_DANGER if name == 'exit' else COL_BTN
            hov = rect.collidepoint(pygame.mouse.get_pos())
            if hov:
                col = COL_BTN_HOVER if name != 'exit' else (180, 90, 90)
            pygame.draw.rect(self.screen, col, rect, border_radius=6)
            pygame.draw.rect(self.screen, COL_BORDER, rect, 1, border_radius=6)
            t = self.font_sm.render(btn['label'], True, COL_TEXT)
            self.screen.blit(t, (rect.x + (rect.w - t.get_width()) // 2,
                                 rect.y + (rect.h - t.get_height()) // 2))

        # Имя файла
        pygame.draw.rect(self.screen, (60, 80, 120), self.name_rect, border_radius=4)
        pygame.draw.rect(self.screen, COL_BORDER, self.name_rect, 1, border_radius=4)
        text = self.filename_buf + "_" if self.editing_filename else self.filename
        nt = self.font_md.render(text, True, COL_TEXT)
        self.screen.blit(nt, (self.name_rect.x + 8, self.name_rect.y + 4))

        # Переключатели
        states = {
            'grid': ('Сетка', self.show_grid),
            'axes': ('Оси', self.show_axes),
            'wire': ('Каркас', self.wireframe),
            'smooth': ('Свет', self.smooth_light),
        }
        for key, rect in self.toggle_rects.items():
            label, on = states[key]
            col = COL_BTN_ACTIVE if on else (60, 70, 90)
            hov = rect.collidepoint(pygame.mouse.get_pos())
            if hov:
                col = (col[0] + 30, col[1] + 30, col[2] + 30)
            pygame.draw.rect(self.screen, col, rect, border_radius=6)
            pygame.draw.rect(self.screen, COL_BORDER, rect, 1, border_radius=6)
            t = self.font_sm.render(label, True, COL_TEXT)
            self.screen.blit(t, (rect.x + (rect.w - t.get_width()) // 2,
                                 rect.y + (rect.h - t.get_height()) // 2))

    def _render_right_panel(self):
        panel_x = self.w - 380
        panel_y = self.TOOLBAR_H + 10
        panel_w = 370
        panel_h = self.h - self.TOOLBAR_H - self.BOTTOM_H - 20

        pygame.draw.rect(self.screen, COL_PANEL,
                         (panel_x, panel_y, panel_w, panel_h), border_radius=8)
        pygame.draw.rect(self.screen, COL_BORDER_SOFT,
                         (panel_x, panel_y, panel_w, panel_h), 1, border_radius=8)

        head = self.font_lg.render("ПРИМИТИВЫ", True, COL_ACCENT)
        self.screen.blit(head, (panel_x + 12, panel_y + 10))

        # Параметры примитива
        py = panel_y + 110
        info = self.font_sm.render(
            f"Размер: {self.prim_size:.2f}   Сегменты: {self.prim_segments}",
            True, COL_TEXT_DIM)
        self.screen.blit(info, (panel_x + 12, py))

        # Нижние кнопки-операции — рисуем их
        head2 = self.font_lg.render("ОПЕРАЦИИ", True, COL_ACCENT)
        self.screen.blit(head2, (panel_x + 12, py + 40))

        # Рисуем все нижние кнопки
        for name, btn in self.buttons.items():
            if btn['rect'].y < 100:
                continue
            rect = btn['rect']
            col = COL_BTN
            hov = rect.collidepoint(pygame.mouse.get_pos())
            if hov:
                col = COL_BTN_HOVER
            pygame.draw.rect(self.screen, col, rect, border_radius=6)
            pygame.draw.rect(self.screen, COL_BORDER, rect, 1, border_radius=6)
            t = self.font_sm.render(btn['label'], True, COL_TEXT)
            self.screen.blit(t, (rect.x + (rect.w - t.get_width()) // 2,
                                 rect.y + (rect.h - t.get_height()) // 2))

        # Цветовая палитра
        (_, palette_y, sw, sp, cols, start_x, start_y) = self._palette_layout()
        pygame.draw.line(self.screen, COL_BORDER_SOFT,
                         (panel_x + 8, palette_y - 8),
                         (panel_x + panel_w - 8, palette_y - 8), 1)
        head3 = self.font_lg.render("ЦВЕТ", True, COL_ACCENT)
        self.screen.blit(head3, (panel_x + 12, palette_y))
        for i, (rgb, name) in enumerate(COLOR_PRESETS):
            cx = start_x + (i % cols) * (sw + sp)
            cy = start_y + (i // cols) * (sw + sp)
            r = pygame.Rect(cx, cy, sw, sw)
            hov = r.collidepoint(pygame.mouse.get_pos())
            is_cur = tuple(rgb) == tuple(self.current_color)
            pygame.draw.rect(self.screen, color_to_int(rgb), r, border_radius=6)
            if is_cur:
                pygame.draw.rect(self.screen, (255, 255, 255), r, 3, border_radius=6)
            elif hov:
                pygame.draw.rect(self.screen, COL_BORDER, r, 2, border_radius=6)

    def _render_bottom_bar(self):
        y0 = self.h - self.BOTTOM_H
        pygame.draw.rect(self.screen, COL_PANEL_SOFT, (0, y0, self.w, self.BOTTOM_H))
        pygame.draw.line(self.screen, COL_BORDER_SOFT, (0, y0), (self.w, y0), 1)

        # --- Левая часть: список объектов ---
        head = self.font_lg.render("ОБЪЕКТЫ", True, COL_ACCENT)
        self.screen.blit(head, (16, y0 + 8))

        x = 120
        bw, bh = 110, 60
        gap = 8
        max_x = self.w - 420  # оставляем место под панель обучения
        for i, obj in enumerate(self.objects):
            if x + bw > max_x:
                break
            r = pygame.Rect(x, y0 + 30, bw, bh)
            active = (i == self.current_object_index)
            col = COL_BTN_ACTIVE if active else (60, 65, 80)
            hov = r.collidepoint(pygame.mouse.get_pos())
            if hov and not active:
                col = (80, 90, 110)
            pygame.draw.rect(self.screen, col, r, border_radius=6)
            pygame.draw.rect(self.screen, COL_BORDER, r, 1, border_radius=6)
            name = obj.name[:12]
            t1 = self.font_sm.render(name, True, COL_TEXT)
            t2 = self.font_sm.render(f"V:{len(obj.vertices)} F:{len(obj.faces)}",
                                     True, COL_TEXT_DIM)
            self.screen.blit(t1, (r.x + 6, r.y + 8))
            self.screen.blit(t2, (r.x + 6, r.y + 30))
            x += bw + gap

        # --- Правая часть: обучение ---
        help_x = self.w - 400
        help_w = 380
        help_rect = pygame.Rect(help_x, y0 + 4, help_w, self.BOTTOM_H - 8)
        self.help_rect = help_rect  # ← для обработки скролла

        pygame.draw.rect(self.screen, (30, 34, 44), help_rect, border_radius=6)
        pygame.draw.rect(self.screen, COL_BORDER_SOFT, help_rect, 1, border_radius=6)

        head2 = self.font_md.render("УПРАВЛЕНИЕ", True, COL_ACCENT)
        self.screen.blit(head2, (help_rect.x + 8, help_rect.y + 4))

        lines = [
            "ЛКМ по грани — выбрать   ·   Shift+ЛКМ — добавить",
            "ЛКМ в пустоте / зажать — вращение вида",
            "ПКМ зажать — панорама",
            "Колесо — зум вида   ·   Ctrl+колесо — масштаб объекта",
            "Стрелки — двигать объект   ·   Alt+стрелки — по Z",
            "Shift+стрелки — медленный шаг",
            "A / D / W / S — панорама вида",
            "+ / − — зум вида",
            "F — сбросить вид   ·   H / X / W — сетка / оси / каркас",
            "E — экструзия выделенных граней",
            "Delete — удалить грани   ·   Ctrl+A — все грани",
            "Ctrl+Z / Ctrl+Y — undo / redo",
            "Ctrl+D — дублировать   ·   Ctrl+S / O / N — файл",
            "1..9 — цвет + покрасить выделенные грани",
            "Shift + 1..9 — покрасить ВЕСЬ объект целиком",
            "Кнопки «Красить грани / объект / всё» — то же самое",
            "ESC — выход (диалог)",
        ]
        clip_rect = pygame.Rect(help_rect.x + 4, help_rect.y + 28,
                                help_rect.w - 8, help_rect.h - 32)
        old_clip = self.screen.get_clip()
        self.screen.set_clip(clip_rect)

        line_h = self.font_sm.get_linesize() + 2
        total_h = line_h * len(lines)
        self.help_scroll_max = max(0, total_h - clip_rect.h)

        for i, line in enumerate(lines):
            y = clip_rect.y + i * line_h - self.help_scroll
            if y + line_h < clip_rect.y or y > clip_rect.y + clip_rect.h:
                continue
            t = self.font_sm.render(line, True, (180, 190, 210))
            self.screen.blit(t, (clip_rect.x + 4, y))

        self.screen.set_clip(old_clip)

        # Индикатор скролла справа от панели (если нужно)
        if self.help_scroll_max > 0:
            track = pygame.Rect(help_rect.right - 6, clip_rect.y, 3, clip_rect.h)
            pygame.draw.rect(self.screen, (60, 65, 80), track, border_radius=2)
            ratio = self.help_scroll / self.help_scroll_max
            bar_h = max(20, int(clip_rect.h * clip_rect.h / total_h))
            bar_y = clip_rect.y + int((clip_rect.h - bar_h) * ratio)
            pygame.draw.rect(self.screen, COL_ACCENT,
                             (track.x, bar_y, 3, bar_h), border_radius=2)

        # Информация в левом нижнем углу
        info = self.font_sm.render(
            f"Объектов: {len(self.objects)}   "
            f"Выбрано граней: {len(self.selected_faces)}   "
            f"Zoom: {int(self.view_zoom * 100)}%",
            True, COL_TEXT_DIM)
        self.screen.blit(info, (16, self.h - 20))

    def _render_message(self):
        if self.message_t <= 0:
            return
        t = self.font_md.render(self.message, True, (255, 240, 180))
        bg = pygame.Surface((t.get_width() + 24, t.get_height() + 12),
                            pygame.SRCALPHA)
        bg.fill((0, 0, 0, 200))
        self.screen.blit(bg, (self.w // 2 - t.get_width() // 2 - 12, 72))
        self.screen.blit(t, (self.w // 2 - t.get_width() // 2, 78))

    def _render_exit_dialog(self):
        ov = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
        ov.fill((0, 0, 0, 170))
        self.screen.blit(ov, (0, 0))

        dw, dh = 720, 260
        dx = (self.w - dw) // 2
        dy = (self.h - dh) // 2
        panel = pygame.Rect(dx, dy, dw, dh)
        pygame.draw.rect(self.screen, (40, 45, 60), panel, border_radius=14)
        pygame.draw.rect(self.screen, COL_BORDER, panel, 2, border_radius=14)

        title = self.font_ttl.render("Сохранить перед выходом?", True, COL_ACCENT)
        self.screen.blit(title, title.get_rect(center=(self.w // 2, dy + 60)))
        hint = self.font_sm.render(
            "S / Enter — сохранить   ·   D — без сохранения   ·   Esc — отмена",
            True, COL_TEXT_DIM)
        self.screen.blit(hint, hint.get_rect(center=(self.w // 2, dy + 100)))

        bw, bh = 200, 52
        gap = 20
        labels = [
            ('Сохранить',      COL_BTN_SUCCESS, 'save'),
            ('Без сохранения', COL_BTN_DANGER,  'discard'),
            ('Отмена',         (70, 80, 110),   'cancel'),
        ]
        cx = self.w // 2 - (bw * 3 + gap * 2) // 2
        y = dy + 150
        for i, (label, col, key) in enumerate(labels):
            r = pygame.Rect(cx + i * (bw + gap), y, bw, bh)
            hov = r.collidepoint(pygame.mouse.get_pos())
            draw_col = (col[0] + 30, col[1] + 30, col[2] + 30) if hov else col
            pygame.draw.rect(self.screen, draw_col, r, border_radius=10)
            pygame.draw.rect(self.screen, COL_BORDER, r, 1, border_radius=10)
            t = self.font_md.render(label, True, COL_TEXT)
            self.screen.blit(t, t.get_rect(center=r.center))

    # --------------------------------------------------------
    # Обработка событий
    # --------------------------------------------------------
    def handle_event(self, e):
        if e.type == pygame.QUIT:
            self.exit_dialog = True
            return

        if self.exit_dialog:
            self._handle_exit_dialog(e)
            return

        if self.editing_filename:
            self._handle_filename_input(e)
            return

        if e.type == pygame.MOUSEWHEEL:
            mx, my = pygame.mouse.get_pos()
            mods = pygame.key.get_mods()

            # Скролл панели обучения
            if self.help_rect.collidepoint(mx, my):
                self.help_scroll -= e.y * 30
                self.help_scroll = max(0, min(self.help_scroll_max,
                                              self.help_scroll))
                return

            if self.viewport_rect().collidepoint(mx, my):
                if mods & pygame.KMOD_CTRL:
                    # Ctrl+колесо = масштаб объекта
                    if self.current_object_index < 0:
                        return
                    self.push_undo()
                    factor = 1.1 if e.y > 0 else 1 / 1.1
                    self.cmd_scale_object(factor)
                    self.show_msg(
                        f"Масштаб объекта: x{self.objects[self.current_object_index].scale_v[0]:.2f}")
                else:
                    factor = 1.15 if e.y > 0 else 1 / 1.15
                    self.view_zoom = max(0.15, min(6.0, self.view_zoom * factor))
            return
        if e.type == pygame.MOUSEBUTTONDOWN:
            self._handle_mouse_down(e)
            return

        if e.type == pygame.MOUSEBUTTONUP:
            if e.button in (1, 3):
                self.drag_mode = None
            return

        if e.type == pygame.MOUSEMOTION:
            self._handle_mouse_motion(e)
            return

        if e.type == pygame.KEYDOWN:
            self._handle_keydown(e)
            return

    def _handle_exit_dialog(self, e):
        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_ESCAPE:
                self.exit_dialog = False
            elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_s):
                self.cmd_save()
                self.exit_dialog = False
                self._should_quit = True
            elif e.key == pygame.K_d:
                self.exit_dialog = False
                self._should_quit = True
            return
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            dw, dh = 720, 260
            dx = (self.w - dw) // 2
            dy = (self.h - dh) // 2
            bw, bh = 200, 52
            gap = 20
            cx = self.w // 2 - (bw * 3 + gap * 2) // 2
            y = dy + 150
            labels = ['save', 'discard', 'cancel']
            for i in range(3):
                r = pygame.Rect(cx + i * (bw + gap), y, bw, bh)
                if r.collidepoint(e.pos):
                    key = labels[i]
                    if key == 'save':
                        self.cmd_save()
                        self.exit_dialog = False
                        self._should_quit = True
                    elif key == 'discard':
                        self.exit_dialog = False
                        self._should_quit = True
                    else:
                        self.exit_dialog = False
                    return

    def _handle_filename_input(self, e):
        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_RETURN:
                if self.filename_buf.strip():
                    self.filename = self.filename_buf.strip()
                self.editing_filename = False
            elif e.key == pygame.K_ESCAPE:
                self.editing_filename = False
            elif e.key == pygame.K_BACKSPACE:
                self.filename_buf = self.filename_buf[:-1]
            else:
                ch = e.unicode
                if ch and ch.isprintable() and ch not in ('/', '\\'):
                    self.filename_buf += ch

    def _palette_layout(self):
        """Возвращает (panel_x, palette_y, sw, sp, cols, start_x, start_y)."""
        panel_x = self.w - 380
        panel_y = self.TOOLBAR_H + 10
        panel_h = self.h - self.TOOLBAR_H - self.BOTTOM_H - 20
        palette_y = panel_y + panel_h - 100
        sw, sp, cols = 34, 6, 6
        start_x = panel_x + 12
        start_y = palette_y + 30
        return (panel_x, palette_y, sw, sp, cols, start_x, start_y)

    def _handle_mouse_down(self, e):
        mx, my = e.pos

        # Клик по имени файла
        if e.button == 1 and self.name_rect.collidepoint(mx, my):
            self.editing_filename = True
            self.filename_buf = self.filename
            return

        # Клик по верхнему тулбару
        if my < self.TOOLBAR_H:
            for name, btn in self.buttons.items():
                if btn['rect'].y < 100 and btn['rect'].collidepoint(mx, my):
                    btn['cb']()
                    return
            for key, rect in self.toggle_rects.items():
                if rect.collidepoint(mx, my):
                    if key == 'grid':
                        self.show_grid = not self.show_grid
                    elif key == 'axes':
                        self.show_axes = not self.show_axes
                    elif key == 'wire':
                        self.wireframe = not self.wireframe
                    elif key == 'smooth':
                        self.smooth_light = not self.smooth_light
                    return
            return

        # Клик по нижним кнопкам-операциям
        for name, btn in self.buttons.items():
            if btn['rect'].y >= 100 and btn['rect'].collidepoint(mx, my):
                btn['cb']()
                return

        # Клик по палитре цветов
        # Клик по палитре цветов
        (_, _, sw, sp, cols, start_x, start_y) = self._palette_layout()
        for i, (rgb, name) in enumerate(COLOR_PRESETS):
            r = pygame.Rect(start_x + (i % cols) * (sw + sp),
                            start_y + (i // cols) * (sw + sp), sw, sw)
            if r.collidepoint(mx, my):
                self.current_color = rgb
                # Shift клик = покрасить весь объект, обычный = выделенные грани
                shift = pygame.key.get_mods() & pygame.KMOD_SHIFT

                if shift and self.current_object_index >= 0:
                    self.push_undo()
                    self.objects[self.current_object_index].paint_all(rgb)
                    self.show_msg(f"Объект окрашен в {name}")
                elif self.selected_faces and self.current_object_index >= 0:
                    self.push_undo()
                    self.objects[self.current_object_index].paint_faces(
                        list(self.selected_faces), rgb)
                    self.show_msg(f"Грани окрашены в {name}")
                else:
                    self.show_msg(f"Цвет: {name}")
                return

        # Клик по списку объектов
        y0 = self.h - self.BOTTOM_H
        if my >= y0 + 30:
            x = 120
            bw, bh = 110, 60
            gap = 8
            for i in range(len(self.objects)):
                r = pygame.Rect(x, y0 + 30, bw, bh)
                if r.collidepoint(mx, my):
                    self.current_object_index = i
                    self.selected_faces.clear()
                    self.show_msg(f"Активный объект: {self.objects[i].name}")
                    return
                x += bw + gap
                if x + bw > self.w - 10:
                    break
            return

        # Viewport
        if self.viewport_rect().collidepoint(mx, my):
            if e.button == 1:
                # Попробовать выбрать грань
                pick = self.pick_face((mx, my))
                if pick:
                    oi, fi = pick
                    if pygame.key.get_mods() & pygame.KMOD_SHIFT:
                        if fi in self.selected_faces:
                            self.selected_faces.discard(fi)
                        else:
                            self.selected_faces.add(fi)
                    else:
                        self.selected_faces = {fi}
                    self.show_msg(f"Грань {fi} выбрана (всего {len(self.selected_faces)})")
                else:
                    # Не попали по грани → вращение
                    self.drag_mode = 'rotate'
                    self.drag_last = (mx, my)
                    self.selected_faces.clear()
            elif e.button == 3:
                self.drag_mode = 'pan'
                self.drag_last = (mx, my)

    def _handle_mouse_motion(self, e):
        mx, my = e.pos
        # Hover-подсветка
        if self.viewport_rect().collidepoint(mx, my) and not self.drag_mode:
            pick = self.pick_face((mx, my))
            self.hovered_face = pick
        else:
            self.hovered_face = None

        if self.drag_mode == 'rotate':
            dx, dy = mx - self.drag_last[0], my - self.drag_last[1]
            self.view_rot_y -= dx * 0.5
            self.view_rot_x -= dy * 0.5
            self.view_rot_x = max(-89, min(89, self.view_rot_x))
            self.drag_last = (mx, my)
        elif self.drag_mode == 'pan':
            dx, dy = mx - self.drag_last[0], my - self.drag_last[1]
            self.view_pan[0] += dx / (200 * self.view_zoom)
            self.view_pan[1] -= dy / (200 * self.view_zoom)
            self.drag_last = (mx, my)

    def _handle_keydown(self, e):
        mods = pygame.key.get_mods()

        if e.key == pygame.K_ESCAPE:
            self.exit_dialog = True
            return

        # Undo / redo
        if e.key == pygame.K_z and (mods & pygame.KMOD_CTRL):
            if mods & pygame.KMOD_SHIFT:
                self.cmd_redo()
            else:
                self.cmd_undo()
            return
        if e.key == pygame.K_y and (mods & pygame.KMOD_CTRL):
            self.cmd_redo()
            return

        # Save / open
        if e.key == pygame.K_s and (mods & pygame.KMOD_CTRL):
            self.cmd_save()
            return
        if e.key == pygame.K_o and (mods & pygame.KMOD_CTRL):
            self.cmd_open()
            return
        if e.key == pygame.K_n and (mods & pygame.KMOD_CTRL):
            self.cmd_new()
            return

        # Дублировать
        if e.key == pygame.K_d and (mods & pygame.KMOD_CTRL):
            self.cmd_duplicate()
            return

        # Delete
        if e.key == pygame.K_DELETE:
            self.cmd_delete_faces()
            return

        # Focus
        if e.key == pygame.K_f:
            self.view_zoom = 1.5
            self.view_pan = [0, 0]
            self.view_rot_x = 20
            self.view_rot_y = 30
            self.show_msg("Вид сфокусирован")
            return

        # +/- — зум вида
        if e.key in (pygame.K_EQUALS, pygame.K_PLUS, pygame.K_KP_PLUS):
            self.view_zoom = min(6.0, self.view_zoom * 1.15)
            return
        if e.key in (pygame.K_MINUS, pygame.K_KP_MINUS):
            self.view_zoom = max(0.15, self.view_zoom / 1.15)
            return
        # WASD — панорама вида
        pan_step = 0.15 / self.view_zoom
        if e.key == pygame.K_a:
            self.view_pan[0] += pan_step
        elif e.key == pygame.K_d:
            self.view_pan[0] -= pan_step
        elif e.key == pygame.K_w:
            self.view_pan[1] += pan_step
        elif e.key == pygame.K_s:
            self.view_pan[1] -= pan_step

        # Toggle
        if e.key == pygame.K_h:
            self.show_grid = not self.show_grid
            return
        if e.key == pygame.K_x:
            self.show_axes = not self.show_axes
            return
        if e.key == pygame.K_w:
            self.wireframe = not self.wireframe
            return

        # Стрелки — двигают активный объект (Shift = медленнее, Alt = по Z)
        if e.key in (pygame.K_LEFT, pygame.K_RIGHT,
                     pygame.K_UP, pygame.K_DOWN):
            if self.current_object_index < 0:
                return
            shift = pygame.key.get_mods() & pygame.KMOD_SHIFT
            alt = pygame.key.get_mods() & pygame.KMOD_ALT
            step = self.move_step * (0.1 if shift else 1.0)
            self.push_undo()
            if e.key == pygame.K_LEFT:
                self.cmd_move_object(-step, 0, 0)
            elif e.key == pygame.K_RIGHT:
                self.cmd_move_object(+step, 0, 0)
            elif e.key == pygame.K_UP:
                if alt:
                    self.cmd_move_object(0, 0, +step)
                else:
                    self.cmd_move_object(0, +step, 0)
            elif e.key == pygame.K_DOWN:
                if alt:
                    self.cmd_move_object(0, 0, -step)
                else:
                    self.cmd_move_object(0, -step, 0)
            return

        # Экструзия по E
        if e.key == pygame.K_e:
            self.cmd_extrude()

        # Выделить всё — Ctrl+A
        if e.key == pygame.K_a and (mods & pygame.KMOD_CTRL):
            self.cmd_select_all_faces()

        # Цифры 1..9 — цвет.
        #   без модификаторов: красит выделенные грани
        #   Shift + цифра:     красит активный объект целиком
        if pygame.K_1 <= e.key <= pygame.K_9:
            idx = e.key - pygame.K_1
            if idx < len(COLOR_PRESETS):
                self.current_color = COLOR_PRESETS[idx][0]
                shift = pygame.key.get_mods() & pygame.KMOD_SHIFT

                if shift and self.current_object_index >= 0:
                    # Красим весь объект
                    self.push_undo()
                    self.objects[self.current_object_index].paint_all(
                        self.current_color)
                    self.show_msg(
                        f"Объект окрашен: {COLOR_PRESETS[idx][1]}")
                elif self.selected_faces and self.current_object_index >= 0:
                    # Красим только выделенные грани
                    self.push_undo()
                    self.objects[self.current_object_index].paint_faces(
                        list(self.selected_faces), self.current_color)
                    self.show_msg(
                        f"Грани окрашены: {COLOR_PRESETS[idx][1]}")
                else:
                    self.show_msg(f"Цвет: {COLOR_PRESETS[idx][1]}")

    # --------------------------------------------------------
    # Update / Run
    # --------------------------------------------------------
    def update(self, dt):
        if self.message_t > 0:
            self.message_t -= dt

    def run(self):
        running = True
        while running:
            dt = self.clock.tick(60) / 1000.0
            for e in pygame.event.get():
                # Настоящий выход — только через флаг
                if self._should_quit:
                    running = False
                    break
                # Системный QUIT — открываем диалог (не закрываем сразу)
                if e.type == pygame.QUIT:
                    if not self.exit_dialog:
                        self.exit_dialog = True
                    continue
                self.handle_event(e)
            if self._should_quit:
                running = False
            if not running:
                break
            self.update(dt)
            self.render()
        pygame.quit()


def point_in_triangle(p, a, b, c):
    """Проверка точки внутри треугольника (2D)."""
    def sign(p1, p2, p3):
        return (p1[0] - p3[0]) * (p2[1] - p3[1]) - (p2[0] - p3[0]) * (p1[1] - p3[1])
    d1 = sign(p, a, b)
    d2 = sign(p, b, c)
    d3 = sign(p, c, a)
    has_neg = (d1 < 0) or (d2 < 0) or (d3 < 0)
    has_pos = (d1 > 0) or (d2 > 0) or (d3 > 0)
    return not (has_neg and has_pos)


def color_to_int(rgb):
    return (int(max(0, min(1, rgb[0])) * 255),
            int(max(0, min(1, rgb[1])) * 255),
            int(max(0, min(1, rgb[2])) * 255))


if __name__ == "__main__":
    GBJEditor().run()