import pygame
import sys
import os


def _find_project_root(start):
    """Ищем папку, где лежит пакет gradus_rc."""
    cur = start
    for _ in range(8):
        if os.path.isdir(os.path.join(cur, 'gradus_rc')):
            return cur
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    return start


_root = _find_project_root(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _root)

# Меняем рабочий каталог на корень проекта — иначе ассеты не найдутся
os.chdir(_root)
print(f"[Play] Working dir: {os.getcwd()}")

from gradus_rc import Engine
from gradus_rc.cutscene import Cutscene, CutscenePlayer


EMPTY_MAP = """
[COLLISION]
1 1 1
1 0 1
1 1 1
[FLOOR_COLOR=333333]
[CEILING_COLOR=111111]
[SPAWN=1.5,1.5]
[AMBIENT=0.15]
"""


def main():
    if len(sys.argv) < 2:
        print("Usage: python play_cutscene.py <path.gs3>")
        return
    path = sys.argv[1]

    pygame.init()
    W, H = 960, 540
    screen = pygame.display.set_mode((W, H))
    pygame.display.set_caption(f"Cutscene Preview: {os.path.basename(path)}")
    clock = pygame.time.Clock()

    engine = Engine(
        clock=clock, levels=[EMPTY_MAP], current_level=0,
        width=W, height=H, fov=70, rays=200, tile_size=64,
        player_speed=0.0, player_rot_speed=0.0,
        rt_quality='balanced')
    engine.enemy_ai_paused = True

    try:
        cs = Cutscene.load(path)
    except Exception as e:
        print(f"[Play] Failed to load cutscene: {e}")
        pygame.quit()
        return

    player = CutscenePlayer(engine, cs)
    engine.cutscene_player = player  # ← регистрируем в движке
    player.start()

    running = True
    last_log = 0.0
    while running:
        dt = clock.tick(60) / 1000.0
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            elif e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                running = False
        keys = pygame.key.get_pressed()
        engine.update(dt, keys)
        engine.render(screen)
        if player.playing:
            last_log += dt
            if last_log >= 0.5:
                last_log = 0.0
                print(f"[Play] t={player.time:.2f}/{cs.total_duration:.2f} "
                      f"playing={player.playing}")
        else:
            # После конца сцены подержим 1 секунду и закроем
            pygame.time.delay(300)
            running = False
        pygame.display.flip()

    pygame.quit()


if __name__ == "__main__":
    main()