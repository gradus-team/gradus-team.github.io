# REDACTORS/map_editor.py
"""
Gradus Map Editor — редактор карт.

Управление:
  ЛКМ (зажать)          — рисовать / ставить активный инструмент
  ЛКМ короткий          — поставить
  ПКМ короткий по клетке— открыть окно тегов этой клетки
  ПКМ (зажать и тянуть) — панорама
  SHIFT+ЛКМ             — точка спавна
  ALT+ЛКМ               — враг
  CTRL+ЛКМ              — модель
  Колесо мыши           — зум (в сетке)
  Ctrl+колесо           — размер кисти (1..5)
  A / D                 — размер кисти
  0..9                  — быстрый выбор тайла
  Tab                   — след. вкладка панели
  G / P                 — сетка / счётчик тегов
  Ctrl+Z / Ctrl+Y       — undo / redo
  Ctrl+S / O / N        — файл
  Ctrl+I                — импорт .txt
  F5                    — Play (запуск карты в движке)
  ESC                   — выход с диалогом
"""
import pygame
import os
import sys
import json
import math
import copy
import glob
import subprocess
import traceback

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# ============================================================
# ПАЛИТРА
# ============================================================
COL_BG          = (25, 28, 38)
COL_TOOLBAR     = (40, 45, 60)
COL_PANEL       = (40, 45, 60)
COL_PANEL_SOFT  = (30, 34, 44)
COL_BTN         = (70, 90, 130)
COL_BTN_HOVER   = (100, 130, 180)
COL_BTN_ACTIVE  = (100, 140, 200)
COL_BTN_DANGER  = (140, 70, 70)
COL_BTN_SUCCESS = (60, 140, 70)
COL_BORDER      = (140, 170, 220)
COL_BORDER_SOFT = (60, 65, 80)
COL_TEXT        = (240, 240, 240)
COL_TEXT_DIM    = (180, 190, 210)
COL_TEXT_MUTE   = (120, 130, 150)
COL_ACCENT      = (255, 200, 100)
COL_SELECT      = (255, 80, 80)
COL_HIGHLIGHT   = (255, 220, 100)
COL_SPAWN       = (255, 200, 60)
COL_ENEMY       = (200, 80, 80)
COL_MODEL       = (80, 180, 80)
COL_DOOR        = (200, 180, 60)
COL_KEY         = (255, 215, 100)
COL_PORTAL      = (80, 140, 220)
COL_TRIGGER     = (140, 80, 200)
COL_BILBOARD    = (180, 100, 200)

TILE_COLORS = {
    0: (30, 33, 45), 1: (120, 120, 120), 2: (140, 200, 220),
    3: (140, 90, 70), 4: (150, 110, 60), 5: (180, 180, 200),
    6: (80, 180, 80), 7: (200, 180, 60), 8: (140, 80, 200),
    9: (80, 140, 220),
}

TILE_NAMES = {
    0: 'Пусто', 1: 'Бетон', 2: 'Стекло', 3: 'Кирпич', 4: 'Дерево',
    5: 'Металл', 6: 'Модель', 7: 'Дверь/Ключ', 8: 'Триггер', 9: 'Портал',
}

MATERIALS = ['none', 'brick', 'concrete', 'stone', 'metal',
             'silver', 'glass', 'wood', 'marble', 'granite',
             'earth', 'plaster', 'obsidian', 'gold', 'copper',
             'sand', 'snow', 'water', 'lava']
ALPHAS = [1.0, 0.75, 0.5, 0.25]
HEIGHTS = [1.0, 0.75, 0.5, 0.25, 0.1]
ENEMY_TYPES = ['static', 'chase', 'patrol', 'multiplayer']
ATTACK_TYPES = ['ranged', 'melee']
LOGIC_KINDS = ['door', 'key', 'portal', 'trigger']
FLOOR_COLORS = ['333333', '444444', '555555', '222222', '666666', '111111']
CEIL_COLORS = ['111111', '222222', '000000', '333333', '1a1a2e']
FOG_COLORS = ['303040', '202030', '101020', '404050', '000000', '1a1a1a']
LIGHT_COLORS = [
    ('Белый', [255, 255, 255]),
    ('Тёплый', [255, 220, 160]),
    ('Холодный', [180, 220, 255]),
    ('Красный', [255, 120, 100]),
    ('Зелёный', [120, 255, 140]),
    ('Синий', [100, 140, 255]),
    ('Жёлтый', [255, 240, 100]),
    ('Фиолетовый', [200, 130, 255]),
]
GRID_SIZES = [8, 16, 24, 32, 48, 64]

CELL_BASE = 48

TOOLS = [
    ('wall', 'Рисовать'), ('erase', 'Стереть'), ('spawn', 'Спавн'),
    ('enemy', 'Враг'), ('model', 'Модель'), ('light', 'Свет'),
    ('door', 'Дверь'), ('key', 'Ключ'), ('portal', 'Портал'),
    ('trigger', 'Триггер'), ('bilboard', 'Билборд'),
    ('team_spawn_blue', 'Спавн синих'),
    ('team_spawn_red', 'Спавн красных'),
]

TABS = [
    ('tile', 'Тайл'), ('enemy', 'Враг'), ('model', 'Модель'),
    ('logic', 'Логика'), ('light', 'Свет'), ('bilb', 'Билборд'),
    ('map', 'Карта'),
]


# ============================================================
# Схема тегов по ID
# ============================================================
# Для каждой ID: список (ключ, тип, варианты/подсказка)
#   type: 'enum' | 'number' | 'text' | 'bool'
TAG_SCHEMA = {
    0: [
        ('floor_h', 'number', 'высота пола (-0.4..0.9)'),
        ('ceil_h',  'number', 'сдвиг потолка вниз (-0.4..0.9)'),
        ('enemy',   'text',   'строка врага: type=chase;hp=100;...'),
    ],
    1: [
        ('material',     'enum', ['brick', 'concrete', 'stone', 'metal',
                                   'silver', 'glass', 'wood', 'marble',
                                   'granite', 'gold', 'copper', 'sand',
                                   'snow', 'obsidian', 'plaster']),
        ('alpha',        'enum', [1.0, 0.75, 0.5, 0.25]),
        ('height',       'enum', [1.0, 0.75, 0.5, 0.25, 0.1]),
        ('color',        'text',  'hex #RRGGBB'),
        ('isvisible',    'bool', None),
        ('addcollision', 'bool', None),
        ('destructible', 'bool', None),
        ('hp',           'number', 'прочность'),
        ('reflectivity', 'number', '0..1'),
        ('sprite',       'text',  'путь к текстуре'),
        ('water',        'bool', None),
        ('puddle',       'bool', None),
    ],
    2: [
        ('material',     'enum', ['glass', 'ice', 'silver']),
        ('alpha',        'enum', [1.0, 0.75, 0.5, 0.25]),
        ('height',       'enum', [1.0, 0.75, 0.5, 0.25, 0.1]),
        ('isvisible',    'bool', None),
        ('addcollision', 'bool', None),
    ],
    3: [
        ('material',     'enum', ['brick', 'concrete', 'wood']),
        ('alpha',        'enum', [1.0, 0.75, 0.5, 0.25]),
        ('height',       'enum', [1.0, 0.75, 0.5, 0.25, 0.1]),
        ('destructible', 'bool', None),
        ('hp',           'number', 'прочность'),
        ('addcollision', 'bool', None),
    ],
    4: [
        ('material',     'enum', ['wood', 'plaster']),
        ('alpha',        'enum', [1.0, 0.75, 0.5, 0.25]),
        ('height',       'enum', [1.0, 0.75, 0.5, 0.25, 0.1]),
        ('destructible', 'bool', None),
        ('hp',           'number', 'прочность'),
    ],
    5: [
        ('material',     'enum', ['metal', 'silver', 'copper', 'gold']),
        ('alpha',        'enum', [1.0, 0.75, 0.5, 0.25]),
        ('height',       'enum', [1.0, 0.75, 0.5, 0.25, 0.1]),
        ('reflectivity', 'number', '0..1'),
        ('addcollision', 'bool', None),
    ],
    6: [
        ('path',        'text',  'путь к .obj / .gbj'),
        ('texture',     'text',  'текстура поверх модели'),
        ('rotx',        'number', 'градусы'),
        ('roty',        'number', 'градусы'),
        ('rotz',        'number', 'градусы'),
        ('scale',       'number', 'множитель'),
        ('color',       'text',  'hex #RRGGBB'),
        ('pushable',    'bool', None),
        ('mass',        'number', 'масса'),
        ('friction',    'number', '0..1'),
        ('bounciness',  'number', '0..1'),
        ('interactive', 'bool', None),
        ('on_press',    'text',  'имя события'),
        ('radius',      'number', 'радиус взаимодействия'),
        ('anim',        'text',  'путь1,путь2,...'),
        ('anim_speed',  'number', 'сек/кадр'),
    ],
    7: [
        ('type',      'enum', ['door', 'key']),
        ('id',        'text',  'уникальный ID'),
        ('link',      'text',  'связь с дверью'),
        ('material',  'enum', ['concrete', 'wood', 'metal', 'glass']),
        ('height',    'enum', [1.0, 0.9, 0.75, 0.5]),
        ('texture',   'text',  'путь'),
        ('isvisible', 'bool', None),
    ],
    8: [
        ('id',     'text', 'уникальный ID'),
        ('action', 'text', 'имя события'),
    ],
    9: [
        ('level',     'number', 'целевой уровень'),
        ('target_x',  'number', 'мировые координаты'),
        ('target_y',  'number', 'мировые координаты'),
        ('isvisible', 'bool', None),
        ('material',  'enum', ['glass', 'concrete', 'silver']),
    ],
}


def get_tag_schema(tile_id):
    """Возвращает список тегов для ID."""
    return TAG_SCHEMA.get(tile_id, [])


# ============================================================
# Окно редактора тегов клетки
# ============================================================
class TagEditorWindow:
    """Модальное окно для редактирования тегов клетки."""
    def __init__(self, editor, cx, cy):
        self.editor = editor
        self.cx = cx
        self.cy = cy
        self.tile_id = editor.cells[cy][cx]
        self.props = dict(editor.props.get((cx, cy), {}))
        self.schema = get_tag_schema(self.tile_id)
        self.scroll = 0
        self.max_scroll = 0
        self.edit_field = None       # key, который сейчас редактируется
        self.edit_buf = ""
        self.hover_row = None
        self.row_rects = {}
        self.button_rects = {}

        # Геометрия
        self.w = 560
        self.h = 620
        self.x = (editor.w - self.w) // 2
        self.y = (editor.h - self.h) // 2
        self.rect = pygame.Rect(self.x, self.y, self.w, self.h)

    def _get_value(self, key):
        v = self.props.get(key)
        if v is None:
            return '— не задано —'
        if isinstance(v, bool):
            return 'да' if v else 'нет'
        return str(v)

    def _set_value(self, key, value):
        self.props[key] = value

    def _del_value(self, key):
        self.props.pop(key, None)

    def _apply_to_editor(self):
        """Сохраняет теги обратно в редактор."""
        self.editor.push_undo()
        if self.props:
            self.editor.props[(self.cx, self.cy)] = dict(self.props)
        else:
            self.editor.props.pop((self.cx, self.cy), None)
        self.editor._dirty = True
        self.editor.show_msg(f"Теги клетки ({self.cx},{self.cy}) сохранены")

    # ---------- Обработка событий ----------
    def handle_event(self, e):
        """Возвращает True если окно закрылось."""
        if e.type == pygame.KEYDOWN:
            if self.edit_field is not None:
                return self._handle_edit_key(e)
            if e.key == pygame.K_ESCAPE:
                return True
            if e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self._apply_to_editor()
                return True
            # Стрелки для скролла
            if e.key == pygame.K_UP:
                self.scroll = max(0, self.scroll - 40)
            elif e.key == pygame.K_DOWN:
                self.scroll = min(self.max_scroll, self.scroll + 40)
            return False

        if e.type == pygame.MOUSEWHEEL:
            self.scroll = max(0, min(self.max_scroll,
                                     self.scroll - e.y * 40))
            return False

        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            mx, my = e.pos

            # Клик вне окна — ничего
            if not self.rect.collidepoint(mx, my):
                return False

            # Кнопки
            for name, r in self.button_rects.items():
                if r.collidepoint(mx, my):
                    if name == 'ok':
                        self._apply_to_editor()
                        return True
                    elif name == 'cancel':
                        return True
                    elif name == 'clear':
                        self.props.clear()
                        self.scroll = 0
                    return False

            # Строки
            for key, r in self.row_rects.items():
                if r.collidepoint(mx, my):
                    self._on_row_click(key)
                    return False

        if e.type == pygame.MOUSEMOTION:
            mx, my = e.pos
            self.hover_row = None
            for key, r in self.row_rects.items():
                if r.collidepoint(mx, my):
                    self.hover_row = key
                    break
        return False

    def _handle_edit_key(self, e):
        if e.key == pygame.K_RETURN:
            self._commit_edit()
        elif e.key == pygame.K_ESCAPE:
            self.edit_field = None
            self.edit_buf = ""
        elif e.key == pygame.K_BACKSPACE:
            self.edit_buf = self.edit_buf[:-1]
        else:
            ch = e.unicode
            if ch and ch.isprintable():
                self.edit_buf += ch
        return False

    def _commit_edit(self):
        key = self.edit_field
        val_str = self.edit_buf.strip()
        if not val_str:
            self._del_value(key)
        else:
            # Угадываем тип по схеме
            tag_type = None
            for k, t, _ in self.schema:
                if k == key:
                    tag_type = t
                    break
            if tag_type == 'number':
                try:
                    self.props[key] = float(val_str) if '.' in val_str else int(val_str)
                except ValueError:
                    pass
            else:
                self.props[key] = val_str
        self.edit_field = None
        self.edit_buf = ""

    def _on_row_click(self, key):
        """Клик по строке: enum — переключить, number/text — ввод, bool — toggle."""
        tag_type = None
        options = None
        for k, t, o in self.schema:
            if k == key:
                tag_type = t
                options = o
                break

        if tag_type == 'bool':
            current = bool(self.props.get(key, False))
            self.props[key] = not current
            return

        if tag_type == 'enum':
            if not options:
                return
            current = self.props.get(key)
            if current not in options:
                self.props[key] = options[0]
                return
            i = options.index(current)
            self.props[key] = options[(i + 1) % len(options)]
            return

        # number / text — редактирование
        self.edit_field = key
        current = self.props.get(key)
        self.edit_buf = str(current) if current is not None else ""

    # ---------- Отрисовка ----------
    def draw(self, screen):
        # Затемнение фона
        ov = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
        ov.fill((0, 0, 0, 180))
        screen.blit(ov, (0, 0))

        # Панель
        pygame.draw.rect(screen, COL_PANEL, self.rect, border_radius=12)
        pygame.draw.rect(screen, COL_BORDER, self.rect, 2, border_radius=12)

        font_ttl = self.editor.font_ttl
        font_md = self.editor.font_md
        font_sm = self.editor.font_sm

        # Заголовок
        tname = TILE_NAMES.get(self.tile_id, '?')
        title = font_ttl.render(
            f"Теги клетки ({self.cx}, {self.cy})  ·  ID={self.tile_id} ({tname})",
            True, COL_ACCENT)
        screen.blit(title, (self.x + 20, self.y + 14))

        hint = font_sm.render(
            "Клик — изменить · Enter — сохранить · Esc — отмена",
            True, COL_TEXT_DIM)
        screen.blit(hint, (self.x + 20, self.y + 42))

        # Область строк
        list_top = self.y + 70
        list_bot = self.y + self.h - 70
        list_rect = pygame.Rect(self.x + 12, list_top,
                                self.w - 24, list_bot - list_top)

        pygame.draw.rect(screen, COL_PANEL_SOFT, list_rect, border_radius=6)
        pygame.draw.rect(screen, COL_BORDER_SOFT, list_rect, 1, border_radius=6)

        row_h = 30
        gap = 3
        y = list_top + 8 - self.scroll
        self.row_rects = {}

        old_clip = screen.get_clip()
        screen.set_clip(list_rect.inflate(-4, -4))

        # Текущий враг (если есть) показывается отдельно
        for key, ttype, options in self.schema:
            r = pygame.Rect(list_rect.x + 8, y, list_rect.w - 16, row_h)
            if y + row_h < list_rect.top - 10 or y > list_rect.bottom + 10:
                y += row_h + gap
                continue

            hov = (self.hover_row == key) or r.collidepoint(pygame.mouse.get_pos())
            is_set = key in self.props

            # Фон строки
            bg = (55, 70, 100) if is_set else (40, 45, 60)
            if hov:
                bg = (bg[0] + 20, bg[1] + 25, bg[2] + 30)
            pygame.draw.rect(screen, bg, r, border_radius=4)
            pygame.draw.rect(screen, COL_BORDER_SOFT, r, 1, border_radius=4)

            # Левый ярлык
            lbl = font_sm.render(key, True, COL_TEXT)
            screen.blit(lbl, (r.x + 10, r.y + 7))

            # Правый — значение или edit buffer
            if self.edit_field == key:
                val = self.edit_buf + "_"
                vcol = COL_HIGHLIGHT
            else:
                val = self._get_value(key)
                vcol = COL_TEXT if is_set else COL_TEXT_MUTE

            # Обрезка
            vmax = r.w - 210
            vt = font_sm.render(str(val)[:40], True, vcol)
            if vt.get_width() > vmax:
                while vt.get_width() > vmax and len(val) > 3:
                    val = val[:-1]
                    vt = font_sm.render(str(val) + "…", True, vcol)
            screen.blit(vt, (r.x + 160, r.y + 7))

            # Показать тип на правой стороне
            type_label = {'number': '#', 'text': 'ab',
                          'bool': '☐', 'enum': '▾'}.get(ttype, '?')
            tt = font_sm.render(type_label, True, COL_TEXT_MUTE)
            screen.blit(tt, (r.right - 22, r.y + 7))

            self.row_rects[key] = r
            y += row_h + gap

        # Скроллбар
        total_h = len(self.schema) * (row_h + gap)
        visible_h = list_rect.h - 16
        self.max_scroll = max(0, total_h - visible_h)
        if self.max_scroll > 0:
            track = pygame.Rect(list_rect.right - 6, list_rect.top + 4,
                                3, list_rect.h - 8)
            pygame.draw.rect(screen, COL_BORDER_SOFT, track, border_radius=2)
            ratio = self.scroll / self.max_scroll
            bh = max(20, int(visible_h * visible_h / max(1, total_h)))
            by = track.y + int((track.h - bh) * ratio)
            pygame.draw.rect(screen, COL_ACCENT,
                             (track.x, by, 3, bh), border_radius=2)

        screen.set_clip(old_clip)

        # Кнопки внизу
        bw, bh = 150, 44
        gap = 20
        y_btn = self.y + self.h - bh - 14
        cx0 = self.x + self.w // 2 - (bw * 3 + gap * 2) // 2

        self.button_rects = {}
        for i, (name, label, col) in enumerate([
            ('ok', 'OK', COL_BTN_SUCCESS),
            ('cancel', 'Отмена', (70, 80, 110)),
            ('clear', 'Очистить теги', COL_BTN_DANGER),
        ]):
            r = pygame.Rect(cx0 + i * (bw + gap), y_btn, bw, bh)
            self.button_rects[name] = r
            hov = r.collidepoint(pygame.mouse.get_pos())
            c = (col[0] + 30, col[1] + 30, col[2] + 30) if hov else col
            pygame.draw.rect(screen, c, r, border_radius=8)
            pygame.draw.rect(screen, COL_BORDER, r, 1, border_radius=8)
            t = font_md.render(label, True, COL_TEXT)
            screen.blit(t, t.get_rect(center=r.center))


# ============================================================
# РЕДАКТОР
# ============================================================
class MapEditor:
    TOOLBAR_H = 60
    BOTTOM_H  = 140
    LEFT_PANEL_W = 210
    RIGHT_PANEL_W = 400

    def __init__(self, width=1500, height=920):
        pygame.init()
        self.w, self.h = width, height
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption("Gradus Map Editor")
        self.clock = pygame.time.Clock()

        self.font_sm = pygame.font.SysFont('Arial', 13)
        self.font_md = pygame.font.SysFont('Arial', 15, bold=True)
        self.font_lg = pygame.font.SysFont('Arial', 18, bold=True)
        self.font_ttl = pygame.font.SysFont('Arial', 22, bold=True)

        # Данные карты
        self.grid_w = 16
        self.grid_h = 16
        self.cells = [[0] * self.grid_w for _ in range(self.grid_h)]
        self.props = {}
        self.spawn = [0.5, 0.5]
        self.team_spawns = {'blue': [], 'red': []}   # список [x, y]
        self.params = {
            'floor_color': '333333', 'ceiling_color': '111111',
            'ambient': 0.15, 'fog_color': '303040',
            'fog_start': 400, 'fog_end': 1200, 'use_lt': True,
        }
        self.lights = []
        self.bilboards = []
        self.map_name = "untitled"

        self.undo_stack = []
        self.redo_stack = []

        self.zoom = 1.0
        self.zoom_min = 0.3
        self.zoom_max = 4.0
        self.pan_x = 0
        self.pan_y = 0
        self.show_grid = True
        self.show_props_overlay = True

        self.current_tile = 1
        self.brush_size = 1
        self.active_tool = 'wall'

        # Настройки тайла
        self.sel_material = 'none'
        self.sel_alpha = 1.0
        self.sel_height = 1.0
        self.sel_texture = ''
        self.texture_idx = 0   # для листания

        # Врага
        self.obj_enemy_type = 'chase'
        self.obj_enemy_hp = 100
        self.obj_enemy_aim = 10
        self.obj_enemy_speed = 60
        self.obj_attack_type = 'ranged'
        self.obj_enemy_sprite = ''
        self.sprite_idx = 0    # для листания

        # Модель
        self.obj_model_path = ''
        self.obj_model_scale = 1.0
        self.obj_model_rot_y = 0.0
        self.obj_model_texture = ''
        self.obj_model_pushable = False
        self.obj_model_interactive = False
        self.model_idx = 0
        self.model_tex_idx = 0

        # Логика
        self.logic_kind = 'door'
        self.logic_id = ''
        self.logic_link = ''
        self.logic_level = 0
        self.logic_target_x = 0.0
        self.logic_target_y = 0.0
        self.logic_action = ''

        # Свет
        self.light_color_idx = 0
        self.light_intensity = 0.7
        self.light_radius = 250.0

        # Билборд
        self.bilboard_key = ''
        self.bilboard_scale = 1.0
        self.bilb_idx = 0

        # Ассеты
        self.models_list = self._scan_models()
        self.sprites_list = self._scan_sprites()

        # Мышь
        self.lmb_down = False
        self.rmb_down = False
        self.rmb_moved = False
        self.rmb_start = (0, 0)
        self.rmb_last = (0, 0)
        self.last_cell = None
        self._pending_rmb_cell = None

        self.held_keys = set()
        self.pan_speed = 500

        self.editing_filename = False
        self.filename_buf = ""

        self.exit_dialog = False
        self._should_quit = False
        self._dirty = False

        self.panel_tab = 'tile'
        self.panel_row_rects = {}

        # Модальное окно тегов
        self.tag_window = None

        self.message = "Готово. ЛКМ — рисовать, короткий ПКМ — теги."
        self.message_t = 5.0

        self.buttons = {}
        self.toggle_rects = {}
        self.grid_size_rects = {}
        self.tile_btn_rects = {}
        self.tool_rects = {}
        self.panel_tab_rects = {}
        self._build_ui()

    # --------------------------------------------------------
    def _scan_models(self):
        result = []
        for root in ('assets', 'models'):
            if not os.path.isdir(root):
                continue
            for ext in ('obj', 'gbj'):
                result.extend(glob.glob(
                    os.path.join(root, '**', f'*.{ext}'), recursive=True))
        return sorted(set(m.replace('\\', '/') for m in result))

    def _scan_sprites(self):
        result = []
        for root in ('assets', 'textures'):
            if not os.path.isdir(root):
                continue
            for ext in ('png', 'jpg', 'jpeg'):
                result.extend(glob.glob(
                    os.path.join(root, '**', f'*.{ext}'), recursive=True))
        return sorted(set(s.replace('\\', '/') for s in result))

    # --------------------------------------------------------
    def _build_ui(self):
        self.buttons = {}
        self.toggle_rects = {}
        self.grid_size_rects = {}
        self.tile_btn_rects = {}
        self.tool_rects = {}
        self.panel_tab_rects = {}

        x = 20
        for name, label, w in [
            ('new', 'Новая', 80), ('open', 'Открыть', 95),
            ('save', 'Сохранить', 100), ('import', 'Импорт', 85),
            ('play', 'Play', 70), ('exit', 'Выход', 75),
        ]:
            self.buttons[name] = {
                'rect': pygame.Rect(x, 15, w, 32),
                'label': label,
                'cb': getattr(self, f'cmd_{name}'),
            }
            x += w + 8

        self.name_rect = pygame.Rect(x + 8, 18, 240, 26)

        tx = self.name_rect.right + 20
        self.toggle_rects['grid'] = pygame.Rect(tx, 15, 80, 32)
        self.toggle_rects['props'] = pygame.Rect(tx + 88, 15, 80, 32)

        gx = tx + 176
        for size in GRID_SIZES:
            self.grid_size_rects[size] = pygame.Rect(gx, 15, 56, 32)
            gx += 60

        ty0 = self.TOOLBAR_H + 80
        for i in range(10):
            r = pygame.Rect(10, ty0 + i * 32, self.LEFT_PANEL_W - 20, 28)
            self.tile_btn_rects[i] = r

        ty = ty0 + 10 * 32 + 30
        for i, (key, _) in enumerate(TOOLS):
            r = pygame.Rect(10, ty + i * 30, self.LEFT_PANEL_W - 20, 26)
            self.tool_rects[key] = r

        px = self.w - self.RIGHT_PANEL_W
        py = self.TOOLBAR_H + 10
        avail = self.RIGHT_PANEL_W - 16
        tab_w = (avail - (len(TABS) - 1) * 4) // len(TABS)
        for i, (key, _) in enumerate(TABS):
            r = pygame.Rect(px + 8 + i * (tab_w + 4), py + 10, tab_w, 30)
            self.panel_tab_rects[key] = r

    # --------------------------------------------------------
    def show_msg(self, text, t=3.0):
        self.message = text
        self.message_t = t
        print(f"[MapEditor] {text}")

    def _snapshot(self):
        return {
            'cells': [r[:] for r in self.cells],
            'props': {k: dict(v) for k, v in self.props.items()},
            'spawn': list(self.spawn),
            'lights': [dict(L) for L in self.lights],
            'bilboards': [dict(b) for b in self.bilboards],
            'params': dict(self.params),
        }

    def _restore(self, snap):
        self.cells = snap['cells']
        self.props = snap['props']
        self.spawn = snap['spawn']
        self.lights = snap['lights']
        self.bilboards = snap['bilboards']
        self.params = snap['params']

    def push_undo(self):
        self.undo_stack.append(self._snapshot())
        if len(self.undo_stack) > 60:
            self.undo_stack.pop(0)
        self.redo_stack.clear()
        self._dirty = True

    def cmd_undo(self):
        if not self.undo_stack:
            self.show_msg("Нечего отменять")
            return
        self.redo_stack.append(self._snapshot())
        self._restore(self.undo_stack.pop())
        self.show_msg("Отменено")

    def cmd_redo(self):
        if not self.redo_stack:
            self.show_msg("Нечего повторять")
            return
        self.undo_stack.append(self._snapshot())
        self._restore(self.redo_stack.pop())
        self.show_msg("Повторено")

    # --------------------------------------------------------
    def cmd_new(self):
        self.push_undo()
        self.cells = [[0] * self.grid_w for _ in range(self.grid_h)]
        self.props = {}
        self.spawn = [0.5, 0.5]
        self.lights = []
        self.bilboards = []
        self.params = {
            'floor_color': '333333', 'ceiling_color': '111111',
            'ambient': 0.15, 'fog_color': '303040',
            'fog_start': 400, 'fog_end': 1200, 'use_lt': True,
        }
        self.map_name = "untitled"
        self._dirty = False
        self.show_msg("Новая карта")

    def cmd_open(self):
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk(); root.withdraw()
            root.attributes('-topmost', True)
            path = filedialog.askopenfilename(
                title="Открыть карту", initialdir="maps",
                filetypes=[
                    ("Карта Gradus", "*.json *.txt *.map"),
                    ("JSON", "*.json"),
                    ("Текстовый", "*.txt *.map"),
                    ("Все файлы", "*.*"),
                ])
            root.destroy()
            if path:
                self.load_file(path)
        except Exception as e:
            self.show_msg(f"Ошибка диалога: {e}")

    def cmd_save(self):
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk(); root.withdraw()
            root.attributes('-topmost', True)
            os.makedirs("maps", exist_ok=True)
            path = filedialog.asksaveasfilename(
                title="Сохранить карту", initialdir="maps",
                initialfile=f"{self.map_name}.json",
                defaultextension=".json",
                filetypes=[("JSON карта", "*.json"), ("Все файлы", "*.*")])
            root.destroy()
            if path:
                self.save_json(path)
        except Exception as e:
            self.show_msg(f"Ошибка диалога: {e}")

    def cmd_import(self):
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk(); root.withdraw()
            root.attributes('-topmost', True)
            path = filedialog.askopenfilename(
                title="Импорт .txt",
                filetypes=[("Текстовая карта", "*.txt *.map"),
                           ("Все файлы", "*.*")])
            root.destroy()
            if path:
                self.import_txt(path)
        except Exception as e:
            self.show_msg(f"Ошибка диалога: {e}")

    def cmd_play(self):
        try:
            os.makedirs("maps", exist_ok=True)
            play_path = os.path.abspath("maps/_play.json")
            self.save_json(play_path, silent=True)

            script = os.path.join(os.path.dirname(__file__), 'play_map.py')
            python = sys.executable or "python"

            # Открываем в новом окне
            if os.name == 'nt':
                subprocess.Popen(
                    [python, script, play_path],
                    creationflags=subprocess.CREATE_NEW_CONSOLE)
            else:
                subprocess.Popen([python, script, play_path])

            self.show_msg(f"Запускаю игру: {play_path}")
        except Exception as e:
            self.show_msg(f"Ошибка запуска: {e}")

    def cmd_exit(self):
        self.exit_dialog = True

    # --------------------------------------------------------
    def load_file(self, path):
        ext = os.path.splitext(path)[1].lower()
        if ext == '.json':
            self.load_json(path)
        else:
            self.import_txt(path)

    def save_json(self, path, silent=False):
        data = {
            'format_version': 1, 'name': self.map_name,
            'size': [self.grid_w, self.grid_h],
            'spawn': list(self.spawn), 'params': dict(self.params),
            'lights': [dict(L) for L in self.lights],
            'bilboards': [dict(b) for b in self.bilboards],
            'cells': [],
        }
        if self.team_spawns.get('blue') or self.team_spawns.get('red'):
            data['team_spawns'] = {
                'blue': [list(p) for p in self.team_spawns['blue']],
                'red': [list(p) for p in self.team_spawns['red']],
            }
        for y in range(self.grid_h):
            for x in range(self.grid_w):
                bid = self.cells[y][x]
                props = self.props.get((x, y))
                if bid == 0 and not props:
                    continue
                cell = {'x': x, 'y': y, 'id': bid}
                if props:
                    cell['props'] = dict(props)
                data['cells'].append(cell)

        try:
            parent = os.path.dirname(path)
            if parent:
                os.makedirs(parent, exist_ok=True)
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            if not silent:
                self.map_name = os.path.splitext(os.path.basename(path))[0]
                self._dirty = False
                self.show_msg(f"Сохранено: {path}")
        except Exception as e:
            self.show_msg(f"Ошибка сохранения: {e}")
            traceback.print_exc()

    def load_json(self, path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self.push_undo()

            w, h = data.get('size', [16, 16])
            self.grid_w, self.grid_h = int(w), int(h)
            self.cells = [[0] * self.grid_w for _ in range(self.grid_h)]
            self.props = {}

            for cell in data.get('cells', []):
                x = int(cell.get('x', 0))
                y = int(cell.get('y', 0))
                if not (0 <= x < self.grid_w and 0 <= y < self.grid_h):
                    continue
                self.cells[y][x] = int(cell.get('id', 0))
                p = cell.get('props')
                if p:
                    self.props[(x, y)] = dict(p)

            self.spawn = list(data.get('spawn', [0.5, 0.5]))
            self.params = dict(data.get('params', self.params))
            self.lights = [dict(L) for L in data.get('lights', [])]
            self.bilboards = [dict(b) for b in data.get('bilboards', [])]
            ts = data.get('team_spawns', {}) or {}
            self.team_spawns = {
                'blue': [list(p) for p in ts.get('blue', [])],
                'red':  [list(p) for p in ts.get('red',  [])],
            }
            self.map_name = data.get('name', 'untitled')
            self._dirty = False
            self.show_msg(f"Загружено: {path}")
        except Exception as e:
            self.show_msg(f"Ошибка загрузки: {e}")
            traceback.print_exc()

    def import_txt(self, path):
        try:
            from gradus_rc.utils.map_loader import text_to_json
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            data = text_to_json(text, name=os.path.basename(path))

            self.push_undo()
            w, h = data['size']
            self.grid_w, self.grid_h = int(w), int(h)
            self.cells = [[0] * self.grid_w for _ in range(self.grid_h)]
            self.props = {}

            for cell in data.get('cells', []):
                x = int(cell['x']); y = int(cell['y'])
                if not (0 <= x < self.grid_w and 0 <= y < self.grid_h):
                    continue
                self.cells[y][x] = int(cell.get('id', 0))
                p = cell.get('props')
                if p:
                    self.props[(x, y)] = dict(p)

            self.spawn = list(data.get('spawn', [0.5, 0.5]))
            self.params = dict(data.get('params', self.params))
            self.lights = list(data.get('lights', []))
            self.bilboards = list(data.get('bilboards', []))
            self.map_name = data.get('name', 'untitled')
            self._dirty = False
            self.show_msg(f"Импортировано: {path}")
        except Exception as e:
            self.show_msg(f"Ошибка импорта: {e}")
            traceback.print_exc()

    # --------------------------------------------------------
    def viewport_rect(self):
        return pygame.Rect(
            self.LEFT_PANEL_W + 10, self.TOOLBAR_H + 10,
            self.w - self.LEFT_PANEL_W - self.RIGHT_PANEL_W - 20,
            self.h - self.TOOLBAR_H - self.BOTTOM_H - 20)

    def cell_size(self):
        return CELL_BASE * self.zoom

    def grid_origin(self):
        return (self.LEFT_PANEL_W + 30 + self.pan_x,
                self.TOOLBAR_H + 30 + self.pan_y)

    def cell_at(self, mx, my):
        gx0, gy0 = self.grid_origin()
        cs = self.cell_size()
        if mx < gx0 or my < gy0:
            return None
        cx = int((mx - gx0) / cs)
        cy = int((my - gy0) / cs)
        if 0 <= cx < self.grid_w and 0 <= cy < self.grid_h:
            return cx, cy
        return None

    def zoom_at(self, mx, my, factor):
        old_cs = self.cell_size()
        gx0, gy0 = self.grid_origin()
        gx = (mx - gx0) / old_cs
        gy = (my - gy0) / old_cs
        new_zoom = max(self.zoom_min, min(self.zoom_max, self.zoom * factor))
        if abs(new_zoom - self.zoom) < 1e-4:
            return
        self.zoom = new_zoom
        new_cs = self.cell_size()
        self.pan_x = int(mx - gx * new_cs - (self.LEFT_PANEL_W + 30))
        self.pan_y = int(my - gy * new_cs - (self.TOOLBAR_H + 30))

    # --------------------------------------------------------
    # Редактирование
    # --------------------------------------------------------
    def _make_tile_props(self):
        props = {}
        if self.sel_material != 'none':
            props['material'] = self.sel_material
        if self.sel_alpha < 1.0:
            props['alpha'] = self.sel_alpha
        if self.sel_height < 1.0:
            props['height'] = self.sel_height
        if self.sel_texture:
            props['sprite'] = self.sel_texture
        return props

    def paint_tile(self, cx, cy, tile_id):
        half = self.brush_size // 2
        for dy in range(-half, half + 1):
            for dx in range(-half, half + 1):
                x = cx + dx
                y = cy + dy
                if not (0 <= x < self.grid_w and 0 <= y < self.grid_h):
                    continue
                self.cells[y][x] = tile_id
                if tile_id == 0:
                    self.props.pop((x, y), None)
                else:
                    props = self._make_tile_props()
                    if props:
                        self.props[(x, y)] = props
                    else:
                        self.props.pop((x, y), None)
        self._dirty = True

    def set_spawn(self, cx, cy):
        self.spawn = [cx + 0.5, cy + 0.5]
        self._dirty = True
        self.show_msg(f"Спавн: ({cx + 0.5}, {cy + 0.5})")

    def place_enemy(self, cx, cy):
        self.push_undo()
        enemy_str = (
            f"type={self.obj_enemy_type};hp={self.obj_enemy_hp};"
            f"aim={self.obj_enemy_aim};speed={self.obj_enemy_speed};"
            f"attack_type={self.obj_attack_type}")
        if self.obj_enemy_sprite:
            enemy_str += f";sprite={self.obj_enemy_sprite}"
        existing = dict(self.props.get((cx, cy), {}))
        existing['enemy'] = enemy_str
        self.props[(cx, cy)] = existing
        self._dirty = True
        self.show_msg(f"Враг на ({cx},{cy})")

    def place_model(self, cx, cy):
        self.push_undo()
        if not self.obj_model_path:
            self.show_msg("Не выбрана модель")
            return
        existing = dict(self.props.get((cx, cy), {}))
        existing['path'] = self.obj_model_path
        existing['scale'] = self.obj_model_scale
        existing['roty'] = self.obj_model_rot_y
        if self.obj_model_texture:
            existing['texture'] = self.obj_model_texture
        if self.obj_model_pushable:
            existing['pushable'] = True
        if self.obj_model_interactive:
            existing['interactive'] = True
        self.cells[cy][cx] = 6
        self.props[(cx, cy)] = existing
        self._dirty = True
        self.show_msg(f"Модель на ({cx},{cy})")

    def place_light(self, cx, cy):
        self.push_undo()
        _, col = LIGHT_COLORS[self.light_color_idx]
        self.lights.append({
            'x': cx + 0.5, 'y': cy + 0.5,
            'intensity': self.light_intensity,
            'radius': self.light_radius,
            'color': list(col)})
        self._dirty = True
        self.show_msg(f"Свет на ({cx},{cy})")

    def place_logic(self, cx, cy):
        self.push_undo()
        kind = self.logic_kind
        obj_id = self.logic_id or f"{kind}_{cx}_{cy}"
        existing = dict(self.props.get((cx, cy), {}))
        if kind == 'door':
            self.cells[cy][cx] = 7
            existing['type'] = 'door'
            existing['id'] = obj_id
            if self.logic_link:
                existing['link'] = self.logic_link
            if 'height' not in existing:
                existing['height'] = 0.9
            if 'material' not in existing:
                existing['material'] = 'concrete'
            existing['isvisible'] = False
        elif kind == 'key':
            self.cells[cy][cx] = 7
            existing['type'] = 'key'
            existing['id'] = obj_id
            if self.logic_link:
                existing['link'] = self.logic_link
        elif kind == 'portal':
            self.cells[cy][cx] = 9
            existing['level'] = int(self.logic_level)
            existing['target_x'] = float(self.logic_target_x)
            existing['target_y'] = float(self.logic_target_y)
            existing['isvisible'] = True
        elif kind == 'trigger':
            self.cells[cy][cx] = 8
            existing['id'] = obj_id
            if self.logic_action:
                existing['action'] = self.logic_action
        self.props[(cx, cy)] = existing
        self._dirty = True
        self.show_msg(f"{kind.capitalize()} на ({cx},{cy})")

    def place_bilboard(self, cx, cy):
        self.push_undo()
        if not self.bilboard_key:
            self.show_msg("Не выбран спрайт")
            return
        self.bilboards.append({
            'x': cx + 0.5, 'y': cy + 0.5,
            'key': self.bilboard_key})
        self._dirty = True
        self.show_msg(f"Билборд '{self.bilboard_key}' на ({cx},{cy})")

    def erase_at(self, cx, cy):
        self.cells[cy][cx] = 0
        self.props.pop((cx, cy), None)
        self.lights = [L for L in self.lights
                       if not (int(L['x']) == cx and int(L['y']) == cy)]
        self.bilboards = [b for b in self.bilboards
                          if not (int(b['x']) == cx and int(b['y']) == cy)]
        self._dirty = True

    # --------------------------------------------------------
    # Обработка событий
    # --------------------------------------------------------
    def handle_event(self, e):
        if e.type == pygame.QUIT:
            self.exit_dialog = True
            self.held_keys.clear()
            return

        # Модальное окно тегов — перехватывает всё
        if self.tag_window is not None:
            if self.tag_window.handle_event(e):
                self.tag_window = None
            return

        if self.exit_dialog:
            self._handle_exit_dialog(e)
            return
        if self.editing_filename:
            self._handle_filename_input(e)
            return

        if e.type == pygame.MOUSEWHEEL:
            mx, my = pygame.mouse.get_pos()
            mods = pygame.key.get_mods()
            if self.viewport_rect().collidepoint(mx, my):
                if mods & pygame.KMOD_CTRL:
                    self.brush_size = max(1, min(5, self.brush_size + e.y))
                    self.show_msg(f"Кисть: {self.brush_size}")
                else:
                    factor = 1.15 if e.y > 0 else 1 / 1.15
                    self.zoom_at(mx, my, factor)
            return

        if e.type == pygame.KEYDOWN:
            self.held_keys.add(e.key)
            self._handle_keydown(e)
            return
        if e.type == pygame.KEYUP:
            self.held_keys.discard(e.key)
            return
        if e.type == pygame.MOUSEBUTTONDOWN:
            self._handle_mouse_down(e)
            return
        if e.type == pygame.MOUSEBUTTONUP:
            self._handle_mouse_up(e)
            return
        if e.type == pygame.MOUSEMOTION:
            self._handle_mouse_motion(e)
            return

    def _handle_keydown(self, e):
        mods = pygame.key.get_mods()

        if e.key == pygame.K_ESCAPE:
            self.exit_dialog = True
            self.held_keys.clear()
            return
        if e.key == pygame.K_z and (mods & pygame.KMOD_CTRL):
            if mods & pygame.KMOD_SHIFT:
                self.cmd_redo()
            else:
                self.cmd_undo()
            return
        if e.key == pygame.K_y and (mods & pygame.KMOD_CTRL):
            self.cmd_redo()
            return
        if e.key == pygame.K_s and (mods & pygame.KMOD_CTRL):
            self.cmd_save()
            return
        if e.key == pygame.K_o and (mods & pygame.KMOD_CTRL):
            self.cmd_open()
            return
        if e.key == pygame.K_n and (mods & pygame.KMOD_CTRL):
            self.cmd_new()
            return
        if e.key == pygame.K_i and (mods & pygame.KMOD_CTRL):
            self.cmd_import()
            return
        if e.key == pygame.K_F5:
            self.cmd_play()
            return

        if e.key == pygame.K_g:
            self.show_grid = not self.show_grid
            return
        if e.key == pygame.K_p:
            self.show_props_overlay = not self.show_props_overlay
            self.show_msg(f"Счётчик тегов: {'вкл' if self.show_props_overlay else 'выкл'}")
            return

        if pygame.K_0 <= e.key <= pygame.K_9:
            self.current_tile = e.key - pygame.K_0
            self.active_tool = 'erase' if self.current_tile == 0 else 'wall'
            self.show_msg(f"Тайл: {TILE_NAMES.get(self.current_tile, '?')}")
            return

        if e.key == pygame.K_TAB:
            keys = [k for k, _ in TABS]
            i = keys.index(self.panel_tab)
            self.panel_tab = keys[(i + 1) % len(keys)]
            return

        if e.key == pygame.K_a:
            self.brush_size = max(1, self.brush_size - 1)
            self.show_msg(f"Кисть: {self.brush_size}")
        if e.key == pygame.K_d:
            self.brush_size = min(5, self.brush_size + 1)
            self.show_msg(f"Кисть: {self.brush_size}")

        if e.key == pygame.K_0 and (mods & pygame.KMOD_CTRL):
            self.zoom = 1.0
            self.pan_x = 0
            self.pan_y = 0

    def _handle_mouse_down(self, e):
        mx, my = e.pos

        if e.button == 1 and self.name_rect.collidepoint(mx, my):
            self.editing_filename = True
            self.filename_buf = self.map_name
            return

        if my < self.TOOLBAR_H:
            for name, btn in self.buttons.items():
                if btn['rect'].collidepoint(mx, my):
                    btn['cb']()
                    return
            for key, rect in self.toggle_rects.items():
                if rect.collidepoint(mx, my):
                    if key == 'grid':
                        self.show_grid = not self.show_grid
                    elif key == 'props':
                        self.show_props_overlay = not self.show_props_overlay
                    return
            for size, rect in self.grid_size_rects.items():
                if rect.collidepoint(mx, my):
                    self.set_grid_size(size)
                    return
            return

        if mx < self.LEFT_PANEL_W:
            for tid, rect in self.tile_btn_rects.items():
                if rect.collidepoint(mx, my):
                    self.current_tile = tid
                    self.active_tool = 'erase' if tid == 0 else 'wall'
                    return
            for key, rect in self.tool_rects.items():
                if rect.collidepoint(mx, my):
                    self.active_tool = key
                    return
            return

        if mx >= self.w - self.RIGHT_PANEL_W:
            for key, rect in self.panel_tab_rects.items():
                if rect.collidepoint(mx, my):
                    self.panel_tab = key
                    return
            self._handle_panel_click(mx, my)
            return

        if self.viewport_rect().collidepoint(mx, my):
            cell = self.cell_at(mx, my)

            if e.button == 3:
                # ПКМ: запомним клетку. Если drag — панорама, если короткий — теги.
                self.rmb_down = True
                self.rmb_start = (mx, my)
                self.rmb_last = (mx, my)
                self.rmb_moved = False
                self._pending_rmb_cell = cell
                return

            if cell is None:
                return
            cx, cy = cell
            mods = pygame.key.get_mods()

            if e.button == 1:
                if mods & pygame.KMOD_SHIFT:
                    self.set_spawn(cx, cy)
                elif mods & pygame.KMOD_ALT:
                    self.place_enemy(cx, cy)
                elif mods & pygame.KMOD_CTRL:
                    self.place_model(cx, cy)
                else:
                    tool = self.active_tool
                    if tool == 'wall':
                        self.push_undo()
                        self.paint_tile(cx, cy, self.current_tile)
                    elif tool == 'erase':
                        self.push_undo()
                        self.paint_tile(cx, cy, 0)
                    elif tool == 'spawn':
                        self.set_spawn(cx, cy)
                    elif tool == 'team_spawn_blue':
                        self.team_spawns['blue'].append([cx + 0.5, cy + 0.5])
                        self._dirty = True
                        self.show_msg(f"Синий спавн ({cx},{cy})")
                    elif tool == 'team_spawn_red':
                        self.team_spawns['red'].append([cx + 0.5, cy + 0.5])
                        self._dirty = True
                        self.show_msg(f"Красный спавн ({cx},{cy})")
                    elif tool == 'enemy':
                        self.place_enemy(cx, cy)
                    elif tool == 'model':
                        self.place_model(cx, cy)
                    elif tool == 'light':
                        self.place_light(cx, cy)
                    elif tool == 'door':
                        self.logic_kind = 'door'
                        self.place_logic(cx, cy)
                    elif tool == 'key':
                        self.logic_kind = 'key'
                        self.place_logic(cx, cy)
                    elif tool == 'portal':
                        self.logic_kind = 'portal'
                        self.place_logic(cx, cy)
                    elif tool == 'trigger':
                        self.logic_kind = 'trigger'
                        self.place_logic(cx, cy)
                    elif tool == 'bilboard':
                        self.place_bilboard(cx, cy)
                    self.lmb_down = True
                    self.last_cell = (cx, cy)

    def _handle_mouse_up(self, e):
        if e.button == 1:
            self.lmb_down = False
            self.last_cell = None
        if e.button == 3:
            # Если НЕ тянули — открываем окно тегов
            if not self.rmb_moved and self._pending_rmb_cell is not None:
                cx, cy = self._pending_rmb_cell
                self.tag_window = TagEditorWindow(self, cx, cy)
            self.rmb_down = False
            self.rmb_moved = False
            self._pending_rmb_cell = None

    def _handle_mouse_motion(self, e):
        mx, my = e.pos

        if self.rmb_down:
            dx = mx - self.rmb_last[0]
            dy = my - self.rmb_last[1]
            if not self.rmb_moved:
                if abs(mx - self.rmb_start[0]) + abs(my - self.rmb_start[1]) > 4:
                    self.rmb_moved = True
            if self.rmb_moved:
                self.pan_x += dx
                self.pan_y += dy
            self.rmb_last = (mx, my)
            return

        if self.lmb_down:
            cell = self.cell_at(mx, my)
            if cell is None:
                return
            cx, cy = cell
            if self.last_cell == (cx, cy):
                return
            self.last_cell = (cx, cy)
            if self.active_tool == 'wall':
                self.paint_tile(cx, cy, self.current_tile)
            elif self.active_tool == 'erase':
                self.paint_tile(cx, cy, 0)

    def _handle_exit_dialog(self, e):
        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_ESCAPE:
                self.exit_dialog = False
            elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_s):
                if self._dirty:
                    self.cmd_save()
                self.exit_dialog = False
                self._should_quit = True
            elif e.key == pygame.K_d:
                self.exit_dialog = False
                self._should_quit = True
            return
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            dw, dh = 720, 260
            dx = (self.w - dw) // 2
            dy = (self.h - dh) // 2
            bw, bh = 200, 52
            gap = 20
            cx = self.w // 2 - (bw * 3 + gap * 2) // 2
            y = dy + 150
            keys = ['save', 'discard', 'cancel']
            for i in range(3):
                r = pygame.Rect(cx + i * (bw + gap), y, bw, bh)
                if r.collidepoint(e.pos):
                    k = keys[i]
                    if k == 'save':
                        if self._dirty:
                            self.cmd_save()
                        self.exit_dialog = False
                        self._should_quit = True
                    elif k == 'discard':
                        self.exit_dialog = False
                        self._should_quit = True
                    else:
                        self.exit_dialog = False
                    return

    def _handle_filename_input(self, e):
        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_RETURN:
                if self.filename_buf.strip():
                    self.map_name = self.filename_buf.strip()
                self.editing_filename = False
            elif e.key == pygame.K_ESCAPE:
                self.editing_filename = False
            elif e.key == pygame.K_BACKSPACE:
                self.filename_buf = self.filename_buf[:-1]
            else:
                ch = e.unicode
                if ch and ch.isprintable() and ch not in ('/', '\\'):
                    self.filename_buf += ch

    def _handle_panel_click(self, mx, my):
        for key, rect in self.panel_row_rects.items():
            if rect.collidepoint(mx, my):
                self._on_panel_row(key)
                return

    def _on_panel_row(self, key):
        # ---------- ТАЙЛ ----------
        if key == 'tile.material':
            i = MATERIALS.index(self.sel_material) if self.sel_material in MATERIALS else 0
            self.sel_material = MATERIALS[(i + 1) % len(MATERIALS)]
        elif key == 'tile.alpha':
            i = ALPHAS.index(self.sel_alpha) if self.sel_alpha in ALPHAS else 0
            self.sel_alpha = ALPHAS[(i + 1) % len(ALPHAS)]
        elif key == 'tile.height':
            i = HEIGHTS.index(self.sel_height) if self.sel_height in HEIGHTS else 0
            self.sel_height = HEIGHTS[(i + 1) % len(HEIGHTS)]
        elif key == 'tile.texture':
            self._cycle_sprite('sel_texture')

        # ---------- ВРАГ ----------
        elif key == 'enemy.type':
            i = ENEMY_TYPES.index(self.obj_enemy_type) if self.obj_enemy_type in ENEMY_TYPES else 0
            self.obj_enemy_type = ENEMY_TYPES[(i + 1) % len(ENEMY_TYPES)]
        elif key == 'enemy.hp':
            self.obj_enemy_hp = (self.obj_enemy_hp + 50) % 1000 or 50
        elif key == 'enemy.aim':
            self.obj_enemy_aim = (self.obj_enemy_aim + 5) % 100
        elif key == 'enemy.speed':
            self.obj_enemy_speed = (self.obj_enemy_speed + 10) % 250
        elif key == 'enemy.attack_type':
            i = ATTACK_TYPES.index(self.obj_attack_type) if self.obj_attack_type in ATTACK_TYPES else 0
            self.obj_attack_type = ATTACK_TYPES[(i + 1) % len(ATTACK_TYPES)]
        elif key == 'enemy.sprite':
            self._cycle_sprite('obj_enemy_sprite')

        # ---------- МОДЕЛЬ ----------
        elif key == 'model.path':
            self._cycle_model('obj_model_path')
        elif key == 'model.scale':
            self.obj_model_scale = round((self.obj_model_scale + 0.25) % 4.0, 2) or 0.25
        elif key == 'model.roty':
            self.obj_model_rot_y = (self.obj_model_rot_y + 45) % 360
        elif key == 'model.texture':
            self._cycle_sprite('obj_model_texture')
        elif key == 'model.pushable':
            self.obj_model_pushable = not self.obj_model_pushable
        elif key == 'model.interactive':
            self.obj_model_interactive = not self.obj_model_interactive

        # ---------- ЛОГИКА ----------
        elif key == 'logic.kind':
            i = LOGIC_KINDS.index(self.logic_kind) if self.logic_kind in LOGIC_KINDS else 0
            self.logic_kind = LOGIC_KINDS[(i + 1) % len(LOGIC_KINDS)]
        elif key == 'logic.id':
            self.logic_id = '' if self.logic_id else f"{self.logic_kind}_1"
        elif key == 'logic.link':
            self.logic_link = '' if self.logic_link else "door_1"
        elif key == 'logic.level':
            self.logic_level = (self.logic_level + 1) % 10
        elif key == 'logic.target_x':
            self.logic_target_x = (self.logic_target_x + 1.0) % 32
        elif key == 'logic.target_y':
            self.logic_target_y = (self.logic_target_y + 1.0) % 32
        elif key == 'logic.action':
            actions = ['', 'scream', 'open', 'close', 'spawn']
            i = actions.index(self.logic_action) if self.logic_action in actions else 0
            self.logic_action = actions[(i + 1) % len(actions)]

        # ---------- СВЕТ ----------
        elif key == 'light.color':
            self.light_color_idx = (self.light_color_idx + 1) % len(LIGHT_COLORS)
        elif key == 'light.intensity':
            self.light_intensity = round((self.light_intensity + 0.1) % 2.0, 1)
        elif key == 'light.radius':
            self.light_radius = (self.light_radius + 50) % 800
        elif key == 'light.clear':
            self.lights = []
            self._dirty = True
            self.show_msg("Все источники света удалены")

        # ---------- БИЛБОРД ----------
        elif key == 'bilb.key':
            self._cycle_sprite('bilboard_key')
        elif key == 'bilb.scale':
            self.bilboard_scale = round((self.bilboard_scale + 0.25) % 4.0, 2) or 0.25
        elif key == 'bilb.clear':
            self.bilboards = []
            self._dirty = True
            self.show_msg("Все билборды удалены")

        # ---------- КАРТА ----------
        elif key == 'map.floor_color':
            i = FLOOR_COLORS.index(self.params.get('floor_color', '333333')) \
                if self.params.get('floor_color') in FLOOR_COLORS else 0
            self.params['floor_color'] = FLOOR_COLORS[(i + 1) % len(FLOOR_COLORS)]
        elif key == 'map.ceiling_color':
            i = CEIL_COLORS.index(self.params.get('ceiling_color', '111111')) \
                if self.params.get('ceiling_color') in CEIL_COLORS else 0
            self.params['ceiling_color'] = CEIL_COLORS[(i + 1) % len(CEIL_COLORS)]
        elif key == 'map.ambient':
            v = round(self.params.get('ambient', 0.15) + 0.05, 2)
            if v > 0.6:
                v = 0.0
            self.params['ambient'] = v
        elif key == 'map.fog_color':
            i = FOG_COLORS.index(self.params.get('fog_color', '303040')) \
                if self.params.get('fog_color') in FOG_COLORS else 0
            self.params['fog_color'] = FOG_COLORS[(i + 1) % len(FOG_COLORS)]
        elif key == 'map.fog_start':
            self.params['fog_start'] = (self.params.get('fog_start', 400) + 100) % 1500
        elif key == 'map.fog_end':
            self.params['fog_end'] = (self.params.get('fog_end', 1200) + 200) % 3000
        elif key == 'map.use_lt':
            self.params['use_lt'] = not self.params.get('use_lt', True)

    def _cycle_sprite(self, attr_name):
        """Листает полный список спрайтов вперёд."""
        if not self.sprites_list:
            self.show_msg("Нет .png/.jpg в assets/ или textures/")
            return
        current = getattr(self, attr_name)
        opts = [''] + self.sprites_list
        try:
            i = opts.index(current)
        except ValueError:
            i = 0
        i = (i + 1) % len(opts)
        setattr(self, attr_name, opts[i])
        idx_str = f"{i}/{len(opts)-1}" if i > 0 else "нет"
        self.show_msg(f"{idx_str}  ·  {opts[i] if i > 0 else '— пусто —'}")

    def _cycle_model(self, attr_name):
        if not self.models_list:
            self.show_msg("Нет .obj / .gbj в assets/ или models/")
            return
        current = getattr(self, attr_name)
        opts = self.models_list
        try:
            i = opts.index(current)
        except ValueError:
            i = -1
        i = (i + 1) % len(opts)
        setattr(self, attr_name, opts[i])
        self.show_msg(f"{i+1}/{len(opts)}  ·  {opts[i]}")

    def set_grid_size(self, size):
        if size == self.grid_w == self.grid_h:
            return
        self.push_undo()
        new_cells = [[0] * size for _ in range(size)]
        new_props = {}
        for y in range(min(size, self.grid_h)):
            for x in range(min(size, self.grid_w)):
                new_cells[y][x] = self.cells[y][x]
        for (x, y), p in self.props.items():
            if 0 <= x < size and 0 <= y < size:
                new_props[(x, y)] = p
        self.cells = new_cells
        self.props = new_props
        self.grid_w = size
        self.grid_h = size
        self._dirty = True
        self.show_msg(f"Размер: {size}×{size}")

    # --------------------------------------------------------
    def update(self, dt):
        if self.message_t > 0:
            self.message_t -= dt
        if self.tag_window is not None:
            return  # во время окна тегов панорама не двигается

        step = self.pan_speed * dt
        if pygame.key.get_mods() & pygame.KMOD_SHIFT:
            step *= 3
        dx = dy = 0
        if pygame.K_LEFT in self.held_keys:
            dx += step
        if pygame.K_RIGHT in self.held_keys:
            dx -= step
        if pygame.K_UP in self.held_keys:
            dy += step
        if pygame.K_DOWN in self.held_keys:
            dy -= step
        if dx or dy:
            self.pan_x += int(dx)
            self.pan_y += int(dy)

    def run(self):
        running = True
        while running:
            dt = self.clock.tick(60) / 1000.0
            for e in pygame.event.get():
                if self._should_quit:
                    running = False
                    break
                if e.type == pygame.QUIT:
                    if not self.exit_dialog:
                        self.exit_dialog = True
                    continue
                self.handle_event(e)
            if self._should_quit:
                running = False
            if not running:
                break
            self.update(dt)
            self.render()
        pygame.quit()

    # ============================================================
    # РЕНДЕР
    # ============================================================
    def render(self):
        self.screen.fill(COL_BG)
        self.panel_row_rects = {}
        self._render_viewport()
        self._render_left_panel()
        self._render_toolbar()
        self._render_right_panel()
        self._render_bottom_bar()
        self._render_message()
        if self.exit_dialog:
            self._render_exit_dialog()
        if self.tag_window is not None:
            self.tag_window.draw(self.screen)
        pygame.display.flip()

    def _render_viewport(self):
        vp = self.viewport_rect()
        pygame.draw.rect(self.screen, (18, 20, 28), vp, border_radius=8)
        pygame.draw.rect(self.screen, COL_BORDER_SOFT, vp, 1, border_radius=8)

        old_clip = self.screen.get_clip()
        self.screen.set_clip(vp)

        gx0, gy0 = self.grid_origin()
        cs = self.cell_size()

        # Клетки
        for y in range(self.grid_h):
            for x in range(self.grid_w):
                px = gx0 + x * cs
                py = gy0 + y * cs
                if px + cs < vp.left or px > vp.right:
                    continue
                if py + cs < vp.top or py > vp.bottom:
                    continue
                rect = pygame.Rect(int(px), int(py),
                                   max(1, int(cs) - 1), max(1, int(cs) - 1))
                bid = self.cells[y][x]
                col = TILE_COLORS.get(bid, (100, 100, 100))

                props = self.props.get((x, y), {})

                if bid in (1, 2, 3, 4, 5) and self.show_props_overlay:
                    try:
                        a = float(props.get('alpha', 1.0))
                    except (TypeError, ValueError):
                        a = 1.0
                    if a < 1.0:
                        col = tuple(int(c * (0.4 + 0.6 * a)) for c in col)

                pygame.draw.rect(self.screen, col, rect)
                if self.show_grid and cs >= 24:
                    pygame.draw.rect(self.screen, (60, 65, 80), rect, 1)

                # Счётчик тегов + метки
                if self.show_props_overlay:
                    cxs = int(px + cs // 2)
                    cys = int(py + cs // 2)
                    r = max(3, int(cs * 0.22))

                    # Метки врагов / моделей / дверей и т. д.
                    if 'enemy' in props:
                        pygame.draw.circle(self.screen, COL_ENEMY, (cxs, cys), r)
                    elif 'path' in props:
                        pygame.draw.rect(self.screen, COL_MODEL,
                                         (cxs - r, cys - r, 2 * r, 2 * r))
                    elif bid == 7 and props.get('type') == 'door':
                        pygame.draw.rect(self.screen, COL_DOOR,
                                         (cxs - r, cys - r, 2 * r, 2 * r))
                    elif bid == 7 and props.get('type') == 'key':
                        pygame.draw.circle(self.screen, COL_KEY, (cxs, cys), r)
                    elif bid == 9:
                        pygame.draw.rect(self.screen, COL_PORTAL,
                                         (cxs - r, cys - r, 2 * r, 2 * r), 2)
                    elif bid == 8:
                        pygame.draw.polygon(self.screen, COL_TRIGGER,
                                            [(cxs, cys - r), (cxs + r, cys + r),
                                             (cxs - r, cys + r)])

                    # Число тегов в правом верхнем углу клетки
                    if props and cs >= 28:
                        n = len(props)
                        tag_t = self.font_sm.render(str(n), True, (255, 255, 255))
                        bg_w = tag_t.get_width() + 6
                        bg_h = tag_t.get_height() - 2
                        bg_r = pygame.Rect(int(px + cs - bg_w - 2),
                                           int(py + 2), bg_w, bg_h)
                        pygame.draw.rect(self.screen, (200, 130, 60), bg_r,
                                         border_radius=3)
                        self.screen.blit(tag_t,
                                         (bg_r.x + 3, bg_r.y + 1))

        # Спавн
        sx = gx0 + self.spawn[0] * cs
        sy = gy0 + self.spawn[1] * cs
        pygame.draw.circle(self.screen, COL_SPAWN, (int(sx), int(sy)), 10, 2)
        pygame.draw.line(self.screen, COL_SPAWN,
                         (int(sx) - 12, int(sy)), (int(sx) + 12, int(sy)), 2)
        pygame.draw.line(self.screen, COL_SPAWN,
                         (int(sx), int(sy) - 12), (int(sx), int(sy) + 12), 2)
        # Team spawns
        for tx, ty in self.team_spawns.get('blue', []):
            bx = gx0 + tx * cs
            by = gy0 + ty * cs
            pygame.draw.circle(self.screen, (80, 140, 255), (int(bx), int(by)), 8, 2)
            pygame.draw.line(self.screen, (80, 140, 255),
                             (int(bx) - 10, int(by)), (int(bx) + 10, int(by)), 2)
        for tx, ty in self.team_spawns.get('red', []):
            bx = gx0 + tx * cs
            by = gy0 + ty * cs
            pygame.draw.circle(self.screen, (255, 90, 90), (int(bx), int(by)), 8, 2)
            pygame.draw.line(self.screen, (255, 90, 90),
                             (int(bx) - 10, int(by)), (int(bx) + 10, int(by)), 2)
        # Источники света
        for L in self.lights:
            lx = gx0 + L['x'] * cs
            ly = gy0 + L['y'] * cs
            try:
                c = L.get('color', [255, 255, 255])
                col = (int(c[0]), int(c[1]), int(c[2]))
            except Exception:
                col = (255, 255, 255)
            r = max(4, int((L.get('radius', 200) / 64.0) * cs * 0.5))
            pygame.draw.circle(self.screen, col, (int(lx), int(ly)), r, 1)
            pygame.draw.circle(self.screen, col, (int(lx), int(ly)), 3)

        # Билборды
        for b in self.bilboards:
            bx = gx0 + b['x'] * cs
            by = gy0 + b['y'] * cs
            pygame.draw.rect(self.screen, COL_BILBOARD,
                             (int(bx) - 6, int(by) - 6, 12, 12))

        # Превью кисти
        mx, my = pygame.mouse.get_pos()
        cell = self.cell_at(mx, my)
        if cell and vp.collidepoint(mx, my):
            cx, cy = cell
            half = self.brush_size // 2
            preview = pygame.Rect(
                int(gx0 + (cx - half) * cs),
                int(gy0 + (cy - half) * cs),
                int(self.brush_size * cs),
                int(self.brush_size * cs))
            pygame.draw.rect(self.screen, COL_HIGHLIGHT, preview, 2)

        self.screen.set_clip(old_clip)

        info = self.font_sm.render(
            f"Zoom {int(self.zoom * 100)}%  ·  Сетка {self.grid_w}×{self.grid_h}"
            f"  ·  Кисть {self.brush_size}  ·  "
            f"Спрайтов: {len(self.sprites_list)}  ·  Моделей: {len(self.models_list)}",
            True, COL_TEXT_DIM)
        self.screen.blit(info, (vp.left + 8, vp.top + 6))

    def _render_left_panel(self):
        panel = pygame.Rect(0, self.TOOLBAR_H, self.LEFT_PANEL_W,
                            self.h - self.TOOLBAR_H - self.BOTTOM_H)
        pygame.draw.rect(self.screen, COL_PANEL, panel)
        pygame.draw.line(self.screen, COL_BORDER_SOFT,
                         (self.LEFT_PANEL_W, self.TOOLBAR_H),
                         (self.LEFT_PANEL_W, self.h - self.BOTTOM_H), 1)

        head = self.font_md.render("ТАЙЛЫ", True, COL_ACCENT)
        self.screen.blit(head, (10, self.TOOLBAR_H + 10))

        for tid, rect in self.tile_btn_rects.items():
            active = (tid == self.current_tile and self.active_tool == 'wall') or \
                     (tid == 0 and self.active_tool == 'erase')
            col = COL_BTN_ACTIVE if active else COL_BTN
            hov = rect.collidepoint(pygame.mouse.get_pos())
            if hov and not active:
                col = COL_BTN_HOVER
            pygame.draw.rect(self.screen, col, rect, border_radius=6)
            pygame.draw.rect(self.screen, COL_BORDER, rect, 1, border_radius=6)
            swatch = pygame.Rect(rect.x + 6, rect.y + 6, 16, 16)
            pygame.draw.rect(self.screen, TILE_COLORS.get(tid, (100, 100, 100)),
                             swatch, border_radius=3)
            pygame.draw.rect(self.screen, (0, 0, 0), swatch, 1, border_radius=3)
            t = self.font_sm.render(f"{tid}  {TILE_NAMES.get(tid, '?')}",
                                    True, COL_TEXT)
            self.screen.blit(t, (rect.x + 30, rect.y + 7))

        tools_label_y = self.TOOLBAR_H + 80 + 10 * 32 + 5
        head2 = self.font_md.render("ИНСТРУМЕНТ", True, COL_ACCENT)
        self.screen.blit(head2, (10, tools_label_y))

        tool_labels = {k: name for k, name in TOOLS}
        for key, rect in self.tool_rects.items():
            active = (self.active_tool == key)
            col = COL_BTN_ACTIVE if active else COL_BTN
            hov = rect.collidepoint(pygame.mouse.get_pos())
            if hov and not active:
                col = COL_BTN_HOVER
            pygame.draw.rect(self.screen, col, rect, border_radius=6)
            pygame.draw.rect(self.screen, COL_BORDER, rect, 1, border_radius=6)
            t = self.font_sm.render(tool_labels.get(key, key), True, COL_TEXT)
            self.screen.blit(t, t.get_rect(center=rect.center))

    def _render_toolbar(self):
        pygame.draw.rect(self.screen, COL_TOOLBAR, (0, 0, self.w, self.TOOLBAR_H))
        pygame.draw.line(self.screen, COL_BORDER_SOFT,
                         (0, self.TOOLBAR_H), (self.w, self.TOOLBAR_H), 1)

        for name, btn in self.buttons.items():
            rect = btn['rect']
            col = COL_BTN_DANGER if name == 'exit' else COL_BTN
            if name == 'play':
                col = COL_BTN_SUCCESS
            hov = rect.collidepoint(pygame.mouse.get_pos())
            if hov:
                col = COL_BTN_HOVER if name not in ('exit', 'play') else \
                      ((180, 90, 90) if name == 'exit' else (80, 180, 90))
            pygame.draw.rect(self.screen, col, rect, border_radius=6)
            pygame.draw.rect(self.screen, COL_BORDER, rect, 1, border_radius=6)
            t = self.font_sm.render(btn['label'], True, COL_TEXT)
            self.screen.blit(t, t.get_rect(center=rect.center))

        pygame.draw.rect(self.screen, (60, 80, 120), self.name_rect, border_radius=4)
        pygame.draw.rect(self.screen, COL_BORDER, self.name_rect, 1, border_radius=4)
        text = self.filename_buf + "_" if self.editing_filename else self.map_name
        nt = self.font_md.render(text, True, COL_TEXT)
        self.screen.blit(nt, (self.name_rect.x + 8, self.name_rect.y + 4))

        states = {'grid': ('Сетка', self.show_grid),
                  'props': ('Теги', self.show_props_overlay)}
        for key, rect in self.toggle_rects.items():
            label, on = states[key]
            col = COL_BTN_ACTIVE if on else (60, 70, 90)
            hov = rect.collidepoint(pygame.mouse.get_pos())
            if hov:
                col = (col[0] + 30, col[1] + 30, col[2] + 30)
            pygame.draw.rect(self.screen, col, rect, border_radius=6)
            pygame.draw.rect(self.screen, COL_BORDER, rect, 1, border_radius=6)
            t = self.font_sm.render(label, True, COL_TEXT)
            self.screen.blit(t, t.get_rect(center=rect.center))

        for size, rect in self.grid_size_rects.items():
            active = (size == self.grid_w == self.grid_h)
            col = COL_BTN_ACTIVE if active else COL_BTN
            hov = rect.collidepoint(pygame.mouse.get_pos())
            if hov and not active:
                col = COL_BTN_HOVER
            pygame.draw.rect(self.screen, col, rect, border_radius=6)
            pygame.draw.rect(self.screen, COL_BORDER, rect, 1, border_radius=6)
            t = self.font_sm.render(f"{size}", True, COL_TEXT)
            self.screen.blit(t, t.get_rect(center=rect.center))

    def _render_right_panel(self):
        px = self.w - self.RIGHT_PANEL_W
        py = self.TOOLBAR_H + 10
        pw = self.RIGHT_PANEL_W - 10
        ph = self.h - self.TOOLBAR_H - self.BOTTOM_H - 20

        pygame.draw.rect(self.screen, COL_PANEL, (px, py, pw, ph), border_radius=8)
        pygame.draw.rect(self.screen, COL_BORDER_SOFT, (px, py, pw, ph), 1, border_radius=8)

        for key, rect in self.panel_tab_rects.items():
            active = (key == self.panel_tab)
            col = COL_BTN_ACTIVE if active else COL_BTN
            pygame.draw.rect(self.screen, col, rect, border_radius=6)
            pygame.draw.rect(self.screen, COL_BORDER, rect, 1, border_radius=6)
            label = dict(TABS)[key]
            t = self.font_sm.render(label, True, COL_TEXT)
            self.screen.blit(t, t.get_rect(center=rect.center))

        rows = self._get_tab_rows()
        x_off = px + 10
        y_off = py + 50
        row_h = 28
        gap = 4
        label_w = 130

        for i, (label, value, row_key) in enumerate(rows):
            y = y_off + i * (row_h + gap)
            if label:
                lt = self.font_sm.render(label, True, COL_TEXT_DIM)
                self.screen.blit(lt, (x_off, y + 6))

            r = pygame.Rect(x_off + label_w, y, pw - label_w - 20, row_h)
            self.panel_row_rects[row_key] = r
            hov = r.collidepoint(pygame.mouse.get_pos())
            col = COL_BTN_HOVER if hov else (60, 80, 120)
            pygame.draw.rect(self.screen, col, r, border_radius=4)
            pygame.draw.rect(self.screen, COL_BORDER, r, 1, border_radius=4)
            display = str(value)
            if len(display) > 34:
                display = "…" + display[-33:]
            vt = self.font_sm.render(display, True, COL_TEXT)
            self.screen.blit(vt, (r.x + 6, r.y + 6))

    def _get_tab_rows(self):
        t = self.panel_tab

        if t == 'tile':
            tex_display = self.sel_texture if self.sel_texture else '— по материалу —'
            return [
                ('Материал', self.sel_material, 'tile.material'),
                ('Alpha', f"{int(self.sel_alpha * 100)}%", 'tile.alpha'),
                ('Высота', str(self.sel_height), 'tile.height'),
                ('Текстура', tex_display, 'tile.texture'),
            ]

        if t == 'enemy':
            return [
                ('Тип', self.obj_enemy_type, 'enemy.type'),
                ('HP', str(self.obj_enemy_hp), 'enemy.hp'),
                ('Aim', str(self.obj_enemy_aim), 'enemy.aim'),
                ('Speed', str(self.obj_enemy_speed), 'enemy.speed'),
                ('Атака', self.obj_attack_type, 'enemy.attack_type'),
                ('Sprite',
                 self.obj_enemy_sprite or '— по умолчанию —', 'enemy.sprite'),
            ]

        if t == 'model':
            return [
                ('Путь', self.obj_model_path or '— выбрать —', 'model.path'),
                ('Scale', f"{self.obj_model_scale:.2f}", 'model.scale'),
                ('RotY', f"{self.obj_model_rot_y:.0f}°", 'model.roty'),
                ('Texture', self.obj_model_texture or '— нет —', 'model.texture'),
                ('Pushable', 'да' if self.obj_model_pushable else 'нет', 'model.pushable'),
                ('Interactive', 'да' if self.obj_model_interactive else 'нет',
                 'model.interactive'),
            ]

        if t == 'logic':
            rows = [('Тип', self.logic_kind, 'logic.kind'),
                    ('ID', self.logic_id or '— авто —', 'logic.id')]
            if self.logic_kind in ('door', 'key'):
                rows.append(('Link', self.logic_link or '— нет —', 'logic.link'))
            if self.logic_kind == 'portal':
                rows.append(('Level', str(self.logic_level), 'logic.level'))
                rows.append(('Target X', f"{self.logic_target_x:.1f}", 'logic.target_x'))
                rows.append(('Target Y', f"{self.logic_target_y:.1f}", 'logic.target_y'))
            if self.logic_kind == 'trigger':
                rows.append(('Action', self.logic_action or '—', 'logic.action'))
            return rows

        if t == 'light':
            color_name, color_rgb = LIGHT_COLORS[self.light_color_idx]
            return [
                ('Цвет', f"{color_name} {tuple(color_rgb)}", 'light.color'),
                ('Intensity', f"{self.light_intensity:.1f}", 'light.intensity'),
                ('Radius', f"{self.light_radius:.0f}", 'light.radius'),
                ('Всего источников', str(len(self.lights)), 'light.dummy'),
                ('Удалить все', '← нажми', 'light.clear'),
            ]

        if t == 'bilb':
            return [
                ('Спрайт', self.bilboard_key or '— выбрать —', 'bilb.key'),
                ('Scale', f"{self.bilboard_scale:.2f}", 'bilb.scale'),
                ('Всего билбордов', str(len(self.bilboards)), 'bilb.dummy'),
                ('Удалить все', '← нажми', 'bilb.clear'),
            ]

        if t == 'map':
            return [
                ('Floor', self.params.get('floor_color', '—'), 'map.floor_color'),
                ('Ceiling', self.params.get('ceiling_color', '—'), 'map.ceiling_color'),
                ('Ambient', str(self.params.get('ambient', '—')), 'map.ambient'),
                ('Fog color', self.params.get('fog_color', '—'), 'map.fog_color'),
                ('Fog start', str(self.params.get('fog_start', '—')), 'map.fog_start'),
                ('Fog end', str(self.params.get('fog_end', '—')), 'map.fog_end'),
                ('USE_LT', 'да' if self.params.get('use_lt', True) else 'нет', 'map.use_lt'),
            ]

        return []

    def _render_bottom_bar(self):
        y0 = self.h - self.BOTTOM_H
        pygame.draw.rect(self.screen, COL_PANEL_SOFT, (0, y0, self.w, self.BOTTOM_H))
        pygame.draw.line(self.screen, COL_BORDER_SOFT, (0, y0), (self.w, y0), 1)

        head = self.font_lg.render("УПРАВЛЕНИЕ", True, COL_ACCENT)
        self.screen.blit(head, (16, y0 + 8))

        hints = [
            "ЛКМ — рисовать / ставить   ·   короткий ПКМ — теги клетки   ·   ПКМ зажать — панорама",
            "SHIFT+ЛКМ — спавн   ·   ALT+ЛКМ — враг   ·   CTRL+ЛКМ — модель",
            "Колесо — зум   ·   Ctrl+колесо — размер кисти   ·   A/D — размер кисти",
            "Стрелки — панорама   ·   Tab — вкладка панели   ·   G — сетка   ·   P — счётчик тегов",
            "0..9 — быстрый выбор тайла   ·   F5 — Play   ·   Ctrl+I — импорт .txt",
            "Ctrl+Z / Ctrl+Y — undo / redo   ·   Ctrl+S / O / N — файл   ·   ESC — выход",
        ]
        line_h = self.font_sm.get_linesize() + 2
        for i, line in enumerate(hints):
            t = self.font_sm.render(line, True, COL_TEXT_DIM)
            self.screen.blit(t, (16, y0 + 34 + i * line_h))

        info = self.font_sm.render(
            f"Тайл: {self.current_tile} ({TILE_NAMES.get(self.current_tile, '?')})   "
            f"·   Инструмент: {self.active_tool}   ·   "
            f"Свет: {len(self.lights)}   ·   Билборды: {len(self.bilboards)}   ·   "
            f"{'● не сохранено' if self._dirty else '✓ сохранено'}",
            True, COL_TEXT_MUTE)
        self.screen.blit(info, (16, self.h - 22))

    def _render_message(self):
        if self.message_t <= 0:
            return
        t = self.font_md.render(self.message, True, (255, 240, 180))
        bg = pygame.Surface((t.get_width() + 24, t.get_height() + 12),
                            pygame.SRCALPHA)
        bg.fill((0, 0, 0, 200))
        self.screen.blit(bg, (self.w // 2 - t.get_width() // 2 - 12, 72))
        self.screen.blit(t, (self.w // 2 - t.get_width() // 2, 78))

    def _render_exit_dialog(self):
        ov = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
        ov.fill((0, 0, 0, 170))
        self.screen.blit(ov, (0, 0))

        dw, dh = 720, 260
        dx = (self.w - dw) // 2
        dy = (self.h - dh) // 2
        panel = pygame.Rect(dx, dy, dw, dh)
        pygame.draw.rect(self.screen, (40, 45, 60), panel, border_radius=14)
        pygame.draw.rect(self.screen, COL_BORDER, panel, 2, border_radius=14)

        title = self.font_ttl.render("Сохранить перед выходом?", True, COL_ACCENT)
        self.screen.blit(title, title.get_rect(center=(self.w // 2, dy + 60)))
        hint = self.font_sm.render(
            "S / Enter — сохранить   ·   D — без сохранения   ·   Esc — отмена",
            True, COL_TEXT_DIM)
        self.screen.blit(hint, hint.get_rect(center=(self.w // 2, dy + 100)))

        bw, bh = 200, 52
        gap = 20
        labels = [('Сохранить', COL_BTN_SUCCESS),
                  ('Без сохранения', COL_BTN_DANGER),
                  ('Отмена', (70, 80, 110))]
        cx = self.w // 2 - (bw * 3 + gap * 2) // 2
        y = dy + 150
        for i, (label, col) in enumerate(labels):
            r = pygame.Rect(cx + i * (bw + gap), y, bw, bh)
            hov = r.collidepoint(pygame.mouse.get_pos())
            draw_col = (col[0] + 30, col[1] + 30, col[2] + 30) if hov else col
            pygame.draw.rect(self.screen, draw_col, r, border_radius=10)
            pygame.draw.rect(self.screen, COL_BORDER, r, 1, border_radius=10)
            t = self.font_md.render(label, True, COL_TEXT)
            self.screen.blit(t, t.get_rect(center=r.center))


if __name__ == "__main__":
    MapEditor().run()