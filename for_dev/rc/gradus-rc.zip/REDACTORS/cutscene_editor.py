"""
Редактор кат-сцен Gradus RC.

Управление:
  ЛКМ (зажать)         — рисование стен
  SHIFT+ЛКМ            — камера
  ПКМ                  — объект (поставить/удалить)
  A / D, Q / E         — повороты камеры
  SPACE / DEL          — новый / удалить кадр
  Ctrl+S / O / N       — файл
  F5 / кнопка Play     — предпросмотр в отдельном окне
  ESC                  — выход
"""
import pygame
import os
import json
import sys
import math
import glob
import subprocess

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# ====== НАСТРОЙКА ПУТЕЙ ======
# Здесь можно поменять корневую папку ассетов
ASSETS_ROOT = 'assets'
# =============================


CELL = 70
GRID_W = 6
GRID_H = 6
PAD = 40
TOOLBAR_H = 60
FRAMES_H = 200
HINT_SCROLL_STEP = 30

MATERIALS = ['none', 'brick', 'concrete', 'stone', 'metal',
             'silver', 'glass', 'wood', 'marble']
ALPHAS = [1.0, 0.75, 0.5, 0.25]
HEIGHTS = [1.0, 0.75, 0.5, 0.25, 0.1]


def scan_assets():
    """Возвращает (sprites_list, models_list) из ASSETS_ROOT."""
    sprites = []
    models = []
    if not os.path.isdir(ASSETS_ROOT):
        return sprites, models
    for ext in ('png', 'jpg', 'jpeg'):
        sprites.extend(glob.glob(os.path.join(ASSETS_ROOT, '**', f'*.{ext}'),
                                 recursive=True))
    for ext in ('obj', 'gbj'):
        models.extend(glob.glob(os.path.join(ASSETS_ROOT, '**', f'*.{ext}'),
                                recursive=True))
    sprites = sorted(set(s.replace('\\', '/') for s in sprites))
    models = sorted(set(m.replace('\\', '/') for m in models))
    return sprites, models


class CutsceneEditor:
    def __init__(self):
        pygame.init()
        self.w, self.h = 1400, 900
        self.screen = pygame.display.set_mode((self.w, self.h))
        pygame.display.set_caption("Gradus RC — Редактор кат-сцен")
        self.clock = pygame.time.Clock()

        self.font_sm = pygame.font.SysFont('Arial', 14)
        self.font_md = pygame.font.SysFont('Arial', 16, bold=True)
        self.font_lg = pygame.font.SysFont('Arial', 20, bold=True)

        # Ассеты
        self.sprites_list, self.models_list = scan_assets()
        if not self.sprites_list:
            self.sprites_list = ['assets/enemy_demon.png']
        if not self.models_list:
            self.models_list = ['models/model.gbj']

        self.name = "untitled"
        self.frames = []
        self.events = []
        self.current_frame = 0

        self.map = [[0] * GRID_W for _ in range(GRID_H)]
        self.wall_props = {}
        self.camera = {'x': 1.5, 'y': 1.5, 'angle': 0.0, 'pitch': 0.0}
        self.objects = []
        self.duration = 2.0

        # Wall settings
        self.sel_material = 'none'
        self.sel_alpha = 1.0
        self.sel_height = 1.0
        self.sel_texture = ''

        # Object settings
        self.obj_type = 'model'
        self.obj_path = self.models_list[0]
        self.obj_sprite = self.sprites_list[0]
        self.obj_enemy = 'chase'
        self.obj_hp = 100
        self.obj_roty = 0
        self.obj_rotx = 0
        self.obj_rotz = 0
        self.obj_scale = 1.0

        self.running = True
        self.message = ""
        self.message_t = 0.0

        self.editing_duration = False
        self.duration_buf = ""
        self.editing_name = False
        self.name_buf = ""
        self.hint_scroll = 0

        self.lmb_down = False
        self.last_cell = None

        # Zoom / pan / grid size
        self.zoom = 1.0
        self.zoom_min = 0.25
        self.zoom_max = 4.0
        self.pan_x = 0
        self.pan_y = 0
        self.grid_w = GRID_W
        self.grid_h = GRID_H

        # Зажатые клавиши (для плавного панорамирования)
        self.held_keys = set()
        self.pan_speed = 500  # px/сек

        # Перетаскивание карты ПКМ
        self.rmb_down = False
        self.rmb_start = (0, 0)
        self.rmb_last = (0, 0)
        self.rmb_moved = False
        self.rmb_drag_threshold = 4  # px, после которых это уже drag, а не клик

        # Диалог подтверждения выхода
        self.exit_dialog = False

        self.add_frame()

    # ---------- Frames ----------
    def add_frame(self):
        new = {
            'duration': self.duration,
            'map': [row[:] for row in self.map],
            'wall_props': {k: dict(v) for k, v in self.wall_props.items()},
            'camera': dict(self.camera),
            'objects': [dict(o) for o in self.objects],
        }
        self.frames.append(new)
        self.current_frame = len(self.frames) - 1
        self.load_frame(self.current_frame)

    def load_frame(self, i):
        if i < 0 or i >= len(self.frames):
            return
        self.current_frame = i
        f = self.frames[i]
        self.map = [row[:] for row in f.get('map', self.map)]
        if self.map:
            self.grid_h = len(self.map)
            self.grid_w = len(self.map[0]) if self.map[0] else 6
        self.wall_props = {k: dict(v)
                           for k, v in f.get('wall_props', {}).items()}
        self.camera = dict(f.get('camera', self.camera))
        self.objects = [dict(o) for o in f.get('objects', [])]
        self.duration = float(f.get('duration', 2.0))
        # Отфильтровываем всё, что вылезло за границы
        keep = {}
        for k, v in self.wall_props.items():
            try:
                x, y = map(int, k.split(','))
                if 0 <= x < self.grid_w and 0 <= y < self.grid_h:
                    keep[k] = v
            except Exception:
                pass
        self.wall_props = keep
        self.objects = [
            o for o in self.objects
            if 0 <= int(o.get('x', 0)) < self.grid_w
               and 0 <= int(o.get('y', 0)) < self.grid_h
        ]
    def save_frame(self):
        if 0 <= self.current_frame < len(self.frames):
            self.frames[self.current_frame] = {
                'duration': self.duration,
                'map': [row[:] for row in self.map],
                'wall_props': {k: dict(v)
                               for k, v in self.wall_props.items()},
                'camera': dict(self.camera),
                'objects': [dict(o) for o in self.objects],
            }

    def delete_frame(self, i):
        if 0 <= i < len(self.frames):
            self.frames.pop(i)
            if not self.frames:
                self.add_frame()
            else:
                self.load_frame(min(i, len(self.frames) - 1))

    # ---------- File ----------
    def save_scene(self, path=None):
        if path is None:
            path = f"cutscenes/{self.name}.gs3"
        self.save_frame()
        data = {
            'version': 1,
            'name': self.name,
            'frames': self.frames,
            'events': self.events,
        }
        try:
            parent = os.path.dirname(path)
            if parent:
                os.makedirs(parent, exist_ok=True)
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            self.show_msg(f"Сохранено: {path}")
            return path
        except Exception as e:
            self.show_msg(f"Ошибка: {e}")
            return None

    def load_scene(self, path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self.name = data.get('name', 'untitled')
            self.frames = data.get('frames', [])
            self.events = data.get('events', [])
            if self.frames:
                self.load_frame(0)
            else:
                self.add_frame()
            self.show_msg(f"Загружено: {path}")
        except Exception as e:
            self.show_msg(f"Ошибка: {e}")

    def new_scene(self):
        self.name = "untitled"
        self.frames = []
        self.events = []
        self.current_frame = 0
        self.map = [[0] * self.grid_w for _ in range(self.grid_h)]
        self.wall_props = {}
        self.camera = {'x': 1.5, 'y': 1.5, 'angle': 0.0, 'pitch': 0.0}
        self.objects = []
        self.duration = 2.0
        self.add_frame()
        self.show_msg("Новая сцена")
    def _default_scene_path(self):
        """cutscenes/<name>.gs3 в корне проекта."""
        here = os.path.dirname(os.path.abspath(__file__))
        root = here
        for _ in range(8):
            if os.path.isdir(os.path.join(root, 'gradus_rc')):
                break
            parent = os.path.dirname(root)
            if parent == root:
                break
            root = parent
        return os.path.join(root, 'cutscenes', f"{self.name}.gs3")
    def play_scene(self):
        """Сохранить и запустить предпросмотр в отдельном окне."""
        path = self.save_scene()
        if not path:
            return
        script = os.path.join(os.path.dirname(__file__), 'tools\\play_cutscene.py')
        try:
            subprocess.Popen([sys.executable, script, os.path.abspath(path)])
            self.show_msg(f"Запущен предпросмотр: {path}")
        except Exception as e:
            self.show_msg(f"Ошибка запуска: {e}")

    # ---------- Utils ----------
    def show_msg(self, text, t=2.5):
        self.message = text
        self.message_t = t
        print(f"[Editor] {text}")

    def grid_origin(self):
        return PAD + self.pan_x, TOOLBAR_H + PAD + self.pan_y

    def cell_size(self):
        return CELL * self.zoom

    def cell_at(self, mx, my):
        gx0, gy0 = self.grid_origin()
        cs = self.cell_size()
        if mx < gx0 or my < gy0:
            return None
        cx = int((mx - gx0) / cs)
        cy = int((my - gy0) / cs)
        if 0 <= cx < self.grid_w and 0 <= cy < self.grid_h:
            return cx, cy
        return None

    def zoom_at(self, mx, my, factor):
        old_cs = self.cell_size()
        gx0, gy0 = self.grid_origin()
        gx = (mx - gx0) / old_cs
        gy = (my - gy0) / old_cs
        new_zoom = max(self.zoom_min, min(self.zoom_max, self.zoom * factor))
        if abs(new_zoom - self.zoom) < 1e-4:
            return
        self.zoom = new_zoom
        new_cs = self.cell_size()
        self.pan_x = int(mx - gx * new_cs - PAD)
        self.pan_y = int(my - gy * new_cs - (TOOLBAR_H + PAD))

    def set_grid_size(self, w, h=None):
        if h is None:
            h = w
        w = max(1, min(256, int(w)))
        h = max(1, min(256, int(h)))
        if w == self.grid_w and h == self.grid_h:
            return
        old_w, old_h = self.grid_w, self.grid_h
        new_map = [[0] * w for _ in range(h)]
        for y in range(min(h, old_h)):
            for x in range(min(w, old_w)):
                new_map[y][x] = self.map[y][x]
        self.map = new_map
        self.grid_w, self.grid_h = w, h
        keep = {}
        for k, v in self.wall_props.items():
            try:
                x, y = map(int, k.split(','))
                if 0 <= x < w and 0 <= y < h:
                    keep[k] = v
            except Exception:
                pass
        self.wall_props = keep
        self.objects = [
            o for o in self.objects
            if 0 <= int(o.get('x', 0)) < w and 0 <= int(o.get('y', 0)) < h
        ]

    def _open_dialog(self):
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk()
            root.withdraw()
            root.attributes('-topmost', True)
            path = filedialog.askopenfilename(
                title="Открыть кат-сцену",
                initialdir="cutscenes",
                filetypes=[("Gradus Cutscene", "*.gs3"),
                           ("Все файлы", "*.*")],
            )
            root.destroy()
            if path:
                self.load_scene(path)
        except Exception as e:
            self.show_msg(f"Ошибка диалога: {e}")

    def grid_buttons_rects(self):
        sizes = [6, 12, 24, 32, 64]
        rects = {}
        x0 = 810
        for i, s in enumerate(sizes):
            rects[s] = pygame.Rect(x0 + i * 62, 15, 58, 32)
        return rects

    def toolbar_rects(self):
        return {
            'new':   pygame.Rect(20, 15, 70, 32),
            'open':  pygame.Rect(100, 15, 80, 32),
            'save':  pygame.Rect(190, 15, 90, 32),
            'play':  pygame.Rect(290, 15, 90, 32),
            'exit':  pygame.Rect(390, 15, 70, 32),
        }

    def frame_rect(self, i):
        return pygame.Rect(20 + i * 80, self.h - FRAMES_H + 70, 70, 70)

    def name_rect(self):
        return pygame.Rect(470, 18, 260, 26)

    # ---------- Wall / object ----------
    def paint_wall(self, cx, cy):
        self.map[cy][cx] = 1
        props = {}
        if self.sel_material != 'none':
            props['material'] = self.sel_material
        if self.sel_alpha < 1.0:
            props['alpha'] = self.sel_alpha
        if self.sel_height < 1.0:
            props['height'] = self.sel_height
        if self.sel_texture:
            props['sprite'] = self.sel_texture
        if props:
            self.wall_props[f"{cx},{cy}"] = props
        elif f"{cx},{cy}" in self.wall_props:
            del self.wall_props[f"{cx},{cy}"]

    def erase_wall(self, cx, cy):
        self.map[cy][cx] = 0
        key = f"{cx},{cy}"
        if key in self.wall_props:
            del self.wall_props[key]

    def toggle_wall(self, cx, cy):
        if self.map[cy][cx] == 1:
            self.erase_wall(cx, cy)
        else:
            self.paint_wall(cx, cy)

    # ---------- Events ----------
    def handle_event(self, e):
        if e.type == pygame.QUIT:
            self.exit_dialog = True
            self.held_keys.clear()
            self.lmb_down = False
            self.rmb_down = False
            return

            # Когда диалог открыт — принимаем только его события
        if self.exit_dialog:
            self._handle_exit_dialog(e)
            return

        if e.type == pygame.MOUSEWHEEL:
            mx, my = pygame.mouse.get_pos()
            gx0, gy0 = self.grid_origin()
            cs = self.cell_size()
            in_grid = (gx0 <= mx <= gx0 + self.grid_w * cs and
                       gy0 <= my <= gy0 + self.grid_h * cs and
                       my >= TOOLBAR_H and
                       my < self.h - FRAMES_H)
            if in_grid:
                factor = 1.15 if e.y > 0 else (1.0 / 1.15)
                self.zoom_at(mx, my, factor)
            else:
                self.hint_scroll -= e.y * HINT_SCROLL_STEP
                if self.hint_scroll < 0:
                    self.hint_scroll = 0
            return
            return
        if e.type == pygame.KEYDOWN:
            self.held_keys.add(e.key)
            self._handle_key(e)
            return
        if e.type == pygame.KEYUP:
            self.held_keys.discard(e.key)
            return
        if e.type == pygame.MOUSEBUTTONDOWN:
            self._handle_down(e)
            return
        if e.type == pygame.MOUSEBUTTONUP:
            self._handle_up(e)
            return
        if e.type == pygame.MOUSEMOTION:
            self._handle_motion(e)
            return

    def _handle_key(self, e):
        mods = pygame.key.get_mods()

        if self.editing_duration:
            if e.key == pygame.K_RETURN:
                try:
                    self.duration = max(0.1, float(self.duration_buf))
                    self.save_frame()
                except ValueError:
                    pass
                self.editing_duration = False
                # Стрелки — панорамирование
                # if e.key == pygame.K_LEFT:
                #     self.pan_x += 30;
                # if e.key == pygame.K_RIGHT:
                #     self.pan_x -= 30;
                # if e.key == pygame.K_UP:
                #     self.pan_y += 30;
                # if e.key == pygame.K_DOWN:
                #     self.pan_y -= 30;
                # Зум клавишами
                if e.key in (pygame.K_EQUALS, pygame.K_PLUS, pygame.K_KP_PLUS):
                    mx, my = pygame.mouse.get_pos()
                    self.zoom_at(mx, my, 1.2);
                    return
                if e.key in (pygame.K_MINUS, pygame.K_KP_MINUS):
                    mx, my = pygame.mouse.get_pos()
                    self.zoom_at(mx, my, 1.0 / 1.2);
                    return
                # Сброс вида
                if e.key == pygame.K_0:
                    self.zoom = 1.0
                    self.pan_x = 0
                    self.pan_y = 0
                    return

                if e.key == pygame.K_ESCAPE:
                    self.running = False
                if e.key == pygame.K_s and (mods & pygame.KMOD_CTRL):
                    self.save_scene()
            elif e.key == pygame.K_BACKSPACE:
                self.duration_buf = self.duration_buf[:-1]
            else:
                ch = e.unicode
                if ch and (ch.isdigit() or ch == '.'):
                    self.duration_buf += ch
            return

        if self.editing_name:
            if e.key == pygame.K_RETURN:
                if self.name_buf.strip():
                    self.name = self.name_buf.strip()
                self.editing_name = False
            elif e.key == pygame.K_ESCAPE:
                self.editing_name = False
            elif e.key == pygame.K_BACKSPACE:
                self.name_buf = self.name_buf[:-1]
            else:
                ch = e.unicode
                if ch and ch.isprintable() and ch not in ('/', '\\'):
                    self.name_buf += ch
            return

        if e.key == pygame.K_ESCAPE:
            self.exit_dialog = True
            self.held_keys.clear()
            self.lmb_down = False
            self.rmb_down = False
        elif e.key == pygame.K_s and (mods & pygame.KMOD_CTRL):
            self.save_scene()
        elif e.key == pygame.K_o and (mods & pygame.KMOD_CTRL):
            self.load_scene(f"cutscenes/{self.name}.gs3")
        elif e.key == pygame.K_n and (mods & pygame.KMOD_CTRL):
            self.new_scene()
        elif e.key == pygame.K_SPACE:
            self.add_frame()
        elif e.key == pygame.K_DELETE:
            self.delete_frame(self.current_frame)
        elif e.key == pygame.K_F5:
            self.play_scene()
        elif e.key == pygame.K_a:
            self.camera['angle'] += math.pi / 12
        elif e.key == pygame.K_d:
            self.camera['angle'] -= math.pi / 12
        elif e.key == pygame.K_q:
            self.camera['pitch'] = min(0.5, self.camera['pitch'] + 0.05)
        elif e.key == pygame.K_e:
            self.camera['pitch'] = max(-0.5, self.camera['pitch'] - 0.05)

    def _handle_down(self, e):
        mx, my = e.pos

        if my < TOOLBAR_H:
            for name, rect in self.toolbar_rects().items():
                if rect.collidepoint(mx, my):
                    if name == 'new':
                        self.new_scene()
                    elif name == 'open':
                        self._open_dialog()
                    elif name == 'save':
                        self.save_scene()
                    elif name == 'play':
                        self.play_scene()
                    elif name == 'exit':
                        self.exit_dialog = True
                        self.held_keys.clear()
                        self.lmb_down = False
                        self.rmb_down = False
                    return
            # Поле имени
            if self.name_rect().collidepoint(mx, my):
                self.editing_name = True
                self.name_buf = self.name
                return
            # Кнопки размера сетки
            for size, rect in self.grid_buttons_rects().items():
                if rect.collidepoint(mx, my):
                    self.set_grid_size(size, size)
                    return

        if my >= self.h - FRAMES_H:
            self._frames_click(mx, my)
            return

        panel_x = PAD + GRID_W * CELL + PAD
        if mx >= panel_x:
            self._panel_click(mx, my)
            return

        cell = self.cell_at(mx, my)

        if e.button == 1:
            if cell is None:
                return
            cx, cy = cell
            self.lmb_down = True
            self.last_cell = (cx, cy)
            if pygame.key.get_mods() & pygame.KMOD_SHIFT:
                self.camera['x'] = cx + 0.5
                self.camera['y'] = cy + 0.5
            else:
                self.toggle_wall(cx, cy)
        elif e.button == 3:
            # Начинаем отслеживать ПКМ — либо drag (панорамирование),
            # либо клик (поставить/удалить объект). Решим при отпускании.
            self.rmb_down = True
            self.rmb_start = (mx, my)
            self.rmb_last = (mx, my)
            self.rmb_moved = False

    def _handle_up(self, e):
        if e.button == 1:
            self.lmb_down = False
            self.last_cell = None
            return
        if e.button == 3:
            was_drag = self.rmb_moved
            start = self.rmb_start
            self.rmb_down = False
            self.rmb_moved = False
            if was_drag:
                return  # это была панорама, не ставим объект
            # Клик без движения — ставим/удаляем объект в клетке старта
            cell = self.cell_at(*start)
            if cell is not None:
                self._obj_place_or_remove(*cell)

    def _handle_motion(self, e):
        mx, my = e.pos

        # --- Перетаскивание карты ПКМ ---
        if self.rmb_down:
            dx = mx - self.rmb_last[0]
            dy = my - self.rmb_last[1]
            if not self.rmb_moved:
                total_dx = mx - self.rmb_start[0]
                total_dy = my - self.rmb_start[1]
                if abs(total_dx) + abs(total_dy) >= self.rmb_drag_threshold:
                    self.rmb_moved = True
            if self.rmb_moved:
                self.pan_x += dx
                self.pan_y += dy
            self.rmb_last = (mx, my)
            return

        # --- Рисование ЛКМ ---
        if not self.lmb_down:
            return
        if my >= self.h - FRAMES_H or my < TOOLBAR_H:
            return
        cell = self.cell_at(mx, my)
        if cell is None:
            return
        cx, cy = cell
        if self.last_cell == (cx, cy):
            return
        self.last_cell = (cx, cy)
        if pygame.key.get_mods() & pygame.KMOD_SHIFT:
            self.camera['x'] = cx + 0.5
            self.camera['y'] = cy + 0.5
        else:
            if self.map[cy][cx] == 0:
                self.paint_wall(cx, cy)

    def _obj_place_or_remove(self, cx, cy):
        clicked = None
        for i, o in enumerate(self.objects):
            if int(o.get('x', 0)) == cx and int(o.get('y', 0)) == cy:
                clicked = i
                break
        if clicked is not None:
            self.objects.pop(clicked)
            return
        self.objects.append({
            'key': f"obj_{len(self.objects)}",
            'type': self.obj_type,
            'x': cx + 0.5, 'y': cy + 0.5,
            'path': self.obj_path,
            'sprite_path': self.obj_sprite,
            'enemy_type': self.obj_enemy,
            'hp': self.obj_hp,
            'roty': self.obj_roty,
            'rotx': self.obj_rotx,
            'rotz': self.obj_rotz,
            'scale': self.obj_scale,
        })

    def _frames_click(self, mx, my):
        fy = self.h - FRAMES_H + 10
        if pygame.Rect(20, fy, 110, 30).collidepoint(mx, my):
            self.add_frame(); return
        if pygame.Rect(140, fy, 110, 30).collidepoint(mx, my):
            self.delete_frame(self.current_frame); return
        if pygame.Rect(260, fy, 170, 30).collidepoint(mx, my):
            self.editing_duration = True
            self.duration_buf = f"{self.duration}"; return
        for i in range(len(self.frames)):
            if self.frame_rect(i).collidepoint(mx, my):
                self.save_frame()
                self.load_frame(i)
                return

    def _panel_click(self, mx, my):
        gx0 = PAD
        panel_x = gx0 + GRID_W * CELL + PAD
        top = TOOLBAR_H + 20

        # Wall settings
        r = pygame.Rect(panel_x + 120, top + 30, 240, 26)
        if r.collidepoint(mx, my):
            i = MATERIALS.index(self.sel_material) if self.sel_material in MATERIALS else 0
            self.sel_material = MATERIALS[(i + 1) % len(MATERIALS)]
            return
        r = pygame.Rect(panel_x + 120, top + 60, 240, 26)
        if r.collidepoint(mx, my):
            i = ALPHAS.index(self.sel_alpha) if self.sel_alpha in ALPHAS else 0
            self.sel_alpha = ALPHAS[(i + 1) % len(ALPHAS)]
            return
        r = pygame.Rect(panel_x + 120, top + 90, 240, 26)
        if r.collidepoint(mx, my):
            i = HEIGHTS.index(self.sel_height) if self.sel_height in HEIGHTS else 0
            self.sel_height = HEIGHTS[(i + 1) % len(HEIGHTS)]
            return
        r = pygame.Rect(panel_x + 120, top + 120, 240, 26)
        if r.collidepoint(mx, my):
            opts = [''] + self.sprites_list
            i = opts.index(self.sel_texture) if self.sel_texture in opts else 0
            self.sel_texture = opts[(i + 1) % len(opts)]
            return

        # Object type
        for i, t in enumerate(['model', 'sprite', 'enemy']):
            r = pygame.Rect(panel_x + i * 110, top + 180, 100, 30)
            if r.collidepoint(mx, my):
                self.obj_type = t
                return

        # Object fields
        field_y = top + 230
        # Model path
        r = pygame.Rect(panel_x + 120, field_y, 240, 26)
        if r.collidepoint(mx, my) and self.obj_type == 'model':
            i = (self.models_list.index(self.obj_path)
                 if self.obj_path in self.models_list else 0)
            self.obj_path = self.models_list[(i + 1) % len(self.models_list)]
            return
        # Sprite path
        r = pygame.Rect(panel_x + 120, field_y + 30, 240, 26)
        if r.collidepoint(mx, my) and self.obj_type in ('sprite', 'enemy'):
            i = (self.sprites_list.index(self.obj_sprite)
                 if self.obj_sprite in self.sprites_list else 0)
            self.obj_sprite = self.sprites_list[(i + 1) % len(self.sprites_list)]
            return
        # enemy type
        r = pygame.Rect(panel_x + 120, field_y + 60, 240, 26)
        if r.collidepoint(mx, my) and self.obj_type == 'enemy':
            opts = ['chase', 'patrol', 'static']
            i = opts.index(self.obj_enemy) if self.obj_enemy in opts else 0
            self.obj_enemy = opts[(i + 1) % len(opts)]
            return
        # HP
        r = pygame.Rect(panel_x + 120, field_y + 90, 240, 26)
        if r.collidepoint(mx, my) and self.obj_type == 'enemy':
            self.obj_hp = (self.obj_hp + 50) % 1000 or 50
            return
        # RotY
        r = pygame.Rect(panel_x + 120, field_y + 120, 240, 26)
        if r.collidepoint(mx, my):
            self.obj_roty = (self.obj_roty + 45) % 360
            return
        # RotX
        r = pygame.Rect(panel_x + 120, field_y + 150, 240, 26)
        if r.collidepoint(mx, my) and self.obj_type == 'model':
            self.obj_rotx = (self.obj_rotx + 45) % 360
            return
        # RotZ
        r = pygame.Rect(panel_x + 120, field_y + 180, 240, 26)
        if r.collidepoint(mx, my) and self.obj_type == 'model':
            self.obj_rotz = (self.obj_rotz + 45) % 360
            return
        # Scale
        r = pygame.Rect(panel_x + 120, field_y + 210, 240, 26)
        if r.collidepoint(mx, my):
            self.obj_scale += 0.25
            if self.obj_scale > 4.0:
                self.obj_scale = 0.25
            return

    # ---------- Update ----------
    def update(self, dt):
        if self.message_t > 0:
            self.message_t -= dt

        # --- Плавное панорамирование зажатыми стрелками ---
        # Shift ускоряет в 3 раза
        speed = self.pan_speed
        if pygame.key.get_mods() & pygame.KMOD_SHIFT:
            speed *= 3
        step = speed * dt

        dx = dy = 0
        if pygame.K_LEFT in self.held_keys:
            dx += step
        if pygame.K_RIGHT in self.held_keys:
            dx -= step
        if pygame.K_UP in self.held_keys:
            dy += step
        if pygame.K_DOWN in self.held_keys:
            dy -= step
        if dx or dy:
            self.pan_x += int(dx)
            self.pan_y += int(dy)
    # ---------- Render ----------
    def render(self):
        self.screen.fill((25, 28, 38))
        self._render_toolbar()
        self._render_grid()
        self._render_panel()
        self._render_frames()
        self._render_message()
        if self.exit_dialog:
            self._render_exit_dialog()
        pygame.display.flip()

    def _render_toolbar(self):
        pygame.draw.rect(self.screen, (40, 45, 60), (0, 0, self.w, TOOLBAR_H))
        labels = {'new': 'Новая', 'open': 'Открыть',
                  'save': 'Сохранить', 'play': 'Play', 'exit': 'Выход'}
        for name, rect in self.toolbar_rects().items():
            col = (120, 60, 60) if name == 'exit' else (70, 90, 130)
            pygame.draw.rect(self.screen, col, rect, border_radius=6)
            pygame.draw.rect(self.screen, (180, 200, 240), rect, 1, border_radius=6)
            txt = self.font_sm.render(labels[name], True, (240, 240, 240))
            self.screen.blit(txt, (rect.x + (rect.w - txt.get_width()) // 2,
                                    rect.y + (rect.h - txt.get_height()) // 2))

        # Имя файла
        nr = self.name_rect()
        pygame.draw.rect(self.screen, (60, 80, 120), nr, border_radius=4)
        pygame.draw.rect(self.screen, (140, 170, 220), nr, 1, border_radius=4)
        if self.editing_name:
            name_text = f"{self.name_buf}_"
        else:
            name_text = self.name
        nt = self.font_md.render(name_text, True, (240, 240, 240))
        self.screen.blit(nt, (nr.x + 8, nr.y + 4))

        # Кнопки размера сетки
        gt = self.font_sm.render("Сетка:", True, (200, 210, 230))
        self.screen.blit(gt, (760, 22))
        for size, rect in self.grid_buttons_rects().items():
            active = (size == self.grid_w == self.grid_h)
            col = (100, 140, 200) if active else (60, 75, 110)
            pygame.draw.rect(self.screen, col, rect, border_radius=6)
            pygame.draw.rect(self.screen, (140, 170, 220), rect, 1,
                             border_radius=6)
            txt = self.font_sm.render(f"{size}×{size}", True, (240, 240, 240))
            self.screen.blit(txt, (rect.x + (rect.w - txt.get_width()) // 2,
                                   rect.y + (rect.h - txt.get_height()) // 2))

        # Индикатор зума
        zt = self.font_sm.render(f"Zoom: {int(self.zoom * 100)}%", True,
                                 (200, 210, 230))
        self.screen.blit(zt, (self.w - 130, 22))

    def _render_grid(self):
        gx0, gy0 = self.grid_origin()
        cs = self.cell_size()

        clip = pygame.Rect(PAD, TOOLBAR_H + PAD,
                           self.w - 2 * PAD,
                           self.h - FRAMES_H - TOOLBAR_H - 2 * PAD)
        old_clip = self.screen.get_clip()
        self.screen.set_clip(clip)

        for y in range(self.grid_h):
            for x in range(self.grid_w):
                px = gx0 + x * cs
                py = gy0 + y * cs
                if px + cs < clip.left or px > clip.right:
                    continue
                if py + cs < clip.top or py > clip.bottom:
                    continue
                rect = pygame.Rect(int(px), int(py),
                                   max(1, int(cs) - 1), max(1, int(cs) - 1))
                if self.map[y][x] == 1:
                    props = self.wall_props.get(f"{x},{y}", {})
                    alpha = props.get('alpha', 1.0)
                    if alpha < 0.5:
                        col = (60, 55, 45)
                    elif alpha < 1.0:
                        col = (100, 90, 75)
                    else:
                        col = (120, 100, 80)
                else:
                    col = (30, 33, 45)
                pygame.draw.rect(self.screen, col, rect)
                pygame.draw.rect(self.screen, (60, 65, 80), rect, 1)

        for o in self.objects:
            ox = int(o.get('x', 0))
            oy = int(o.get('y', 0))
            if not (0 <= ox < self.grid_w and 0 <= oy < self.grid_h):
                continue
            px = gx0 + ox * cs
            py = gy0 + oy * cs
            if px + cs < clip.left or px > clip.right:
                continue
            if py + cs < clip.top or py > clip.bottom:
                continue
            pad = cs * 0.17
            rect = pygame.Rect(int(px + pad), int(py + pad),
                               max(2, int(cs - 2 * pad)),
                               max(2, int(cs - 2 * pad)))
            col = {'model': (80, 180, 80), 'sprite': (180, 180, 80),
                   'enemy': (200, 80, 80)}.get(o.get('type', 'model'),
                                               (150, 150, 150))
            pygame.draw.rect(self.screen, col, rect, border_radius=4)
            if cs > 30:
                key_txt = self.font_sm.render(str(o.get('key', '?'))[:6],
                                              True, (20, 20, 20))
                self.screen.blit(key_txt, (rect.x + 2, rect.y + 2))

        cxs = gx0 + self.camera['x'] * cs
        cys = gy0 + self.camera['y'] * cs
        ang = self.camera['angle']
        pygame.draw.circle(self.screen, (255, 200, 60),
                           (int(cxs), int(cys)), 12, 2)
        tip_x = cxs + 35 * math.cos(ang)
        tip_y = cys + 35 * math.sin(ang)
        pygame.draw.line(self.screen, (255, 200, 60),
                         (int(cxs), int(cys)), (int(tip_x), int(tip_y)), 3)

        # Индикатор зума
        zt = self.font_sm.render(
            f"Zoom: {int(self.zoom * 100)}%  ·  "
            f"Сетка: {self.grid_w}×{self.grid_h}",
            True, (200, 210, 230))
        self.screen.blit(zt, (clip.left + 8, clip.top + 8))

        self.screen.set_clip(old_clip)

    def _render_panel(self):
        gx0 = PAD
        panel_x = gx0 + GRID_W * CELL + PAD
        top = TOOLBAR_H + 20

        pygame.draw.rect(self.screen, (40, 45, 60),
                         (panel_x - 10, top - 10,
                          410, self.h - FRAMES_H - top + 10),
                         border_radius=8)

        head = self.font_lg.render("НАСТРОЙКИ СТЕНЫ (для новых)", True,
                                    (255, 200, 100))
        self.screen.blit(head, (panel_x, top))

        rows = [
            ("Материал", self.sel_material),
            ("Alpha", f"{int(self.sel_alpha * 100)}%"),
            ("Высота", f"{self.sel_height}"),
            ("Текстура", self.sel_texture or "— по материалу —"),
        ]
        for i, (label, value) in enumerate(rows):
            y = top + 30 + i * 30
            lt = self.font_sm.render(label + ":", True, (200, 210, 230))
            self.screen.blit(lt, (panel_x, y))
            r = pygame.Rect(panel_x + 120, y - 2, 240, 26)
            pygame.draw.rect(self.screen, (60, 80, 120), r, border_radius=4)
            pygame.draw.rect(self.screen, (140, 170, 220), r, 1, border_radius=4)
            vt = self.font_sm.render(value, True, (240, 240, 240))
            self.screen.blit(vt, (r.x + 8, r.y + 5))

        head2 = self.font_lg.render("НАСТРОЙКИ ОБЪЕКТА", True, (255, 200, 100))
        self.screen.blit(head2, (panel_x, top + 150))

        for i, t in enumerate(['model', 'sprite', 'enemy']):
            r = pygame.Rect(panel_x + i * 110, top + 180, 100, 30)
            active = (self.obj_type == t)
            col = (100, 140, 200) if active else (60, 65, 80)
            pygame.draw.rect(self.screen, col, r, border_radius=6)
            txt = self.font_sm.render(t.capitalize(), True, (240, 240, 240))
            self.screen.blit(txt, (r.x + (r.w - txt.get_width()) // 2,
                                    r.y + (r.h - txt.get_height()) // 2))

        field_y = top + 230
        rows2 = [
            ("Путь модели", self.obj_path if self.obj_type == 'model' else "—"),
            ("Sprite", self.obj_sprite if self.obj_type in ('sprite', 'enemy') else "—"),
            ("Enemy type", self.obj_enemy if self.obj_type == 'enemy' else "—"),
            ("HP", str(self.obj_hp) if self.obj_type == 'enemy' else "—"),
            ("RotY", f"{self.obj_roty}°"),
            ("RotX", f"{self.obj_rotx}°" if self.obj_type == 'model' else "—"),
            ("RotZ", f"{self.obj_rotz}°" if self.obj_type == 'model' else "—"),
            ("Scale", f"{self.obj_scale:.2f}x"),
        ]
        for i, (label, value) in enumerate(rows2):
            y = field_y + i * 30
            lt = self.font_sm.render(label + ":", True, (200, 210, 230))
            self.screen.blit(lt, (panel_x, y))
            r = pygame.Rect(panel_x + 120, y - 2, 240, 26)
            disabled = (value == "—")
            col = (40, 45, 55) if disabled else (60, 80, 120)
            pygame.draw.rect(self.screen, col, r, border_radius=4)
            pygame.draw.rect(self.screen, (140, 170, 220), r, 1, border_radius=4)
            # Обрезаем длинные пути
            display = value
            if len(display) > 38:
                display = "…" + display[-37:]
            vt = self.font_sm.render(display, True,
                                      (120, 130, 150) if disabled else (240, 240, 240))
            self.screen.blit(vt, (r.x + 8, r.y + 5))

        # Help
        help_x = panel_x + 420
        help_w = self.w - help_x - 20
        help_y = top
        help_h = self.h - FRAMES_H - top - 10

        pygame.draw.rect(self.screen, (30, 34, 44),
                         (help_x - 10, help_y - 10, help_w + 10, help_h + 10),
                         border_radius=8)
        head3 = self.font_lg.render("УПРАВЛЕНИЕ", True, (255, 200, 100))
        self.screen.blit(head3, (help_x, help_y))

        hints = [
            "ЛКМ (зажать) — рисование стен",
            "SHIFT+ЛКМ — камера",
            "ПКМ — объект (ставить/удалить)",
            "",
            "A / D — угол камеры",
            "Q / E — pitch камеры",
            "",
            "SPACE — новый кадр",
            "DEL — удалить кадр",
            "",
            "F5 — предпросмотр",
            "Ctrl+S / O / N — файл",
            "ESC — выход",
            "",
            "Клик по названию сцены —",
            "изменить её имя.",
            "Открыть — выбор файла .gs3",
            "",
            "Колесо мыши (в сетке) — зум",
            "ПКМ (зажать) — двигать карту",
            "Стрелки (удерживать) — панорама",
            "Shift + стрелки — быстрее",
            "+ / − — зум клавишами",
            "0 — сбросить вид",
            "",
            "Кнопки 6×6 … 64×64 —",
            "выбор размера карты.",
            "Существующая карта обрезается,",
            "если новый размер меньше.",
            "",
            "Alpha: 100/75/50/25%",
            "Height: 1.0/0.75/0.5/0.25/0.1",
            "",
            "Модели и спрайты берутся из:",
            f"  {ASSETS_ROOT}",
            "Рекурсивно, все .png/.obj/.gbj.",
            "",
            "Колёсико вне сетки —",
            "скроллинг этой панели.",
        ]
        clip_rect = pygame.Rect(help_x, help_y + 30, help_w, help_h - 40)
        old_clip = self.screen.get_clip()
        self.screen.set_clip(clip_rect)
        for i, line in enumerate(hints):
            y = help_y + 30 + i * 20 - self.hint_scroll
            if y < help_y - 30 or y > self.h - FRAMES_H:
                continue
            t = self.font_sm.render(line, True, (180, 190, 210))
            self.screen.blit(t, (help_x, y))
        self.screen.set_clip(old_clip)

    def _render_frames(self):
        fy = self.h - FRAMES_H
        pygame.draw.rect(self.screen, (35, 38, 50), (0, fy, self.w, FRAMES_H))

        plus_rect = pygame.Rect(20, fy + 10, 110, 30)
        pygame.draw.rect(self.screen, (60, 120, 60), plus_rect, border_radius=6)
        t = self.font_sm.render("+ Новый кадр", True, (240, 240, 240))
        self.screen.blit(t, (plus_rect.x + 8, plus_rect.y + 7))

        del_rect = pygame.Rect(140, fy + 10, 110, 30)
        pygame.draw.rect(self.screen, (120, 60, 60), del_rect, border_radius=6)
        t = self.font_sm.render("Удалить", True, (240, 240, 240))
        self.screen.blit(t, (del_rect.x + 20, del_rect.y + 7))

        dur_rect = pygame.Rect(260, fy + 10, 170, 30)
        pygame.draw.rect(self.screen, (70, 80, 110), dur_rect, border_radius=6)
        dtext = (f"Duration: {self.duration_buf}_"
                 if self.editing_duration
                 else f"Duration: {self.duration:.1f}s")
        t = self.font_sm.render(dtext, True, (240, 240, 240))
        self.screen.blit(t, (dur_rect.x + 8, dur_rect.y + 7))

        for i in range(len(self.frames)):
            r = self.frame_rect(i)
            active = (i == self.current_frame)
            col = (100, 140, 200) if active else (60, 65, 80)
            pygame.draw.rect(self.screen, col, r, border_radius=6)
            num = self.font_md.render(str(i + 1), True, (240, 240, 240))
            self.screen.blit(num, (r.x + 26, r.y + 5))
            d = self.frames[i].get('duration', 1.0)
            dt = self.font_sm.render(f"{d:.1f}s", True, (200, 200, 200))
            self.screen.blit(dt, (r.x + 8, r.y + 40))

    # ---------- Exit dialog ----------
    def _exit_dialog_rects(self):
        cx = self.w // 2
        cy = self.h // 2
        bw, bh = 190, 52
        gap = 20
        y = cy + 40
        return {
            'save':    pygame.Rect(cx - bw - gap - bw // 2, y, bw, bh),
            'discard': pygame.Rect(cx - bw // 2, y, bw, bh),
            'cancel':  pygame.Rect(cx + bw // 2 + gap, y, bw, bh),
        }

    def _handle_exit_dialog(self, e):
        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_ESCAPE:
                self.exit_dialog = False
                return
            if e.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_s):
                self.save_scene()
                self.running = False
                self.exit_dialog = False
                return
            if e.key == pygame.K_d:
                self.running = False
                self.exit_dialog = False
                return
            return
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            mx, my = e.pos
            for name, rect in self._exit_dialog_rects().items():
                if rect.collidepoint(mx, my):
                    if name == 'save':
                        self.save_scene()
                        self.running = False
                    elif name == 'discard':
                        self.running = False
                    elif name == 'cancel':
                        self.exit_dialog = False
                    return

    def _render_exit_dialog(self):
        # Затемнение
        overlay = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 170))
        self.screen.blit(overlay, (0, 0))

        # Панель
        dw, dh = 720, 260
        dx = (self.w - dw) // 2
        dy = (self.h - dh) // 2
        panel = pygame.Rect(dx, dy, dw, dh)
        pygame.draw.rect(self.screen, (40, 45, 60), panel, border_radius=14)
        pygame.draw.rect(self.screen, (140, 170, 220), panel, 2,
                         border_radius=14)

        title = self.font_lg.render("Сохранить перед выходом?",
                                    True, (255, 200, 100))
        self.screen.blit(title, title.get_rect(center=(self.w // 2, dy + 55)))

        hint = self.font_sm.render(
            "S / Enter — сохранить  ·  D — выйти без сохранения  ·  Esc — отмена",
            True, (180, 190, 210))
        self.screen.blit(hint, hint.get_rect(center=(self.w // 2, dy + 95)))

        labels = {
            'save':    ('Сохранить',       (60, 140, 70)),
            'discard': ('Без сохранения',  (140, 70, 70)),
            'cancel':  ('Отмена',          (70, 80, 110)),
        }
        for name, rect in self._exit_dialog_rects().items():
            col = labels[name][1]
            pygame.draw.rect(self.screen, col, rect, border_radius=10)
            pygame.draw.rect(self.screen, (200, 210, 230), rect, 1,
                             border_radius=10)
            txt = self.font_md.render(labels[name][0], True, (240, 240, 240))
            self.screen.blit(txt, txt.get_rect(center=rect.center))

    def _render_message(self):
        if self.message_t <= 0:
            return
        msg = self.font_md.render(self.message, True, (255, 240, 180))
        bg = pygame.Surface((msg.get_width() + 20, msg.get_height() + 10),
                            pygame.SRCALPHA)
        bg.fill((0, 0, 0, 200))
        self.screen.blit(bg, (self.w // 2 - msg.get_width() // 2 - 10, 70))
        self.screen.blit(msg, (self.w // 2 - msg.get_width() // 2, 75))

    def run(self):
        while self.running:
            dt = self.clock.tick(60) / 1000.0
            for e in pygame.event.get():
                self.handle_event(e)
            self.update(dt)
            self.render()
        pygame.quit()


if __name__ == "__main__":
    CutsceneEditor().run()