// client.js – Gradus Static.JS Client v2.5.1 (новые shop-плейсхолдеры, фикс вложенных)
const GradusClient = {
    _config: {},
    _customHandlers: {},

    async process(config, customHandlers = {}) {
        this._config = config;
        this._customHandlers = customHandlers;
        await this._walk(document.body);
    },

    async _walk(node) {
        if (node.nodeType === Node.TEXT_NODE) {
            node.textContent = await this._resolveText(node.textContent);
        } else if (node.nodeType === Node.ELEMENT_NODE && node.nodeName !== 'SCRIPT' && node.nodeName !== 'STYLE') {
            for (let attr of node.attributes) {
                const newVal = await this._resolveText(attr.value);
                if (newVal !== attr.value) node.setAttribute(attr.name, newVal);
            }
            for (let child of node.childNodes) await this._walk(child);
        }
    },

    async _resolveText(text) {
        if (typeof text !== 'string') return text;
        const result = [];
        let i = 0;
        while (i < text.length) {
            if (text[i] === '{' && i + 1 < text.length) {
                const placeholder = this._extractPlaceholder(text, i);
                if (placeholder) {
                    const resolved = await this._processPlaceholder(placeholder.inner);
                    result.push(resolved);
                    i += placeholder.length;
                    continue;
                }
            }
            result.push(text[i]); i++;
        }
        return result.join('');
    },

    _extractPlaceholder(text, start) {
        let depth = 1, i = start + 1;
        while (i < text.length && depth > 0) { if (text[i] === '{') depth++; else if (text[i] === '}') depth--; i++; }
        if (depth !== 0) return null;
        return { inner: text.substring(start + 1, i - 1), length: i - start };
    },

    async _processPlaceholder(inner) {
        // Обрабатываем вложенные плейсхолдеры рекурсивно
        const colonIdx = inner.indexOf(':');
        let func, rawArgs;
        if (colonIdx !== -1) { func = inner.substring(0, colonIdx).trim(); rawArgs = inner.substring(colonIdx + 1); }
        else { func = inner.trim(); rawArgs = ''; }
        const result = await this._execute(func, rawArgs);
        return GradusWeb.security.sanitizeHTML(String(result));
    },

    async _parseArgs(rawArgs) {
        if (!rawArgs) return [];
        const args = [], depth = 0; let current = '';
        for (let i = 0; i < rawArgs.length; i++) {
            const ch = rawArgs[i];
            if (ch === '{') depth++; else if (ch === '}') depth--;
            if (ch === ',' && depth === 0) { args.push(current.trim()); current = ''; }
            else current += ch;
        }
        if (current.trim() !== '') args.push(current.trim());
        const resolved = [];
        for (let arg of args) resolved.push(await this._resolveText(arg)); // рекурсивно разрешаем аргументы
        return resolved;
    },

    async _execute(func, rawArgs) {
        const args = await this._parseArgs(rawArgs);

        // Пользовательские обработчики
        if (this._customHandlers[func]) {
            try {
                return await this._customHandlers[func](...args);
            } catch (e) {
                console.error('[CLIENT] Ошибка пользовательского обработчика:', func, e);
                return 'ERROR';
            }
        }

        // Встроенные
        const G = window.GradusWeb;
        switch (func) {
            case 'cache_read':   return G.cache.get(args[0] ?? '') ?? '';
            case 'cache_write':
                if (args.length >= 2) {
                    const ttl = args.length > 2 ? parseInt(args[2]) : 3600;
                    G.cache.set(args[0], args[1], ttl);
                }
                return '';
            case 'cache_delete': G.cache.remove(args[0] ?? ''); return '';

            case 'db_read': return window.GradusDB ? (await GradusDB.get(args[0] ?? '')) ?? '' : '';
            case 'db_write': if (window.GradusDB && args.length >= 2) GradusDB.set(args[0], args[1]); return '';
            case 'db_delete': if (window.GradusDB) GradusDB.delete(args[0] ?? ''); return '';

            case 'server_get':
                return window.GradusServer ? await GradusServer.get(args[0] ?? '') : '';
            case 'server_post':
                return window.GradusServer ? await GradusServer.post(args[0] ?? '', args[1] ?? '') : '';
            case 'firebase_get':
                return window.GradusServer ? await GradusServer.firebaseGet(args[0] ?? '') : '';
            case 'firebase_set':
                if (window.GradusServer && args.length >= 2) await GradusServer.firebaseSet(args[0], args[1]);
                return '';

            case 'secret_read': return (await G.secretStorage.get(args[0] ?? '')) ?? '';
            case 'secret_write': if (args.length >= 2) await G.secretStorage.set(args[0], args[1]); return '';
            case 'secret_delete': await G.secretStorage.remove(args[0] ?? ''); return '';

            case 'encode': return G.encode(args[0] ?? '');
            case 'decode': return G.decode(args[0] ?? '');

            case 'random_uuid': return G.generate.uuid();
            case 'random_password': return G.generate.password(parseInt(args[0]) || 12);
            case 'random_int': {
                const parts = (args[0] || '1-100').split('-').map(Number);
                return String(G.generate.randomInt(parts[0], parts[1] || 100));
            }

            case 'config': return this._config[args[0]] !== undefined ? String(this._config[args[0]]) : '';

            case 'date': return new Date().toLocaleDateString(args[0] || undefined);
            case 'time': return new Date().toLocaleTimeString(args[0] || undefined);
            case 'timestamp': return String(Date.now());

            case 'calc': {
                try {
                    const sanitized = (args[0] || '').replace(/[^0-9+\-*/().%\s]/g, '');
                    return String(Function('"use strict"; return (' + sanitized + ')')());
                } catch (e) { return 'ERROR'; }
            }

            case 'upper': return (args[0] || '').toUpperCase();
            case 'lower': return (args[0] || '').toLowerCase();
            case 'concat': return args.join('');
            case 'substring': {
                const start = parseInt(args[1]) || 0;
                const end = args.length > 2 ? parseInt(args[2]) : undefined;
                return (args[0] || '').substring(start, end);
            }

            case 'notify':
                if (args.length >= 1) G.notify.show(args[0], args[1] || 'info', parseInt(args[2]) || 3000);
                return '';

            case 'base64_encode': return G.toBase64(args[0] || '');
            case 'base64_decode': return G.fromBase64(args[0] || '');
            case 'url_encode': return encodeURIComponent(args[0] || '');
            case 'url_decode': return decodeURIComponent(args[0] || '');
            case 'escape_html': return G.security.sanitizeHTML(args[0] || '');
            case 'nl2br': return (args[0] || '').replace(/\n/g, '<br>');
            case 'random_hex_color': return '#' + Math.floor(Math.random() * 0xffffff).toString(16).padStart(6, '0');
            case 'clipboard_copy':
                if (navigator.clipboard) navigator.clipboard.writeText(args[0] || '');
                return '';
            case 'countdown': {
                const end = new Date(args[0]).getTime();
                const now = Date.now();
                if (isNaN(end) || end <= now) return '0 дн. 0 ч. 0 мин. 0 сек.';
                let diff = end - now;
                const days = Math.floor(diff / 86400000); diff %= 86400000;
                const hours = Math.floor(diff / 3600000); diff %= 3600000;
                const mins = Math.floor(diff / 60000); diff %= 60000;
                const secs = Math.floor(diff / 1000);
                return `${days} дн. ${hours} ч. ${mins} мин. ${secs} сек.`;
            }

            // Новые плейсхолдеры v2.5
            case 'qr_code': {
                const text = args[0] || '';
                if (text) {
                    return `<img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(text)}" alt="QR Code" />`;
                }
                return '';
            }
            case 'spell_check': {
                const word = args[0] || '';
                if (word && window.GradusServer) {
                    const resp = await GradusServer.get(`https://api.languagetoolplus.com/v2/check?text=${encodeURIComponent(word)}&language=auto`);
                    try {
                        const data = JSON.parse(resp);
                        if (data.matches && data.matches.length > 0) {
                            return data.matches.map(m => m.message).join('; ');
                        } else return 'Ошибок не найдено';
                    } catch(e) { return 'Ошибка проверки'; }
                }
                return '';
            }

            // Shop-плейсхолдеры (v2.5.1)
            case 'product_name': {
                if (G.shop && G.shop.catalog) {
                    const product = G.shop.catalog.getById(args[0]);
                    return product ? (product.name || '') : '';
                }
                return '';
            }
            case 'product_price': {
                if (G.shop && G.shop.catalog) {
                    const product = G.shop.catalog.getById(args[0]);
                    return product ? String(product.price || 0) : '';
                }
                return '';
            }
            case 'product_desc': {
                if (G.shop && G.shop.catalog) {
                    const product = G.shop.catalog.getById(args[0]);
                    return product ? (product.description || '') : '';
                }
                return '';
            }
            case 'cart_count': {
                if (G.shop && G.shop.cart) {
                    return String(G.shop.cart.count());
                }
                return '0';
            }
            case 'cart_total': {
                if (G.shop && G.shop.cart && G.shop.catalog) {
                    const cartItems = G.shop.cart.get();
                    let total = 0;
                    for (let item of cartItems) {
                        const product = G.shop.catalog.getById(item.id);
                        const price = product ? product.price : item.price || 0;
                        total += price * item.quantity;
                    }
                    return total.toFixed(2);
                }
                return '0.00';
            }

            case 'get_api_key_preview':
                const key = await G.secretStorage.get('api_key');
                return key ? key.substr(0, 4) + '...' : 'не найден';

            default:
                console.warn('[CLIENT] Неизвестная функция:', func);
                return '';
        }
    }
};

window.GradusClient = GradusClient;