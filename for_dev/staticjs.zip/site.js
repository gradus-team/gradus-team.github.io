async function initSite() {
    // Регистрация обработчика с защитой от ошибок
    GradusStatic.registerHandler('currency_rate', async (from, to) => {
        try {
            const url = `https://api.exchangerate-api.com/v4/latest/${from}`;
            const resp = await GradusServer.get(url);
            const data = JSON.parse(resp);
            if (data && data.rates && data.rates[to]) {
                return data.rates[to].toFixed(2);
            } else {
                console.warn('[SITE] currency_rate: не удалось получить курс');
                return '—';
            }
        } catch (e) {
            console.error('[SITE] Ошибка currency_rate:', e);
            return '—';
        }
    });

    GradusStatic.registerHandler('hello', (name) => `Привет, ${name}!`);

    // Запишем что-то в кэш для примера (можно убрать)
    GradusWeb.cache.set('username', 'Гость');
}

const siteConfig = {
    debug: true,
    dbFile: '/db.json'
};

window.addEventListener('load', () => {
    GradusStatic.init(siteConfig);
});