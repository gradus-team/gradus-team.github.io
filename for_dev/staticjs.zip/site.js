const siteConfig = {
    debug: true,
    dbFile: '/db.json'
};

async function initSite() {
    GradusWeb.security.enableDevToolsProtection(() => {
        alert('Обнаружены инструменты разработчика! Данные удалены.');
        GradusWeb.secretStorage.clear();
        GradusWeb.cache.clear();
    }, { removeScripts: true, skipMobile: true });

    const existing = await GradusWeb.secretStorage.get('api_key');
    if (!existing) {
        await GradusWeb.secretStorage.set('api_key', 'sk_live_1234567890secret');
    }

    GradusWeb.cache.set('username', 'Гость', 86400);
    GradusWeb.cache.set('greeting', 'Привет, Мир!');
    GradusWeb.clipboard.startTracking();

    const NOTES_INDEX_KEY = 'gradus_notes_index';  // точное совпадение с index.html
    let index = GradusWeb.cache.get(NOTES_INDEX_KEY) || [];
    if (typeof index === 'string') index = JSON.parse(index);
    if (!index.length) {
        const id1 = 'note_' + GradusWeb.generate.uuid();
        const id2 = 'note_' + GradusWeb.generate.uuid();
        await GradusDB.set(id1, '🌟 Первая заметка');
        await GradusDB.set(id2, '🛡️ Вторая заметка');
        index.push(id1, id2);
        GradusWeb.cache.set(NOTES_INDEX_KEY, index);
    }
}

GradusStatic.init(siteConfig);