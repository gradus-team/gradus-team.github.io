// core.js – Gradus Static.JS Core v2.5.1 (автоинициализация, фикс пустого dbFile, shop-плейсхолдеры)
const GradusStatic = {
    _config: { debug: false, dbFile: '/db.json' },
    _handlers: {},
    _initialized: false,

    registerHandler(name, fn) {
        const builtInHandlers = [
            'cache_read', 'cache_write', 'cache_delete',
            'db_read', 'db_write', 'db_delete',
            'secret_read', 'secret_write', 'secret_delete',
            'server_get', 'server_post',
            'firebase_get', 'firebase_set',
            'encode', 'decode',
            'random_uuid', 'random_password', 'random_int',
            'date', 'time', 'timestamp',
            'calc', 'upper', 'lower', 'concat', 'substring',
            'notify', 'config', 'get_api_key_preview',
            'base64_encode', 'base64_decode', 'url_encode', 'url_decode',
            'escape_html', 'nl2br', 'random_hex_color', 'clipboard_copy', 'countdown',
            'qr_code', 'spell_check',
            'product_name', 'product_price', 'product_desc', 'cart_count', 'cart_total'
        ];
        if (builtInHandlers.includes(name)) {
            console.warn(`[CORE] Попытка переопределить встроенный обработчик "${name}". Используйте префикс "custom_".`);
            return;
        }

        const wrapped = async (...args) => {
            try {
                return await fn(...args);
            } catch (e) {
                console.error(`[CORE] Ошибка в обработчике "${name}":`, e);
                return 'ERROR';
            }
        };
        this._handlers[name] = wrapped;
        if (this._config.debug) console.log('[CORE] Зарегистрирован обработчик:', name);
    },

    async init(userConfig = {}) {
        // Предотвращаем повторную инициализацию
        if (this._initialized) {
            console.warn('[CORE] GradusStatic уже инициализирован');
            return;
        }
        this._initialized = true;

        // Защита от null/undefined конфига
        userConfig = userConfig || {};

        // Ждём полной загрузки DOM, если он ещё не готов
        if (document.readyState === 'loading') {
            await new Promise(resolve => document.addEventListener('DOMContentLoaded', resolve));
        }

        // Объединяем пользовательскую конфигурацию с дефолтной
        Object.assign(this._config, userConfig);
        console.log('[CORE] Init вызван. Debug =', this._config.debug);

        // Инициализируем базу данных
        if (window.GradusDB) {
            try {
                await GradusDB.init(this._config);
                if (this._config.debug) console.log('[CORE] База данных инициализирована');
            } catch (e) {
                console.warn('[CORE] Ошибка инициализации БД:', e);
            }
        } else {
            if (this._config.debug) console.warn('[CORE] GradusDB не найден');
        }

        // Вызываем пользовательскую функцию инициализации, если она определена
        if (typeof window.initSite === 'function') {
            if (this._config.debug) console.log('[CORE] Вызов initSite...');
            try {
                await window.initSite();
            } catch (e) {
                console.error('[CORE] Ошибка в initSite:', e);
            }
            if (this._config.debug) console.log('[CORE] initSite завершён');
        } else {
            if (this._config.debug) console.log('[CORE] initSite не определена, пропускаем');
        }

        // Инициализируем Shop (экземпляр GradusWeb.shop)
        if (window.GradusWeb && window.GradusWeb.shop) {
            GradusStatic.shop = window.GradusWeb.shop;
        }

        // Защита от DevTools (отключается при debug: true)
        if (!this._config.debug && window.GradusWeb && window.GradusWeb.security) {
            window.GradusWeb.security.enableDevToolsProtection(() => {
                alert('Обнаружены инструменты разработчика! Данные удалены.');
                window.GradusWeb.cache.clear();
                window.GradusWeb.secretStorage.clear();
                location.reload();
            }, { removeScripts: true, skipMobile: true });
            console.log('[CORE] Защита от DevTools включена.');
        } else if (this._config.debug) {
            console.log('[CORE] Защита от DevTools отключена (debug: true)');
        }

        // Запускаем рендеринг страницы
        if (window.GradusClient) {
            if (this._config.debug) console.log('[CORE] Запуск рендеринга страницы...');
            await window.GradusClient.process(this._config, this._handlers);
            if (this._config.debug) console.log('[CORE] Рендеринг завершён');
        } else {
            console.warn('[CORE] GradusClient не найден – рендеринг пропущен');
        }

        // Определение оффлайн-режима
        window.addEventListener('online', () => console.log('[CORE] Соединение восстановлено'));
        window.addEventListener('offline', () => console.warn('[CORE] Отсутствует интернет-соединение'));
    }
};

// Автоинициализация при отсутствии явного вызова из site.js
(function autoInit() {
    function tryAutoInit() {
        if (!window.GradusStatic._initialized) {
            console.log('[CORE] Автоинициализация (site.js пуст или отсутствует)');
            window.GradusStatic.init({});
        }
    }
    if (document.readyState === 'loading') {
        window.addEventListener('DOMContentLoaded', () => {
            // Даём небольшую задержку на случай, если site.js всё же вызывает init позже
            setTimeout(tryAutoInit, 50);
        });
    } else {
        setTimeout(tryAutoInit, 50);
    }
})();

window.GradusStatic = GradusStatic;