"""Взрывы: урон по радиусу + динамический свет + частицы."""
import math
import random


class Explosion:
    """Одноразовый взрыв — живёт пока не нанесёт урон, потом только визуал."""
    # БЕЗ __slots__ — иначе AttributeError на _particles_done

    def __init__(self, x, y, radius, damage, color=(255, 180, 60)):
        self.x = x
        self.y = y
        self.radius = float(radius)
        self.damage = float(damage)
        self.age = 0.0
        self.max_age = 0.35
        self.damage_applied = False
        self.color = color
        self.light_radius = radius * 3.0
        self._particles_done = False    # ← вот этого не хватало в __slots__

    def apply_damage(self, engine):
        if self.damage_applied:
            return
        self.damage_applied = True
        r2 = self.radius * self.radius

        for enemy in list(engine.enemies):
            if not enemy.alive:
                continue
            dx = enemy.x - self.x
            dy = enemy.y - self.y
            d2 = dx * dx + dy * dy
            if d2 > r2:
                continue
            t = math.sqrt(d2) / self.radius
            dmg = self.damage * (1.0 - t)
            enemy.take_damage(dmg)
            if d2 > 1e-3:
                d = math.sqrt(d2)
                kick = 300 * (1.0 - t)
                enemy.x += dx / d * kick * 0.05
                enemy.y += dy / d * kick * 0.05

        px, py = engine.player.pos.x, engine.player.pos.y
        dx = px - self.x
        dy = py - self.y
        d2 = dx * dx + dy * dy
        if d2 < r2:
            t = math.sqrt(d2) / self.radius
            engine.damage_player(self.damage * (1.0 - t) * 0.6)

        tile = engine.tile_size
        cx = int(self.x // tile)
        cy = int(self.y // tile)
        tr = int(self.radius // tile) + 1
        for ty in range(cy - tr, cy + tr + 1):
            for tx in range(cx - tr, cx + tr + 1):
                if not (0 <= ty < engine.map_height and 0 <= tx < engine.map_width):
                    continue
                wx = tx * tile + tile * 0.5
                wy = ty * tile + tile * 0.5
                dd = math.hypot(wx - self.x, wy - self.y)
                if dd > self.radius:
                    continue
                cell = engine.map_data[ty][tx]
                props = cell.get('properties', {})
                if not props.get('destructible', False):
                    continue
                dmg = self.damage * (1.0 - dd / self.radius)
                hp = props.get('hp', engine.default_wall_hp) - dmg
                props['hp'] = hp
                if hp <= 0:
                    bid = int(cell.get('base_id', 0))

                    # Получаем материал
                    mat = None
                    try:
                        mat = engine._get_material_for_cell(cell)
                    except Exception:
                        pass
                    wall_col = mat.color if mat and mat.color else (200, 200, 200)

                    # Для ID=6 — ищем текстуру модели
                    use_texture = None
                    if bid == 6:
                        model_key = f"model_{tx}_{ty}"
                        sprite = engine.sprite_manager.get_by_key(model_key)
                        if sprite is not None:
                            if hasattr(sprite, 'frame_sets') and sprite.frame_sets:
                                try:
                                    fs = sprite.frame_sets[sprite.current_frame_index]
                                    if fs:
                                        use_texture = fs[sprite.current_angle_frame]
                                except Exception:
                                    pass
                            elif hasattr(sprite, 'frames') and sprite.frames:
                                use_texture = sprite.frames[0]
                            elif hasattr(sprite, 'texture'):
                                use_texture = sprite.texture
                        try:
                            engine.sprite_manager.remove_by_key(model_key)
                        except Exception:
                            pass
                    else:
                        use_texture = mat.texture if mat else None

                    # Осколки — 3D-разлёт
                    try:
                        engine.particles.spawn_wall_break(
                            wx, wy,
                            texture=use_texture,
                            color=wall_col,
                            mode=engine.particles.debris_mode,
                        )
                    except Exception as e:
                        print(f"[Explosion] debris failed: {e}")

                    # След на полу
                    try:
                        engine.decals.spawn_rubble(
                            wx, wy, wall_col,
                            size=96, cell=(tx, ty),
                            wall_texture=use_texture,
                        )
                    except Exception as e:
                        print(f"[Explosion] decal failed: {e}")

                    cell['base_id'] = 0
                    props.pop('material', None)
                    if engine.use_gpu:
                        engine.gpu_raycaster.mark_map_dirty()
    def update(self, dt):
        self.age += dt
        return self.age < self.max_age

    def spawn_particles(self, particle_system):
        if self._particles_done:
            return
        self._particles_done = True
        from .particles import Particle

        n = int(self.radius * 0.8)  # было 0.6 — чуть больше частиц

        for _ in range(n):
            ang = random.uniform(0, 2 * math.pi)
            r = random.uniform(0, self.radius)
            px = self.x + math.cos(ang) * r
            py = self.y + math.sin(ang) * r

            # Разброс по высоте — до 3/4 радиуса взрыва
            pz = random.uniform(0.0, self.radius * 0.75)
            # Скорость вверх — сильная, вниз — почти ноль (гравитация уронит)
            pvz = random.uniform(60.0, 320.0)

            # Скорость в стороны — чем выше, тем меньше (сфера, а не цилиндр)
            h_factor = 1.0 - (pz / max(self.radius, 1.0))
            side_speed = random.uniform(20, 140) * h_factor

            particle_system.particles.append(Particle(
                px, py,
                math.cos(ang) * side_speed,
                math.sin(ang) * side_speed,
                life=random.uniform(0.4, 1.0),
                color=(255, random.randint(120, 200), 60),
                world_size=random.uniform(3, 7),
                gravity=150.0,
                z=pz,
                vz=pvz,
                gravity_z=-500.0,  # падает обратно
            ))