import pygame
import random
import time

class EffectsManager:
    def __init__(self):
        self.effect_type = None      # 'noise', 'static', 'glitch', 'vhs'
        self.alpha = 255             # общая прозрачность эффекта
        self.intensity = 0.5         # сила эффекта (0..1)

        # Кэш эффект-слоя и таймер обновления
        self._effect_layer = None
        self._last_update = 0.0
        self._update_interval = 0.3  # секунды

    def set_effect(self, effect_type, alpha=255, intensity=0.5):
        self.effect_type = effect_type
        self.alpha = max(0, min(255, int(alpha)))
        self.intensity = max(0.0, min(1.0, float(intensity)))
        # При смене эффекта сбрасываем кэш, чтобы сразу обновиться
        self._effect_layer = None

    def clear_effect(self):
        self.effect_type = None
        self._effect_layer = None

    def apply(self, screen):
        if not self.effect_type or self.alpha <= 0:
            return

        now = time.time()
        # Перегенерируем слой эффектов с заданным интервалом
        if self._effect_layer is None or (now - self._last_update) >= self._update_interval:
            self._effect_layer = self._generate_effect_layer(screen)
            self._last_update = now

        if self._effect_layer is not None:
            self._effect_layer.set_alpha(self.alpha)
            screen.blit(self._effect_layer, (0, 0))

    # ------------------------------------------------------------
    def _generate_effect_layer(self, screen):
        width, height = screen.get_size()
        layer = pygame.Surface((width, height), pygame.SRCALPHA)

        if self.effect_type == 'noise' or self.effect_type == 'vhs':
            self._add_noise(layer, width, height)

        if self.effect_type == 'static' or self.effect_type == 'vhs':
            self._add_static(layer, width, height)

        if self.effect_type == 'glitch' or self.effect_type == 'vhs':
            self._add_glitch(layer, width, height)

        return layer

    # ------------------------------------------------------------
    def _add_noise(self, surf, w, h):
        """Зернистость: случайные цветные точки."""
        if self.intensity <= 0:
            return
        num_pixels = int(w * h * self.intensity * 0.1)  # 10% пикселей при макс. интенсивности
        for _ in range(num_pixels):
            x = random.randint(0, w - 1)
            y = random.randint(0, h - 1)
            col = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255), random.randint(50, 150))
            surf.set_at((x, y), col)

    def _add_static(self, surf, w, h):
        """VHS-помехи: вертикальные полупрозрачные полосы."""
        if self.intensity <= 0:
            return
        num_strips = int(3 + 8 * self.intensity)
        for _ in range(num_strips):
            strip_x = random.randint(0, max(0, w - 1))
            strip_w = random.randint(1, 5)
            if strip_x + strip_w > w:
                strip_w = w - strip_x
            if strip_w <= 0:
                continue
            alpha = random.randint(30, 140)
            pygame.draw.rect(surf, (255, 255, 255, alpha), (strip_x, 0, strip_w, h))

    def _add_glitch(self, surf, w, h):
        """Цветовые глюки: тонкие горизонтальные разноцветные полосы."""
        if self.intensity <= 0:
            return
        num_lines = int(5 + 15 * self.intensity)
        for _ in range(num_lines):
            y = random.randint(0, h - 1)
            line_h = random.randint(1, 3)  # толщина 1-3 пикселя
            # Случайный яркий цвет
            color = (random.randint(50, 255), random.randint(50, 255), random.randint(50, 255))
            # Альфа = 102 (0.4 * 255)
            pygame.draw.rect(surf, (*color, 102), (0, y, w, line_h))