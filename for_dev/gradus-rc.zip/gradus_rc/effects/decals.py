import pygame
import math
import random


class Decal:
    __slots__ = ('x', 'y', 'texture', 'world_size', 'age', 'max_age',
                 'kind', 'cell_x', 'cell_y')

    def __init__(self, x, y, texture, world_size=48, max_age=99999,
                 kind='blood', cell_x=None, cell_y=None):
        self.x = x; self.y = y
        self.texture = texture
        self.world_size = world_size
        self.age = 0.0; self.max_age = max_age
        self.kind = kind
        self.cell_x = cell_x; self.cell_y = cell_y


class DecalSystem:
    def __init__(self, engine):
        self.engine = engine
        self.decals = []
        self.max_decals = 80
        self.enabled = True
        self._cache = {}

    # ---------- Текстуры ----------
    def _blood_tex(self, size=64):
        key = ('blood', size)
        if key in self._cache:
            return self._cache[key]
        surf = pygame.Surface((size, size), pygame.SRCALPHA)
        # основное пятно
        for _ in range(random.randint(4, 8)):
            cx = size // 2 + random.randint(-size // 4, size // 4)
            cy = size // 2 + random.randint(-size // 4, size // 4)
            r = random.randint(size // 8, size // 4)
            col = (random.randint(90, 170), random.randint(0, 20),
                   random.randint(0, 20), random.randint(160, 230))
            pygame.draw.circle(surf, col, (cx, cy), r)
        # мелкие брызги
        for _ in range(30):
            x = random.randint(0, size - 1)
            y = random.randint(0, size - 1)
            col = (random.randint(120, 200), 0, 0, random.randint(120, 200))
            surf.set_at((x, y), col)
        self._cache[key] = surf
        return surf

    def _rubble_tex_from_wall(self, wall_texture, wall_color, size=96):
        """Делает пятно из текстуры стены: уменьшенная текстура + тёмные пятна."""
        if wall_texture is None:
            return self._rubble_tex_procedural(wall_color, size)

        # Извлекаем bbox и уменьшаем до размера пятна
        surf = pygame.Surface((size, size), pygame.SRCALPHA)
        try:
            small = pygame.transform.scale(wall_texture, (size, size))
            surf.blit(small, (0, 0))
        except Exception:
            surf.fill((*wall_color[:3], 255))

        # Затемняем края и добавляем дырки (прозрачность)
        mask = pygame.Surface((size, size), pygame.SRCALPHA)
        mask.fill((0, 0, 0, 0))
        # эллипс-маска: центр видим, края прозрачные
        pygame.draw.ellipse(mask, (255, 255, 255, 220),
                            (size * 0.1, size * 0.1, size * 0.8, size * 0.8))
        # рандомные дырки
        for _ in range(random.randint(8, 14)):
            cx = random.randint(size // 6, size * 5 // 6)
            cy = random.randint(size // 6, size * 5 // 6)
            r = random.randint(size // 20, size // 10)
            pygame.draw.circle(mask, (0, 0, 0, 0), (cx, cy), r)
        surf.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)

        # Пара тёмных камешков сверху
        for _ in range(random.randint(15, 25)):
            x = random.randint(size // 6, size * 5 // 6)
            y = random.randint(size // 6, size * 5 // 6)
            r = random.randint(1, 3)
            b = random.randint(40, 90)
            pygame.draw.circle(surf, (b, b, b, 200), (x, y), r)
        return surf

    def _rubble_tex_procedural(self, wall_color, size=96):
        key = ('rubble_proc', size, tuple(wall_color[:3]))
        if key in self._cache:
            return self._cache[key]
        surf = pygame.Surface((size, size), pygame.SRCALPHA)
        for _ in range(random.randint(35, 55)):
            x = random.randint(0, size - 1)
            y = random.randint(0, size - 1)
            r = random.randint(2, 7)
            c = self._vary(wall_color, 40)
            pygame.draw.circle(surf, (*c[:3], random.randint(140, 220)),
                               (x, y), r)
        self._cache[key] = surf
        return surf

    def _scorch_tex(self, size=64):
        key = ('scorch', size)
        if key in self._cache:
            return self._cache[key]
        surf = pygame.Surface((size, size), pygame.SRCALPHA)
        for _ in range(random.randint(15, 25)):
            cx = size // 2 + random.randint(-size // 3, size // 3)
            cy = size // 2 + random.randint(-size // 3, size // 3)
            r = random.randint(size // 8, size // 3)
            pygame.draw.circle(surf, (0, 0, 0, random.randint(80, 180)),
                               (cx, cy), r)
        self._cache[key] = surf
        return surf

    @staticmethod
    def _vary(color, delta):
        r, g, b = color[:3]
        return (max(0, min(255, r + random.randint(-delta, delta))),
                max(0, min(255, g + random.randint(-delta, delta))),
                max(0, min(255, b + random.randint(-delta, delta))))

    # ---------- Spawn ----------
    def spawn_blood(self, x, y, size=64):
        if not self.enabled:
            return
        self.decals.append(Decal(x, y, self._blood_tex(),
                                 world_size=size, kind='blood'))
        self._trim()

    def spawn_rubble(self, x, y, wall_color=(150, 150, 150),
                     size=96, cell=None, wall_texture=None):
        if not self.enabled:
            return
        cx, cy = cell if cell else (None, None)
        tex = self._rubble_tex_from_wall(wall_texture, wall_color, size)
        self.decals.append(Decal(x, y, tex,
                                 world_size=size, kind='rubble',
                                 cell_x=cx, cell_y=cy))
        self._trim()

    def spawn_scorch(self, x, y, size=56):
        if not self.enabled:
            return
        self.decals.append(Decal(x, y, self._scorch_tex(),
                                 world_size=size, kind='scorch'))
        self._trim()

    def remove_by_cell(self, cell_x, cell_y):
        self.decals = [d for d in self.decals
                       if not (d.cell_x == cell_x and d.cell_y == cell_y)]

    def clear(self):
        self.decals.clear()

    def _trim(self):
        if len(self.decals) > self.max_decals:
            self.decals = self.decals[-self.max_decals:]

    # ---------- Update ----------
    def update(self, dt):
        for d in self.decals:
            d.age += dt
        self.decals = [d for d in self.decals if d.age < d.max_age]

    # ---------- Draw ----------
    def draw(self, screen):
        if not self.enabled or not self.decals:
            return
        eng = self.engine
        px, py = eng.player.pos.x, eng.player.pos.y
        pa = eng.player.angle
        half_fov = eng.half_fov
        fov = eng.fov
        proj = eng.proj_coeff
        horizon = eng.height // 2 + eng._get_pitch_offset()
        tile = eng.tile_size

        for d in self.decals:
            dx, dy = d.x - px, d.y - py
            dist = math.hypot(dx, dy)
            if dist < 40 or dist > eng.max_depth:
                continue
            rel = math.atan2(dy, dx) - pa
            while rel < -math.pi: rel += 2 * math.pi
            while rel > math.pi:  rel -= 2 * math.pi
            if abs(rel) > half_fov:
                continue

            # проверка видимости
            if not eng._is_sprite_visible(d.x, d.y):
                continue

            scr_x = (rel / fov + 0.5) * eng.width

            # === ПРАВИЛЬНАЯ ПРОЕКЦИЯ НА ПОЛ ===
            w = int(proj * (d.world_size / tile) / dist)
            if w < 3 or w > eng.width * 2:
                continue
            h = max(2, int(w * 0.22))
            y_floor = horizon + int(proj / (2.0 * dist))
            y_top = y_floor - h // 2

            scaled = pygame.transform.scale(d.texture, (w, h))

            # Затухание в конце жизни
            if d.max_age < 90000:
                life_ratio = 1.0 - (d.age / d.max_age)
                if life_ratio < 0.3:
                    scaled.set_alpha(int(255 * (life_ratio / 0.3)))

            screen.blit(scaled, (scr_x - w // 2, y_top))