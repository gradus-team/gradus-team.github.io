import pygame
import math
import random


class Particle:
    __slots__ = ('x', 'y', 'vx', 'vy', 'life', 'max_life',
                 'color', 'world_size', 'gravity', 'fade',
                 'z', 'vz', 'gravity_z')

    def __init__(self, x, y, vx, vy, life, color, world_size=4,
                 gravity=0.0, fade=True, z=0.0, vz=0.0, gravity_z=0.0):
        self.x = x; self.y = y
        self.vx = vx; self.vy = vy
        self.life = life; self.max_life = life
        self.color = color; self.world_size = world_size
        self.gravity = gravity; self.fade = fade
        # 3D — по умолчанию 0 (не влияет на старые частицы)
        self.z = z
        self.vz = vz
        self.gravity_z = gravity_z

    def update(self, dt):
        self.x += self.vx * dt; self.y += self.vy * dt
        self.vy += self.gravity * dt
        self.vx *= 0.98; self.vy *= 0.98

        # 3D-движение
        self.vz += self.gravity_z * dt
        self.z += self.vz * dt
        if self.z <= 0.0:
            self.z = 0.0
            self.vz = -self.vz * 0.35   # отскок от пола

        self.life -= dt
    def is_alive(self):
        return self.life > 0


class WallDebris:
    __slots__ = ('x', 'y', 'vx', 'vy', 'life', 'max_life',
                 'surface', 'rot', 'rot_speed', 'gravity', 'fade',
                 'z', 'vz', 'gravity_z')

    def __init__(self, x, y, vx, vy, surface, life=1.5,
                 rotation=0.0, rotation_speed=0.0, gravity=250.0):
        self.x = x;
        self.y = y
        self.vx = vx;
        self.vy = vy
        self.life = life;
        self.max_life = life
        self.surface = surface
        self.rot = rotation;
        self.rot_speed = rotation_speed
        self.gravity = gravity;
        self.fade = True
        # 3D — по умолчанию на полу
        self.z = 0.0
        self.vz = 0.0
        self.gravity_z = 0.0

    def update(self, dt):
        self.x += self.vx * dt;
        self.y += self.vy * dt
        self.vy += self.gravity * dt
        self.vx *= 0.97;
        self.vy *= 0.98
        self.rot += self.rot_speed * dt
        self.life -= dt
        # 3D
        if self.gravity_z != 0.0 or self.z != 0.0 or self.vz != 0.0:
            self.vz += self.gravity_z * dt
            self.z += self.vz * dt
            if self.z <= 0.0:
                self.z = 0.0
                self.vz = -self.vz * 0.3

    def is_alive(self):
        return self.life > 0


class ParticleSystem:

    MODE_OFF = 'off'
    MODE_MAIN = 'main'
    MODE_OPTIMAL = 'optimal'
    MODE_ALL = 'all'
    def __init__(self, engine):
        self.engine = engine
        self.particles = []
        self.debris_particles = []
        self.mode = self.MODE_OPTIMAL
        self.max_particles = 300
        self.max_debris = 60
        self.graphics_level = 'high'
        self.debris_enabled = True
        self.debris_mode = 'medium'
        self._particle_tex_cache = {}

    def set_mode(self, mode):
        if mode not in (self.MODE_OFF, self.MODE_MAIN,
                        self.MODE_OPTIMAL, self.MODE_ALL):
            return
        self.mode = mode
        if mode == self.MODE_OFF:
            self.particles.clear()
            self.debris_particles.clear()

    def set_graphics_level(self, level):
        self.graphics_level = level
        if level == 'lite':
            self.debris_enabled = False
        elif level == 'medium':
            self.debris_enabled = True
            self.debris_mode = 'low'
        elif level == 'high':
            self.debris_enabled = True
            if self.debris_mode == 'low':
                self.debris_mode = 'medium'
        elif level == 'ultra':
            self.debris_enabled = True
            self.debris_mode = 'big'

    def _particle_tex(self, color, size):
        """Мягкий радиальный градиент вместо pygame.draw.circle."""
        size = max(2, int(size))
        key = (tuple(int(c) for c in color[:3]), size)
        if key in self._particle_tex_cache:
            return self._particle_tex_cache[key]
        surf = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        cx = cy = size
        for r in range(size, 0, -1):
            alpha = int(255 * (1.0 - r / size) ** 1.8)
            pygame.draw.circle(surf, (*color[:3], alpha), (cx, cy), r)
        self._particle_tex_cache[key] = surf
        return surf

    # ---------- Частицы ----------
    def spawn_hit_wall(self, x, y, wall_color=(200, 200, 200), count=None):
        if self.mode not in (self.MODE_OPTIMAL, self.MODE_ALL):
            return
        if count is None:
            count = 6 if self.mode == self.MODE_OPTIMAL else 12
        for _ in range(count):
            ang = random.uniform(0, 2 * math.pi)
            spd = random.uniform(30, 120)
            self.particles.append(Particle(
                x, y, math.cos(ang) * spd, math.sin(ang) * spd,
                random.uniform(0.2, 0.5), self._vary(wall_color, 40),
                random.uniform(1.5, 3.0), 80.0))


    def spawn_hit_enemy(self, x, y, count=None):
        if self.mode not in (self.MODE_OPTIMAL, self.MODE_ALL):
            return
        if count is None:
            count = 8 if self.mode == self.MODE_OPTIMAL else 16
        for _ in range(count):
            ang = random.uniform(0, 2 * math.pi)
            spd = random.uniform(40, 160)
            self.particles.append(Particle(
                x, y, math.cos(ang) * spd, math.sin(ang) * spd,
                random.uniform(0.3, 0.7), self._vary((200, 30, 30), 40),
                random.uniform(2.0, 4.0), 120.0))

    def spawn_hit_player(self, count=None):
        if self.mode == self.MODE_OFF:
            return
        if count is None:
            count = 10 if self.mode == self.MODE_MAIN else 18
        px, py = self.engine.player.pos.x, self.engine.player.pos.y
        for _ in range(count):
            ang = random.uniform(0, 2 * math.pi)
            spd = random.uniform(20, 80)
            # Отступ 30-60 пикселей от игрока — иначе dist≈0 → size = ∞
            offset = random.uniform(30.0, 60.0)
            ox = px + math.cos(ang) * offset
            oy = py + math.sin(ang) * offset
            self.particles.append(Particle(
                ox, oy, math.cos(ang) * spd, math.sin(ang) * spd,
                random.uniform(0.3, 0.6), self._vary((220, 30, 30), 40),
                random.uniform(2.0, 4.0), 100.0))

    def spawn_muzzle(self, x, y, angle, color=(255, 220, 120)):
        if self.mode != self.MODE_ALL:
            return
        for _ in range(5):
            a = angle + random.uniform(-0.3, 0.3)
            spd = random.uniform(150, 300)
            self.particles.append(Particle(
                x, y, math.cos(a) * spd, math.sin(a) * spd,
                random.uniform(0.08, 0.18), self._vary(color, 40),
                random.uniform(3, 5), 0))

    def spawn_death(self, x, y, count=None):
        if self.mode != self.MODE_ALL:
            return
        if count is None:
            count = 25
        for _ in range(count):
            ang = random.uniform(0, 2 * math.pi)
            spd = random.uniform(30, 200)
            self.particles.append(Particle(
                x, y, math.cos(ang) * spd, math.sin(ang) * spd,
                random.uniform(0.5, 1.2), self._vary((180, 20, 20), 50),
                random.uniform(2.5, 5.0), 140.0))

    # ---------- Обломки стен ----------
    def spawn_wall_break(self, x, y, texture=None, color=(200, 200, 200),
                         mode=None, force_texture=None):
        if self.mode == self.MODE_OFF:
            return
        if not self.debris_enabled:
            self.spawn_hit_wall(x, y, color, count=25)
            return
        mode = mode or self.debris_mode
        grid = {'big': 2, 'medium': 3, 'low': 4}.get(mode, 3)
        use_tex = force_texture
        if use_tex is None:
            use_tex = (texture is not None and
                       self.graphics_level in ('high', 'ultra'))
        if use_tex and texture is not None:
            self._spawn_textured_debris(x, y, texture, grid)
        else:
            self._spawn_colored_debris(x, y, color, grid * grid)

    def _spawn_textured_debris(self, x, y, texture, grid):
        tex_w, tex_h = texture.get_size()
        cw = tex_w / grid
        ch = tex_h / grid
        jitter = 0.38
        pts = {}
        for gy in range(grid + 1):
            for gx in range(grid + 1):
                px = gx * cw + (random.uniform(-jitter * cw, jitter * cw) if 0 < gx < grid else 0)
                py = gy * ch + (random.uniform(-jitter * ch, jitter * ch) if 0 < gy < grid else 0)
                pts[(gx, gy)] = (px, py)
        base_size = max(8, int(self.engine.tile_size / grid))
        for gy in range(grid):
            for gx in range(grid):
                corners = [pts[(gx, gy)], pts[(gx + 1, gy)],
                           pts[(gx + 1, gy + 1)], pts[(gx, gy + 1)]]
                if random.random() < 0.55:
                    edge = random.randint(0, 3)
                    p1 = corners[edge]; p2 = corners[(edge + 1) % 4]
                    mx = (p1[0] + p2[0]) / 2 + random.uniform(-cw * 0.25, cw * 0.25)
                    my = (p1[1] + p2[1]) / 2 + random.uniform(-ch * 0.25, ch * 0.25)
                    corners.insert(edge + 1, (mx, my))
                if random.random() < 0.22 and len(corners) > 3:
                    corners.pop(random.randint(0, len(corners) - 1))
                xs = [v[0] for v in corners]; ys = [v[1] for v in corners]
                min_x = max(0, int(min(xs)) - 1)
                min_y = max(0, int(min(ys)) - 1)
                max_x = min(tex_w, int(max(xs)) + 2)
                max_y = min(tex_h, int(max(ys)) + 2)
                w = max_x - min_x; h = max_y - min_y
                if w < 3 or h < 3:
                    continue
                surf = self._build_shard(texture, corners, min_x, min_y, w, h, base_size)
                if surf is None:
                    continue
                cx = sum(xs) / len(xs) - tex_w / 2
                cy = sum(ys) / len(ys) - tex_h / 2
                ang = math.atan2(cy, cx) + random.uniform(-0.5, 0.5)
                # Смешанная скорость: сильный разброс + случайное вертикальное отклонение
                spd = random.uniform(60, 320)
                # Имитация 3D-отскока — добавляем угол наклона
                vertical_bias = random.uniform(-120, -40)  # вверх-вниз
                d = WallDebris(
                    x, y, math.cos(ang) * spd, math.sin(ang) * spd + vertical_bias,
                    surf, random.uniform(1.2, 2.4),
                    random.uniform(0, 360), random.uniform(-720, 720), 280.0)
                d.z = random.uniform(4.0, 24.0)
                d.vz = random.uniform(80.0, 260.0)
                d.gravity_z = -600.0
                self.debris_particles.append(d)
        if len(self.debris_particles) > self.max_debris:
            self.debris_particles = self.debris_particles[-self.max_debris:]

    def _build_shard(self, texture, verts, min_x, min_y, w, h, base_size):
        try:
            region = pygame.Surface((w, h), pygame.SRCALPHA)
            try:
                sub = texture.subsurface((min_x, min_y, w, h))
                region.blit(sub, (0, 0))
            except Exception:
                region.fill((150, 150, 150))
            mask = pygame.Surface((w, h), pygame.SRCALPHA)
            mask.fill((0, 0, 0, 0))
            shifted = [(int(p[0] - min_x), int(p[1] - min_y)) for p in verts]
            pygame.draw.polygon(mask, (255, 255, 255, 255), shifted)
            region.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
            return pygame.transform.scale(region, (base_size, base_size))
        except Exception:
            return None

    def _spawn_colored_debris(self, x, y, color, count):
        for _ in range(count):
            surf = self._colored_shard(color)
            ang = random.uniform(0, 2 * math.pi)
            spd = random.uniform(60, 180)
            d = WallDebris(
                x, y, math.cos(ang) * spd, math.sin(ang) * spd - 60,
                surf, random.uniform(0.9, 1.8),
                random.uniform(0, 360), random.uniform(-540, 540), 260.0)
            # 3D-начальные условия
            d.z = random.uniform(4.0, 24.0)
            d.vz = random.uniform(80.0, 260.0)
            d.gravity_z = -600.0
            self.debris_particles.append(d)
        if len(self.debris_particles) > self.max_debris:
            self.debris_particles = self.debris_particles[-self.max_debris:]

    def _colored_shard(self, color):
        size = random.randint(8, 16)
        surf = pygame.Surface((size, size), pygame.SRCALPHA)
        col = self._vary(color, 12)
        n = random.randint(3, 5)
        cx, cy = size / 2, size / 2
        verts = []
        for i in range(n):
            ang = (i / n) * 2 * math.pi + random.uniform(-0.35, 0.35)
            r = random.uniform(size * 0.32, size * 0.48)
            verts.append((cx + math.cos(ang) * r, cy + math.sin(ang) * r))
        pygame.draw.polygon(surf, (*col, 255), verts)
        return surf

    # ---------- Update ----------
    def update(self, dt):
        if self.mode == self.MODE_OFF:
            return
        alive = []
        for p in self.particles:
            p.update(dt)
            if p.is_alive():
                alive.append(p)
        self.particles = alive[-self.max_particles:]
        alive_d = []
        for d in self.debris_particles:
            d.update(dt)
            if d.is_alive():
                alive_d.append(d)
        self.debris_particles = alive_d[-self.max_debris:]

    # ---------- Draw ----------
    def draw(self, screen):
        if self.mode == self.MODE_OFF:
            return
        eng = self.engine
        px, py = eng.player.pos.x, eng.player.pos.y
        pa = eng.player.angle
        half_fov = eng.half_fov
        fov = eng.fov
        proj = eng.proj_coeff
        horizon = eng.height // 2 + eng._get_pitch_offset()
        fog = eng.fog_enabled
        fog_s = eng.fog_start
        fog_e = eng.fog_end
        fog_c = eng.fog_color

        for p in self.particles:
            dx, dy = p.x - px, p.y - py
            dist = math.hypot(dx, dy)
            if dist < 1:
                continue
            # Защита: не даём dist быть слишком маленьким (иначе size = ∞)
            if dist < 20.0:
                dist = 20.0
            rel = math.atan2(dy, dx) - pa
            while rel < -math.pi: rel += 2 * math.pi
            while rel > math.pi:  rel -= 2 * math.pi
            if abs(rel) > half_fov:
                continue
            scr_x = (rel / fov + 0.5) * eng.width
            size = proj / dist * (p.world_size / 20.0)
            if size < 1:
                continue
            if size > 128:
                size = 128
            alpha = int(255 * (p.life / p.max_life)) if p.fade else 255
            if fog and dist > fog_s:
                t = min(1.0, (dist - fog_s) / max(1, fog_e - fog_s))
                if t >= 0.95:
                    continue
                col = tuple(int(p.color[i] * (1 - t) + fog_c[i] * t) for i in range(3))
            else:
                col = p.color
            tex = self._particle_tex(col, int(size) // 2)
            tex = tex.copy()
            tex.set_alpha(alpha)

            # 3D-смещение: чем выше z, тем выше на экране
            # Коэффициент подобран эмпирически — 0.5 даёт заметный подъём
            z_shift = int(p.z * proj / max(dist * eng.tile_size, 1.0) * 0.5)
            y_draw = horizon - tex.get_height() // 2 - z_shift

            screen.blit(tex, (int(scr_x - tex.get_width() // 2), int(y_draw)))

        for d in self.debris_particles:
            dx, dy = d.x - px, d.y - py
            dist = math.hypot(dx, dy)
            if dist < 1:
                continue
            rel = math.atan2(dy, dx) - pa
            while rel < -math.pi: rel += 2 * math.pi
            while rel > math.pi:  rel -= 2 * math.pi
            if abs(rel) > half_fov:
                continue
            scr_x = (rel / fov + 0.5) * eng.width
            sf = proj / dist / eng.tile_size
            osz = d.surface.get_width() * sf
            if osz < 2:
                continue
            scaled = pygame.transform.scale(d.surface, (int(osz), int(osz)))
            rotated = pygame.transform.rotate(scaled, d.rot)
            alpha = 255
            if d.fade and d.life < 0.4:
                alpha = int(255 * (d.life / 0.4))
            if fog and dist > fog_s:
                t = min(1.0, (dist - fog_s) / max(1, fog_e - fog_s))
                if t >= 0.95:
                    continue
                tint = pygame.Surface(rotated.get_size(), pygame.SRCALPHA)
                tint.fill((*fog_c, int(255 * t)))
                rotated.blit(tint, (0, 0))
            if alpha < 255:
                rotated = rotated.copy()
                rotated.set_alpha(alpha)
            z_shift = int(getattr(d, 'z', 0.0) * proj / max(dist * eng.tile_size, 1.0) * 0.5)
            screen.blit(rotated,
                        (int(scr_x - rotated.get_width() // 2),
                         int(horizon - rotated.get_height() // 2 - z_shift)))

    @staticmethod
    def _vary(color, delta):
        r, g, b = color[:3]
        return (max(0, min(255, r + random.randint(-delta, delta))),
                max(0, min(255, g + random.randint(-delta, delta))),
                max(0, min(255, b + random.randint(-delta, delta))))