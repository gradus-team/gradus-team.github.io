import pygame
import math
import random


class WallDebrisParticle:
    """Один кусок разрушенной стены — вращается и падает."""
    __slots__ = ('x', 'y', 'vx', 'vy', 'life', 'max_life',
                 'surface', 'rot', 'rot_speed', 'world_size',
                 'gravity', 'fade')

    def __init__(self, x, y, vx, vy, surface, life=1.5,
                 rotation=0.0, rotation_speed=0.0,
                 world_size=16.0, gravity=220.0, fade=True):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.life = life
        self.max_life = life
        self.surface = surface
        self.rot = rotation
        self.rot_speed = rotation_speed
        self.world_size = world_size
        self.gravity = gravity
        self.fade = fade

    def update(self, dt):
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.vy += self.gravity * dt
        # Усиленное трение (имитация воздуха/трения о пол)
        self.vx *= 0.94
        self.vy *= 0.96
        self.rot += self.rot_speed * dt
        self.life -= dt

    def is_alive(self):
        return self.life > 0