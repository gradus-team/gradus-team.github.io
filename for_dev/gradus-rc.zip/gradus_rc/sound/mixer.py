# gradus_rc/sound/mixer.py
import pygame

class SoundManager:
    def __init__(self):
        self.sounds = {}
        self.channels = {}

    def load_all(self, sound_dict):
        for name, path in sound_dict.items():
            self.load_sound(name, path)

    def load_sound(self, key, path):
        try:
            self.sounds[key] = pygame.mixer.Sound(path)
        except Exception as e:
            print(f"Не удалось загрузить звук {key}: {e}")

    def play_sound(self, name, loops=0):
        if name in self.sounds:
            channel = self.sounds[name].play(loops)
            if channel:
                self.channels[name] = channel
            return channel
        return None

    def stop_sound(self, name):
        if name in self.channels:
            self.channels[name].stop()
            del self.channels[name]

    def stop_all(self):
        for channel in self.channels.values():
            channel.stop()
        self.channels.clear()


import math

class Sound3D:
    """
    Объёмный звук с учётом позиции источника и ориентации камеры игрока.
    Использует стерео-панорамирование и затухание по расстоянию.
    """
    def __init__(self, sound):
        self.sound = sound
        self.channel = None

    def play(self, listener_pos, listener_angle, source_pos, max_distance=500.0, doppler_factor=0.0):
        """
        Воспроизводит звук с объёмным эффектом.

        :param listener_pos: (x, y) — позиция слушателя (камеры/игрока) в мировых координатах.
        :param listener_angle: угол поворота камеры в радианах.
        :param source_pos: (x, y) — позиция источника звука в мировых координатах.
        :param max_distance: расстояние, на котором звук полностью затухает.
        :param doppler_factor: коэффициент эффекта Доплера (0..1), 0 — выключен.
        """
        dx = source_pos[0] - listener_pos[0]
        dy = source_pos[1] - listener_pos[1]
        dist = math.hypot(dx, dy)

        if dist > max_distance:
            return None  # звук не слышен

        # Громкость в зависимости от расстояния (линейное затухание)
        volume = max(0.0, 1.0 - dist / max_distance)

        # Панорамирование: определяем, насколько источник смещён влево/вправо от направления взгляда
        # Переводим вектор в систему координат камеры
        # listener_angle – угол направления взгляда (0 = вправо, против часовой)
        # Поворачиваем вектор (dx, dy) на -listener_angle
        cos_a = math.cos(-listener_angle)
        sin_a = math.sin(-listener_angle)
        local_x = dx * cos_a - dy * sin_a
        local_y = dx * sin_a + dy * cos_a

        # local_x – вперёд/назад, local_y – влево/вправо (положительное вправо)
        # Нормализуем
        if dist > 0:
            normalized_y = local_y / dist
        else:
            normalized_y = 0.0

        # pan: -1 (полностью слева) .. 1 (полностью справа)
        pan = max(-1.0, min(1.0, normalized_y))

        # Громкости каналов
        # При pan = 0 – звук по центру, оба канала равны.
        # При pan = -1 (слева) – левый громче, правый тише.
        # Простая модель: left_vol = volume * (0.5 + 0.5*pan), right_vol = volume * (0.5 - 0.5*pan)
        # Но так как pan в [-1,1], то left_vol может быть 0..volume, right_vol тоже.
        left_vol = volume * (0.5 + 0.5 * pan)
        right_vol = volume * (0.5 - 0.5 * pan)

        # Эффект Доплера (приближённый): изменяем pitch через изменение частоты воспроизведения.
        # В Pygame нельзя напрямую менять pitch, поэтому можно использовать смещение громкости
        # или просто игнорировать, если doppler_factor=0.
        # В качестве заглушки: если doppler_factor > 0, немного увеличиваем громкость при приближении.
        if doppler_factor > 0 and dist > 0:
            # Считаем скорость приближения (просто по разнице расстояний можно позже)
            # Здесь простая имитация: если источник близко, делаем чуть громче
            pass

        # Запускаем звук
        self.channel = self.sound.play()
        if self.channel:
            # В новых версиях Pygame set_volume принимает два аргумента (left, right)
            try:
                self.channel.set_volume(left_vol, right_vol)
            except TypeError:
                # Для старых версий – общая громкость
                self.channel.set_volume(volume)
        return self.channel

    def stop(self):
        if self.channel:
            self.channel.stop()

    def set_volume(self, left, right=None):
        if self.channel:
            if right is not None:
                try:
                    self.channel.set_volume(left, right)
                except TypeError:
                    self.channel.set_volume((left + right) / 2)
            else:
                self.channel.set_volume(left)