# gradus_rc/sound/mixer.py
import pygame

class SoundManager:
    def __init__(self):
        self.sounds = {}
        self.channels = {}

    def load_all(self, sound_dict):
        for name, path in sound_dict.items():
            self.load_sound(name, path)

    def load_sound(self, key, path):
        try:
            self.sounds[key] = pygame.mixer.Sound(path)
        except Exception as e:
            print(f"Не удалось загрузить звук {key}: {e}")

    def play_sound(self, name, loops=0):
        if name in self.sounds:
            channel = self.sounds[name].play(loops)
            if channel:
                self.channels[name] = channel
            return channel
        return None

    def stop_sound(self, name):
        if name in self.channels:
            self.channels[name].stop()
            del self.channels[name]

    def stop_all(self):
        for channel in self.channels.values():
            channel.stop()
        self.channels.clear()