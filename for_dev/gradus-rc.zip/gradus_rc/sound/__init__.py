from .mixer import SoundManager


import pygame
import math
class Sound3D:
    """
    Объёмный звук с учётом позиции источника, ориентации камеры и препятствий (стен).
    Поддерживает динамическое обновление положения слушателя.
    """
    def __init__(self, sound, engine=None):
        self.sound = sound
        self.engine = engine          # ссылка на движок для raycast'а стен
        self.channel = None
        self.source_pos = (0, 0)      # мировые координаты источника
        self.max_distance = 500.0
        self.doppler_factor = 0.0
        self._last_dist = None        # для эффекта Доплера (если понадобится)

    def play(self, listener_pos, listener_angle, source_pos, max_distance=500.0, doppler_factor=0.0):
        self.source_pos = source_pos
        self.max_distance = max_distance
        self.doppler_factor = doppler_factor
        self.channel = self.sound.play(loops=0)
        if self.channel:
            self.update(listener_pos, listener_angle)
        return self.channel

    def update(self, listener_pos, listener_angle):
        if not self.channel:
            return

        dx = self.source_pos[0] - listener_pos[0]
        dy = self.source_pos[1] - listener_pos[1]
        dist = math.hypot(dx, dy)

        if dist > self.max_distance:
            self.channel.set_volume(0.0, 0.0)
            return

        # 1. Плавное затухание по расстоянию
        t = dist / self.max_distance
        k = 2.5
        volume = 1.0 / (1.0 + k * t * t)

        # 2. Определяем нормализованное боковое смещение
        cos_a = math.cos(listener_angle)
        sin_a = math.sin(listener_angle)
        local_y = -dx * sin_a + dy * cos_a  # положительное – справа
        if dist > 0:
            norm_y = local_y / dist
        else:
            norm_y = 0.0

        # Ограничиваем панораму, чтобы каналы никогда не занулялись полностью
        pan = max(-0.8, min(0.8, norm_y))  # диапазон [-0.8, 0.8]

        # 3. Приглушение стенами
        wall_factor = 1.0
        if self.engine:
            wall_factor = self.engine.get_sound_occlusion_factor(listener_pos, self.source_pos)
        volume *= wall_factor

        # 4. Линейная панорама с постоянной суммарной мощностью
        # При pan=0 -> оба канала 0.707*volume
        # При pan=±0.8 -> один канал ~0.95*volume, другой ~0.31*volume (оба слышны)
        left_vol = volume * math.sqrt(0.5 * (1.0 - pan))
        right_vol = volume * math.sqrt(0.5 * (1.0 + pan))

        # 5. Эффект Доплера (необязательно)
        if self.doppler_factor > 0 and self._last_dist is not None:
            speed = self._last_dist - dist
            if speed > 0:
                boost = 1.0 + min(0.2, speed * self.doppler_factor * 0.01)
                left_vol *= boost
                right_vol *= boost
        self._last_dist = dist

        # Применяем громкости
        try:
            self.channel.set_volume(left_vol, right_vol)
        except TypeError:
            self.channel.set_volume(volume)

        # 5. Эффект Доплера (упрощённый)
        if self.doppler_factor > 0 and self._last_dist is not None:
            speed = self._last_dist - dist
            if speed > 0:
                boost = 1.0 + min(0.2, speed * self.doppler_factor * 0.01)
                left_vol *= boost
                right_vol *= boost
        self._last_dist = dist

        # Применяем громкости
        try:
            self.channel.set_volume(left_vol, right_vol)
        except TypeError:
            self.channel.set_volume(volume)

    def stop(self):
        if self.channel:
            self.channel.stop()
            self.channel = None