class EntityType:
    """Константы типов объектов."""
    EMPTY = 0
    WALL = 1
    # можно добавить другие

class GameObjectRegistry:
    """Хранит соответствие между ID объекта и его свойствами."""
    def __init__(self):
        self.types = {
            0: {'name': 'empty', 'solid': False},
            1: {'name': 'wall', 'solid': True},
        }

    def register(self, id, props):
        self.types[id] = props

    def get(self, id):
        return self.types.get(id, None)