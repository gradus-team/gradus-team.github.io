"""Интерактивные и толкаемые объекты."""
import math


class InteractiveObject:
    def __init__(self, x, y, key, props, cell=None, sprite_key=None):
        self.x = float(x)
        self.y = float(y)
        self.vx = 0.0
        self.vy = 0.0
        self.key = key
        self.props = props or {}
        self.cell = cell
        self.alive = True
        self.sprite_key = sprite_key

        def _b(v, default=False):
            if isinstance(v, bool): return v
            if isinstance(v, str): return v.lower() in ('true', '1', 'yes', 'on')
            if v is None: return default
            return bool(v)

        def _f(v, d):
            try: return float(v)
            except (TypeError, ValueError): return d

        # --- Независимые свойства ---
        self.pushable = _b(self.props.get('pushable'), False)  # по умолчанию НЕТ
        self.on_press = self.props.get('on_press', None)       # None если нет

        # "Можно нажать" = есть on_press ИЛИ interactive:true
        self.interactive = _b(self.props.get('interactive'), False)
        self.can_press = bool(self.on_press) or self.interactive

        self.radius = _f(self.props.get('radius', 32.0), 32.0)
        self.mass = max(0.001, _f(self.props.get('mass', 20.0), 20.0))
        self.friction = _f(self.props.get('friction', 0.85), 0.85)
        self.bounciness = _f(self.props.get('bounciness', 0.2), 0.2)

    def apply_impulse(self, ix, iy):
        if not self.pushable:
            return
        self.vx += ix / self.mass
        self.vy += iy / self.mass

    def update(self, dt, engine):
        if not self.alive or not self.pushable:
            return

        # Трение
        self.vx *= self.friction
        self.vy *= self.friction
        if abs(self.vx) < 1.0: self.vx = 0.0
        if abs(self.vy) < 1.0: self.vy = 0.0
        if self.vx == 0.0 and self.vy == 0.0:
            return

        nx = self.x + self.vx * dt
        ny = self.y + self.vy * dt

        # Коллизия со стенами
        if engine._is_walkable(nx, self.y):
            self.x = nx
        else:
            self.vx = -self.vx * self.bounciness
        if engine._is_walkable(self.x, ny):
            self.y = ny
        else:
            self.vy = -self.vy * self.bounciness

        # Синхронизируем спрайт
        if self.sprite_key:
            sprite = engine.sprite_manager.get_by_key(self.sprite_key)
            if sprite is not None:
                sprite.x = self.x
                sprite.y = self.y


class InteractiveManager:
    def __init__(self, engine):
        self.engine = engine
        self.objects = {}

    def add(self, obj):
        self.objects[obj.key] = obj
        return obj

    def remove(self, key):
        self.objects.pop(key, None)

    def get(self, key):
        return self.objects.get(key)

    def clear(self):
        self.objects.clear()

    def query_near(self, x, y, max_dist=None, require_interactive=True):
        out = []
        for obj in self.objects.values():
            if not obj.alive:
                continue
            if require_interactive and not obj.interactive:
                continue
            r = max_dist if max_dist is not None else obj.radius
            d = math.hypot(obj.x - x, obj.y - y)
            if d <= r:
                out.append(obj)
        out.sort(key=lambda o: math.hypot(o.x - x, o.y - y))
        return out