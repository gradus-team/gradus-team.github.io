__version__ = "1.3.0"

from .engine import Engine
from .player import Player
from .utils.parser import MapParser
from .material.library import MaterialLibrary, Material
from .raycast.core import RayCaster, RayResult
from .light.tracer import LightTracer, LightSource
from .image.cache import SpriteManager as ImageManager, load_image
from .sound.mixer import SoundManager
from .object.registry import GameObjectRegistry
from .examples import GameExample, MenuExample
# Добавляем спрайты, если они есть
try:
    from .sprite.core import Sprite, SpriteManager as SpriteManager3D
except ImportError:
    pass