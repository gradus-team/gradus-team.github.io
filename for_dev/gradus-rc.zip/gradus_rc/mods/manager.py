"""
ModsManager — загрузка модов, регистрация сущностей, резолв ассетов.

Дизайн:
  * мод лежит в mods/<mod_id>/
  * содержит mod.py (обязательно) и mod.json (опционально)
  * все свои ассеты кладёт в mods/<mod_id>/assets/**
  * внутри mod.py получает объект `api` (инжектится движком)
  * api.load_image('tree.png') сам найдёт файл в assets/ рекурсивно
  * api.load_image('other_mod:tree.png') — взять из другого мода
  * api.load_image('textures/tree.png') — тоже работает (с подпапками)

Никакой возни с путями — мод пишет только имя файла.
"""
import os
import sys
import json
import importlib.util
from typing import Any, Dict, List, Optional

from .api import ModAPI


# ---------------------------------------------------------------------------
# Контекст «какой мод сейчас активен». Нужен, чтобы load_image в базовом
# движке мог понять: а не из мода ли его позвали?
# ---------------------------------------------------------------------------
_context_stack: List[Optional[str]] = []


def push_context(mod_id: str) -> None:
    _context_stack.append(mod_id)


def pop_context() -> None:
    if _context_stack:
        _context_stack.pop()


def current_mod_name() -> Optional[str]:
    return _context_stack[-1] if _context_stack else None


# ---------------------------------------------------------------------------
class ModError(Exception):
    pass


class ModInfo:
    __slots__ = ('id', 'path', 'meta', 'assets_dir', '_asset_index')

    def __init__(self, mod_id, path, meta):
        self.id = mod_id
        self.path = path
        self.meta = meta or {}
        self.assets_dir = os.path.join(path, 'assets')
        self._asset_index = None

    def index_assets(self):
        """Строит индекс basename -> полный путь рекурсивно."""
        self._asset_index = {}
        if not os.path.isdir(self.assets_dir):
            return
        for root, _, files in os.walk(self.assets_dir):
            for f in files:
                key = f.lower()
                # Первое вхождение выигрывает, но сохраняем список
                self._asset_index.setdefault(key, []).append(os.path.join(root, f))

    def find_asset(self, name):
        if self._asset_index is None:
            self.index_assets()
        base = os.path.basename(name).lower()
        lst = self._asset_index.get(base)
        if not lst:
            return None
        if len(lst) == 1:
            return lst[0]
        # Неоднозначность — предпочитаем точное совпадение по подпути
        norm_name = name.replace('\\', '/').lower()
        for full in lst:
            if full.replace('\\', '/').lower().endswith(norm_name):
                return full
        # Иначе первый + предупреждение
        print(f"[MODS] ВНИМАНИЕ: '{name}' найден несколько раз, беру первый: {lst[0]}")
        return lst[0]


# ---------------------------------------------------------------------------
class ModsManager:
    def __init__(self, mods_root: str = 'mods'):
        self.mods_root = mods_root
        self.mods: Dict[str, ModInfo] = {}
        self.loaded: Dict[str, Any] = {}
        self.order: List[str] = []
        self.engine = None

        # Реестры сущностей. Ключи:
        #   "mod_id:local_name" — точный
        #   "local_name"        — глобальный fallback (последний зарегистрированный побеждает)
        self.enemy_registry: Dict[str, type] = {}
        self.gun_registry: Dict[str, type] = {}
        self.material_registry: Dict[str, Any] = {}
        # Новые реестры
        self.bullet_registry = {}
        self.pickup_registry = {}
        self.map_generators = {}

        # Связь mod_id -> ModAPI (нужно для get_mod_api)
        self._api_by_mod = {}

        # Lifecycle
        self._reload_hooks = {}          # mod_id -> [callbacks]
        self._pending_reload = set()
        self._pending_unload = set()

    # ---------- Discovery ----------

    def discover(self):
        if not os.path.isdir(self.mods_root):
            return []
        found = []
        for name in sorted(os.listdir(self.mods_root)):
            mod_dir = os.path.join(self.mods_root, name)
            if not os.path.isdir(mod_dir):
                continue
            mod_py = os.path.join(mod_dir, 'mod.py')
            if not os.path.isfile(mod_py):
                continue
            meta = {}
            mod_json = os.path.join(mod_dir, 'mod.json')
            if os.path.isfile(mod_json):
                try:
                    with open(mod_json, 'r', encoding='utf-8') as f:
                        meta = json.load(f)
                except Exception as e:
                    print(f"[MODS] Ошибка чтения {mod_json}: {e}")
            found.append((name, mod_dir, meta))
        return found

    # ---------- Загрузка ----------

    def load_all(self, engine):
        self.engine = engine

        discovered = self.discover()
        if not discovered:
            print("[MODS] Модов не найдено")
            return

        by_id = {m[0]: m for m in discovered}
        deps = {m[0]: list(m[2].get('load_after', [])) for m in discovered}

        ordered = []
        visited = set()

        def visit(mid):
            if mid in visited:
                return
            visited.add(mid)
            for dep in deps.get(mid, []):
                if dep in by_id:
                    visit(dep)
            ordered.append(by_id[mid])

        for mid in by_id:
            visit(mid)

        for mod_id, mod_dir, meta in ordered:
            if not meta.get('enabled_by_default', True):
                print(f"[MODS] Пропущен {mod_id} (enabled_by_default=false)")
                continue
            self._load_one(mod_id, mod_dir, meta)

        print(f"[MODS] Итого загружено: {len(self.loaded)}")

    def _load_one(self, mod_id, mod_dir, meta):
        import builtins

        # Проверка версии движка
        try:
            from .. import __version__ as engine_version
        except Exception:
            engine_version = '0.0.0'

        emin = meta.get('engine_min')
        emax = meta.get('engine_max')
        if emin and self._cmp_ver(engine_version, emin) < 0:
            print(f"[MODS] {mod_id} требует движок >= {emin}, у нас {engine_version} — пропуск")
            return
        if emax and self._cmp_ver(engine_version, emax) > 0:
            print(f"[MODS] {mod_id} требует движок <= {emax}, у нас {engine_version} — пропуск")
            return

        info = ModInfo(mod_id, mod_dir, meta)
        info.index_assets()
        self.mods[mod_id] = info

        # api для мода
        api = ModAPI(manager=self, mod_id=mod_id, engine=self.engine)
        self._api_by_mod[mod_id] = api
        # --- Важно: подкладываем пути, чтобы мод мог импортировать
        #     как `import gradus_rc` (глобальный), так и свои модули:
        #     * mod_dir      -> import scripts.enemies
        #     * mod_dir/scripts -> import enemies
        mod_dir_abs = os.path.abspath(mod_dir)
        scripts_dir = os.path.join(mod_dir_abs, 'scripts')
        added_paths = []
        for p in (mod_dir_abs, scripts_dir):
            if os.path.isdir(p) and p not in sys.path:
                sys.path.insert(0, p)
                added_paths.append(p)

        # --- Загружаем mod.py
        mod_py = os.path.join(mod_dir, 'mod.py')
        module_name = f"gradus_mod_{mod_id}"
        spec = importlib.util.spec_from_file_location(module_name, mod_py)
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module

        # Инжектим метаданные
        module.__mod_id__ = mod_id
        module.__mod_path__ = mod_dir
        module.__dict__['api'] = api  # прямой доступ через `api` (для плоского случая)

        # ВАЖНО: чтобы `api` был виден и внутри импортируемых скриптов,
        # кладём его в builtins. Мод может перезаписать, но по умолчанию
        # будет доступен везде, включая scripts/enemies.py.
        _prev_builtin_api = getattr(builtins, '_gradus_api', None)
        builtins._gradus_api = api
        # экспортируем под именем `api` — так мод пишет просто `api.load_image(...)`
        _prev_builtin_public = getattr(builtins, 'api', None)
        builtins.api = api

        # --- exec содержимого mod.py
        try:
            push_context(mod_id)
            spec.loader.exec_module(module)
        except Exception as e:
            print(f"[MODS] Ошибка импорта '{mod_id}': {e}")
            import traceback
            traceback.print_exc()
            pop_context()
            self._cleanup_paths(added_paths)
            builtins._gradus_api = _prev_builtin_api
            builtins.api = _prev_builtin_public
            return
        pop_context()

        # --- on_load(engine) — уже с активным контекстом
        on_load = getattr(module, 'on_load', None)
        if callable(on_load):
            try:
                push_context(mod_id)
                on_load(self.engine)
            except Exception as e:
                print(f"[MODS] Ошибка on_load '{mod_id}': {e}")
                import traceback
                traceback.print_exc()
            finally:
                pop_context()

        # Не убираем пути и не сбрасываем builtins.api — оставляем их
        # для последующих модулей этого мода, которые могут грузиться лениво.
        # Для чистоты можно было бы убирать, но тогда `from scripts import X`
        # внутри on_load не сработает после выхода. Проще оставить.

        self.loaded[mod_id] = module
        self.order.append(mod_id)
        print(f"[MODS] Загружен: {mod_id} v{meta.get('version', '?')}")

    @staticmethod
    def _cleanup_paths(paths):
        for p in paths:
            if p in sys.path:
                sys.path.remove(p)

    # ---------- Resolve ассетов ----------

    def resolve(self, mod_id: str, rel_path: str) -> str:
        info = self.mods.get(mod_id)
        if info is None:
            raise ModError(f"Мод '{mod_id}' не загружен")

        # 1) Точное совпадение по подпути
        for base in (info.assets_dir, info.path):
            candidate = os.path.join(base, rel_path)
            if os.path.isfile(candidate):
                return candidate

        # 2) Рекурсивный поиск по basename
        found = info.find_asset(rel_path)
        if found:
            return found

        raise ModError(f"Ассет '{rel_path}' не найден в моде '{mod_id}'")

    def asset_exists(self, mod_id: str, rel_path: str) -> bool:
        try:
            self.resolve(mod_id, rel_path)
            return True
        except ModError:
            return False

    # ---------- Реестры сущностей ----------

    def register_enemy(self, mod_id, local_name, cls):
        self.enemy_registry[f"{mod_id}:{local_name}"] = cls
        self.enemy_registry[local_name] = cls

    def register_gun(self, mod_id, local_name, cls):
        self.gun_registry[f"{mod_id}:{local_name}"] = cls
        self.gun_registry[local_name] = cls

    def register_material(self, mod_id, local_name, material):
        self.material_registry[f"{mod_id}:{local_name}"] = material
        self.material_registry[local_name] = material

    def get_enemy_class(self, name):
        return self.enemy_registry.get(name)

    def get_gun_class(self, name):
        return self.gun_registry.get(name)

    def get_material(self, name):
        return self.material_registry.get(name)

    def get_api(self, mod_id):
        return self._api_by_mod.get(mod_id)

    def register_bullet(self, mod_id, local_name, cls):
        self.bullet_registry[f"{mod_id}:{local_name}"] = cls
        self.bullet_registry[local_name] = cls

    def register_pickup(self, mod_id, local_name, cls):
        self.pickup_registry[f"{mod_id}:{local_name}"] = cls
        self.pickup_registry[local_name] = cls

    def register_map_generator(self, mod_id, name, fn):
        self.map_generators[f"{mod_id}:{name}"] = fn
        self.map_generators[name] = fn

    def get_bullet_class(self, name):
        return self.bullet_registry.get(name)

    def get_pickup_class(self, name):
        return self.pickup_registry.get(name)

    def get_map_generator(self, name):
        return self.map_generators.get(name)

    def register_reload_hook(self, mod_id, fn):
        self._reload_hooks.setdefault(mod_id, []).append(fn)

    def request_reload(self, mod_id):
        self._pending_reload.add(mod_id)
        print(f"[MODS] reload запрошен: {mod_id}")

    def request_unload(self, mod_id):
        self._pending_unload.add(mod_id)
        print(f"[MODS] unload запрошен: {mod_id}")

    def process_lifecycle(self, engine):
        """
        Вызывается движком каждый кадр. Обрабатывает очереди reload/unload.
        """
        for mod_id in list(self._pending_unload):
            self._pending_unload.discard(mod_id)
            self._unload_one(mod_id, engine)
        for mod_id in list(self._pending_reload):
            self._pending_reload.discard(mod_id)
            self._unload_one(mod_id, engine, keep_meta=True)
            # Перезагружаем через load_all — он подхватит mod.py заново
            self._reload_one(mod_id, engine)

    def _unload_one(self, mod_id, engine, keep_meta=False):
        api = self._api_by_mod.get(mod_id)
        if api:
            # 1) on_unload callbacks
            for fn in list(api._cleanups):
                try:
                    fn()
                except Exception as e:
                    print(f"[MODS] unload cb '{mod_id}': {e}")
            # 2) release all tracked
            api.release_all()
            # 3) cancel timers
            api.cancel_all_timers()
            # 4) unbind HUD
            for h in list(api._hud_binds):
                try:
                    engine.api.unbind_hud(h)
                except Exception:
                    pass
            # 5) remove hooks
            hooks = getattr(engine, '_mod_hooks', {})
            for ev, cb in list(api._hooks_by_id):
                if ev in hooks:
                    hooks[ev] = [item for item in hooks[ev]
                                 if (item[1] if isinstance(item, tuple) else item)
                                 is not cb]
            # 6) debug panels
            panels = getattr(engine, '_debug_panels', [])
            for p in panels:
                if p.get('mod') == mod_id:
                    p['alive'] = False
            engine._debug_panels = [p for p in panels if p.get('alive')]

        # Снимаем модуль из реестров
        self.loaded.pop(mod_id, None)
        if mod_id in self.order:
            self.order.remove(mod_id)
        if not keep_meta:
            self.mods.pop(mod_id, None)
            self._api_by_mod.pop(mod_id, None)
        print(f"[MODS] Выгружен: {mod_id}")

    def _reload_one(self, mod_id, engine):
        info = self.mods.get(mod_id)
        if not info:
            print(f"[MODS] reload: метаданные '{mod_id}' потеряны")
            return
        # Чистим sys.modules и перезагружаем
        module_name = f"gradus_mod_{mod_id}"
        sys.modules.pop(module_name, None)
        # Удаляем старый ModAPI, но оставляем ModInfo для нового
        self._api_by_mod.pop(mod_id, None)
        self._load_one(mod_id, info.path, info.meta)
        # Вызываем reload-hooks
        api = self._api_by_mod.get(mod_id)
        if api:
            for fn in self._reload_hooks.get(mod_id, []):
                try:
                    fn(engine)
                except Exception as e:
                    print(f"[MODS] reload cb '{mod_id}': {e}")
        print(f"[MODS] Перезагружен: {mod_id}")

    # ---------- Хуки движка ----------

    def call_hook(self, event, *args, **kwargs):
        hooks = getattr(self.engine, '_mod_hooks', None)
        if not hooks:
            return
        lst = hooks.get(event, [])

        # Сортируем по приоритету (у простых callable приоритет 0)
        def _prio(item):
            return item[0] if isinstance(item, tuple) else 0

        for item in sorted(lst, key=_prio):
            cb = item[1] if isinstance(item, tuple) else item
            try:
                cb(*args, **kwargs)
            except Exception as e:
                print(f"[MODS] hook '{event}' error: {e}")

    # ---------- Утилиты ----------

    @staticmethod
    def _cmp_ver(a: str, b: str) -> int:
        pa = [int(x) for x in a.split('.') if x.isdigit()]
        pb = [int(x) for x in b.split('.') if x.isdigit()]
        for x, y in zip(pa, pb):
            if x != y:
                return -1 if x < y else 1
        return (len(pa) > len(pb)) - (len(pa) < len(pb))


# ---------------------------------------------------------------------------
# Глобальный singleton — им пользуется load_image/load_sound для резолва.
# ---------------------------------------------------------------------------
_manager: Optional[ModsManager] = None


def set_manager(mgr: ModsManager):
    global _manager
    _manager = mgr


def get_manager() -> Optional[ModsManager]:
    return _manager


def resolve_path(path: str) -> str:
    """
    Резолвит путь к ассету. Вызывается из load_image/load_sound/load_model.

    Порядок:
      1. Файл уже существует как есть (абсолютный или относительный) — не трогаем.
      2. Путь вида "other_mod:file.png" — резолвим через чужой namespace.
      3. Активен мод (или путь содержит "mod_id:...") — ищем в его assets/.
      4. Ничего не нашли — возвращаем как есть (пусть движок сам попробует).
    """
    if not path:
        return path

    if os.path.isabs(path) and os.path.isfile(path):
        return path
    if os.path.isfile(path):
        return path

    mgr = get_manager()

    # Явный namespace
    if ':' in path:
        ns, rel = path.split(':', 1)
        if mgr and ns in mgr.mods:
            try:
                return mgr.resolve(ns, rel)
            except ModError:
                pass

    # Активный мод
    mod_id = current_mod_name()
    if mgr and mod_id:
        try:
            return mgr.resolve(mod_id, path)
        except ModError:
            pass

    return path