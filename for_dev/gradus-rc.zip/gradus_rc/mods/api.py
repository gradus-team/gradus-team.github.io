"""
ModAPI — фасад для мода.

* Все ассеты автоматически резолвятся относительно папки мода:
  пиши только имя файла, движок сам найдёт.
* api.micro   — прямой доступ к MicroAPI движка
* api.physics — прямой доступ к PhysicsAPI движка
* Любой метод MicroAPI/PhysicsAPI доступен напрямую:
    api.fire_current_gun()
    api.set_fog(enabled=True, color=(30,30,40))
    api.spawn_enemy_by_tile(5, 2, enemy_type='dragon', hp=300)
    api.add_body(obj)
    api.apply_impulse(obj, 100, 0)
    api.raycast(x, y, dx, dy, max_dist)

Порядок разрешения имени:
    1) собственные атрибуты ModAPI (load_image, register_enemy, ...)
    2) MicroAPI
    3) PhysicsAPI
Если в обоих API есть одинаковое имя — выигрывает MicroAPI,
для явного выбора используй api.physics.<name> или api.micro.<name>.
"""
from typing import Any, Callable, Optional

import pygame

from .manager import ModsManager, ModError
import os, json

class ModAPI:
    def __init__(self, manager, mod_id: str, engine):
        self._mgr = manager
        self._mod_id = mod_id
        self._engine = engine
        # ----- Расширение 1.3.5 -----
        self._config      = None      # dict или None (ленивая загрузка)
        self._save_data   = None
        self._lang        = None      # dict code -> dict переводов
        self._lang_code   = 'ru'
        self._timers      = []        # handles для auto-cleanup
        self._tracked     = []        # [(obj, kind)] для release_all
        self._hud_binds   = []        # handles bind_hud
        self._hooks_by_id = []        # [(event, callback)]
        self._cleanups    = []        # callbacks на unload
        self.state        = {}        # in-memory state, живёт в сессии

    # ======================================================================
    # Прямой доступ к движковым API
    # ======================================================================

    @property
    def micro(self):
        """MicroAPI движка (без делегации, чистый объект)."""
        return self._engine.api

    @property
    def physics(self):
        """PhysicsAPI движка (без делегации, чистый объект)."""
        return self._engine.physics

    def __getattr__(self, name: str):
        """
        Прозрачная делегация на MicroAPI и PhysicsAPI.
        Вызывается только если атрибута нет в самом ModAPI
        (или в его базовых классах / __dict__).
        """
        # Защита: во время __init__ до присвоения _engine любой lookup
        # неизвестного атрибута не должен уходить в рекурсию.
        engine = self.__dict__.get('_engine')
        if engine is None:
            raise AttributeError(name)

        # Служебные/dunder — не трогаем
        if name.startswith('__') and name.endswith('__'):
            raise AttributeError(name)

        micro = getattr(engine, 'api', None)
        if micro is not None and hasattr(micro, name):
            return getattr(micro, name)

        physics = getattr(engine, 'physics', None)
        if physics is not None and hasattr(physics, name):
            return getattr(physics, name)

        raise AttributeError(
            f"ModAPI: нет атрибута '{name}' "
            f"(нет и в MicroAPI/PhysicsAPI движка)"
        )

    # ======================================================================
    # Удобные свойства-ярлыки
    # ======================================================================

    @property
    def id(self) -> str:
        return self._mod_id

    @property
    def engine(self):
        return self._engine

    @property
    def player(self):
        """Player движка — часто нужно модам."""
        return self._engine.player

    @property
    def enemies(self):
        """Живой список врагов (можно читать/менять)."""
        return self._engine.enemies

    @property
    def bullets(self):
        return self._engine.bullets

    @property
    def map_data(self):
        return self._engine.map_data

    @property
    def tile_size(self):
        return self._engine.tile_size

    @property
    def assets_dir(self) -> str:
        return self._mgr.mods[self._mod_id].assets_dir

    # ===================== МЕТАДАННЫЕ =====================

    @property
    def meta(self):
        """Сырой mod.json (dict) или {} если файла не было."""
        info = self._mgr.mods.get(self._mod_id)
        return info.meta if info else {}

    @property
    def version(self):
        return self.meta.get('version', '0.0.0')

    @property
    def authors(self):
        return self.meta.get('authors', [])

    @property
    def description(self):
        return self.meta.get('description', '')

    @property
    def mod_path(self):
        info = self._mgr.mods.get(self._mod_id)
        return info.path if info else None

    def engine_version(self):
        try:
            from .. import __version__ as v
            return v
        except Exception:
            return '0.0.0'

    def check_engine(self, min_ver=None, max_ver=None):
        """
        Проверка совместимости с версией движка.
        Возвращает (ok: bool, reason: str|None).
        """
        ev = self.engine_version()
        if min_ver and ModsManager._cmp_ver(ev, min_ver) < 0:
            return False, f"нужен движок >= {min_ver}, текущий {ev}"
        if max_ver and ModsManager._cmp_ver(ev, max_ver) > 0:
            return False, f"нужен движок <= {max_ver}, текущий {ev}"
        return True, None

    # ===================== МЕЖМОДОВОЕ =====================

    def has_mod(self, mod_id):
        return mod_id in self._mgr.loaded

    def list_mods(self):
        """Список id всех загруженных модов (включая себя)."""
        return list(self._mgr.order)

    def get_mod_version(self, mod_id):
        info = self._mgr.mods.get(mod_id)
        return info.meta.get('version') if info else None

    def get_mod_api(self, mod_id):
        """API другого мода (ModAPI) или None."""
        return self._mgr.get_api(mod_id)

    def require_mod(self, mod_id, min_ver=None, max_ver=None):
        """
        Проверяет наличие мода и его версию.
        Возвращает его ModAPI. Бросает ModError если не выполнено.
        """
        if mod_id not in self._mgr.loaded:
            raise ModError(f"Мод '{self._mod_id}' требует '{mod_id}', "
                           f"но он не загружен")
        ver = self.get_mod_version(mod_id) or '0.0.0'
        if min_ver and ModsManager._cmp_ver(ver, min_ver) < 0:
            raise ModError(f"Мод '{self._mod_id}' требует '{mod_id}' >= "
                           f"{min_ver}, у нас {ver}")
        if max_ver and ModsManager._cmp_ver(ver, max_ver) > 0:
            raise ModError(f"Мод '{self._mod_id}' требует '{mod_id}' <= "
                           f"{max_ver}, у нас {ver}")
        return self.get_mod_api(mod_id)

    def require_mods(self, *specs):
        """
        Пакетная проверка: require_mods('a>=1.0', 'b', 'c<=2.0')
        Возвращает dict mod_id -> ModAPI.
        """
        out = {}
        for spec in specs:
            mod_id, _, ver_constraint = spec.partition('=')
            min_v, max_v = None, None
            if ver_constraint:
                if spec[len(mod_id) + 1] == '=':
                    min_v = ver_constraint.lstrip('=') or None
                elif spec[len(mod_id) + 1] == '<':
                    max_v = ver_constraint.lstrip('<') or None
            out[mod_id] = self.require_mod(mod_id, min_v, max_v)
        return out

    # ===================== РАСШИРЕННАЯ РЕГИСТРАЦИЯ =====================

    def register_bullet_type(self, local_name, cls):
        """
        Класс пули. Для spawn_bullet(kind='fireball') → создаст cls(...).
        Класс должен принимать (x, y, angle, **kwargs) и иметь .update(dt).
        """
        self._mgr.register_bullet(self._mod_id, local_name, cls)

    def register_pickup_type(self, local_name, cls):
        """
        Класс подбираемого предмета. Спавнится через api.spawn_pickup(kind=name).
        Класс должен иметь (x, y), .radius, .on_pickup(player) и .draw(ctx).
        """
        self._mgr.register_pickup(self._mod_id, local_name, cls)

    def register_hud_layer(self, draw_fn, priority=100, key=None):
        """
        Постоянный HUD-слой. draw_fn(screen, engine) — вызывается каждый кадр.
        Автоматически снимается при unload мода.
        priority: меньше = рисуется первым.
        """
        handle = self._engine.api.bind_hud(draw_fn, layer=priority)
        handle['key'] = key or f"{self._mod_id}_hud"
        self._hud_binds.append(handle)
        return handle

    def register_debug_panel(self, title, draw_fn, key=None):
        """
        Панель для F1-оверлея разработчика.
        draw_fn(screen, engine, x, y) → возвращает высоту, на которой остановился.
        Панели рисуются стопкой справа сверху.
        """
        if not hasattr(self._engine, '_debug_panels'):
            self._engine._debug_panels = []
        entry = {'title': title, 'fn': draw_fn,
                 'mod': self._mod_id, 'key': key,
                 'alive': True}
        self._engine._debug_panels.append(entry)
        return entry

    def register_map_generator(self, name, generator_fn):
        """
        Процедурный генератор карт. generator_fn(width, height, seed, params) -> str (текст карты)
        Вызывается движком, когда игра стартует с use_procedural=True.
        """
        self._mgr.register_map_generator(self._mod_id, name, generator_fn)

    def unregister(self, handle_or_key):
        """Снять любую регистрацию (по handle или ключу)."""
        if handle_or_key is None:
            return False
        if isinstance(handle_or_key, dict) and 'alive' in handle_or_key:
            handle_or_key['alive'] = False
            return True
        # по ключу — ищем в HUD-биндингах и debug-панелях
        for h in self._hud_binds:
            if h.get('key') == handle_or_key:
                self._engine.api.unbind_hud(h)
                return True
        panels = getattr(self._engine, '_debug_panels', [])
        for p in panels:
            if p.get('key') == handle_or_key:
                p['alive'] = False
                return True
        return False

    # ===================== CONFIG =====================

    def _config_path(self):
        info = self._mgr.mods.get(self._mod_id)
        if not info:
            return None
        return os.path.join(info.path, 'config.json')

    def _ensure_config(self):
        if self._config is not None:
            return
        self._config = {}
        p = self._config_path()
        if p and os.path.isfile(p):
            try:
                with open(p, 'r', encoding='utf-8') as f:
                    self._config = json.load(f) or {}
            except Exception as e:
                self.warn(f"config.json не читается: {e}")

    @property
    def config(self):
        """Все настройки мода (dict). Мутация допустима."""
        self._ensure_config()
        return self._config

    def get_config(self, key, default=None):
        self._ensure_config()
        return self._config.get(key, default)

    def set_config(self, key, value):
        """Устанавливает значение и возвращает СТАРОЕ."""
        self._ensure_config()
        old = self._config.get(key)
        self._config[key] = value
        return old

    def save_config(self):
        p = self._config_path()
        if not p:
            return False
        try:
            self._ensure_config()
            with open(p, 'w', encoding='utf-8') as f:
                json.dump(self._config, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            self.error(f"config save: {e}")
            return False

    def load_config(self):
        self._config = None
        self._ensure_config()
        return self._config

    # ===================== STORAGE =====================

    def _save_path(self):
        info = self._mgr.mods.get(self._mod_id)
        if not info:
            return None
        return os.path.join(info.path, 'save.json')

    def _ensure_save(self):
        if self._save_data is not None:
            return
        self._save_data = {}
        p = self._save_path()
        if p and os.path.isfile(p):
            try:
                with open(p, 'r', encoding='utf-8') as f:
                    self._save_data = json.load(f) or {}
            except Exception as e:
                self.warn(f"save.json не читается: {e}")

    @property
    def save(self):
        self._ensure_save()
        return self._save_data

    def get_save(self, key, default=None):
        self._ensure_save()
        return self._save_data.get(key, default)

    def set_save(self, key, value):
        self._ensure_save()
        old = self._save_data.get(key)
        self._save_data[key] = value
        return old

    def save_data(self):
        p = self._save_path()
        if not p:
            return False
        try:
            self._ensure_save()
            with open(p, 'w', encoding='utf-8') as f:
                json.dump(self._save_data, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            self.error(f"save_data: {e}")
            return False

    def load_data(self):
        self._save_data = None
        self._ensure_save()
        return self._save_data

    def clear_save(self):
        self._save_data = {}
        p = self._save_path()
        if p and os.path.isfile(p):
            try:
                os.remove(p)
            except OSError:
                pass

    # ===================== I18N =====================

    def load_lang(self, code=None):
        """
        Загружает перевод. code=None → берёт из engine (глобальный язык).
        Файл: <mod>/lang/<code>.json
        """
        if code is None:
            code = getattr(self._engine, 'lang', 'ru')
        self._lang_code = code
        if self._lang is None:
            self._lang = {}
        path = f"lang/{code}.json"
        try:
            data = self.load_json(path)
            if isinstance(data, dict):
                self._lang[code] = data
                return True
        except Exception:
            # фолбэк: ru, затем en
            for fb in ('ru', 'en'):
                try:
                    data = self.load_json(f"lang/{fb}.json")
                    if isinstance(data, dict):
                        self._lang[code] = data
                        return True
                except Exception:
                    continue
        self._lang[code] = {}
        return False

    def set_lang(self, code):
        """Переключить язык мода (грузит файл, если нужно)."""
        old = self._lang_code
        if code not in (self._lang or {}):
            self.load_lang(code)
        else:
            self._lang_code = code
        return old

    def t(self, key, **kwargs):
        """
        Перевод. Если нет — возвращает сам ключ.
          api.t('greeting', name='Игрок')
        """
        if self._lang is None:
            self.load_lang()
        d = (self._lang or {}).get(self._lang_code, {})
        s = d.get(key, key)
        if kwargs:
            try:
                s = s.format(**kwargs)
            except (KeyError, IndexError):
                pass
        return s

    # ===================== ASSET-ХЕЛПЕРЫ =====================

    def asset_exists(self, name):
        return self._mgr.asset_exists(self._mod_id, name)

    def list_assets(self, pattern="*", subdir=""):
        """
        Список файлов в assets/ мода. pattern — glob ('*.png', 'enemies/*').
        Возвращает относительные пути от assets/.
        """
        info = self._mgr.mods.get(self._mod_id)
        if not info:
            return []
        import fnmatch
        base = info.assets_dir
        if not os.path.isdir(base):
            return []
        out = []
        for root, _, files in os.walk(base):
            for f in files:
                full = os.path.join(root, f)
                rel = os.path.relpath(full, base).replace('\\', '/')
                if subdir and not rel.startswith(subdir):
                    continue
                if fnmatch.fnmatch(rel, pattern):
                    out.append(rel)
        return sorted(out)

    def resolve(self, name):
        """Публичный путь к ассету. Не загружает, просто возвращает путь."""
        return self._resolve(name)

    def override_engine_asset(self, key, path, size=None):
        """
        Заменяет ассет движка по ключу кэша (например, 'shotgun').
        После вызова load_image('shotgun', ...) в движке вернёт твою картинку.
        """
        from ..image.cache import SpriteManager
        from ..image.cache import load_image as _load_image
        full = self._resolve(path)
        try:
            img = pygame.image.load(full).convert_alpha()
            if size:
                img = pygame.transform.scale(img, size)
        except Exception as e:
            self.error(f"override '{key}': {e}")
            return False
        # Кладём напрямую в кэш SpriteManager — там он и останется
        mgr = getattr(self._engine, '_image_cache', None)
        # движок использует модульный load_image с глобальным SpriteManager();
        # достаточно положить в общий кэш движка:
        if not hasattr(self._engine, '_texture_cache'):
            self._engine._texture_cache = {}
        self._engine._texture_cache[key] = img
        self._tracked.append((('texture_override', key), 'engine_asset'))
        return True

    # ===================== LIFECYCLE =====================

    def on_reload(self, fn):
        """Callback, вызываемый при перезагрузке мода."""
        self._mgr.register_reload_hook(self._mod_id, fn)

    def on_unload(self, fn):
        """Callback, вызываемый при выгрузке мода (cleanup)."""
        self._cleanups.append(fn)

    def reload_self(self):
        """Запросить перезагрузку мода на следующем кадре."""
        self._mgr.request_reload(self._mod_id)

    def unload_self(self):
        """Запросить выгрузку мода на следующем кадре."""
        self._mgr.request_unload(self._mod_id)

    def is_loaded(self):
        return self._mod_id in self._mgr.loaded

    # ===================== ХУКИ С ПРИОРИТЕТОМ =====================

    def add_hook(self, event, callback, priority=0, safe=False):
        """
        priority: меньше — раньше. Совместимо со старой сигнатурой.
        safe=True — обернуть в try/except с принтом мода.
        """
        if safe:
            original = callback
            def _safe(*a, _orig=original, _mid=self._mod_id, **kw):
                try:
                    return _orig(*a, **kw)
                except Exception as e:
                    print(f"[MOD:{_mid}][hook:{event}] {e}")
            callback = _safe

        hooks = getattr(self._engine, '_mod_hooks', None)
        if hooks is None:
            hooks = {}
            self._engine._mod_hooks = hooks
        # Поддерживаем сортировку по приоритету
        if event not in hooks:
            hooks[event] = []
        # Храним как (priority, callback), но для совместимости со старым
        # call_hook — оборачиваем в list из двух полей, распознав по tuple
        hooks[event].append((int(priority), callback))
        hooks[event].sort(key=lambda h: h[0] if isinstance(h, tuple) else 0)
        self._hooks_by_id.append((event, callback))
        return callback

    def remove_hook(self, event, callback):
        hooks = getattr(self._engine, '_mod_hooks', None)
        if not hooks or event not in hooks:
            return False
        lst = hooks[event]
        for i, item in enumerate(lst):
            cb = item[1] if isinstance(item, tuple) else item
            if cb is callback:
                lst.pop(i)
                self._hooks_by_id = [(e, c) for (e, c)
                                       in self._hooks_by_id if c is not callback]
                return True
        return False

    # ===================== TIMERS (mod-scoped) =====================

    def after(self, delay, callback):
        """Отложенный вызов с автоматической отменой при unload."""
        h = self._engine.api.schedule(delay, callback)
        self._timers.append(h)
        return h

    def every(self, interval, callback):
        """Повторяющийся вызов с автоматической отменой при unload."""
        h = self._engine.api.every(interval, callback)
        self._timers.append(h)
        return h

    def cancel_timer(self, handle):
        if handle:
            handle['alive'] = False
        try:
            self._timers.remove(handle)
        except ValueError:
            pass

    def cancel_all_timers(self):
        for h in self._timers:
            h['alive'] = False
        self._timers.clear()

    # ===================== RESOURCE TRACKING =====================

    def track(self, obj, kind='generic'):
        """
        Зарегистрировать созданный ресурс для авто-очистки.
        kind:
          'sprite'   — Sprite/ModelSprite, будет удалён из sprite_manager
          'enemy'    — будет убран из enemies
          'body'     — будет убран из physics.bodies
          'trigger'  — будет удалён из trigger_zones
          'timer'    — будет снят (см. cancel_timer)
          'hud'      — будет unbind
          'light'    — будет удалён из light_sources
          'generic'  — просто хранится для явного release_all
        """
        self._tracked.append((obj, kind))
        return obj

    def untrack(self, obj):
        self._tracked = [(o, k) for (o, k) in self._tracked if o is not obj]

    def release_all(self):
        """Освободить все отслеженные ресурсы. Вызывается при unload, но можно вручную."""
        e = self._engine
        for obj, kind in self._tracked:
            try:
                if kind == 'sprite':
                    e.sprite_manager.remove_by_key(getattr(obj, 'key', None))
                elif kind == 'enemy':
                    if obj in e.enemies:
                        e.enemies.remove(obj)
                elif kind == 'body':
                    if obj in e.physics.bodies:
                        e.physics.bodies.remove(obj)
                elif kind == 'trigger':
                    obj['alive'] = False
                elif kind == 'timer':
                    obj['alive'] = False
                elif kind == 'hud':
                    e.api.unbind_hud(obj)
                elif kind == 'light':
                    if obj in e.light_tracer.light_sources:
                        e.light_tracer.light_sources.remove(obj)
                elif kind == 'engine_asset':
                    key = obj[1]
                    e._texture_cache.pop(key, None)
            except Exception as ex:
                self.warn(f"release_all[{kind}]: {ex}")
        self._tracked.clear()

    # ===================== DEBUG =====================

    def assert_(self, cond, msg="assert failed"):
        """assert с префиксом мода. Бросает ModError."""
        if not cond:
            raise ModError(f"[{self._mod_id}] {msg}")

    def print_state(self, title=None):
        """Отладочный дамп состояния мода."""
        print(f"===== MOD {self._mod_id} state =====")
        if title:
            print(f"  {title}")
        print(f"  version:  {self.version}")
        print(f"  engine:   {self.engine_version()}")
        print(f"  timers:   {len(self._timers)} активных")
        print(f"  tracked:  {len(self._tracked)} ресурсов")
        print(f"  hooks:    {len(self._hooks_by_id)}")
        print(f"  config:   {len(self._config or {})} полей")
        print(f"  save:     {len(self._save_data or {})} полей")
        print(f"  state:    {len(self.state)} in-memory полей")
        print(f"========================================")

    def timeit(self, fn, *args, **kwargs):
        """Замер времени вызова (сек). Удобно для профилирования."""
        import time
        t0 = time.perf_counter()
        result = fn(*args, **kwargs)
        dt = time.perf_counter() - t0
        print(f"[MOD:{self._mod_id}] {fn.__name__} → {dt*1000:.3f} ms")
        return result




    # ======================================================================
    # Загрузка ассетов
    # ======================================================================

    def load_image(self, name: str, size=None, default_color=(255, 0, 255)):
        """Загрузить изображение из assets/ мода.
        Пример: api.load_image('tree.png') или api.load_image('textures/tree.png')."""
        from ..image.cache import load_image as _load_image
        path = self._resolve(name)
        key = f"{self._mod_id}:{name}"
        return _load_image(key, path, size=size, default_color=default_color)

    def load_sound(self, name: str):
        """Загрузить звук (WAV/OGG). Возвращает pygame.mixer.Sound."""
        import pygame
        path = self._resolve(name)
        return pygame.mixer.Sound(path)

    def load_model(self, name: str, **kwargs):
        """Загрузить .obj/.gbj модель. Возвращает список спрайтов."""
        from ..polygon.obj_to_sprites import obj_to_sprites
        path = self._resolve(name)
        return obj_to_sprites(path, **kwargs)

    def load_text(self, name: str, encoding: str = 'utf-8') -> str:
        """Прочитать текстовый файл (карта, конфиг)."""
        path = self._resolve(name)
        with open(path, 'r', encoding=encoding) as f:
            return f.read()

    def load_json(self, name: str):
        import json
        return json.loads(self.load_text(name))

    def asset_path(self, name: str) -> str:
        """Полный путь к ассету (если движок требует именно путь)."""
        return self._resolve(name)

    def _resolve(self, name: str) -> str:
        # Свой префикс отрезаем, чужой резолвим через manager
        if ':' in name:
            ns, rel = name.split(':', 1)
            if ns == self._mod_id:
                name = rel
            elif ns in self._mgr.mods:
                return self._mgr.resolve(ns, rel)
        return self._mgr.resolve(self._mod_id, name)

    # ======================================================================
    # Регистрация сущностей
    # ======================================================================

    def register_enemy(self, local_name: str, cls):
        """Регистрирует класс врага. В карте: <enemy:type:dragon>."""
        self._mgr.register_enemy(self._mod_id, local_name, cls)

    def register_gun(self, local_name: str, cls):
        """Регистрирует класс оружия (для будущих расширений)."""
        self._mgr.register_gun(self._mod_id, local_name, cls)

    def register_material(self, local_name: str, material):
        """Регистрирует материал. В карте: <material:ice>."""
        self._mgr.register_material(self._mod_id, local_name, material)

    # ---- Удобные запросы к реестру ----

    def get_enemy_class(self, name: str):
        """Возвращает класс врага (свой или из другого мода)."""
        return self._mgr.get_enemy_class(name)

    def get_material(self, name: str):
        return self._mgr.get_material(name)

    # ======================================================================
    # Хуки движка
    # ======================================================================

    def add_hook(self, event: str, callback: Callable):
        """
        События движка:
          'update'        -> callback(dt, keys)
          'render'        -> callback(screen)
          'level_loaded'  -> callback(level_index)
          'shutdown'      -> callback()
        """
        hooks = getattr(self._engine, '_mod_hooks', None)
        if hooks is None:
            hooks = {}
            self._engine._mod_hooks = hooks
        hooks.setdefault(event, []).append(callback)

    def remove_hook(self, event: str, callback: Callable):
        """Убрать ранее зарегистрированный хук."""
        hooks = getattr(self._engine, '_mod_hooks', None)
        if not hooks:
            return False
        lst = hooks.get(event) or []
        try:
            lst.remove(callback)
            return True
        except ValueError:
            return False

    # ======================================================================
    # Спавн-помощники с автоматическим резолвом текстур
    # ======================================================================

    def spawn_enemy_here(self, tile_x: int = None, tile_y: int = None,
                         world_x: float = None, world_y: float = None,
                         sprite: str = None, **kwargs):
        """
        Спавн врага с автоматическим резолвом спрайта из мода.
        Указывай либо (tile_x, tile_y), либо (world_x, world_y).
        sprite: 'demon.png' — путь внутри assets/ мода.
        """
        if sprite:
            tex = self.load_image(sprite, size=(64, 64))
            kwargs['texture'] = tex

        if world_x is not None and world_y is not None:
            return self._engine.api.spawn_enemy(x=world_x, y=world_y, **kwargs)
        if tile_x is not None and tile_y is not None:
            return self._engine.api.spawn_enemy_by_tile(
                tile_x=tile_x, tile_y=tile_y, **kwargs)
        raise ValueError("spawn_enemy_here: нужны либо (tile_x, tile_y), "
                         "либо (world_x, world_y)")

    # ======================================================================
    # Логирование
    # ======================================================================

    def log(self, *args):
        print(f"[MOD:{self._mod_id}]", *args)

    def warn(self, *args):
        print(f"[MOD:{self._mod_id}][WARN]", *args)

    def error(self, *args):
        print(f"[MOD:{self._mod_id}][ERROR]", *args)