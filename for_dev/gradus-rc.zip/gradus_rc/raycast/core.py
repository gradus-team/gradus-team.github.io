import math
from ..config import DEFAULT_MAX_DEPTH
from ..material.library import MaterialLibrary

class RayResult:
    __slots__ = ('ray_index', 'depth', 'hit_objects', 'wall_x')
    def __init__(self, ray_index, depth, hit_objects=None, wall_x=0):
        self.ray_index = ray_index
        self.depth = depth
        self.hit_objects = hit_objects if hit_objects else []
        self.wall_x = wall_x

class RayCaster:
    def __init__(self, map_data, tile_size, fov, rays, max_depth=DEFAULT_MAX_DEPTH, proj_coeff=20000, material_lib=None):
        self.map_data = map_data
        self.tile_size = tile_size
        self.fov = fov
        self.half_fov = fov / 2
        self.rays = rays
        self.max_depth = max_depth
        self.proj_coeff = proj_coeff
        self.material_lib = material_lib if material_lib else MaterialLibrary()
        self.update_dimensions()
        self._precompute_angles()

    def _precompute_angles(self):
        """Предрассчитываем относительные углы, синусы и косинусы для всех лучей."""
        self._ray_angles = []
        self._cos_values = []
        self._sin_values = []
        for i in range(self.rays):
            ray_angle = -self.half_fov + (i / self.rays) * self.fov
            self._ray_angles.append(ray_angle)
            self._cos_values.append(math.cos(ray_angle))
            self._sin_values.append(math.sin(ray_angle))

    def update_dimensions(self):
        if self.map_data and len(self.map_data) > 0:
            self.map_height = len(self.map_data)
            self.map_width = len(self.map_data[0]) if self.map_height > 0 else 0
        else:
            self.map_height = 0
            self.map_width = 0

    def cast_rays(self, player_pos, player_angle):
        if self.map_data is None or self.map_height == 0 or self.map_width == 0:
            return []
        if not hasattr(self, '_cos_values'):
            self._precompute_angles()
        tile = self.tile_size
        max_depth = self.max_depth
        max_depth_tiles = max_depth / tile  # максимальная дальность в тайлах
        map_width = self.map_width
        map_height = self.map_height
        rays = self.rays
        cos_vals = self._cos_values
        sin_vals = self._sin_values
        player_x = player_pos.x
        player_y = player_pos.y
        player_dir_cos = math.cos(player_angle)
        player_dir_sin = math.sin(player_angle)

        results = [None] * rays

        for i in range(rays):
            # Мировое направление луча
            cos_a = player_dir_cos * cos_vals[i] - player_dir_sin * sin_vals[i]
            sin_a = player_dir_sin * cos_vals[i] + player_dir_cos * sin_vals[i]

            pos_x = player_x / tile
            pos_y = player_y / tile
            map_x = int(pos_x)
            map_y = int(pos_y)

            step_x = 1 if cos_a > 0 else -1
            step_y = 1 if sin_a > 0 else -1

            delta_dist_x = abs(1 / cos_a) if cos_a != 0 else float('inf')
            delta_dist_y = abs(1 / sin_a) if sin_a != 0 else float('inf')

            if cos_a > 0:
                dist_x = (map_x + 1 - pos_x) * delta_dist_x
            elif cos_a < 0:
                dist_x = (pos_x - map_x) * delta_dist_x
            else:
                dist_x = float('inf')

            if sin_a > 0:
                dist_y = (map_y + 1 - pos_y) * delta_dist_y
            elif sin_a < 0:
                dist_y = (pos_y - map_y) * delta_dist_y
            else:
                dist_y = float('inf')

            side = 0
            hit_objects = []

            while dist_x < max_depth_tiles or dist_y < max_depth_tiles:
                if dist_x < dist_y:
                    dist_x += delta_dist_x
                    map_x += step_x
                    side = 0
                else:
                    dist_y += delta_dist_y
                    map_y += step_y
                    side = 1

                if map_x < 0 or map_y < 0 or map_x >= map_width or map_y >= map_height:
                    break

                cell = self.map_data[map_y][map_x]
                base_id = cell['base_id']

                # Проверка видимости (как в старом коде)
                is_visible = cell.get('properties', {}).get('isvisible', True)
                if not is_visible:
                    continue  # стена невидима, идём дальше

                # Пропускаем триггеры
                if base_id == 8:
                    continue

                # Ключи (ID=7, type=key) — пропускаем
                if base_id == 7 and cell.get('properties', {}).get('type') == 'key':
                    continue

                # Двери (ID=7, type=door)
                if base_id == 7 and cell.get('properties', {}).get('type') == 'door':
                    if cell.get('properties', {}).get('open', False):
                        continue  # открытая дверь — пропускаем

                # Порталы (ID=9) — пропускаем, если невидимы (как в старом)
                if base_id == 9 and not cell.get('properties', {}).get('isvisible', False):
                    continue

                # Модели (ID=6) — пропускаем как невидимые для лучей
                if base_id == 6:
                    continue

                # Обработка стены
                if base_id != 0:
                    if side == 0:
                        perp_dist = dist_x - delta_dist_x
                    else:
                        perp_dist = dist_y - delta_dist_y

                    # Переводим расстояние в пиксели
                    perp_dist_pixels = perp_dist * tile
                    corrected_depth = perp_dist_pixels * cos_vals[i]  # cos_vals[i] = cos(относительный угол)
                    if corrected_depth < 0.1:
                        corrected_depth = 0.1

                    # wall_x
                    if side == 0:
                        wall_x = pos_y + perp_dist * sin_a
                    else:
                        wall_x = pos_x + perp_dist * cos_a
                    wall_x -= math.floor(wall_x)

                    alpha = self._get_alpha(cell)
                    height = cell.get('properties', {}).get('height', 1.0)

                    hit_objects.append((corrected_depth, cell, wall_x))

                    if alpha >= 1.0 and height >= 1.0:
                        break

            if not hit_objects:
                hit_objects.append((max_depth, None, 0))

            hit_objects.sort(key=lambda item: item[0])
            closest = hit_objects[0]

            results[i] = RayResult(
                ray_index=i,
                depth=closest[0],
                hit_objects=hit_objects,
                wall_x=closest[2]
            )

        return results

    def _get_alpha(self, cell):
        material_name = cell.get('properties', {}).get('sprite', None)
        if material_name is None:
            mat = self.material_lib.get_material(str(cell['base_id']))
        else:
            mat = self.material_lib.get_material(material_name)
        if mat is None:
            mat = self.material_lib.get_default()
        return mat.alpha if hasattr(mat, 'alpha') else 1.0