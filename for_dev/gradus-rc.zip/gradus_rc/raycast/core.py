import math
from ..config import DEFAULT_MAX_DEPTH
from ..material.library import MaterialLibrary

class RayResult:
    __slots__ = ('ray_index', 'depth', 'hit_objects', 'wall_x')
    def __init__(self, ray_index, depth, hit_objects=None, wall_x=0):
        self.ray_index = ray_index
        self.depth = depth
        self.hit_objects = hit_objects if hit_objects else []
        self.wall_x = wall_x

class RayCaster:
    def __init__(self, map_data, tile_size, fov, rays, max_depth=DEFAULT_MAX_DEPTH, proj_coeff=20000, material_lib=None):
        self.map_data = map_data
        self.tile_size = tile_size
        self.fov = fov
        self.half_fov = fov / 2
        self.rays = rays
        self.max_depth = max_depth
        self.proj_coeff = proj_coeff
        self.material_lib = material_lib if material_lib else MaterialLibrary()
        self.update_dimensions()

    def update_dimensions(self):
        if self.map_data and len(self.map_data) > 0:
            self.map_height = len(self.map_data)
            self.map_width = len(self.map_data[0]) if self.map_height > 0 else 0
        else:
            self.map_height = 0
            self.map_width = 0

    def cast_rays(self, player_pos, player_angle):
        if self.map_data is None or self.map_height == 0 or self.map_width == 0:
            return []
        results = []
        for i in range(self.rays):
            ray_angle = player_angle - self.half_fov + (i / self.rays) * self.fov
            cos_a = math.cos(ray_angle)
            sin_a = math.sin(ray_angle)

            depth = 0
            hit_objects = []
            wall_x = 0

            while depth < self.max_depth:
                x = player_pos.x + depth * cos_a
                y = player_pos.y + depth * sin_a
                map_x = int(x // self.tile_size)
                map_y = int(y // self.tile_size)

                if map_x < 0 or map_y < 0 or map_x >= self.map_width or map_y >= self.map_height:
                    break

                cell = self.map_data[map_y][map_x]
                base_id = cell['base_id']

                # --- Триггеры (ID=8) – пропускаем ---
                if base_id == 8:
                    depth += 1
                    continue

                # --- Ключи (ID=7, type=key) – пропускаем всегда ---
                if base_id == 7 and cell.get('properties', {}).get('type') == 'key':
                    depth += 1
                    continue

                # --- Двери (ID=7, type=door) ---
                if base_id == 7 and cell.get('properties', {}).get('type') == 'door':
                    # Если дверь открыта – пропускаем
                    if cell.get('properties', {}).get('open', False):
                        depth += 1
                        continue
                    # Закрытая дверь – ведёт себя как стена

                # Если это не пустота
                if base_id != 0:
                    corrected_depth = depth * math.cos(player_angle - ray_angle)
                    if corrected_depth < 0.1:
                        corrected_depth = 0.1

                    # Вычисляем wall_x
                    if cos_a != 0:
                        dist_x = ((map_x + 1 - player_pos.x / self.tile_size) / cos_a) if cos_a > 0 else ((map_x - player_pos.x / self.tile_size) / cos_a)
                    else:
                        dist_x = float('inf')
                    if sin_a != 0:
                        dist_y = ((map_y + 1 - player_pos.y / self.tile_size) / sin_a) if sin_a > 0 else ((map_y - player_pos.y / self.tile_size) / sin_a)
                    else:
                        dist_y = float('inf')
                    if dist_x < dist_y:
                        wall_x = (y - map_y * self.tile_size) / self.tile_size
                    else:
                        wall_x = (x - map_x * self.tile_size) / self.tile_size

                    is_visible = cell.get('properties', {}).get('isvisible', False)
                    alpha = self._get_alpha(cell)
                    height = cell.get('properties', {}).get('height', 1.0)

                    hit_objects.append((corrected_depth, cell, wall_x))

                    # Останавливаемся, если стена непрозрачная и высота >= 1
                    if base_id == 9 and not is_visible:
                        depth += 1
                        continue
                    if base_id == 6:
                        depth += 1
                        continue
                    if alpha >= 1.0 and height >= 1.0:
                        break
                depth += 1

            if not hit_objects:
                hit_objects.append((self.max_depth, None, 0))

            results.append(RayResult(
                ray_index=i,
                depth=hit_objects[0][0] if hit_objects else self.max_depth,
                hit_objects=hit_objects,
                wall_x=hit_objects[0][2] if hit_objects else 0
            ))
        return results

    def _get_alpha(self, cell):
        material_name = cell.get('properties', {}).get('sprite', None)
        if material_name is None:
            mat = self.material_lib.get_material(str(cell['base_id']))
        else:
            mat = self.material_lib.get_material(material_name)
        if mat is None:
            mat = self.material_lib.get_default()
        return mat.alpha if hasattr(mat, 'alpha') else 1.0