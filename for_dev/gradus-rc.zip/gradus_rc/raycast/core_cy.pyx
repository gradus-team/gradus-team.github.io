# cython: language_level=3

from libc.math cimport cos, sin, floor, fabs, INFINITY

from ..config import DEFAULT_MAX_DEPTH
from ..material.library import MaterialLibrary


class RayResult:
    __slots__ = ('ray_index', 'depth', 'hit_objects', 'wall_x')
    def __init__(self, ray_index, depth, hit_objects=None, wall_x=0):
        self.ray_index = ray_index
        self.depth = depth
        self.hit_objects = hit_objects if hit_objects else []
        self.wall_x = wall_x


cdef class RayCaster:
    cdef public object map_data
    cdef public double tile_size
    cdef public double fov
    cdef public double half_fov
    cdef public int rays
    cdef public double max_depth
    cdef public double proj_coeff
    cdef public object material_lib
    cdef public int map_width
    cdef public int map_height
    cdef list _cos_values
    cdef list _sin_values
    cdef list _ray_angles

    def __init__(self, map_data, tile_size, fov, rays,
                 max_depth=DEFAULT_MAX_DEPTH, proj_coeff=20000,
                 material_lib=None):
        self.map_data = map_data
        self.tile_size = float(tile_size)
        self.fov = float(fov)
        self.half_fov = self.fov / 2.0
        self.rays = int(rays)
        self.max_depth = float(max_depth)
        self.proj_coeff = float(proj_coeff)
        self.material_lib = material_lib if material_lib is not None else MaterialLibrary()
        # Инициализируем в None — чтобы проверка `is None` в cast_rays работала.
        self._cos_values = None
        self._sin_values = None
        self._ray_angles = None
        self.update_dimensions()
        self._precompute_angles()

    def update_dimensions(self):
        if self.map_data and len(self.map_data) > 0:
            self.map_height = len(self.map_data)
            self.map_width = len(self.map_data[0]) if self.map_height > 0 else 0
        else:
            self.map_height = 0
            self.map_width = 0

    def _precompute_angles(self):
        self._ray_angles = []
        self._cos_values = []
        self._sin_values = []
        cdef int i
        cdef double ray_angle
        cdef double rays_d = <double>self.rays
        for i in range(self.rays):
            ray_angle = -self.half_fov + (i / rays_d) * self.fov
            self._ray_angles.append(ray_angle)
            self._cos_values.append(cos(ray_angle))
            self._sin_values.append(sin(ray_angle))

    # ------------------------------------------------------------------
    # Сортировка вставками (замена lambda, которая ломает cpdef)
    # ------------------------------------------------------------------
    cpdef list _sort_hits(self, list hits):
        cdef int n = len(hits)
        if n <= 1:
            return hits
        cdef list result = list(hits)
        cdef int i, j
        cdef object a
        cdef double a_key, b_key
        for i in range(1, n):
            a = result[i]
            a_key = <double>(<tuple>a)[0]
            j = i - 1
            while j >= 0:
                b_key = <double>(<tuple>result[j])[0]
                if b_key > a_key:
                    result[j + 1] = result[j]
                    j -= 1
                else:
                    break
            result[j + 1] = a
        return result

    # ------------------------------------------------------------------
    # Основной метод рейкастинга
    # ------------------------------------------------------------------
    cpdef list cast_rays(self, player_pos, player_angle):
        if self.map_data is None or self.map_height == 0 or self.map_width == 0:
            return []
        if self._cos_values is None:
            self._precompute_angles()

        cdef double tile = self.tile_size
        cdef double max_depth = self.max_depth
        cdef double max_depth_tiles = self.max_depth / tile
        cdef int map_width = self.map_width
        cdef int map_height = self.map_height
        cdef int rays = self.rays
        cdef list cos_vals = self._cos_values
        cdef list sin_vals = self._sin_values
        cdef double player_x = <double>player_pos.x
        cdef double player_y = <double>player_pos.y
        cdef double player_angle_d = <double>player_angle
        cdef double player_dir_cos = cos(player_angle_d)
        cdef double player_dir_sin = sin(player_angle_d)

        cdef list results = [None] * rays

        cdef int i, side
        cdef double cos_a, sin_a
        cdef double pos_x, pos_y
        cdef int map_x, map_y
        cdef int step_x, step_y
        cdef double delta_dist_x, delta_dist_y
        cdef double dist_x, dist_y
        cdef double perp_dist, corrected_depth, wall_x
        cdef object cell, props
        cdef int base_id
        cdef object is_visible, ptype
        cdef double alpha, height
        cdef double ct
        cdef object closest
        cdef list hit_objects

        for i in range(rays):
            cos_a = player_dir_cos * <double>cos_vals[i] - player_dir_sin * <double>sin_vals[i]
            sin_a = player_dir_sin * <double>cos_vals[i] + player_dir_cos * <double>sin_vals[i]

            pos_x = player_x / tile
            pos_y = player_y / tile
            map_x = <int>pos_x
            map_y = <int>pos_y

            step_x = 1 if cos_a > 0 else -1
            step_y = 1 if sin_a > 0 else -1

            delta_dist_x = fabs(1.0 / cos_a) if cos_a != 0 else INFINITY
            delta_dist_y = fabs(1.0 / sin_a) if sin_a != 0 else INFINITY

            if cos_a > 0:
                dist_x = (map_x + 1 - pos_x) * delta_dist_x
            elif cos_a < 0:
                dist_x = (pos_x - map_x) * delta_dist_x
            else:
                dist_x = INFINITY

            if sin_a > 0:
                dist_y = (map_y + 1 - pos_y) * delta_dist_y
            elif sin_a < 0:
                dist_y = (pos_y - map_y) * delta_dist_y
            else:
                dist_y = INFINITY

            side = 0
            hit_objects = []

            while dist_x < max_depth_tiles or dist_y < max_depth_tiles:
                if dist_x < dist_y:
                    dist_x += delta_dist_x
                    map_x += step_x
                    side = 0
                else:
                    dist_y += delta_dist_y
                    map_y += step_y
                    side = 1

                if map_x < 0 or map_y < 0 or map_x >= map_width or map_y >= map_height:
                    break

                cell = self.map_data[map_y][map_x]
                base_id = <int>cell['base_id']

                props = cell.get('properties', {})
                if props is None:
                    props = {}

                # --- фильтры пропуска (точно как в Python) ---
                is_visible = props.get('isvisible', True)
                if not is_visible:
                    continue

                if base_id == 8:
                    continue

                if base_id == 7:
                    ptype = props.get('type', None)
                    if ptype == 'key':
                        continue
                    if ptype == 'door':
                        if props.get('open', False):
                            continue

                if base_id == 9 and not props.get('isvisible', False):
                    continue

                if base_id == 6:
                    continue

                if base_id == 0:
                    continue

                # --- обработка стены ---
                if side == 0:
                    perp_dist = dist_x - delta_dist_x
                else:
                    perp_dist = dist_y - delta_dist_y

                ct = <double>cos_vals[i]
                corrected_depth = perp_dist * tile * ct
                if corrected_depth < 0.1:
                    corrected_depth = 0.1

                if side == 0:
                    wall_x = pos_y + perp_dist * sin_a
                else:
                    wall_x = pos_x + perp_dist * cos_a
                wall_x -= floor(wall_x)

                alpha = self._get_alpha(cell)

                height = 1.0
                h_val = props.get('height', None)
                if h_val is not None:
                    try:
                        height = <double>h_val
                    except (TypeError, ValueError):
                        height = 1.0

                hit_objects.append((corrected_depth, cell, wall_x))

                if alpha >= 1.0 and height >= 1.0:
                    break

            if not hit_objects:
                hit_objects.append((max_depth, None, 0.0))

            if len(hit_objects) > 1:
                hit_objects = self._sort_hits(hit_objects)

            closest = hit_objects[0]

            results[i] = RayResult(
                ray_index=i,
                depth=closest[0],
                hit_objects=hit_objects,
                wall_x=closest[2]
            )

        return results

    # ------------------------------------------------------------------
    # Получение alpha материала
    # ------------------------------------------------------------------
    cpdef double _get_alpha(self, cell):
        cdef object props = cell.get('properties', {})
        if props is None:
            props = {}
        cdef object material_name = props.get('sprite', None)
        cdef object mat
        cdef double result = 1.0

        if material_name is None:
            mat = self.material_lib.get_material(str(cell['base_id']))
        else:
            mat = self.material_lib.get_material(material_name)

        if mat is None:
            mat = self.material_lib.get_default()

        if hasattr(mat, 'alpha'):
            try:
                result = <double>mat.alpha
            except (TypeError, ValueError):
                result = 1.0
        return result