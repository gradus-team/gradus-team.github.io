import pygame
import math

class Sprite:
    def __init__(self, x, y, texture, key=None, scale=1.0):
        self.x = x
        self.y = y
        self.texture = texture
        self.key = key
        self.scale = scale
        self.visible = True
        self.anim_frames = None
        self.anim_speed = 0.1
        self.anim_time = 0.0
        self.current_frame = 0

    def update(self, dt):
        if self.anim_frames:
            self.anim_time += dt
            if self.anim_time >= self.anim_speed:
                self.anim_time = 0.0
                self.current_frame = (self.current_frame + 1) % len(self.anim_frames)
                self.texture = self.anim_frames[self.current_frame]

class SpriteManager:
    def __init__(self):
        self.sprites = []

    def add(self, sprite):
        self.sprites.append(sprite)

    def get_by_key(self, key):
        for s in self.sprites:
            if s.key == key:
                return s
        return None

    def remove_by_key(self, key):
        self.sprites = [s for s in self.sprites if s.key != key]

    def update(self, dt):
        for s in self.sprites:
            s.update(dt)

    def get_sorted(self, player_pos):
        return sorted(self.sprites, key=lambda s: (s.x - player_pos.x)**2 + (s.y - player_pos.y)**2, reverse=True)



import math

class ModelSprite:
    def __init__(self, x, y, frames, key=None, rot_y=0.0, rot_x=0.0, rot_z=0.0):
        self.x = x
        self.y = y
        self.frames = frames
        self.key = key
        self.visible = True
        self.current_frame = 0
        self.rot_y = rot_y
        self.rot_x = rot_x
        self.rot_z = rot_z

    def update(self, dt):
        pass

    def set_frame_by_angle(self, player_pos, player_angle):
        """Выбирает кадр по абсолютному углу от игрока к объекту с учётом всех поворотов."""
        if not self.frames:
            return
        dx = self.x - player_pos.x
        dy = self.y - player_pos.y
        angle_to_model = math.atan2(dy, dx)
        # Суммарный поворот по всем осям (пока используем только rot_y, но rot_x и rot_z тоже влияют)
        # Для простоты: добавляем rot_x и rot_z как смещение к индексу (но это условно)
        # Можно сделать: сдвиг индекса на основе rot_x и rot_z
        # Например, rot_x и rot_z дают дополнительный сдвиг в кадрах
        # Так как у нас 32 кадра, то rot_x и rot_z могут сдвигать на несколько позиций
        # Но логичнее, чтобы rot_x и rot_z влияли на выбор другого набора спрайтов (если бы мы генерировали несколько наборов)
        # Пока оставим их как задел, а используем только rot_y для основного выбора
        adjusted_angle = angle_to_model - self.rot_y
        adjusted_angle = (adjusted_angle + math.pi) % (2 * math.pi) - math.pi
        num_frames = len(self.frames)
        idx = int((adjusted_angle + math.pi) / (2 * math.pi) * num_frames) % num_frames
        self.current_frame = idx

class AnimatedModelSprite(ModelSprite):
    def __init__(self, x, y, frame_sets, key=None, rot_y=0.0, rot_x=0.0, rot_z=0.0, anim_speed=0.5):
        # frame_sets – список списков Surface (по одному на каждый кадр анимации)
        # Каждый элемент – это список кадров для одного угла (16 или 32 кадра)
        self.x = x
        self.y = y
        self.frame_sets = frame_sets
        self.key = key
        self.visible = True
        self.current_frame_index = 0
        self.anim_timer = 0.0
        self.anim_speed = anim_speed
        self.rot_y = rot_y
        self.rot_x = rot_x
        self.rot_z = rot_z
        self.current_angle_frame = 0

    def update(self, dt):
        self.anim_timer += dt
        if self.anim_timer >= self.anim_speed:
            self.anim_timer = 0.0
            self.current_frame_index = (self.current_frame_index + 1) % len(self.frame_sets)

    def set_frame_by_angle(self, player_pos, player_angle):
        if not self.frame_sets:
            return
        dx = self.x - player_pos.x
        dy = self.y - player_pos.y
        angle_to_model = math.atan2(dy, dx)
        adjusted_angle = angle_to_model - self.rot_y
        adjusted_angle = (adjusted_angle + math.pi) % (2 * math.pi) - math.pi
        num_frames = len(self.frame_sets[0])  # количество кадров на угол (16 или 32)
        idx = int((adjusted_angle + math.pi) / (2 * math.pi) * num_frames) % num_frames
        self.current_angle_frame = idx

    def get_current_texture(self):
        # Возвращает текущий спрайт из текущего кадра анимации и угла
        if not self.frame_sets:
            return None
        frame_set = self.frame_sets[self.current_frame_index]
        if self.current_angle_frame < len(frame_set):
            return frame_set[self.current_angle_frame]
        return None