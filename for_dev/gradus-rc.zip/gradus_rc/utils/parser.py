import re

class MapParser:
    def parse_layers(self, raw_data):
        if isinstance(raw_data, str):
            lines = raw_data.strip().split('\n')
        else:
            lines = raw_data

        layers = {}
        current_layer = 'collision'
        current_data = []
        level_params = {}

        for line in lines:
            line = line.strip()
            if not line:
                continue

            # Если это секция [что-то]
            if line.startswith('[') and line.endswith(']'):
                # Сохраняем текущий слой, если есть данные
                if current_data:
                    layers[current_layer] = self._parse_grid(current_data)
                    current_data = []

                section = line[1:-1]  # убираем скобки
                if '=' in section:
                    key, value = section.split('=', 1)
                    level_params[key.strip().lower()] = value.strip()
                    # Не меняем current_layer, остаёмся в том же слое
                else:
                    current_layer = section.lower()
            else:
                # Это строка данных для текущего слоя
                current_data.append(line)

        # Сохраняем последний слой
        if current_data:
            layers[current_layer] = self._parse_grid(current_data)

        layers['_params'] = level_params
        return layers

    def _parse_grid(self, grid_lines):
        parsed = []
        for line in grid_lines:
            if isinstance(line, str):
                cells = line.split()
            else:
                cells = line
            row = []
            for cell in cells:
                cell = cell.strip()
                if not cell:
                    continue
                base_id, props = self._parse_cell(cell)
                row.append({'base_id': base_id, 'properties': props})
            parsed.append(row)
        return parsed

    def _parse_cell(self, cell_str):
        match = re.search(r'<([^>]+)>', cell_str)
        base_id_str = cell_str[:match.start()] if match else cell_str
        base_id = int(base_id_str) if base_id_str.isdigit() else 0
        props = {}
        if match:
            tag_content = match.group(1)
            parts = re.split(r'[;,]\s*', tag_content)
            for part in parts:
                if ':' in part:
                    key, value = part.split(':', 1)
                    key = key.strip()   # добавить .lower()
                    value = value.strip()
                    if value.lower() == 'true':
                        value = True
                    elif value.lower() == 'false':
                        value = False
                    else:
                        try:
                            if '.' in value:
                                value = float(value)
                            else:
                                value = int(value)
                        except ValueError:
                            pass
                    props[key] = value
        return base_id, props