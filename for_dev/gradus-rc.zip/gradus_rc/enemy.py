import math
import random

class EnemyAI:
    TYPE_STATIC = 'static'
    TYPE_CHASE = 'chase'
    TYPE_PATROL = 'patrol'
    TYPE_MULTIPLAYER = 'multiplayer'

    ATTACK_RANGED = 'ranged'
    ATTACK_MELEE = 'melee'

    def __init__(self, x, y, hp=100, aim=10, shoot_delay=1.0,
                 shoot_intensity=0, intensity_mode='fast',
                 enemy_type=TYPE_STATIC, attack_type=ATTACK_RANGED,
                 detect_radius=5.0, attack_radius=3.0,
                 speed=50.0, key=None, texture=None,
                 sound_spawn=None, effect_spawn=None,
                 effect_until_death=False):
        self.x = x
        self.y = y
        self.hp = hp
        self.aim = max(0, min(100, aim))
        self.shoot_delay = shoot_delay
        self.shoot_intensity = max(0, min(100, shoot_intensity))
        self.intensity_mode = intensity_mode
        self.type = enemy_type
        self.attack_type = attack_type
        self.detect_radius = detect_radius  # в тайлах
        self.attack_radius = attack_radius  # в тайлах
        self.speed = speed
        self.key = key
        self.texture = texture
        self.sound_spawn = sound_spawn
        self.effect_spawn = effect_spawn
        self.effect_until_death = effect_until_death

        self.alive = True
        self.rotation = 0.0  # для static или управляемого
        self.shoot_timer = 0.0
        self.current_gun = None
        self.target = None
        self.patrol_dir = random.uniform(0, 2 * math.pi)
        self.patrol_timer = 0.0

    def update(self, dt, player_pos, engine=None):
        if not self.alive:
            return

        self.shoot_timer -= dt

        dx = player_pos[0] - self.x
        dy = player_pos[1] - self.y
        dist_to_player = math.hypot(dx, dy) / engine.tile_size if engine else 0.0

        # Поведение по типу
        if self.type == self.TYPE_STATIC:
            pass
        elif self.type == self.TYPE_CHASE:
            if dist_to_player <= self.detect_radius:
                angle = math.atan2(dy, dx)
                new_x = self.x + math.cos(angle) * self.speed * dt
                new_y = self.y + math.sin(angle) * self.speed * dt
                if engine and engine._is_walkable(new_x, self.y):
                    self.x = new_x
                if engine and engine._is_walkable(self.x, new_y):
                    self.y = new_y
        elif self.type == self.TYPE_PATROL:
            self.patrol_timer -= dt
            if self.patrol_timer <= 0:
                self.patrol_dir = random.uniform(0, 2 * math.pi)
                self.patrol_timer = random.uniform(1.0, 3.0)
            new_x = self.x + math.cos(self.patrol_dir) * self.speed * dt
            new_y = self.y + math.sin(self.patrol_dir) * self.speed * dt
            if engine and engine._is_walkable(new_x, self.y):
                self.x = new_x
            if engine and engine._is_walkable(self.x, new_y):
                self.y = new_y

        # Атака
        if dist_to_player <= self.attack_radius:
            self.try_attack(player_pos, engine)

    def try_attack(self, player_pos, engine):
        if not self.can_shoot():
            return
        if not self.has_line_of_sight(player_pos, engine):
            self.shoot_timer = self.shoot_delay  # откладываем выстрел
            return
        if self.attack_type == self.ATTACK_RANGED:
            # Стрельба
            if random.randint(1, 100) <= self.aim:
                angle = math.atan2(player_pos[1] - self.y, player_pos[0] - self.x)
                angle += random.uniform(-0.2, 0.2)
            else:
                angle = math.atan2(player_pos[1] - self.y, player_pos[0] - self.x)
            if engine:
                engine.enemy_shoot(self, angle)
        else:  # melee
            if random.randint(1, 100) > self.aim:
                if engine:
                    damage = self.current_gun.damage if self.current_gun else 10
                    engine.damage_player(damage)
        self.shoot_timer = self.shoot_delay
        if random.randint(1, 100) <= self.shoot_intensity:
            if self.intensity_mode == 'long':
                extra = random.uniform(0.3, 3.0)
            else:
                extra = random.uniform(0.1, 1.0)
            self.shoot_timer += extra

    def can_shoot(self):
        return self.alive and self.shoot_timer <= 0

    def take_damage(self, damage, weapon=None):
        if not self.alive:
            return False
        self.hp -= damage
        if self.hp <= 0:
            self.alive = False
        return True

    def has_line_of_sight(self, target_pos, engine):
        """Проверяет, нет ли стен между врагом и целью."""
        if not engine:
            return True
        dx = target_pos[0] - self.x
        dy = target_pos[1] - self.y
        dist = math.hypot(dx, dy)
        if dist < 0.1:
            return True
        steps = int(dist / (engine.tile_size * 0.5)) + 1
        for i in range(1, steps):
            t = i / steps
            x = self.x + dx * t
            y = self.y + dy * t
            map_x = int(x // engine.tile_size)
            map_y = int(y // engine.tile_size)
            if 0 <= map_y < engine.map_height and 0 <= map_x < engine.map_width:
                cell = engine.map_data[map_y][map_x]
                base_id = cell['base_id']
                if base_id in (1, 2, 3, 4, 5):  # стены
                    return False
                elif base_id == 7:
                    props = cell.get('properties', {})
                    if props.get('type') == 'door' and not props.get('open', False):
                        return False
        return True
    def get_position(self):
        return (self.x, self.y)