import math
import random
from .ai.pathfinding import *

class EnemyAI:
    TYPE_STATIC = 'static'
    TYPE_CHASE = 'chase'
    TYPE_PATROL = 'patrol'
    TYPE_MULTIPLAYER = 'multiplayer'

    ATTACK_RANGED = 'ranged'
    ATTACK_MELEE = 'melee'

    def __init__(self, x, y, hp=100, aim=10, shoot_delay=1.0,
                 shoot_intensity=0, intensity_mode='fast',
                 enemy_type=TYPE_STATIC, attack_type=ATTACK_RANGED,
                 detect_radius=5.0, attack_radius=3.0,
                 speed=50.0, key=None, texture=None,
                 sound_spawn=None, effect_spawn=None,
                 effect_until_death=False):
        self.x = x
        self.y = y
        self.hp = hp
        self.max_hp = hp
        self.last_seen_time = 0.0
        self.show_on_minimap = True
        self.aim = max(0, min(100, aim))
        self.shoot_delay = shoot_delay
        self.shoot_intensity = max(0, min(100, shoot_intensity))
        self.intensity_mode = intensity_mode
        self.type = enemy_type
        self.attack_type = attack_type
        self.detect_radius = detect_radius  # в тайлах
        self.attack_radius = attack_radius  # в тайлах
        self.speed = speed
        self.key = key
        self.texture = texture
        self.sound_spawn = sound_spawn
        self.effect_spawn = effect_spawn
        self.effect_until_death = effect_until_death

        self._path = []
        self._path_timer = 0.0
        self._path_recalc_interval = 0.35

        self.alive = True
        self.rotation = 0.0  # для static или управляемого
        self.shoot_timer = 0.0
        self.current_gun = None
        self.target = None
        self.patrol_dir = random.uniform(0, 2 * math.pi)
        self.patrol_timer = 0.0

    def update_visibility(self, dt, engine):
        """Обновляет таймер видимости для мини-карты."""
        # Быстрая проверка FOV
        dx = self.x - engine.player.pos.x
        dy = self.y - engine.player.pos.y
        angle_to = math.atan2(dy, dx)
        rel = angle_to - engine.player.angle
        while rel < -math.pi:
            rel += 2 * math.pi
        while rel > math.pi:
            rel -= 2 * math.pi

        in_fov = abs(rel) <= engine.half_fov
        visible = in_fov and engine._is_sprite_visible(self.x, self.y)

        if visible:
            self.last_seen_time = 0.0
            self.show_on_minimap = True
        else:
            self.last_seen_time += dt
            if self.last_seen_time >= engine.minimap_enemy_hide_delay:
                self.show_on_minimap = False

    def update(self, dt, player_pos, engine=None):
        if not self.alive:
            return

        self.shoot_timer -= dt

        dx = player_pos[0] - self.x
        dy = player_pos[1] - self.y
        dist_to_player = math.hypot(dx, dy) / engine.tile_size if engine else 0.0

        # Поведение по типу
        if self.type == self.TYPE_STATIC:
            pass
        elif self.type == self.TYPE_CHASE:
            if dist_to_player <= self.detect_radius and engine:
                self._path_timer -= dt
                if self._path_timer <= 0 or not self._path:
                    self._path_timer = self._path_recalc_interval
                    tile = engine.tile_size
                    sx = int(self.x // tile)
                    sy = int(self.y // tile)
                    gx = int(player_pos[0] // tile)
                    gy = int(player_pos[1] // tile)

                    if (sx, sy) == (gx, gy):
                        self._path = []
                    else:
                        def walk(x, y):
                            if x < 0 or y < 0 or x >= engine.map_width or y >= engine.map_height:
                                return False
                            try:
                                return engine._is_walkable(x * tile + tile // 2,
                                                           y * tile + tile // 2)
                            except Exception:
                                return False

                        try:
                            raw_path = astar((sx, sy), (gx, gy), walk)
                            self._path = list(raw_path) if raw_path else []
                        except Exception as e:
                            print(f"[AI] astar failed: {e}")
                            self._path = []

                # Убираем стартовые узлы (иногда astar включает наш же тайл)
                while self._path:
                    nx, ny = self._path[0]
                    if (nx, ny) == (int(self.x // engine.tile_size),
                                    int(self.y // engine.tile_size)):
                        self._path.pop(0)
                    else:
                        break

                moved = False

                if self._path:
                    nx, ny = self._path[0]
                    tx = nx * engine.tile_size + engine.tile_size // 2
                    ty = ny * engine.tile_size + engine.tile_size // 2
                    ddx = tx - self.x
                    ddy = ty - self.y
                    d = math.hypot(ddx, ddy)

                    if d < 4:
                        self._path.pop(0)
                    else:
                        step = self.speed * dt
                        new_x = self.x + (ddx / d) * step
                        new_y = self.y + (ddy / d) * step
                        if engine._is_walkable(new_x, self.y):
                            self.x = new_x
                            moved = True
                        if engine._is_walkable(self.x, new_y):
                            self.y = new_y
                            moved = True

                # FALLBACK: если пути нет вообще — идём прямо на игрока
                if not moved and dist_to_player > 0.5:
                    ddx = player_pos[0] - self.x
                    ddy = player_pos[1] - self.y
                    d = math.hypot(ddx, ddy)
                    step = self.speed * dt
                    new_x = self.x + (ddx / d) * step
                    new_y = self.y + (ddy / d) * step
                    if engine._is_walkable(new_x, self.y):
                        self.x = new_x
                    if engine._is_walkable(self.x, new_y):
                        self.y = new_y
        elif self.type == self.TYPE_PATROL:
            self.patrol_timer -= dt
            if self.patrol_timer <= 0:
                # Выбираем случайное проходимое направление
                if engine:
                    tile = engine.tile_size
                    cx = int(self.x // tile)
                    cy = int(self.y // tile)
                    candidates = []
                    # 8 направлений
                    for ddx, ddy in [(1, 0), (-1, 0), (0, 1), (0, -1),
                                     (1, 1), (1, -1), (-1, 1), (-1, -1)]:
                        nx, ny = cx + ddx, cy + ddy
                        if 0 <= ny < engine.map_height and 0 <= nx < engine.map_width:
                            if engine._is_walkable(nx * tile + tile // 2,
                                                   ny * tile + tile // 2):
                                candidates.append((ddx, ddy))
                    if candidates:
                        ddx, ddy = random.choice(candidates)
                        self.patrol_dir = math.atan2(ddy, ddx)
                    else:
                        # Тупик — стоим и ждём
                        self.patrol_dir = None
                else:
                    self.patrol_dir = random.uniform(0, 2 * math.pi)
                self.patrol_timer = random.uniform(1.0, 3.0)

            if self.patrol_dir is not None:
                new_x = self.x + math.cos(self.patrol_dir) * self.speed * dt
                new_y = self.y + math.sin(self.patrol_dir) * self.speed * dt
                moved = False
                if engine and engine._is_walkable(new_x, self.y):
                    self.x = new_x
                    moved = True
                if engine and engine._is_walkable(self.x, new_y):
                    self.y = new_y
                    moved = True
                # Если не сдвинулись — сбросим таймер, чтобы выбрать другое направление
                if not moved:
                    self.patrol_timer = 0.0

        # Атака
        if dist_to_player <= self.attack_radius:
            self.try_attack(player_pos, engine)

    def try_attack(self, player_pos, engine):
        if not self.can_shoot():
            return
        if not self.has_line_of_sight(player_pos, engine):
            self.shoot_timer = self.shoot_delay  # откладываем выстрел
            return
        if self.attack_type == self.ATTACK_RANGED:
            # Стрельба
            if random.randint(1, 100) <= self.aim:
                angle = math.atan2(player_pos[1] - self.y, player_pos[0] - self.x)
                angle += random.uniform(-0.2, 0.2)
            else:
                angle = math.atan2(player_pos[1] - self.y, player_pos[0] - self.x)
            if engine:
                engine.enemy_shoot(self, angle)
        else:  # melee
            if random.randint(1, 100) > self.aim:
                if engine:
                    damage = self.current_gun.damage if self.current_gun else 10
                    engine.damage_player(damage)
        self.shoot_timer = self.shoot_delay
        if random.randint(1, 100) <= self.shoot_intensity:
            if self.intensity_mode == 'long':
                extra = random.uniform(0.3, 3.0)
            else:
                extra = random.uniform(0.1, 1.0)
            self.shoot_timer += extra

    def can_shoot(self):
        return self.alive and self.shoot_timer <= 0

    def take_damage(self, damage, weapon=None):
        if not self.alive:
            return False
        self.hp -= damage
        if self.hp <= 0:
            self.alive = False
        return True

    def has_line_of_sight(self, target_pos, engine):
        """Проверяет, нет ли стен между врагом и целью."""
        if not engine:
            return True
        dx = target_pos[0] - self.x
        dy = target_pos[1] - self.y
        dist = math.hypot(dx, dy)
        if dist < 0.1:
            return True
        steps = int(dist / (engine.tile_size * 0.5)) + 1
        for i in range(1, steps):
            t = i / steps
            x = self.x + dx * t
            y = self.y + dy * t
            map_x = int(x // engine.tile_size)
            map_y = int(y // engine.tile_size)
            if 0 <= map_y < engine.map_height and 0 <= map_x < engine.map_width:
                cell = engine.map_data[map_y][map_x]
                base_id = cell['base_id']
                if base_id in (1, 2, 3, 4, 5):  # стены
                    return False
                elif base_id == 7:
                    props = cell.get('properties', {})
                    if props.get('type') == 'door' and not props.get('open', False):
                        return False
        return True
    def get_position(self):
        return (self.x, self.y)