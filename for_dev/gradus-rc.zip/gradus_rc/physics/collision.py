import pygame

class PhysicsWorld:
    def __init__(self, map_data, tile_size, player_radius=0.4):
        """
        player_radius – радиус игрока в долях от tile_size (0.4 = 40% от клетки)
        """
        self.map_data = map_data
        self.tile_size = tile_size
        self.radius = player_radius * tile_size  # в пикселях

    def is_wall(self, x, y):
        """Проверяет, является ли клетка стеной."""
        map_x = int(x // self.tile_size)
        map_y = int(y // self.tile_size)
        if map_y < 0 or map_y >= len(self.map_data) or map_x < 0 or map_x >= len(self.map_data[0]):
            return True  # за границей – стена
        cell = self.map_data[map_y][map_x]
        return cell['base_id'] != 0

    def resolve_movement(self, pos, vel, dt):
        """Возвращает новую позицию с учётом коллизий."""
        if vel.length() == 0:
            return pos

        new_x = pos.x
        new_y = pos.y

        # Движение по X
        new_x = pos.x + vel.x * dt
        # Проверяем столкновение по X (с учётом радиуса)
        # Проверяем точки: центр + радиус по Y (сверху и снизу) и центр
        test_points = [
            (new_x, pos.y),
            (new_x, pos.y - self.radius),
            (new_x, pos.y + self.radius)
        ]
        collision = False
        for tx, ty in test_points:
            if self.is_wall(tx, ty):
                collision = True
                break
        if collision:
            new_x = pos.x  # откат по X

        # Движение по Y
        new_y = pos.y + vel.y * dt
        test_points = [
            (pos.x, new_y),
            (pos.x - self.radius, new_y),
            (pos.x + self.radius, new_y)
        ]
        collision = False
        for tx, ty in test_points:
            if self.is_wall(tx, ty):
                collision = True
                break
        if collision:
            new_y = pos.y  # откат по Y

        # Дополнительная проверка углов (если обе оси двигались)
        # Если новая позиция полностью внутри стены, откатываем всё
        if self.is_wall(new_x, new_y):
            # Пробуем откатить только X
            test_x = pos.x
            test_y = new_y
            if not self.is_wall(test_x, test_y):
                return pygame.math.Vector2(test_x, test_y)
            # Пробуем откатить только Y
            test_x = new_x
            test_y = pos.y
            if not self.is_wall(test_x, test_y):
                return pygame.math.Vector2(test_x, test_y)
            # Если оба отката не помогают, возвращаем исходную
            return pos

        return pygame.math.Vector2(new_x, new_y)