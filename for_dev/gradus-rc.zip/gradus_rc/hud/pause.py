import pygame


class PauseMenu:
    STATE_CONTINUE = 'continue'
    STATE_EXIT = 'exit'
    STATE_SETTINGS = 'settings'
    STATE_RESUME = 'resume'

    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.active = False

        self.font_title = pygame.font.SysFont('Arial', 64, bold=True)
        self.font_btn = pygame.font.SysFont('Arial', 32, bold=True)

        cx = width // 2
        bw, bh, gap = 300, 60, 20
        base_y = height // 2 - 60

        self.btn_continue = pygame.Rect(cx - bw // 2, base_y, bw, bh)
        self.btn_settings = pygame.Rect(cx - bw // 2, base_y + bh + gap, bw, bh)
        self.btn_exit     = pygame.Rect(cx - bw // 2, base_y + 2 * (bh + gap), bw, bh)

    def handle_event(self, event):
        """Возвращает строку-состояние или None."""
        if not self.active:
            return None
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            return self.STATE_RESUME
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = event.pos
            if self.btn_continue.collidepoint(pos):
                return self.STATE_RESUME
            if self.btn_settings.collidepoint(pos):
                return self.STATE_SETTINGS
            if self.btn_exit.collidepoint(pos):
                return self.STATE_EXIT
        return None

    def draw(self, screen):
        if not self.active:
            return
        # Затемнение
        dim = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        dim.fill((0, 0, 0, 160))
        screen.blit(dim, (0, 0))

        title = self.font_title.render("ПАУЗА", True, (255, 220, 120))
        screen.blit(title, (self.width // 2 - title.get_width() // 2,
                            self.height // 2 - 180))

        self._btn(screen, self.btn_continue, "Продолжить", (60, 140, 60))
        self._btn(screen, self.btn_settings, "Настройки", (70, 70, 180))
        self._btn(screen, self.btn_exit, "Сохранить и выйти", (160, 60, 60))

    def _btn(self, screen, rect, text, color):
        pygame.draw.rect(screen, color, rect, border_radius=10)
        pygame.draw.rect(screen, (255, 255, 255), rect, 2, border_radius=10)
        t = self.font_btn.render(text, True, (255, 255, 255))
        screen.blit(t, (rect.x + (rect.width - t.get_width()) // 2,
                        rect.y + (rect.height - t.get_height()) // 2))