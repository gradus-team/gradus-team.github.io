import pygame
import math
import random


class ScreenShake:
    """Тряска экрана с затуханием."""
    def __init__(self):
        self.intensity = 0.0
        self.timer = 0.0
        self.duration = 0.0
        self.offset_x = 0
        self.offset_y = 0

    def trigger(self, intensity=8.0, duration=0.3):
        """Запустить тряску. Если уже активна — усилить."""
        if intensity > self.intensity or self.timer <= 0:
            self.intensity = intensity
            self.duration = duration
            self.timer = duration

    def update(self, dt):
        if self.timer > 0:
            self.timer -= dt
            factor = max(0.0, self.timer / self.duration) if self.duration > 0 else 0
            cur = self.intensity * factor
            self.offset_x = int(random.uniform(-cur, cur))
            self.offset_y = int(random.uniform(-cur, cur))
        else:
            self.offset_x = 0
            self.offset_y = 0

    def is_active(self):
        return self.timer > 0


class HUDManager:
    """Единый менеджер HUD: полоски HP, патроны, иконка оружия, прицел."""

    def __init__(self, engine):
        self.engine = engine
        self.shake = ScreenShake()

        # Настройки
        self.show_hud = True
        self.show_crosshair = True
        self.show_hp_bar = True
        self.show_ammo = True
        self.show_weapon_icon = True

        # Цвета
        self.hp_color_full = (60, 200, 60)
        self.hp_color_mid = (220, 180, 40)
        self.hp_color_low = (220, 60, 60)
        self.hp_bg_color = (20, 20, 20, 180)
        self.ammo_color = (255, 220, 100)
        self.crosshair_color = (255, 60, 60)

        # Шрифты
        self.font_small = pygame.font.SysFont('Arial', 18, bold=True)
        self.font_mid = pygame.font.SysFont('Arial', 22, bold=True)
        self.font_large = pygame.font.SysFont('Arial', 28, bold=True)

        # Прицел
        self.crosshair_spread = 10  # базовое расхождение
        self.crosshair_recoil = 0.0  # добавочное от выстрела

    # ---------- API ----------
    def hit_marker(self, intensity=1.0):
        """Отметка попадания. Можно вызывать из fire_current_gun."""
        self.shake.trigger(intensity=3 * intensity, duration=0.15)
        self.crosshair_recoil = min(self.crosshair_recoil + 8 * intensity, 30)

    def damage_taken(self, amount=10):
        """Тряска при получении урона."""
        self.shake.trigger(intensity=10, duration=0.35)

    def update(self, dt):
        self.shake.update(dt)
        # Плавное затухание recoil
        self.crosshair_recoil = max(0.0, self.crosshair_recoil - dt * 40)

    # ---------- Отрисовка ----------
    def draw(self, screen):
        if not self.show_hud:
            return

        # HP-полоска в левом нижнем углу
        if self.show_hp_bar:
            self._draw_hp_bar(screen)

        # Аммо + иконка оружия в правом нижнем
        if self.show_ammo or self.show_weapon_icon:
            self._draw_ammo(screen)

        # Прицел в центре
        if self.show_crosshair:
            self._draw_crosshair(screen)

    def _draw_hp_bar(self, screen):
        player = self.engine.player
        w, h = 220, 22
        x, y = 20, screen.get_height() - 50
        hp_ratio = max(0.0, player.hp / player.max_hp)
        hp = int(player.hp)

        # Фон
        bg = pygame.Surface((w, h), pygame.SRCALPHA)
        bg.fill(self.hp_bg_color)
        screen.blit(bg, (x, y))

        # Цвет по уровню HP
        if hp_ratio > 0.6:
            color = self.hp_color_full
        elif hp_ratio > 0.3:
            color = self.hp_color_mid
        else:
            color = self.hp_color_low

        # Заполнение
        fill_w = int(w * hp_ratio)
        if fill_w > 0:
            pygame.draw.rect(screen, color, (x, y, fill_w, h))
        pygame.draw.rect(screen, (200, 200, 200), (x, y, w, h), 2)

        # Текст
        txt = self.font_small.render(f"HP {hp}/{player.max_hp}", True, (255, 255, 255))
        screen.blit(txt, (x + w // 2 - txt.get_width() // 2, y + (h - txt.get_height()) // 2))

    def _draw_ammo(self, screen):
        gun = self.engine.gun_manager.get_current_gun()
        if not gun:
            return
        w, h = 220, 60
        x = screen.get_width() - w - 20
        y = screen.get_height() - h - 20

        # Фон
        bg = pygame.Surface((w, h), pygame.SRCALPHA)
        bg.fill(self.hp_bg_color)
        screen.blit(bg, (x, y))

        # Иконка оружия (если есть)
        if self.show_weapon_icon and gun.texture:
            icon = pygame.transform.scale(gun.texture, (48, 48))
            screen.blit(icon, (x + 6, y + 6))

        # Патроны
        ammo_text = f"{gun.ammo} / {gun.max_ammo}"
        txt = self.font_large.render(ammo_text, True, self.ammo_color)
        tx = x + w - txt.get_width() - 12
        ty = y + h // 2 - txt.get_height() // 2
        screen.blit(txt, (tx, ty))

    def _draw_crosshair(self, screen):
        cx, cy = screen.get_width() // 2, screen.get_height() // 2
        gap = int(self.crosshair_spread + self.crosshair_recoil)
        length = 8
        color = self.crosshair_color

        pygame.draw.line(screen, color, (cx - gap - length, cy), (cx - gap, cy), 2)
        pygame.draw.line(screen, color, (cx + gap, cy), (cx + gap + length, cy), 2)
        pygame.draw.line(screen, color, (cx, cy - gap - length), (cx, cy - gap), 2)
        pygame.draw.line(screen, color, (cx, cy + gap), (cx, cy + gap + length), 2)