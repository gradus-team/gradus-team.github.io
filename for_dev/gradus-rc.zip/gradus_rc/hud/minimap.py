import pygame
import math


class Minimap:
    """Мини-карта с гибкими настройками."""
    MODE_WB = 'wb'
    MODE_COLOR = 'color'
    MODE_CUSTOM = 'custom'

    def __init__(self, engine, size=5, tile_px=16, mode='wb',
                 position=(20, 20), alpha=160, anchor='top-right', margin=(20, 20),pixel_size=(200,200),

                 # Что показывать
                 show_enemies=True,
                 enemy_instant_visible=False,
                 enemy_hide_delay=5.0,
                 show_billboards=False,
                 show_models=True,
                 show_doors=True,
                 show_keys=False,
                 show_triggers=False,
                 show_player_arrow=True,
                 show_border=True,
                 show_grid=False,

                 # Цвета
                 bg_color=(0, 0, 0),
                 wb_wall_color=(255, 255, 255),
                 wb_floor_color=(0, 0, 0),
                 out_of_bounds_color=(30, 30, 30),
                 enemy_color=(255, 0, 0),
                 billboard_color=(0, 255, 0),
                 model_color=(0, 128, 255),
                 player_color=(255, 255, 0),
                 door_closed_color=(200, 100, 50),
                 door_open_color=(50, 200, 50),
                 key_color=(255, 215, 0),
                 trigger_color=(255, 0, 255),

                 # Кастомный рендер
                 custom_renderer=None):
        self.engine = engine
        self.size = size
        self.tile_px = tile_px
        self.mode = mode
        self.position = position
        self.alpha = alpha

        self.anchor = anchor  # 'top-left', 'top-right', 'bottom-left', 'bottom-right', 'center'
        self.margin = margin

        self.show_enemies = show_enemies
        self.enemy_instant_visible = enemy_instant_visible
        self.enemy_hide_delay = enemy_hide_delay
        self.show_billboards = show_billboards
        self.show_models = show_models
        self.show_doors = show_doors
        self.show_keys = show_keys
        self.show_triggers = show_triggers
        self.show_player_arrow = show_player_arrow
        self.show_border = show_border
        self.show_grid = show_grid

        self.bg_color = bg_color
        self.wb_wall_color = wb_wall_color
        self.wb_floor_color = wb_floor_color
        self.out_of_bounds_color = out_of_bounds_color
        self.enemy_color = enemy_color
        self.billboard_color = billboard_color
        self.model_color = model_color
        self.player_color = player_color
        self.door_closed_color = door_closed_color
        self.door_open_color = door_open_color
        self.key_color = key_color
        self.trigger_color = trigger_color

        self.custom_renderer = custom_renderer
        if pixel_size is None: pixel_size = (size*30,size*30)
        if pixel_size is not None:
            pw, ph = pixel_size
            tile_px = min(pw // size, ph // size)
        self.tile_px = max(4, tile_px)

        self.width_px = self.size * self.tile_px
        self.height_px = self.size * self.tile_px
        self._recalculate_position()

        # Кэш поверности фона (перерисовываем только при смене alpha)
        self._bg_cache = None

    # ---------- Данные ----------
    def _recalculate_position(self):
        """Пересчитывает self.position на основе anchor + margin + размеров экрана."""
        sw = self.engine.screen_width
        sh = self.engine.screen_height
        mx, my = self.margin
        if self.anchor == 'top-left':
            x, y = mx, my
        elif self.anchor == 'top-right':
            x, y = sw - self.width_px - mx, my
        elif self.anchor == 'bottom-left':
            x, y = mx, sh - self.height_px - my
        elif self.anchor == 'bottom-right':
            x, y = sw - self.width_px - mx, sh - self.height_px - my
        elif self.anchor == 'center':
            x = (sw - self.width_px) // 2 + mx
            y = (sh - self.height_px) // 2 + my
        else:
            x, y = mx, my
        self.position = (x, y)

    def set_anchor(self, anchor, margin=None):
        self.anchor = anchor
        if margin is not None:
            self.margin = margin
        self._recalculate_position()

    def set_size(self, size, pixel_size=None):
        self.size = size
        if pixel_size is not None:
            pw, ph = pixel_size
            self.tile_px = max(4, min(pw // size, ph // size))
        self.width_px = self.size * self.tile_px
        self.height_px = self.size * self.tile_px
        self._recalculate_position()

    def set_tile_px(self, tile_px):
        self.tile_px = max(4, tile_px)
        self.width_px = self.size * self.tile_px
        self.height_px = self.size * self.tile_px
        self._recalculate_position()

    def get_visible_grid(self):
        """Возвращает кортеж (grid, player_map_x, player_map_y).
        grid — список списков ID клеток размера size×size с центром на игроке.
        Значение -1 — вне карты."""
        px = int(self.engine.player.pos.x // self.engine.tile_size)
        py = int(self.engine.player.pos.y // self.engine.tile_size)
        half = self.size // 2
        grid = []
        for dy in range(-half, half + 1):
            row = []
            for dx in range(-half, half + 1):
                mx = px + dx
                my = py + dy
                if 0 <= my < self.engine.map_height and 0 <= mx < self.engine.map_width:
                    row.append(self.engine.map_data[my][mx]['base_id'])
                else:
                    row.append(-1)
            grid.append(row)
        return grid, px, py

    def world_to_minimap(self, wx, wy, px, py):
        """Переводит мировые координаты в пиксели мини-карты.
        Возвращает (None, None), если вне видимой зоны."""
        half = self.size // 2
        tile = self.engine.tile_size
        mx = (wx / tile) - px
        my = (wy / tile) - py
        if -half - 0.5 <= mx <= half + 0.5 and -half - 0.5 <= my <= half + 0.5:
            ox, oy = self.position
            cx = ox + (mx + half) * self.tile_px
            cy = oy + (my + half) * self.tile_px
            return int(cx), int(cy)
        return None, None

    # ---------- Отрисовка ----------
    def draw(self, screen):
        if self.custom_renderer:
            self.custom_renderer(screen, self)
            return

        grid, px, py = self.get_visible_grid()
        half = self.size // 2
        ox, oy = self.position

        # Фон
        bg = pygame.Surface((self.width_px, self.height_px), pygame.SRCALPHA)
        bg.fill((*self.bg_color, self.alpha))
        screen.blit(bg, (ox, oy))

        # Клетки
        for gy, row in enumerate(grid):
            for gx, cell_id in enumerate(row):
                rect = pygame.Rect(ox + gx * self.tile_px,
                                   oy + gy * self.tile_px,
                                   self.tile_px, self.tile_px)
                color = self._cell_color(cell_id)
                pygame.draw.rect(screen, color, rect)

                if self.show_grid:
                    pygame.draw.rect(screen, (50, 50, 50), rect, 1)

        # Двери и ключи
        if self.show_doors or self.show_keys:
            self._draw_doors_and_keys(screen, px, py)

        # Триггеры
        if self.show_triggers:
            self._draw_triggers(screen, px, py)

        # Билборды
        if self.show_billboards:
            self._draw_sprites_of_type(screen, px, py,
                                       is_model=False,
                                       color=self.billboard_color)

        # 3D-модели
        if self.show_models:
            self._draw_sprites_of_type(screen, px, py,
                                       is_model=True,
                                       color=self.model_color)

        # Враги
        if self.show_enemies:
            self._draw_enemies(screen, px, py)

        # Игрок в центре + направление
        cx = ox + half * self.tile_px + self.tile_px // 2
        cy = oy + half * self.tile_px + self.tile_px // 2
        if self.show_player_arrow:
            ang = self.engine.player.angle
            ex = cx + int(math.cos(ang) * self.tile_px)
            ey = cy + int(math.sin(ang) * self.tile_px)
            pygame.draw.line(screen, self.player_color, (cx, cy), (ex, ey), 2)
        pygame.draw.circle(screen, self.player_color, (cx, cy), max(2, self.tile_px // 4))

    # ---------- Внутреннее ----------
    def _cell_color(self, cell_id):
        if cell_id == -1:
            return self.out_of_bounds_color
        if cell_id == 0:
            return self.wb_floor_color
        if cell_id in (8, 9):
            return self.wb_floor_color  # триггеры/порталы — как пол
        if cell_id == 7:
            return self.door_closed_color  # по умолчанию
        if self.mode == self.MODE_WB:
            return self.wb_wall_color
        # MODE_COLOR
        mat = self.engine.material_lib.get_material(str(cell_id))
        return mat.color if mat and mat.color else (128, 128, 128)

    def _draw_doors_and_keys(self, screen, px, py):
        for y, row in enumerate(self.engine.map_data):
            for x, cell in enumerate(row):
                if cell['base_id'] != 7:
                    continue
                props = cell.get('properties', {})
                obj_type = props.get('type', 'door')
                if obj_type == 'door' and not self.show_doors:
                    continue
                if obj_type == 'key' and not self.show_keys:
                    continue

                cx, cy = self.world_to_minimap(
                    x * self.engine.tile_size + self.engine.tile_size // 2,
                    y * self.engine.tile_size + self.engine.tile_size // 2,
                    px, py)
                if cx is None:
                    continue

                if obj_type == 'door':
                    is_open = props.get('open', False)
                    color = self.door_open_color if is_open else self.door_closed_color
                    pygame.draw.rect(screen, color,
                                     (cx - self.tile_px // 3, cy - self.tile_px // 3,
                                      self.tile_px * 2 // 3, self.tile_px * 2 // 3))
                else:
                    pygame.draw.circle(screen, self.key_color, (cx, cy),
                                       max(2, self.tile_px // 4))

    def _draw_triggers(self, screen, px, py):
        for y, row in enumerate(self.engine.map_data):
            for x, cell in enumerate(row):
                if cell['base_id'] != 8:
                    continue
                cx, cy = self.world_to_minimap(
                    x * self.engine.tile_size + self.engine.tile_size // 2,
                    y * self.engine.tile_size + self.engine.tile_size // 2,
                    px, py)
                if cx is None:
                    continue
                pygame.draw.rect(screen, self.trigger_color,
                                 (cx - 3, cy - 3, 6, 6), 1)

    def _draw_sprites_of_type(self, screen, px, py, is_model, color):
        for s in self.engine.sprite_manager.sprites:
            has_frames = hasattr(s, 'frames') or hasattr(s, 'frame_sets')
            if is_model != has_frames:
                continue
            if hasattr(s, 'visible') and not s.visible:
                continue
            cx, cy = self.world_to_minimap(s.x, s.y, px, py)
            if cx is None:
                continue
            pygame.draw.rect(screen, color, (cx - 2, cy - 2, 4, 4))

    def _draw_enemies(self, screen, px, py):
        for e in self.engine.enemies:
            if not e.alive:
                continue
            if not self.enemy_instant_visible and not getattr(e, 'show_on_minimap', True):
                continue
            cx, cy = self.world_to_minimap(e.x, e.y, px, py)
            if cx is None:
                continue
            pygame.draw.circle(screen, self.enemy_color, (cx, cy),
                               max(2, self.tile_px // 4))