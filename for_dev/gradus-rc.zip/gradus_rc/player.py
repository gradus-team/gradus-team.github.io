import pygame
import math

class Player:
    def __init__(self, x, y, angle=0.0, speed=4.0, rot_speed=0.08, hp=100, regeneration_speed=40, regeneration_value=1):
        self.pos = pygame.math.Vector2(x, y)
        self.angle = angle
        self.speed = speed
        self.rot_speed = rot_speed
        self.vel = pygame.math.Vector2(0, 0)
        self.max_hp = hp
        self.rs = regeneration_speed
        self.rv = regeneration_value
        self.rtimer = 0
        self.hp = self.max_hp
        self.alive = True
        self.on_death = None  # можно задать функцию

    def update(self, keys, dt):
        # Поворот
        self.rtimer += 1
        if self.rtimer >= self.rs:
            self.rtimer = 0
            self.hp += self.rv
            if self.hp >= self.max_hp:
                self.hp = self.max_hp
        if keys[pygame.K_LEFT]:
            self.angle -= self.rot_speed * dt
        if keys[pygame.K_RIGHT]:
            self.angle += self.rot_speed * dt

        # Векторы движения вперёд/назад и вбок
        forward = pygame.math.Vector2(math.cos(self.angle), math.sin(self.angle))
        side = pygame.math.Vector2(-math.sin(self.angle), math.cos(self.angle))

        self.vel = pygame.math.Vector2(0, 0)
        if keys[pygame.K_w]:
            self.vel += forward * self.speed
        if keys[pygame.K_s]:
            self.vel -= forward * self.speed
        if keys[pygame.K_a]:
            self.vel -= side * self.speed
        if keys[pygame.K_d]:
            self.vel += side * self.speed

        # Нормализация скорости, чтобы диагональ не была быстрее
        if self.vel.length() > self.speed:
            self.vel.scale_to_length(self.speed)
    def take_damage(self, damage):
        if not self.alive:
            return
        self.hp -= damage
        if self.hp <= 0:
            self.hp = 0
            self.alive = False
            if self.on_death:
                self.on_death()