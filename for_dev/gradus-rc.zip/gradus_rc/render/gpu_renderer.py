"""
GPU-accelerated offscreen renderer for Gradus RC — full version.
Shaders + context + textures + sprites + water + RTE + dynamic lights + cone light.
"""

from __future__ import annotations

import math
import os

os.environ.setdefault("__NV_PRIME_RENDER_OFFLOAD", "1")
os.environ.setdefault("__GLX_VENDOR_LIBRARY_NAME", "nvidia")

import numpy as np
import pygame

try:
    import moderngl
    _HAS_MODERNGL = True
except ImportError:
    _HAS_MODERNGL = False


# ==========================================================================
# Shaders
# ==========================================================================

_VERT = """
#version 330 core
in vec2 in_pos;
out vec2 v_uv;
void main() {
    v_uv = vec2(in_pos.x * 0.5 + 0.5, 0.5 - in_pos.y * 0.5);
    gl_Position = vec4(in_pos, 0.0, 1.0);
}
"""

_FRAG = """
#version 330 core
#define MAX_LIGHTS 64
#define MAX_SPRITES 18

in vec2 v_uv;
out vec4 frag_color;

uniform sampler2D u_meta;
uniform sampler2D u_atlas;
uniform sampler2D u_floor_tex;
uniform sampler2D u_ceiling_tex;
uniform sampler2D u_water_mask;
uniform sampler2D u_sprite_atlas;

uniform vec2  u_map_size;
uniform vec2  u_player_pos;
uniform vec2  u_camera_dir;
uniform vec2  u_camera_plane;
uniform float u_max_depth;
uniform float u_pitch_offset;

uniform float u_proj_coeff;
uniform float u_tile_size;
uniform float u_screen_h;

uniform bool  u_use_floor_tex;
uniform bool  u_use_ceiling_tex;
uniform vec3  u_floor_color;
uniform vec3  u_ceiling_color;
uniform vec3  u_water_color;

uniform int   u_num_lights;
uniform vec2  u_light_pos[MAX_LIGHTS];
uniform vec3  u_light_color[MAX_LIGHTS];
uniform float u_light_radius[MAX_LIGHTS];
uniform float u_light_intensity[MAX_LIGHTS];

uniform int   u_num_dynamic_lights;
uniform vec2  u_dyn_light_pos[16];
uniform vec3  u_dyn_light_color[16];
uniform float u_dyn_light_radius[16];
uniform float u_dyn_light_intensity[16];

uniform int   u_player_light_mode;    // 0 = default, 1 = circle
uniform float u_player_light_range;   // range (tiles)
uniform float u_player_light_cone;    // cos(half_angle)

uniform float u_ambient;

uniform bool  u_fog_enabled;
uniform vec3  u_fog_color;
uniform float u_fog_start;
uniform float u_fog_end;

uniform vec4  u_mat_uv[64];
uniform float u_mat_reflection[64];

uniform int   u_num_sprites;
uniform vec2  u_sprite_pos[MAX_SPRITES];
uniform float u_sprite_radius[MAX_SPRITES];
uniform vec4  u_sprite_uv[MAX_SPRITES];

uniform bool  u_rt_enabled;
uniform int   u_rt_max_lights;
uniform bool  u_rt_reflections;

// ==========================================================================
// Helpers
// ==========================================================================

vec3 apply_fog(vec3 col, float dist) {
    if (!u_fog_enabled) return col;
    float t = clamp((dist - u_fog_start) / max(1.0, u_fog_end - u_fog_start), 0.0, 1.0);
    return mix(col, u_fog_color, t);
}

// Soft, non-abrupt falloff — cubic + smoothstep at the edge
float light_falloff(float d_norm) {
    if (d_norm >= 1.0) return 0.0;
    float f = 1.0 - d_norm;
    f = f * f * f;
    f *= smoothstep(0.0, 0.15, 1.0 - d_norm);
    return f;
}

float shadow_visibility(vec2 from, vec2 to) {
    vec2 d = to - from;
    float t_max = length(d);
    if (t_max < 1e-4) return 1.0;
    vec2 dir = d / t_max;

    ivec2 mp = ivec2(floor(from));
    vec2 ad = max(abs(dir), vec2(1e-6));
    vec2 delta = 1.0 / ad;
    ivec2 stp = ivec2(sign(dir));
    stp.x = stp.x == 0 ? 1 : stp.x;
    stp.y = stp.y == 0 ? 1 : stp.y;

    vec2 sd;
    sd.x = (dir.x > 0.0) ? (float(mp.x + 1) - from.x) * delta.x
                         : (from.x - float(mp.x)) * delta.x;
    sd.y = (dir.y > 0.0) ? (float(mp.y + 1) - from.y) * delta.y
                         : (from.y - float(mp.y)) * delta.y;

    float opacity = 0.0;
    for (int i = 0; i < 64; ++i) {
        if (sd.x < sd.y) { sd.x += delta.x; mp.x += stp.x; }
        else             { sd.y += delta.y; mp.y += stp.y; }

        if (sd.x > t_max && sd.y > t_max) break;
        if (mp.x < 0 || mp.y < 0 ||
            mp.x >= int(u_map_size.x) || mp.y >= int(u_map_size.y)) break;

        vec4 meta = texelFetch(u_meta, mp, 0);
        if (meta.r > 0.5) {
            opacity += max(meta.a, 0.05);
            if (opacity > 0.9) return 0.0;
        }
    }

    for (int s = 0; s < MAX_SPRITES; ++s) {
        if (s >= u_num_sprites) break;
        vec2 sp = u_sprite_pos[s];
        float sr = u_sprite_radius[s];
        vec2 ab = to - from;
        vec2 ap = sp - from;
        float ab_len2 = max(dot(ab, ab), 1e-6);
        float t = clamp(dot(ap, ab) / ab_len2, 0.0, 1.0);
        vec2 closest = from + ab * t;
        float d2 = dot(sp - closest, sp - closest);
        if (d2 < sr * sr) {
            opacity += 0.6;
            if (opacity > 0.9) return 0.0;
        }
    }
    return clamp(1.0 - opacity, 0.0, 1.0);
}

// -- Simple lighting (no shadows, used in reflections) --------------------
vec3 apply_lighting_simple(vec3 col, vec2 world_pos, float dist) {
    vec3 total = vec3(u_ambient);
    for (int i = 0; i < MAX_LIGHTS; ++i) {
        if (i >= u_num_lights) break;
        vec2 d = u_light_pos[i] - world_pos;
        float dist2 = dot(d, d);
        float r2 = u_light_radius[i] * u_light_radius[i];
        if (dist2 > r2) continue;
        float f = light_falloff(sqrt(dist2) / max(u_light_radius[i], 1e-3));
        total += (u_light_color[i] / 255.0) * u_light_intensity[i] * f;
    }
    for (int i = 0; i < 16; ++i) {
        if (i >= u_num_dynamic_lights) break;
        vec2 d = u_dyn_light_pos[i] - world_pos;
        float dist2 = dot(d, d);
        float r2 = u_dyn_light_radius[i] * u_dyn_light_radius[i];
        if (dist2 > r2) continue;
        float f = light_falloff(sqrt(dist2) / max(u_dyn_light_radius[i], 1e-3));
        total += (u_dyn_light_color[i] / 255.0) * u_dyn_light_intensity[i] * f;
    }
    total += vec3(0.4 * exp(-dist * 0.06));
    total = max(total, vec3(0.12));
    return col * total;
}

// -- Main lighting with shadows + dynamic lights + cone -------------------
vec3 apply_lighting(vec3 col, vec2 world_pos, float dist, vec2 surf_normal) {
    vec3 total = vec3(u_ambient);
    for (int i = 0; i < MAX_LIGHTS; ++i) {
        if (i >= u_num_lights) break;
        vec2 d = u_light_pos[i] - world_pos;
        float dist2 = dot(d, d);
        float r2 = u_light_radius[i] * u_light_radius[i];
        if (dist2 > r2) continue;

        float shade = 1.0;
        if (u_rt_enabled && i < u_rt_max_lights && dist2 > 0.01) {
            vec2 dir = normalize(d);
            vec2 origin = world_pos + surf_normal * 0.1 + dir * 0.02;
            shade = shadow_visibility(origin, u_light_pos[i]);
        }
        float f = light_falloff(sqrt(dist2) / max(u_light_radius[i], 1e-3));
        total += (u_light_color[i] / 255.0) * u_light_intensity[i] * f * shade;
    }

    for (int i = 0; i < 16; ++i) {
        if (i >= u_num_dynamic_lights) break;
        vec2 d = u_dyn_light_pos[i] - world_pos;
        float dist2 = dot(d, d);
        float r2 = u_dyn_light_radius[i] * u_dyn_light_radius[i];
        if (dist2 > r2) continue;
        float f = light_falloff(sqrt(dist2) / max(u_dyn_light_radius[i], 1e-3));
        total += (u_dyn_light_color[i] / 255.0) * u_dyn_light_intensity[i] * f;
    }
    
    // Мягкий bloom от ярких источников
    float bloom = length(total);
    if (bloom > 1.0) {
        total = mix(total, total * 1.4, min((bloom - 1.0) * 0.3, 0.5));
    }

    total += vec3(0.4 * exp(-dist * 0.06));
    total = max(total, vec3(0.12));
    return col * total;
}

// -- Player cone light overlay (applied at the end of the wall/floor pass) -
vec3 apply_player_cone(vec3 col, vec2 world_pos, vec2 view_dir) {
    if (u_player_light_mode != 1) return col;
    vec2 to_pt = world_pos - u_player_pos;
    float pd = length(to_pt);
    if (pd >= u_player_light_range) return col;
    vec2 pt_dir = to_pt / max(pd, 1e-4);
    float cone = dot(pt_dir, view_dir);
    if (cone <= u_player_light_cone) return col;
    float t = (cone - u_player_light_cone) /
              max(1.0 - u_player_light_cone, 1e-4);
    float dfall = 1.0 - pd / u_player_light_range;
    dfall = dfall * dfall;
    return col * (1.0 + 2.0 * t * dfall);
}

// ==========================================================================
// Reflection tracer (mirror + water)
// ==========================================================================
vec3 trace_reflection(vec2 pos, vec2 dir, float v_coord, float v_fh, float f_px_val) {
    float v_abs_val = abs(v_fh);
    float refl_row_dist = 1e30;
    bool refl_is_floor = v_fh > 0.0;

    if (v_abs_val > 1e-6) {
        refl_row_dist = (0.5 * f_px_val) / (v_abs_val * u_screen_h);
    }

    vec3 refl_bg;
    if (refl_row_dist < u_max_depth) {
        vec2 refl_world = pos + dir * refl_row_dist;
        vec2 uv = fract(refl_world);
        if (refl_is_floor) {
            refl_bg = u_use_floor_tex ? texture(u_floor_tex, uv).rgb : u_floor_color;
        } else {
            refl_bg = u_use_ceiling_tex ? texture(u_ceiling_tex, uv).rgb : u_ceiling_color;
        }
        refl_bg = apply_lighting_simple(refl_bg, refl_world, refl_row_dist);
        refl_bg = apply_fog(refl_bg, refl_row_dist);
    } else {
        refl_bg = u_fog_enabled ? u_fog_color : vec3(0.05, 0.05, 0.10);
    }

    ivec2 mp = ivec2(floor(pos));
    vec2 d = max(abs(dir), vec2(1e-6));
    vec2 delta = 1.0 / d;
    ivec2 stp = ivec2(sign(dir));
    stp.x = stp.x == 0 ? 1 : stp.x;
    stp.y = stp.y == 0 ? 1 : stp.y;

    vec2 sd;
    sd.x = (dir.x > 0.0) ? (float(mp.x + 1) - pos.x) * delta.x
                         : (pos.x - float(mp.x)) * delta.x;
    sd.y = (dir.y > 0.0) ? (float(mp.y + 1) - pos.y) * delta.y
                         : (pos.y - float(mp.y)) * delta.y;

    float best_wall_dist = 1e30;
    vec3  best_wall_col  = vec3(0.0);
    bool  wall_found     = false;

    int side = 0;
    for (int i = 0; i < 64; ++i) {
        if (sd.x < sd.y) { sd.x += delta.x; mp.x += stp.x; side = 0; }
        else             { sd.y += delta.y; mp.y += stp.y; side = 1; }

        if (mp.x < 0 || mp.y < 0 ||
            mp.x >= int(u_map_size.x) || mp.y >= int(u_map_size.y)) break;

        vec4 meta = texelFetch(u_meta, mp, 0);
        if (meta.r > 0.5 && meta.a > 0.5) {
            float wall_dist = (side == 0) ? sd.x - delta.x : sd.y - delta.y;
            if (wall_dist > refl_row_dist) break;

            vec2 hit = pos + dir * wall_dist;
            float wx = (side == 0) ? fract(hit.y) : fract(hit.x);
            int mi = int(meta.g);
            float wh = max(meta.b, 0.05);

            float wall_px = u_proj_coeff / max(wall_dist * u_tile_size, 0.01);
            float wall_half_h = wall_px / u_screen_h * wh;
            float refl_v_val = (v_fh + wall_half_h) / max(2.0 * wall_half_h, 1e-5);
            refl_v_val = clamp(refl_v_val, 0.0, 1.0);

            vec4 uv_rect = u_mat_uv[mi];
            float u = mix(uv_rect.x, uv_rect.z, wx);
            float v = mix(uv_rect.y, uv_rect.w, refl_v_val);
            vec3 c = texture(u_atlas, vec2(u, v)).rgb;
            c *= (side == 1) ? 0.72 : 1.0;
            c = apply_lighting_simple(c, hit, wall_dist);
            c = apply_fog(c, wall_dist);

            best_wall_dist = wall_dist;
            best_wall_col  = c;
            wall_found     = true;
            break;
        }
    }

    // Sprite hit
    float sprite_limit = wall_found ? best_wall_dist : refl_row_dist;
    int   sprite_hit   = -1;
    float sprite_best  = sprite_limit;
    for (int s = 0; s < MAX_SPRITES; ++s) {
        if (s >= u_num_sprites) break;
        vec2 sp = u_sprite_pos[s];
        float sr = u_sprite_radius[s];
        vec2 to_sp = sp - pos;
        float t = dot(to_sp, dir);
        if (t < 0.0 || t >= sprite_best) continue;
        vec2 cp = pos + dir * t;
        float d2 = dot(sp - cp, sp - cp);
        if (d2 < sr * sr) {
            sprite_best = t;
            sprite_hit = s;
        }
    }

    if (sprite_hit >= 0) {
        vec4 sp_uv = u_sprite_uv[sprite_hit];
        vec2 perp = vec2(-dir.y, dir.x);
        vec2 closest_pt = pos + dir * sprite_best;
        float u_off = dot(perp, closest_pt - u_sprite_pos[sprite_hit]);
        float su = clamp(0.5 + u_off / max(2.0 * u_sprite_radius[sprite_hit], 1e-5), 0.0, 1.0);
        float sv = clamp(v_coord, 0.0, 1.0);
        float u = mix(sp_uv.x, sp_uv.z, su);
        float v = mix(sp_uv.y, sp_uv.w, sv);
        vec4 sc4 = texture(u_sprite_atlas, vec2(u, v));
        if (sc4.a > 0.15) {                       // ← 0.3 → 0.15, ловим полупрозрачные пиксели
            vec3 sc = sc4.rgb;
            sc = apply_lighting_simple(sc, u_sprite_pos[sprite_hit], sprite_best);
            sc = apply_fog(sc, sprite_best);
            return min(sc, vec3(0.85));           // ← ЗДЕСЬ №1 — потолок яркости
        }
    }

    if (wall_found) return min(best_wall_col, vec3(0.85));  // ← ЗДЕСЬ №2
    return min(refl_bg, vec3(0.85));                        // ← ЗДЕСЬ №3
}

// ==========================================================================
// Main
// ==========================================================================
void main() {
    float ndc_x = v_uv.x * 2.0 - 1.0;
    vec2 ray_dir = u_camera_dir + u_camera_plane * ndc_x;
    vec2 ray_dir_n = normalize(ray_dir);
    float cos_ray = dot(ray_dir_n, u_camera_dir);

    float horizon_uv     = 0.5 + u_pitch_offset;
    float v_from_horizon = v_uv.y - horizon_uv;
    float v_abs          = abs(v_from_horizon);

    float f_px = u_proj_coeff / max(u_tile_size, 1e-3);

    float row_dist;
    bool  is_floor;
    if (v_abs < 1e-6) {
        row_dist = 1e30;
        is_floor = true;
    } else {
        row_dist = (0.5 * f_px) / (v_abs * u_screen_h);
        is_floor = v_from_horizon > 0.0;
    }

    // ---- Water floor detection ----
    bool  is_water_floor    = false;
    float water_refl_amount = 0.0;
    float refl_v            = 0.0;
    vec3  refl_ceiling_col  = vec3(0.0);

    if (is_floor && row_dist < u_max_depth) {
        vec2 world_pos_floor = u_player_pos + ray_dir * row_dist;
        ivec2 tile = ivec2(floor(world_pos_floor));
        if (tile.x >= 0 && tile.y >= 0 &&
            tile.x < int(u_map_size.x) && tile.y < int(u_map_size.y)) {
            vec4 wm = texelFetch(u_water_mask, tile, 0);
            if (wm.r > 0.5) {
                is_water_floor    = true;
                water_refl_amount = wm.g;
                refl_v            = 2.0 * horizon_uv - v_uv.y;
                vec2 uv = fract(world_pos_floor);
                refl_ceiling_col = u_use_ceiling_tex
                    ? texture(u_ceiling_tex, uv).rgb : u_ceiling_color;
                refl_ceiling_col = apply_lighting_simple(refl_ceiling_col,
                                                          world_pos_floor, row_dist);
                refl_ceiling_col = apply_fog(refl_ceiling_col, row_dist);
            }
        }
    }

    // ---- Floor / ceiling background ----
    vec3 background;
    if (row_dist < u_max_depth) {
        vec2 world_pos = u_player_pos + ray_dir * row_dist;
        vec2 uv = fract(world_pos);
        if (is_floor) {
            background = u_use_floor_tex ? texture(u_floor_tex, uv).rgb : u_floor_color;
        } else {
            background = u_use_ceiling_tex ? texture(u_ceiling_tex, uv).rgb : u_ceiling_color;
        }
        background = apply_lighting(background, world_pos, row_dist, vec2(0.0));
        background = apply_player_cone(background, world_pos, ray_dir_n);
        background = apply_fog(background, row_dist);
    } else {
        background = u_fog_enabled ? u_fog_color : vec3(0.05, 0.05, 0.10);
    }

    // ---- Wall march ----
    vec3  accum       = vec3(0.0);
    float alpha_accum = 0.0;
    bool  refl_wall_found = false;
    vec3  refl_wall_col  = vec3(0.0);

    ivec2 mp = ivec2(floor(u_player_pos));
    vec2 d       = max(abs(ray_dir), vec2(1e-6));
    vec2 delta   = 1.0 / d;
    ivec2 stp    = ivec2(sign(ray_dir));
    stp.x = stp.x == 0 ? 1 : stp.x;
    stp.y = stp.y == 0 ? 1 : stp.y;

    vec2 sd;
    sd.x = (ray_dir.x > 0.0) ? (float(mp.x + 1) - u_player_pos.x) * delta.x
                             : (u_player_pos.x - float(mp.x)) * delta.x;
    sd.y = (ray_dir.y > 0.0) ? (float(mp.y + 1) - u_player_pos.y) * delta.y
                             : (u_player_pos.y - float(mp.y)) * delta.y;

    int side = 0;
    for (int i = 0; i < 128; ++i) {
        if (sd.x < sd.y) { sd.x += delta.x; mp.x += stp.x; side = 0; }
        else             { sd.y += delta.y; mp.y += stp.y; side = 1; }

        if (mp.x < 0 || mp.y < 0 ||
            mp.x >= int(u_map_size.x) || mp.y >= int(u_map_size.y)) break;

        vec4 meta = texelFetch(u_meta, mp, 0);
        if (meta.r < 0.5) continue;

        float wall_dist_along = (side == 0) ? sd.x - delta.x : sd.y - delta.y;
        float wall_dist_perp  = wall_dist_along * cos_ray;
        if (wall_dist_perp > u_max_depth) break;

        int   mat_idx = int(meta.g);
        float wh      = max(meta.b, 0.05);
        float walpha  = clamp(meta.a, 0.0, 1.0);
        float wref    = u_mat_reflection[mat_idx];

        float wall_px     = u_proj_coeff / max(wall_dist_perp * u_tile_size, 0.01);
        float line_h_full = wall_px / u_screen_h;
        float line_h      = line_h_full * wh;
        float wall_bot_uv = horizon_uv + line_h_full * 0.5;
        float wall_top_uv = wall_bot_uv - line_h;

        vec2 hit = u_player_pos + ray_dir * wall_dist_along;
        float wx = (side == 0) ? fract(hit.y) : fract(hit.x);
        vec4 uv_rect = u_mat_uv[mat_idx];
        float u_tex = mix(uv_rect.x, uv_rect.z, wx);

        if (v_uv.y >= wall_top_uv && v_uv.y <= wall_bot_uv) {
            float v_local = (v_uv.y - wall_top_uv) / max(line_h, 1e-5);
            float v_tex = mix(uv_rect.y, uv_rect.w, v_local);
            vec3 wcol = texture(u_atlas, vec2(u_tex, v_tex)).rgb;
            wcol *= (side == 1) ? 0.72 : 1.0;

            vec2 surf_normal = (side == 1)
                ? vec2(0.0, (ray_dir.y > 0.0) ? -1.0 : 1.0)
                : vec2((ray_dir.x > 0.0) ? -1.0 : 1.0, 0.0);

            // сначала освещение
            wcol = apply_lighting(wcol, hit, wall_dist_perp, surf_normal);
            
            // потом отражение — оно УЖЕ освещено внутри trace_reflection
            if (u_rt_enabled && u_rt_reflections && wref > 0.05) {
                vec2 refl_origin = hit + surf_normal * 0.03;
                vec2 refl_raw    = ray_dir - 2.0 * dot(ray_dir, surf_normal) * surf_normal;
                vec2 refl_dir    = normalize(refl_raw);
                vec3 refl_col    = trace_reflection(refl_origin, refl_dir,
                                                     v_local, v_from_horizon, f_px);
                refl_col = min(refl_col, vec3(0.85));   // ← потолок
                refl_col *= 0.85;
                float ndv  = abs(dot(ray_dir_n, surf_normal));
                float fres = pow(1.0 - ndv, 5.0);   // убирает пересвет у лобового угла
                float amount = wref * mix(0.35, 1.0, fres);
                // Ограничиваем максимум чтобы не было белого
                amount = min(amount, 0.95);
                wcol = mix(wcol, refl_col, amount);
            }
            
            wcol = apply_player_cone(wcol, hit, ray_dir_n);
            wcol = apply_fog(wcol, wall_dist_perp);

            accum       += (1.0 - alpha_accum) * wcol * walpha;
            alpha_accum += (1.0 - alpha_accum) * walpha;

            if (alpha_accum > 0.995) break;
            if (walpha     > 0.995) break;
        }

        if (is_water_floor && !refl_wall_found && walpha > 0.5) {
            if (refl_v >= wall_top_uv && refl_v <= wall_bot_uv) {
                float refl_v_local = (refl_v - wall_top_uv) / max(line_h, 1e-5);
                float v_refl = mix(uv_rect.y, uv_rect.w, refl_v_local);
                refl_wall_col = texture(u_atlas, vec2(u_tex, v_refl)).rgb;
                refl_wall_col *= (side == 1) ? 0.72 : 1.0;
                refl_wall_col = apply_lighting_simple(refl_wall_col, hit, wall_dist_perp);
                refl_wall_col = apply_fog(refl_wall_col, wall_dist_perp);
                refl_wall_found = true;
            }
        }
    }

    if (is_water_floor) {
        vec3 reflected = refl_wall_found ? refl_wall_col : refl_ceiling_col;
        background = mix(u_water_color, reflected, water_refl_amount);
    }

    vec3 col = accum + (1.0 - alpha_accum) * background;
    frag_color = vec4(col, 1.0);
}
"""


# ==========================================================================
# Renderer class
# ==========================================================================

class GPURaycaster:
    ATLAS_COLS = 8
    ATLAS_ROWS = 8
    SLOT_SIZE = 64
    MAX_MATERIALS = 64
    MAX_SPRITES = 18
    MAX_LIGHTS = 64
    MAX_DYN_LIGHTS = 16
    SPRITE_ATLAS_COLS = 8
    SPRITE_SLOT = 256

    def __init__(self, width: int, height: int):
        if not _HAS_MODERNGL:
            raise RuntimeError("moderngl is not installed. pip install moderngl")

        self.width = int(width)
        self.height = int(height)

        self.ctx = moderngl.create_standalone_context(require=330)

        try:
            vendor = self.ctx.info.get('GL_VENDOR', '?')
            renderer = self.ctx.info.get('GL_RENDERER', '?')
            print(f"[GPU] {vendor} | {renderer}")
            vl = vendor.lower()
            if 'intel' in vl or 'soft' in vl or 'mesa' in vl or 'llvmpipe' in vl:
                print("[GPU] WARNING: integrated/software GPU. "
                      "On Windows assign python.exe to high-performance GPU.")
        except Exception:
            pass

        self.color_tex = self.ctx.texture((self.width, self.height), 4)
        self.depth_tex = self.ctx.depth_texture((self.width, self.height))
        self.fbo = self.ctx.framebuffer(
            color_attachments=[self.color_tex],
            depth_attachment=self.depth_tex,
        )

        self.prog = self.ctx.program(vertex_shader=_VERT, fragment_shader=_FRAG)

        quad = np.array([
            -1.0, -1.0,  1.0, -1.0,  1.0,  1.0,
            -1.0, -1.0,  1.0,  1.0, -1.0,  1.0,
        ], dtype='f4')
        self.vbo = self.ctx.buffer(quad.tobytes())
        self.vao = self.ctx.vertex_array(self.prog, [(self.vbo, '2f', 'in_pos')])

        self.map_meta = None
        self.map_w = 0
        self.map_h = 0
        self.tile_size = 1.0
        self.atlas_tex = None
        self.mat_uv = np.zeros((self.MAX_MATERIALS, 4), dtype='f4')
        self.mat_reflection = np.zeros(self.MAX_MATERIALS, dtype='f4')
        self.num_materials = 0

        self._floor_tex = None
        self._ceil_tex = None
        self._use_floor_tex = False
        self._use_ceiling_tex = False
        self._floor_color_norm = (0.15, 0.12, 0.08)
        self._ceiling_color_norm = (0.08, 0.08, 0.15)

        self._saved_floor_texture = None
        self._saved_ceiling_texture = None
        self._saved_floor_color = (40, 30, 20)
        self._saved_ceiling_color = (20, 20, 40)

        self._map_dirty = False

        # Water
        self._water_mask_tex = None
        self._water_color_norm = (0.1, 0.2, 0.4)
        self._saved_water_color = (30, 60, 120)

        self._sprite_atlas_cooldown = 0.0

        # Sprites
        self._sprite_count = 0
        self._sprite_pos = np.zeros((self.MAX_SPRITES, 2), dtype='f4')
        self._sprite_radius = np.zeros(self.MAX_SPRITES, dtype='f4')
        self._sprite_atlas_uv = np.zeros((self.MAX_SPRITES, 4), dtype='f4')
        self._sprite_atlas_tex = None
        self._last_sprite_keys = None

        dummy = np.array([[[255, 255, 255, 255]]], dtype='u1')
        self._sprite_atlas_tex = self.ctx.texture((1, 1), 4, dummy.tobytes())
        self._sprite_atlas_tex.filter = (moderngl.LINEAR, moderngl.LINEAR)

        wm_dummy = np.zeros((1, 1, 4), dtype='f4')
        self._water_mask_tex = self.ctx.texture((1, 1), 4, wm_dummy.tobytes(), dtype='f4')
        self._water_mask_tex.filter = (moderngl.NEAREST, moderngl.NEAREST)

    # ------------------------------------------------------------------
    # Textures
    # ------------------------------------------------------------------

    def _make_solid_tex(self, color):
        arr = np.zeros((4, 4, 4), dtype='u1')
        arr[:, :, 0] = int(color[0])
        arr[:, :, 1] = int(color[1])
        arr[:, :, 2] = int(color[2])
        arr[:, :, 3] = 255
        tex = self.ctx.texture((4, 4), 4, arr.tobytes())
        tex.repeat_x = True
        tex.repeat_y = True
        tex.filter = (moderngl.NEAREST, moderngl.NEAREST)
        return tex

    def _upload_pygame_tex(self, surf: pygame.Surface):
        try:
            surf = surf.convert_alpha()
        except Exception:
            pass
        w, h = surf.get_size()
        raw = pygame.image.tostring(surf, "RGBA", False)
        tex = self.ctx.texture((w, h), 4, raw)
        tex.repeat_x = True
        tex.repeat_y = True
        tex.filter = (moderngl.NEAREST, moderngl.NEAREST)
        return tex

    # ------------------------------------------------------------------
    # Sprite helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _get_sprite_texture(sprite):
        if hasattr(sprite, 'frame_sets') and sprite.frame_sets:
            fs = sprite.frame_sets
            idx = getattr(sprite, 'current_frame_index', 0)
            if 0 <= idx < len(fs) and fs[idx]:
                angle_idx = getattr(sprite, 'current_angle_frame', 0)
                if 0 <= angle_idx < len(fs[idx]):
                    return fs[idx][angle_idx]
        if hasattr(sprite, 'frames') and sprite.frames:
            return sprite.frames[0]
        if hasattr(sprite, 'texture'):
            return sprite.texture
        return None

    def _build_sprite_atlas(self, sprites):
        cols = self.SPRITE_ATLAS_COLS
        slot = self.SPRITE_SLOT
        atlas_w = cols * slot
        atlas_h = cols * slot
        atlas = np.zeros((atlas_h, atlas_w, 4), dtype='u1')
        atlas[:, :, 3] = 255
        self._sprite_atlas_uv[:] = 0.0

        for i, sprite in enumerate(sprites[:self.MAX_SPRITES]):
            cx = i % cols
            cy = i // cols
            px, py = cx * slot, cy * slot
            tex = self._get_sprite_texture(sprite)

            if tex is not None:
                try:
                    if tex.get_width() != slot or tex.get_height() != slot:
                        tex = pygame.transform.scale(tex, (slot, slot))
                    if (tex.get_flags() & pygame.SRCALPHA) == 0:
                        try: tex = tex.convert_alpha()
                        except: pass
                    raw = pygame.image.tostring(tex, "RGBA", False)
                    sub = np.frombuffer(raw, dtype=np.uint8).reshape(slot, slot, 4)
                    atlas[py:py + slot, px:px + slot, :] = sub
                except Exception:
                    atlas[py:py + slot, px:px + slot, :3] = 255
                    atlas[py:py + slot, px:px + slot, 3] = 0
            else:
                atlas[py:py + slot, px:px + slot, :3] = 255
                atlas[py:py + slot, px:px + slot, 3] = 0

            self._sprite_atlas_uv[i] = (px / atlas_w, py / atlas_h,
                                        (px + slot) / atlas_w, (py + slot) / atlas_h)

        if self._sprite_atlas_tex is not None:
            try: self._sprite_atlas_tex.release()
            except: pass
        self._sprite_atlas_tex = self.ctx.texture((atlas_w, atlas_h), 4, atlas.tobytes())
        self._sprite_atlas_tex.filter = (moderngl.LINEAR, moderngl.LINEAR)

    def update_sprites(self, sprites):
        if sprites is None or len(sprites) == 0:
            self._sprite_count = 0
            self._last_sprite_keys = None
            return

        n = min(len(sprites), self.MAX_SPRITES)

        if not isinstance(sprites[0], (tuple, list)):
            current_keys = tuple(id(s) for s in sprites[:n])
            need_rebuild = (current_keys != self._last_sprite_keys)
            if need_rebuild or self._sprite_atlas_cooldown <= 0.0:
                self._build_sprite_atlas(sprites)
                self._last_sprite_keys = current_keys
                self._sprite_atlas_cooldown = 0.5  # не чаще 2 раз/сек
            else:
                self._sprite_atlas_cooldown -= 1.0 / 60.0  # приблизительно

        for i, s in enumerate(sprites[:n]):
            try:
                if isinstance(s, (tuple, list)):
                    x, y = float(s[0]), float(s[1])
                    r = float(s[2]) if len(s) > 2 else 20.0
                elif hasattr(s, 'x') and hasattr(s, 'y'):
                    x, y = float(s.x), float(s.y)
                    if getattr(s, 'world_radius', None):
                        r = float(s.world_radius)
                    elif getattr(s, 'shadow_radius', None):
                        r = float(s.shadow_radius)
                    else:
                        r = 0.75 * self.tile_size
                else:
                    # Не поддерживаемый объект — просто пропускаем
                    self._sprite_pos[i] = (0.0, 0.0)
                    self._sprite_radius[i] = 0.0
                    continue
            except Exception:
                self._sprite_pos[i] = (0.0, 0.0)
                self._sprite_radius[i] = 0.0
                continue

            self._sprite_pos[i] = (x / self.tile_size, y / self.tile_size)
            self._sprite_radius[i] = r / self.tile_size
        self._sprite_count = n

    # ------------------------------------------------------------------
    # Level setup
    # ------------------------------------------------------------------

    def setup_level(self, map_data, tile_size, material_lib,
                    floor_texture=None, ceiling_texture=None,
                    floor_color=(40, 30, 20), ceiling_color=(20, 20, 40),
                    water_color=(30, 60, 120)):
        self.tile_size = float(tile_size)
        self._saved_floor_texture = floor_texture
        self._saved_ceiling_texture = ceiling_texture
        self._saved_floor_color = tuple(floor_color) if floor_color else (40, 30, 20)
        self._saved_ceiling_color = tuple(ceiling_color) if ceiling_color else (20, 20, 40)
        self._saved_water_color = tuple(water_color) if water_color else (30, 60, 120)

        h = len(map_data) if map_data else 0
        if h == 0:
            return

        row_lens = [len(r) for r in map_data]
        w = max(row_lens) if row_lens else 0
        if len(set(row_lens)) > 1:
            print(f"[GPU] WARNING: map rows have different widths: "
                  f"min={min(row_lens)} max={max(row_lens)}")
        self.map_w, self.map_h = w, h

        meta = np.zeros((h, w, 4), dtype='f4')
        water_mask = np.zeros((h, w, 4), dtype='f4')
        mat_key_to_idx = {}
        mat_list = []

        def get_or_add_mat(name, tint, alpha):
            key = (name, tint)
            if key in mat_key_to_idx:
                return mat_key_to_idx[key]
            if len(mat_list) >= self.MAX_MATERIALS:
                return 0
            idx = len(mat_list)
            mat_key_to_idx[key] = idx
            mat_list.append((name, tint, alpha))
            return idx

        for y in range(h):
            row = map_data[y]
            row_w = len(row)
            for x in range(w):
                if x >= row_w:
                    meta[y, x] = [0.0, 0.0, 1.0, 1.0]
                    continue

                cell = row[x]
                try:
                    bid = int(cell.get('base_id', 0))
                except (TypeError, ValueError):
                    bid = 0
                props = cell.get('properties', {}) or {}
                if not isinstance(props, dict):
                    props = {}

                blocking = self._is_blocking(bid, props)

                def _f(v, d):
                    try:
                        return float(v)
                    except (TypeError, ValueError):
                        return d

                height = _f(props.get('height', 1.0), 1.0)
                alpha  = max(0.0, min(1.0, _f(props.get('alpha', 1.0), 1.0)))

                mat_name = props.get('material') or props.get('sprite')
                if mat_name is None or not isinstance(mat_name, str):
                    mat_name = str(bid)

                tint_hex = props.get('color', None)
                if isinstance(tint_hex, str):
                    try:
                        tint = self._hex_to_rgb(tint_hex)
                    except Exception:
                        tint = None
                elif isinstance(tint_hex, (tuple, list)) and len(tint_hex) == 3:
                    tint = tuple(int(c) for c in tint_hex)
                else:
                    tint = None

                mat_idx = 0
                if blocking:
                    mat_idx = get_or_add_mat(mat_name, tint, alpha)

                meta[y, x] = [1.0 if blocking else 0.0,
                              float(mat_idx), height, alpha]

                is_water = bool(props.get('water', False))
                is_puddle = bool(props.get('puddle', False))
                if is_water or is_puddle:
                    default_refl = 0.6 if is_water else 0.3
                    refl = _f(props.get('reflectivity', default_refl), default_refl)
                    water_mask[y, x] = [1.0, max(0.0, min(1.0, refl)), 0.0, 0.0]

        if self.map_meta is not None:
            try: self.map_meta.release()
            except: pass
        self.map_meta = self.ctx.texture((w, h), 4, meta.tobytes(), dtype='f4')
        self.map_meta.filter = (moderngl.NEAREST, moderngl.NEAREST)

        if self._water_mask_tex is not None:
            try: self._water_mask_tex.release()
            except: pass
        self._water_mask_tex = self.ctx.texture((w, h), 4, water_mask.tobytes(), dtype='f4')
        self._water_mask_tex.filter = (moderngl.NEAREST, moderngl.NEAREST)

        self._build_atlas(mat_list, material_lib)

        if floor_texture is not None:
            self._floor_tex = self._upload_pygame_tex(floor_texture)
            self._use_floor_tex = True
        else:
            self._floor_tex = self._make_solid_tex(floor_color)
            self._use_floor_tex = False

        if ceiling_texture is not None:
            self._ceil_tex = self._upload_pygame_tex(ceiling_texture)
            self._use_ceiling_tex = True
        else:
            self._ceil_tex = self._make_solid_tex(ceiling_color)
            self._use_ceiling_tex = False

        self._floor_color_norm   = tuple(c / 255.0 for c in floor_color[:3])
        self._ceiling_color_norm = tuple(c / 255.0 for c in ceiling_color[:3])
        self._water_color_norm   = tuple(c / 255.0 for c in
                                          (water_color[:3] if water_color else (30, 60, 120)))

    def _is_blocking(self, bid, props) -> bool:
        if bid == 0: return False
        if not props.get('isvisible', True): return False
        if bid == 8: return False
        if bid == 7:
            ptype = props.get('type')
            if ptype == 'key': return False
            if ptype == 'door' and props.get('open', False): return False
        if bid == 9 and not props.get('isvisible', False): return False
        if bid == 6: return False
        return True

    def _build_atlas(self, mat_list, material_lib):
        cols, rows = self.ATLAS_COLS, self.ATLAS_ROWS
        slot = self.SLOT_SIZE
        atlas_w = cols * slot
        atlas_h = rows * slot

        atlas = np.zeros((atlas_h, atlas_w, 4), dtype='u1')
        atlas[:, :, 3] = 255
        self.mat_uv[:] = 0.0
        self.mat_reflection[:] = 0.0

        for idx, (name, tint, alpha) in enumerate(mat_list):
            if idx >= self.MAX_MATERIALS:
                break
            cx = idx % cols
            cy = idx // cols
            px, py = cx * slot, cy * slot

            mat = None
            if material_lib is not None:
                try: mat = material_lib.get_material(name)
                except: mat = None
                if mat is None:
                    try: mat = material_lib.get_default()
                    except: mat = None

            refl = 0.0
            if mat is not None:
                refl = float(getattr(mat, 'reflection', 0.0) or 0.0)
                refl = max(0.0, min(1.0, refl))
            self.mat_reflection[idx] = refl

            surf = None
            try:
                tex = getattr(mat, 'texture', None) if mat is not None else None
                if tex is not None:
                    surf = tex
                    if surf.get_width() != slot or surf.get_height() != slot:
                        surf = pygame.transform.scale(surf, (slot, slot))
            except:
                surf = None

            if surf is None:
                color = tint or (getattr(mat, 'color', None) if mat else None) or (200, 200, 200)
                surf = pygame.Surface((slot, slot), pygame.SRCALPHA)
                surf.fill((int(color[0]), int(color[1]), int(color[2]), 255))

            try:
                if (surf.get_flags() & pygame.SRCALPHA) == 0:
                    surf = surf.convert_alpha()
            except:
                try: surf = surf.convert_alpha()
                except: pass

            if tint is not None:
                tinted = surf.copy()
                tinted.fill((int(tint[0]), int(tint[1]), int(tint[2]), 255),
                            special_flags=pygame.BLEND_RGB_MULT)
                surf = tinted

            raw = pygame.image.tostring(surf, "RGBA", False)
            sub = np.frombuffer(raw, dtype=np.uint8).reshape(slot, slot, 4)
            atlas[py:py + slot, px:px + slot, :] = sub

            self.mat_uv[idx] = (px / atlas_w, py / atlas_h,
                                (px + slot) / atlas_w, (py + slot) / atlas_h)

        if self.atlas_tex is not None:
            try: self.atlas_tex.release()
            except: pass
        self.atlas_tex = self.ctx.texture((atlas_w, atlas_h), 4, atlas.tobytes())
        self.atlas_tex.filter = (moderngl.LINEAR, moderngl.LINEAR)
        self.num_materials = min(len(mat_list), self.MAX_MATERIALS)

    # ------------------------------------------------------------------
    # Runtime
    # ------------------------------------------------------------------

    def update_cell(self, x, y, cell, material_lib):
        self._map_dirty = True

    def mark_map_dirty(self):
        self._map_dirty = True

    # ------------------------------------------------------------------
    # Render
    # ------------------------------------------------------------------

    def render(self,
               player_pos,
               player_angle,
               fov,
               max_depth,
               pitch_offset,
               proj_coeff,
               lights,
               ambient,
               fog_enabled,
               fog_color,
               fog_start,
               fog_end,
               rt_enabled=False,
               rt_max_lights=2,
               rt_reflections=True,
               map_data_ref=None,
               material_lib=None,
               sprites=None,
               water_color=None,
               dynamic_lights=None,
               player_light_mode='default',
               player_light_range=400.0,
               player_light_cone=0.55):
        if self.map_meta is None:
            return pygame.Surface((self.width, self.height))

        if self._map_dirty and map_data_ref is not None and material_lib is not None:
            self.setup_level(
                map_data_ref, self.tile_size, material_lib,
                floor_texture=self._saved_floor_texture,
                ceiling_texture=self._saved_ceiling_texture,
                floor_color=self._saved_floor_color,
                ceiling_color=self._saved_ceiling_color,
                water_color=water_color or self._saved_water_color,
            )
            self._map_dirty = False

        if sprites is not None:
            self.update_sprites(sprites)

        p = self.prog

        p['u_map_size']  = (float(self.map_w), float(self.map_h))
        p['u_player_pos'] = (player_pos.x / self.tile_size,
                             player_pos.y / self.tile_size)

        dir_x = math.cos(player_angle)
        dir_y = math.sin(player_angle)
        plane_len = math.tan(fov * 0.5)
        p['u_camera_dir']   = (dir_x, dir_y)
        p['u_camera_plane'] = (-dir_y * plane_len, dir_x * plane_len)

        p['u_max_depth']    = float(max_depth) / self.tile_size
        p['u_pitch_offset'] = float(pitch_offset) / float(self.height)

        p['u_proj_coeff'] = float(proj_coeff)
        p['u_tile_size']  = float(self.tile_size)
        p['u_screen_h']   = float(self.height)

        p['u_use_floor_tex']   = int(bool(self._use_floor_tex))
        p['u_use_ceiling_tex'] = int(bool(self._use_ceiling_tex))
        p['u_floor_color']     = self._floor_color_norm
        p['u_ceiling_color']   = self._ceiling_color_norm

        wc = water_color or self._saved_water_color
        p['u_water_color'] = (wc[0] / 255.0, wc[1] / 255.0, wc[2] / 255.0)

        # Static lights
        n = min(len(lights), self.MAX_LIGHTS)
        p['u_num_lights'] = int(n)
        if n > 0:
            lp = np.zeros((self.MAX_LIGHTS, 2), dtype='f4')
            lc = np.zeros((self.MAX_LIGHTS, 3), dtype='f4')
            lr = np.zeros(self.MAX_LIGHTS, dtype='f4')
            li = np.zeros(self.MAX_LIGHTS, dtype='f4')
            for i, L in enumerate(lights[:n]):
                lp[i] = (L.x / self.tile_size, L.y / self.tile_size)
                col = getattr(L, 'color', (255, 255, 255))
                lc[i] = (float(col[0]), float(col[1]), float(col[2]))
                lr[i] = float(getattr(L, 'radius', 200)) / self.tile_size
                li[i] = float(getattr(L, 'intensity', 1.0))
            try:
                p['u_light_pos'].write(lp.tobytes())
                p['u_light_color'].write(lc.tobytes())
                p['u_light_radius'].write(lr.tobytes())
                p['u_light_intensity'].write(li.tobytes())
            except Exception as e:
                print(f"[GPU] Light upload error: {e}")
        else:
            p['u_num_lights'] = 0

        # Dynamic lights (bullets, explosions)
        dl = dynamic_lights or []
        nd = min(len(dl), self.MAX_DYN_LIGHTS)
        p['u_num_dynamic_lights'] = int(nd)
        if nd > 0:
            dp = np.zeros((self.MAX_DYN_LIGHTS, 2), dtype='f4')
            dc = np.zeros((self.MAX_DYN_LIGHTS, 3), dtype='f4')
            dr = np.zeros(self.MAX_DYN_LIGHTS, dtype='f4')
            di = np.zeros(self.MAX_DYN_LIGHTS, dtype='f4')
            for i, L in enumerate(dl[:nd]):
                # L = [x, y, radius, intensity, color(rgb), ttl]
                dp[i] = (L[0] / self.tile_size, L[1] / self.tile_size)
                col = L[4] if len(L) > 4 else (255, 200, 100)
                dc[i] = (float(col[0]), float(col[1]), float(col[2]))
                dr[i] = float(L[2]) / self.tile_size
                ttl = L[5] if len(L) > 5 else 1.0
                ttl_frac = max(0.0, min(1.0, ttl / 0.35))
                di[i] = float(L[3]) * ttl_frac
            try:
                p['u_dyn_light_pos'].write(dp.tobytes())
                p['u_dyn_light_color'].write(dc.tobytes())
                p['u_dyn_light_radius'].write(dr.tobytes())
                p['u_dyn_light_intensity'].write(di.tobytes())
            except Exception as e:
                print(f"[GPU] Dyn light upload error: {e}")

        # Player light mode
        p['u_player_light_mode']  = 1 if player_light_mode == 'circle' else 0
        p['u_player_light_range'] = float(player_light_range) / self.tile_size
        p['u_player_light_cone']  = float(player_light_cone)

        p['u_ambient'] = float(ambient)

        p['u_fog_enabled'] = int(bool(fog_enabled))
        fc = fog_color if fog_color else (30, 30, 40)
        p['u_fog_color'] = (fc[0] / 255.0, fc[1] / 255.0, fc[2] / 255.0)
        p['u_fog_start'] = float(fog_start) / self.tile_size
        p['u_fog_end']   = float(fog_end)   / self.tile_size

        p['u_mat_uv'].write(self.mat_uv.tobytes())
        try:
            p['u_mat_reflection'].write(self.mat_reflection.tobytes())
        except: pass

        p['u_num_sprites'] = int(self._sprite_count)
        if self._sprite_count > 0:
            try:
                p['u_sprite_pos'].write(self._sprite_pos.tobytes())
                p['u_sprite_radius'].write(self._sprite_radius.tobytes())
                p['u_sprite_uv'].write(self._sprite_atlas_uv.tobytes())
            except Exception as e:
                print(f"[GPU] Sprite upload error: {e}")

        p['u_rt_enabled']     = int(bool(rt_enabled))
        p['u_rt_max_lights']  = int(rt_max_lights)
        p['u_rt_reflections'] = int(bool(rt_reflections and rt_enabled))

        self.map_meta.use(0)
        self.atlas_tex.use(1)
        self._floor_tex.use(2)
        self._ceil_tex.use(3)
        self._water_mask_tex.use(4)
        self._sprite_atlas_tex.use(5)
        p['u_meta']         = 0
        p['u_atlas']        = 1
        p['u_floor_tex']    = 2
        p['u_ceiling_tex']  = 3
        p['u_water_mask']   = 4
        p['u_sprite_atlas'] = 5

        self.fbo.use()
        self.fbo.clear(0.0, 0.0, 0.0, 1.0)
        self.vao.render()

        raw = self.fbo.read(components=3, alignment=1)
        arr = np.frombuffer(raw, dtype=np.uint8).reshape((self.height, self.width, 3))
        arr = np.flipud(arr)
        return pygame.image.frombuffer(arr.tobytes(), (self.width, self.height), 'RGB')

    def release(self):
        try:
            self.fbo.release()
            self.color_tex.release()
            self.depth_tex.release()
            self.prog.release()
            self.vbo.release()
            self.vao.release()
            if self.map_meta: self.map_meta.release()
            if self.atlas_tex: self.atlas_tex.release()
            if self._floor_tex: self._floor_tex.release()
            if self._ceil_tex: self._ceil_tex.release()
            if self._water_mask_tex: self._water_mask_tex.release()
            if self._sprite_atlas_tex: self._sprite_atlas_tex.release()
            self.ctx.release()
        except:
            pass

    @staticmethod
    def _hex_to_rgb(hex_str):
        if not hex_str:
            return (255, 255, 255)
        s = str(hex_str).lstrip('#')
        return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))