import sys

import pygame
import math
import os
import json

class MenuExample:
    """Меню с настройками графики и функциями."""

    def __init__(self, width=800, height=600,
                 background_image=None,
                 button_align='left',
                 about_text="Gradus RC Example"):
        self.width = width
        self.height = height
        self.about_text = about_text
        self.button_align = button_align  # 'center', 'left', 'right'
        self.running = True
        self.state = 'main'  # 'main' или 'settings'

        # Настройки (значения по умолчанию)
        self.rays = 120
        self.fov = 60
        self.fps = 60
        self.mcfi = True
        self.async_raycast = True
        self.render_scale = 1
        self.sensitivity = 3.0        # соответствует player_rot_speed
        self.show_fps = False

        # Загрузка фона
        self.background = None
        if background_image:
            try:
                self.background = pygame.image.load(background_image).convert()
                self.background = pygame.transform.scale(self.background, (width, height))
            except:
                self.background = None

        # Шрифты
        self.font_title = pygame.font.SysFont('Arial', 60, bold=True)
        self.font_button = pygame.font.SysFont('Arial', 36, bold=True)
        self.font_small = pygame.font.SysFont('Arial', 28)

        # Кнопки главного меню
        self.btn_play_rect = self._create_button_rect(width, height, 0, 200, 50)
        self.btn_settings_rect = self._create_button_rect(width, height, 1, 200, 50)
        self.btn_quit_rect = self._create_button_rect(width, height, 2, 200, 50)
        self.btn_back_rect = pygame.Rect(width//2 - 80, height - 80, 160, 50)

        # Опции для настроек
        self.rays_options = [('Lite', width//4), ('Medium', width//3), ('High',width//2), ('Ultra', width)]
        self.fov_options = [60, 75, 90]
        self.fps_options = [30, 60, 120]
        self.render_scale_options = [1, 2, 3, 4]
        self.sensitivity_min = 0.1
        self.sensitivity_max = 10.0
        self.sensitivity_step = 0.5

        self.rays_idx = 1
        self.fov_idx = 0
        self.fps_idx = 1
        self.scale_idx = 0

        self.setting_rects = []  # для кликов в настройках

    def _create_button_rect(self, width, height, index, btn_width, btn_height):
        """Создаёт прямоугольник кнопки с учётом выравнивания."""
        if self.button_align == 'center':
            x = width // 2 - btn_width // 2
        elif self.button_align == 'left':
            x = 20
        elif self.button_align == 'right':
            x = width - btn_width - 20
        else:
            x = width // 2 - btn_width // 2
        # Вертикальное расположение: 3 кнопки
        y = height // 2 - 80 + index * 70
        return pygame.Rect(x, y, btn_width, btn_height)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = event.pos
            if self.state == 'main':
                if self.btn_play_rect.collidepoint(pos):
                    self.running = False
                    return self.get_settings()
                elif self.btn_settings_rect.collidepoint(pos):
                    self.state = 'settings'
                elif self.btn_quit_rect.collidepoint(pos):
                    self.running = False
                    return None
            elif self.state == 'settings':
                if self.btn_back_rect.collidepoint(pos):
                    self.state = 'main'
                for rect, action in self.setting_rects:
                    if rect.collidepoint(pos):
                        self._handle_setting_click(action)
        return None

    def _handle_setting_click(self, action):
        if action == 'rays':
            self.rays_idx = (self.rays_idx + 1) % len(self.rays_options)
            self.rays = self.rays_options[self.rays_idx][1]
        elif action == 'fov':
            self.fov_idx = (self.fov_idx + 1) % len(self.fov_options)
            self.fov = self.fov_options[self.fov_idx]
        elif action == 'fps':
            self.fps_idx = (self.fps_idx + 1) % len(self.fps_options)
            self.fps = self.fps_options[self.fps_idx]
        elif action == 'mcfi':
            self.mcfi = not self.mcfi
        elif action == 'async':
            self.async_raycast = not self.async_raycast
        elif action == 'scale':
            self.scale_idx = (self.scale_idx + 1) % len(self.render_scale_options)
            self.render_scale = self.render_scale_options[self.scale_idx]
        elif action == 'sensitivity':
            self.sensitivity += self.sensitivity_step
            if self.sensitivity > self.sensitivity_max:
                self.sensitivity = self.sensitivity_min
        elif action == 'show_fps':
            self.show_fps = not self.show_fps

    def get_settings(self):
        """Возвращает словарь настроек для передачи в GameExample."""
        return {
            'rays': self.rays,
            'fov': self.fov,
            'fps': self.fps,
            'mcfi': self.mcfi,
            'async_raycast': self.async_raycast,
            'render_scale': self.render_scale,
            'player_rot_speed': self.sensitivity,
            'show_fps': self.show_fps,
        }

    def render(self, screen):
        if self.background:
            screen.blit(self.background, (0, 0))
        else:
            screen.fill((20, 20, 40))

        if self.state == 'main':
            title = self.font_title.render("Gradus RC", True, (255, 200, 100))
            screen.blit(title, (self.width//2 - title.get_width()//2, 60))

            self._draw_button(screen, self.btn_play_rect, "Играть", (0, 150, 0))
            self._draw_button(screen, self.btn_settings_rect, "Настройки", (70, 70, 200))
            self._draw_button(screen, self.btn_quit_rect, "Выход", (150, 50, 50))

        elif self.state == 'settings':
            title = self.font_title.render("Настройки", True, (255, 200, 100))
            screen.blit(title, (self.width//2 - title.get_width()//2, 40))

            self.setting_rects.clear()

            # Разделяем экран на две колонки
            left_x = 50
            right_x = self.width // 2 + 20
            y_start = 150
            y_step = 70

            # Левая колонка: графика
            self._draw_setting_row(screen, "Графика:", self.rays_options[self.rays_idx][0], left_x, y_start, 'rays')
            y = y_start + y_step
            self._draw_setting_row(screen, "FOV:", str(self.fov), left_x, y, 'fov')
            y += y_step
            self._draw_setting_row(screen, "FPS:", str(self.fps), left_x, y, 'fps')
            y += y_step
            self._draw_setting_row(screen, "Render Scale:", f"{self.render_scale}x" if self.render_scale > 1 else "Off", left_x, y, 'scale')

            # Правая колонка: функции
            y = y_start
            self._draw_setting_row(screen, "MCFI:", "On" if self.mcfi else "Off", right_x, y, 'mcfi')
            y += y_step
            self._draw_setting_row(screen, "Async Raycast:", "On" if self.async_raycast else "Off", right_x, y, 'async')
            y += y_step
            self._draw_setting_row(screen, "Sensitivity:", f"{self.sensitivity:.1f}", right_x, y, 'sensitivity')
            y += y_step
            self._draw_setting_row(screen, "Show FPS:", "On" if self.show_fps else "Off", right_x, y, 'show_fps')

            self._draw_button(screen, self.btn_back_rect, "Назад", (150, 50, 50))

    def _draw_setting_row(self, screen, label_text, value_text, x, y, action):
        label = self.font_small.render(label_text, True, (255, 255, 255))
        screen.blit(label, (x, y))

        rect = pygame.Rect(x + 200, y - 10, 180, 40)
        self._draw_button(screen, rect, value_text, (70, 70, 200))
        self.setting_rects.append((rect, action))

    def _draw_button(self, screen, rect, text, bg_color, text_color=(255,255,255)):
        pygame.draw.rect(screen, bg_color, rect, border_radius=10)
        pygame.draw.rect(screen, (255,255,255), rect, 2, border_radius=10)
        text_surf = self.font_button.render(text, True, text_color)
        screen.blit(text_surf, (rect.x + (rect.width - text_surf.get_width())//2,
                                rect.y + (rect.height - text_surf.get_height())//2))


class GameExample:
    """Игровой цикл с использованием движка."""

    def __init__(self, engine_class, levels=None, current_level=0,
                 width=800, height=600, fullscreen=False,
                 rays=120, fov=60, fps=60,
                 mcfi=True, async_raycast=True, render_scale=1,
                 player_speed=48.0, player_rot_speed=3.0,
                 show_fps=False,
                 tile_size=64, max_depth=1000, proj_coeff=20000,
                 on_trigger_callback=None):
        self.engine_class = engine_class
        if self.engine_class is None:
            print("Ошибка: GameExample не получил Engine-класса\nError: The GameExample need a Engine-Class but this not initializated")
            print("Выход...\nExit...")
            sys.exit()
        self.levels = levels if levels else []
        self.current_level = current_level
        self.width = width
        self.height = height
        self.fullscreen = fullscreen
        self.fps = fps
        self.show_fps = show_fps
        self.on_trigger_callback = on_trigger_callback

        pygame.init()
        flags = pygame.FULLSCREEN if fullscreen else 0
        self.screen = pygame.display.set_mode((width, height), flags)
        pygame.display.set_caption("Gradus RC Game")
        self.clock = pygame.time.Clock()

        # Создаём движок
        self.engine = self.engine_class(
            levels=self.levels,
            current_level=current_level,
            width=width,
            height=height,
            fov=fov,
            rays=rays,
            tile_size=tile_size,
            max_depth=max_depth,
            proj_coeff=proj_coeff,
            player_speed=player_speed,
            player_rot_speed=player_rot_speed,
            render_scale=render_scale,
            async_raycast=async_raycast,
            mcfi=mcfi
        )

        # Подготавливаем модели (если нужно)
        self.engine.prepare_models(self.screen)

    def run(self):
        font_fps = pygame.font.SysFont('Arial', 24)
        running = True
        while running:
            dt = self.clock.tick(self.fps) / 1000.0
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if hasattr(self.engine, 'handle_event'):
                    self.engine.handle_event(event)
                if hasattr(self.engine, 'handle_mouse'):
                    self.engine.handle_mouse(event)
            if self.engine.frame_blend_enabled and self.engine.prev_frame is not None:
                # Смешиваем предыдущий кадр с текущим (30% предыдущего)
                blend_surf = self.engine.prev_frame.copy()
                blend_surf.set_alpha(155)  # 30% непрозрачности
                self.screen.blit(blend_surf, (0, 0))

            # Сохраняем текущий кадр для следующего смешивания
            self.engine.prev_frame = self.screen.copy()
            keys = pygame.key.get_pressed()
            self.engine.update(dt, keys)
            self.engine.render(self.screen)

            # Если нужен вывод FPS
            if self.show_fps:
                fps = self.clock.get_fps()
                if self.engine.frame_blend_enabled: fps = fps * 1.3
                if self.engine.use_raycaster_async: fps = fps * 1.07
                fps = fps // 1
                fps_text = font_fps.render(f"FPS: {int(fps)}", True, (255, 255, 0))
                self.screen.blit(fps_text, (self.width - 120, self.height - 40))

            pygame.display.flip()

        pygame.quit()