from ..engine import Engine

class GameExample:
    def __init__(self, engine, levels=None, current_level=0, on_trigger_callback=None):
        self.engine = engine
        self.engine.levels = levels if levels else []
        self.engine.current_level = current_level
        self.on_trigger_callback = on_trigger_callback
        if self.engine.levels:
            self.engine.load_level(self.engine.current_level)

    def handle_event(self, event):
        # Обработка событий игры (если нужно)
        pass

    def update(self, dt, keys):
        self.engine.update(dt, keys)

    def render(self, screen):
        self.engine.render(screen)

    def run(self):
        # Запускает игровой цикл (если нужно отдельно)
        pass