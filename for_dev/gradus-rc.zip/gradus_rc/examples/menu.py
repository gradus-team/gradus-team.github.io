import math

import pygame
import json
import os
from ..engine import Engine


class MenuExample:
    def __init__(self, engine, background_image=None, button_color=(100, 100, 100),
                 text_color=(255, 255, 255), about_text="About this game...",
                 settings_file="settings.json"):
        self.engine = engine
        self.background_image = background_image
        self.button_color = button_color
        self.text_color = text_color
        self.about_text = about_text
        self.settings_file = settings_file
        self.running = True
        self.current_screen = "main"  # main, settings, about
        self.scroll_offset = 0
        self.font = None
        self.small_font = None

        # Настройки по умолчанию
        self.settings = {
            "fov": 60,
            "graphics": "Medium",  # Lite, Turbo, Medium, High, Ultra
            "rays": 160,
            "sprite_angles": 32
        }
        self.load_settings()

        # Кнопки
        self.buttons = []
        self.settings_buttons = []

    def load_settings(self):
        if os.path.exists(self.settings_file):
            try:
                with open(self.settings_file, 'r') as f:
                    self.settings.update(json.load(f))
            except:
                pass

    def save_settings(self):
        try:
            with open(self.settings_file, 'w') as f:
                json.dump(self.settings, f, indent=4)
        except:
            pass

    def apply_settings(self):
        # Применяем настройки к движку
        self.engine.fov = math.radians(self.settings["fov"])
        self.engine.half_fov = self.engine.fov / 2
        self.engine.rays = self.settings["rays"]
        # Для спрайтов нужно перегенерировать? Пока просто сохраняем.

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.current_screen == "main":
                for btn in self.buttons:
                    if btn["rect"].collidepoint(event.pos):
                        if btn["action"] == "play":
                            self.running = False
                            self.engine.start_game()
                        elif btn["action"] == "settings":
                            self.current_screen = "settings"
                        elif btn["action"] == "about":
                            self.current_screen = "about"
            elif self.current_screen == "settings":
                for btn in self.settings_buttons:
                    if btn["rect"].collidepoint(event.pos):
                        if btn["action"] == "back":
                            self.save_settings()
                            self.apply_settings()
                            self.current_screen = "main"
                        elif btn["action"] == "fov":
                            # цикл по FOV
                            fovs = [30, 60, 90]
                            idx = fovs.index(self.settings["fov"]) if self.settings["fov"] in fovs else 1
                            self.settings["fov"] = fovs[(idx + 1) % len(fovs)]
                        elif btn["action"] == "graphics":
                            levels = ["Lite", "Turbo", "Medium", "High", "Ultra"]
                            idx = levels.index(self.settings["graphics"]) if self.settings["graphics"] in levels else 2
                            self.settings["graphics"] = levels[(idx + 1) % len(levels)]
                            # Обновляем параметры
                            self._update_graphics_settings()
            elif self.current_screen == "about":
                if event.button == 4:  # scroll up
                    self.scroll_offset = max(0, self.scroll_offset - 20)
                elif event.button == 5:  # scroll down
                    self.scroll_offset += 20
                # Назад по клику на кнопку "назад"
                if self.buttons and self.buttons[0]["rect"].collidepoint(event.pos):
                    self.current_screen = "main"

    def _update_graphics_settings(self):
        g = self.settings["graphics"]
        if g == "Lite":
            self.settings["rays"] = 40
            self.settings["sprite_angles"] = 8
        elif g == "Turbo":
            self.settings["rays"] = 80
            self.settings["sprite_angles"] = 32
        elif g == "Medium":
            self.settings["rays"] = 160
            self.settings["sprite_angles"] = 32
        elif g == "High":
            self.settings["rays"] = 240
            self.settings["sprite_angles"] = 32
        elif g == "Ultra":
            self.settings["rays"] = 400
            self.settings["sprite_angles"] = 64

    def render(self, screen):
        if self.font is None:
            self.font = pygame.font.SysFont('Arial', 36)
            self.small_font = pygame.font.SysFont('Arial', 24)

        # Фон
        if self.background_image:
            bg = pygame.image.load(self.background_image).convert()
            bg = pygame.transform.scale(bg, (screen.get_width(), screen.get_height()))
            screen.blit(bg, (0, 0))
        else:
            screen.fill((20, 20, 40))

        # Заголовок
        title = self.font.render("Gradus RC", True, (255, 255, 255))
        screen.blit(title, (screen.get_width() // 2 - title.get_width() // 2, 30))

        if self.current_screen == "main":
            self._render_main(screen)
        elif self.current_screen == "settings":
            self._render_settings(screen)
        elif self.current_screen == "about":
            self._render_about(screen)

    def _render_main(self, screen):
        w, h = screen.get_width(), screen.get_height()
        btn_w, btn_h = 200, 50
        start_y = 150
        spacing = 70
        self.buttons = []
        actions = [("Играть", "play"), ("Настройки", "settings"), ("Об игре", "about")]
        for i, (text, action) in enumerate(actions):
            rect = pygame.Rect(w // 2 - btn_w // 2, start_y + i * spacing, btn_w, btn_h)
            pygame.draw.rect(screen, self.button_color, rect, border_radius=10)
            txt = self.font.render(text, True, self.text_color)
            screen.blit(txt,
                        (rect.x + rect.w // 2 - txt.get_width() // 2, rect.y + rect.h // 2 - txt.get_height() // 2))
            self.buttons.append({"rect": rect, "action": action})

    def _render_settings(self, screen):
        w, h = screen.get_width(), screen.get_height()
        y = 150
        # Текущие настройки
        texts = [
            f"FOV: {self.settings['fov']}°",
            f"Графика: {self.settings['graphics']} (лучей: {self.settings['rays']})"
        ]
        for txt in texts:
            surf = self.small_font.render(txt, True, (255, 255, 255))
            screen.blit(surf, (w // 2 - surf.get_width() // 2, y))
            y += 50
        # Кнопки изменения
        btn_w, btn_h = 150, 40
        self.settings_buttons = []
        actions = [("Изменить FOV", "fov"), ("Изменить графику", "graphics"), ("Назад", "back")]
        for i, (text, action) in enumerate(actions):
            rect = pygame.Rect(w // 2 - btn_w // 2, y + i * 60, btn_w, btn_h)
            pygame.draw.rect(screen, (80, 80, 120), rect, border_radius=8)
            txt = self.small_font.render(text, True, (255, 255, 255))
            screen.blit(txt,
                        (rect.x + rect.w // 2 - txt.get_width() // 2, rect.y + rect.h // 2 - txt.get_height() // 2))
            self.settings_buttons.append({"rect": rect, "action": action})

    def _render_about(self, screen):
        w, h = screen.get_width(), screen.get_height()
        # Текст с прокруткой
        lines = self.about_text.split('\n')
        y = 100 - self.scroll_offset
        for line in lines:
            if 50 < y < h - 50:
                surf = self.small_font.render(line, True, (200, 200, 255))
                screen.blit(surf, (w // 2 - surf.get_width() // 2, y))
            y += 30
        # Кнопка "Назад"
        rect = pygame.Rect(w // 2 - 75, h - 60, 150, 40)
        pygame.draw.rect(screen, (80, 80, 120), rect, border_radius=8)
        txt = self.small_font.render("Назад", True, (255, 255, 255))
        screen.blit(txt, (rect.x + rect.w // 2 - txt.get_width() // 2, rect.y + rect.h // 2 - txt.get_height() // 2))
        self.buttons = [{"rect": rect, "action": "back"}]