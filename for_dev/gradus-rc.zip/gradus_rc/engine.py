import time
import random

import pygame
import math
import os
import sys
import numpy as np
import threading

from .config import *
from .player import Player
from .utils.parser import MapParser
from .raycast.core import RayCaster
from .light.tracer import LightTracer, LightSource
from .material.library import MaterialLibrary
from .image.cache import SpriteManager as ImageManager
import imageio
import imageio_ffmpeg
from .sound.mixer import SoundManager
from .sound import Sound3D
from .object.registry import GameObjectRegistry
from .sprite.core import SpriteManager, Sprite, ModelSprite, AnimatedModelSprite
from .image.cache import load_image
from .polygon.obj_to_sprites import obj_to_sprites
from .effects.manager import EffectsManager
from .enemy import EnemyAI
from .gun import GunManager, Bullet
from .hud.core import HUDManager
from .hud.minimap import *
from .effects.particles import ParticleSystem, Particle
from .effects.decals import DecalSystem
from .effects.explosion import Explosion
from .mods.manager import ModsManager, set_manager as _set_mods_manager, resolve_path

try:
    from .raycast.core_cy import RayCaster
    _CYTHON_RAYS = True
except ImportError:
    from .raycast.core import RayCaster
    _CYTHON_RAYS = False
try:
    from .render.gpu_renderer import GPURaycaster
    _GPU_OK = True
except ImportError as e:
    print(f"[GPU] not available: {e}")
    _GPU_OK = False

class Engine:
    def __init__(self, clock, width=DEFAULT_WIDTH, height=DEFAULT_HEIGHT,
                 levels=None, current_level=0,
                 fov=DEFAULT_FOV, rays=DEFAULT_RAYS,
                 tile_size=DEFAULT_TILE_SIZE, max_depth=DEFAULT_MAX_DEPTH,
                 proj_coeff=DEFAULT_PROJ_COEFF,
                 player_speed=DEFAULT_PLAYER_SPEED,
                 player_rot_speed=DEFAULT_PLAYER_ROT_SPEED,
                 rt_quality='balanced',
                 particles_mode='optimal',
                 graphics_level='high',  # ← новое
                 debris_mode=None,  # ← новое
                 default_wall_hp=100,  # ← новое
                 use_rt=False,
                 rt_level=4,
                 floor_texture=None, ceiling_texture=None,
                 mouse_sensitivity=0.002,render_scale=1,async_raycast=True,mcfi=False,mcfi_level=None,enemy_sprite="assets/enemy_imp.png",show_fps=True,
                 use_example=False):  # <-- добавили параметр
        try:
            print(f"[Engine] RayCaster: {'Cython' if _CYTHON_RAYS else 'Python'} version")
            if mcfi_level is not None:
                self.mcfi_level = mcfi_level
            else:
                self.mcfi_level = 1 if mcfi else 0
            self.frame_blend_enabled = self.mcfi_level > 0
            self._mcfi_step = 0
            self._mcfi_real_prev = None
            self._mcfi_real_curr = None
            self._mcfi_strength = 0.125
            print(f"MCFI level: {self.mcfi_level}, enabled: {self.frame_blend_enabled}")

            self.mods_manager = ModsManager(mods_root='mods')
            _set_mods_manager(self.mods_manager)
            self._mod_hooks = {}

            self.interactive_objects = {}  # key -> InteractiveObject
            self.ceiling_collision = True
            self.gravity_enabled = True  # глобальный флаг

            self._pitch_offset_cache = 0
            self._particle_tex_cache = {}  # (color, size) -> Surface

            self.explosions = []  # активные взрывы
            self.transient_lights = []  # [(x, y, r, intensity, color, ttl)]
            self.player_light_mode = 'default'  # 'default' | 'circle'
            self.player_light_range = 400.0  # дальность конуса (пиксели)
            self.player_light_cone = 0.55  # cos угла полураскрытия (~55°)
            # Fixed timestep
            self.fixed_physics_dt = 1.0 / 30.0
            self._physics_accumulator = 0.0

            self.show_enemy_hp = True
            self.show_enemy_ammo = False
            self.enemy_bar_max_distance = 800  # не рисуем за этой дистанцией

            self.particles = ParticleSystem(self)
            self.particles.set_mode(particles_mode or "optimal")
            self.particles.set_graphics_level(graphics_level)
            if debris_mode:
                self.particles.debris_mode = debris_mode
            self.default_wall_hp = default_wall_hp
            self.scheduled_walls = []  # отложенный восстановитель стен

            self.decals = DecalSystem(self)

            # Y-shearing
            self.y_shearing_enabled = True
            self.y_shearing_pixels_per_rad = 400  # сколько пикселей на 1 радиан наклона

            self.default_wall_hp = 100
            self.scheduled_walls = []

            self.use_raycaster_async = async_raycast  # включить асинхронный режим
            self._ray_thread = None
            self._ray_results = None
            self.use_example = use_example
            self._ray_lock = threading.Lock()
            self.width = int(width)
            self.height = int(height)
            self.screen_width = int(width)
            self.screen_height = int(height)
            self.render_scale = max(1, int(render_scale))
            self.font_fps = pygame.font.SysFont('Arial', 24)
            self.enemy_sprite = enemy_sprite

            self.hud = HUDManager(self)
            self.minimap = None
            self.minimap_enemy_hide_delay = 5.0
            # Fog
            self.fog_enabled = False
            self.fog_color = (30, 30, 40)
            self.fog_start = 400  # начало проявления тумана (пиксели)
            self.fog_end = 1200  # полный туман
            self.fog_floor_ceiling = True
            self.show_fps = show_fps
            self.clock = clock

            self.active_3d_sounds = []
            self.global_model_cache = {}  # ключ -> список спрайтов
            self.text_color = (30,30,30)

            self._debug_panels = []  # F1-панели от модов
            self.lang = 'ru'  # текущий язык (для api.t())
            self.show_debug_overlay = False  # F1
            self.show_debug_user = False  # F3

            self.enemies = []
            self.bullets = []
            self.gun_manager = GunManager()
            self.enemy_effect_timers = {}  # key -> timer

            self.column_cache = {}
            self.prev_frame = None
            self.prev_player_pos = None
            self.prev_player_angle = None

            # Рабочие размеры (уменьшенные)
            self.width = max(1, self.screen_width // self.render_scale)
            self.height = max(1, self.screen_height // self.render_scale)

            # Буфер для рендера
            self.render_surface = pygame.Surface((self.width, self.height))
            self.fov = math.radians(fov)
            self.half_fov = self.fov / 2
            self.rays = rays
            self.effects_manager = EffectsManager()
            self.tile_size = tile_size
            self.max_depth = max_depth
            self.proj_coeff = proj_coeff
            if proj_coeff is None or proj_coeff == DEFAULT_PROJ_COEFF:
                self.proj_coeff = (self.height / 2) * tile_size
            else:
                # Если пользователь задал своё значение, масштабируем относительно старой высоты
                self.proj_coeff = proj_coeff * (self.height / self.screen_height)
            self.use_lt = True
            self.overlay_texture = None
            self.overlay_alpha = 255
            self.effect_texture = None
            self.effect_timer = 0
            self.inactive_triggers = set()
            self.model_data = []

            self.message_text = ""
            self.message_timer = 0.0
            self.message_duration = 0.0
            self.font = pygame.font.SysFont("Arial", 36)

            self.doors = {}
            self.keys = {}

            # ---- Водяной знак и экран загрузки (уже есть) ----
            self.watermark = ""
            self.loading_progress = (0, 0)
            self.show_loading_screen = True
            self.example_menu = None
            self.example_game = None
            self._load_watermark()

            self.global_model_cache = {}
            self.model_cache_lock = threading.Lock()
            self.model_generate_lock = threading.Lock()

            # ---- Видео (через imageio, без cv2) ----
            self.video_playing = False
            self.video_surface = None
            self.video_mode = "full"
            self.video_rect = pygame.Rect(0, 0, 0, 0)
            self.video_lock = threading.Lock()
            self.video_thread = None
            self.video_loop = True
            self.model_generate_lock = threading.Lock()
            # ---- Управление мышью (новое) ----
            self.mouse_sensitivity = mouse_sensitivity
            self.mouse_captured = False

            self.physics = self.PhysicsAPI(self)

            # ---- Текстуры пола/потолка ----
            self.floor_texture = None
            self.ceiling_texture = None
            if floor_texture:
                try:
                    self.floor_texture = pygame.image.load(floor_texture).convert_alpha()
                except:
                    self.floor_texture = None
            if ceiling_texture:
                try:
                    self.ceiling_texture = pygame.image.load(ceiling_texture).convert_alpha()
                except:
                    self.ceiling_texture = None

            self.material_lib = MaterialLibrary()
            self.sprite_manager = SpriteManager()
            self.sound_manager = SoundManager()
            self.registry = GameObjectRegistry()

            self.prev_prev_frame = None  # ← добавить
            self._mcfi_is_blend_frame = False

            self.levels = levels if levels else []
            self.current_level = current_level
            self.map_data = None
            self.map_width = 0
            self.map_height = 0

            self.model_cache_lock = threading.Lock()

            self.texture_cache = {}

            self.raycaster = RayCaster(
                map_data=self.map_data,
                tile_size=self.tile_size,
                fov=self.fov,
                rays=self.rays,
                max_depth=self.max_depth,
                proj_coeff=self.proj_coeff,
                material_lib=self.material_lib
            )
            self.rt_enabled = False  # ← True чтобы включить RTE
            self.rt_max_lights = rt_level  # сколько источников считают тени
            self.rt_reflections = True  # зеркала
            self.rt_quality = rt_quality if rt_quality in (
                'fast', 'balanced', 'high', 'ultra', 'reference'
            ) else 'balanced'
            self.use_gpu = False
            self.gpu_raycaster = None
            if _GPU_OK:
                try:
                    # Рендерим в том же разрешении, что render_surface
                    self.gpu_raycaster = GPURaycaster(self.width, self.height)
                    self.use_gpu = True
                    print("[Engine] GPU renderer: enabled")
                except Exception as e:
                    print(f"[Engine] GPU renderer failed: {e}")
            self.light_tracer = LightTracer(map_data=self.map_data, tile_size=self.tile_size)

            self.spawn = None
            self.floor_color = None
            self.ceiling_color = None
            self.ambient = 0.03
            self.level_sprites = []
            try:
                self.mods_manager.load_all(self)
            except Exception as e:
                print(f"[MODS] load_all failed: {e}")
            if self.levels:
                self.load_level(self.current_level)

            start_x, start_y = self._find_spawn_point()
            self.player = Player(
                x=start_x,
                y=start_y,
                angle=0.0,
                speed=player_speed,
                rot_speed=player_rot_speed
            )

            self.player.on_death = self._on_player_death

            self._world_renderers = {}
            self._world_renderer_objects = []
            self._trigger_zones = []
            self._scheduled_callbacks = []
            self._screen_flashes = []
            self._vignette = None
            self._skybox_tex = None
            self._skybox_color = (20, 20, 30)
            self._frame_counter = 0
            self._elapsed_time = 0.0
            self._last_dt = 0.0
            self.time_scale = 1.0
            self.noclip = False

            self.mesh_objects = []
            self.api = self.MicroAPI(self)
            self.rt = use_rt
            if self.rt:
                self.api.set_rt(enabled=True,max_lights=rt_level or 4,reflections=True)
        except Exception as e:
            print(f"Error in Engine.__init__: {e}")
            raise

    def _get_pitch_offset(self):
        # """Возвращает сдвиг горизонта в пикселях (в координатах render_surface)."""
        # if not self.y_shearing_enabled:
        #     return 0
        # offset = -int(self.player.pitch * self.y_shearing_pixels_per_rad)
        # limit = self.height // 2 - 1
        # return max(-limit, min(limit, offset))
        return self._pitch_offset_cache

    def _on_player_death(self):
        self.show_message("GAME OVER", duration=5.0)
        print("Игра завершена")

    def _draw_enemy_bars(self, screen):
        """Полоски HP и патронов над врагами."""
        if not self.enemies:
            return
        if not (self.show_enemy_hp or self.show_enemy_ammo):
            return

        px, py = self.player.pos.x, self.player.pos.y
        pa = self.player.angle
        half_fov = self.half_fov
        fov = self.fov
        proj = self.proj_coeff
        horizon = self.height // 2 + self._get_pitch_offset()

        if not hasattr(self, '_enemy_bar_font'):
            self._enemy_bar_font = pygame.font.SysFont('Arial', 14, bold=True)

        for enemy in self.enemies:
            if not enemy.alive:
                continue
            if not self._is_sprite_visible(enemy.x, enemy.y):
                continue
            dx, dy = enemy.x - px, enemy.y - py
            dist = math.hypot(dx, dy)
            if dist < 1 or dist > self.enemy_bar_max_distance:
                continue

            rel = math.atan2(dy, dx) - pa
            while rel < -math.pi: rel += 2 * math.pi
            while rel > math.pi:  rel -= 2 * math.pi
            if abs(rel) > half_fov:
                continue

            screen_x = (rel / fov + 0.5) * self.width
            size = proj / dist
            if size > self.height:
                size = self.height
            if size < 20:
                continue

            # Позиция бара — над головой врага
            bar_w = int(size * 0.7)
            bar_h = max(4, int(size * 0.05))
            bar_x = int(screen_x - bar_w // 2)
            bar_y = int(horizon - size // 2 - bar_h - 6)

            if bar_x < 0 or bar_x + bar_w > self.width:
                continue

            # Фон
            pygame.draw.rect(screen, (20, 20, 20),
                             (bar_x - 1, bar_y - 1, bar_w + 2, bar_h + 2))
            # HP
            if self.show_enemy_hp:
                max_hp = getattr(enemy, 'max_hp', 100) or 100
                hp_ratio = max(0.0, min(1.0, enemy.hp / max_hp))
                hp_w = int(bar_w * hp_ratio)
                if hp_ratio > 0.6:
                    col = (60, 200, 60)
                elif hp_ratio > 0.3:
                    col = (220, 180, 40)
                else:
                    col = (220, 60, 60)
                pygame.draw.rect(screen, col, (bar_x, bar_y, hp_w, bar_h))

                # Число HP рядом
                hp_txt = self._enemy_bar_font.render(
                    f"{int(enemy.hp)}", True, (255, 255, 255))
                screen.blit(hp_txt, (bar_x + bar_w + 4, bar_y - 2))

            # Патроны (если включено)
            if self.show_enemy_ammo:
                gun = getattr(enemy, 'current_gun', None)
                if gun:
                    ammo_txt = self._enemy_bar_font.render(
                        f"{gun.ammo}", True, (255, 220, 100))
                    screen.blit(ammo_txt, (bar_x + bar_w + 4, bar_y + bar_h))

    def enemy_shoot(self, enemy, angle):
        damage = enemy.current_gun.damage if enemy.current_gun else 10
        bullet = Bullet(enemy.x, enemy.y, angle, damage=damage, speed=800, owner=enemy)
        self.bullets.append(bullet)

    def damage_player(self, damage):
        if hasattr(self.player, 'take_damage'):
            self.player.take_damage(damage)
            self.hud.damage_taken(damage)
            self.particles.spawn_hit_player()

    def update_enemies(self, dt):
        for enemy in self.enemies:
            enemy.update(dt, (self.player.pos.x, self.player.pos.y), self)
            enemy.update_visibility(dt, self)
        for enemy in self.enemies:
            if not enemy.alive:
                self.particles.spawn_death(enemy.x, enemy.y)
                # лужа крови под мёртвым
                for _ in range(2):
                    self.decals.spawn_blood(
                        enemy.x + random.uniform(-14, 14),
                        enemy.y + random.uniform(-14, 14),
                        size=80)
        self.enemies = [e for e in self.enemies if e.alive]
        # Управление эффектами врагов
        for key in list(self.enemy_effect_timers.keys()):
            if self.enemy_effect_timers[key] is not None:
                self.enemy_effect_timers[key] -= dt
                if self.enemy_effect_timers[key] <= 0:
                    self.effects_manager.clear_effect()
                    del self.enemy_effect_timers[key]

    def _bullet_hit(self, bullet):
        """Централизованное попадание — сюда весь взрывной код."""
        if getattr(bullet, 'explosive', False):
            self.explosions.append(Explosion(
                bullet.x, bullet.y,
                bullet.explosion_radius,
                bullet.explosion_damage,
            ))
        bullet.alive = False

    def update_bullets(self, dt):
        for bullet in self.bullets[:]:
            bullet.update(dt)

            # Попадание в игрока или врагов
            if bullet.owner != 'player':  # пуля врага
                dist = math.hypot(bullet.x - self.player.pos.x, bullet.y - self.player.pos.y)

                if dist < 20:
                    self.damage_player(bullet.damage)
                    self._bullet_hit(bullet)
                    bullet.alive = False
            else:  # пуля игрока
                for enemy in self.enemies:
                    if not enemy.alive:
                        continue
                    dist = math.hypot(bullet.x - enemy.x, bullet.y - enemy.y)
                    if dist < 20:
                        enemy.take_damage(bullet.damage, bullet.owner)
                        self.particles.spawn_hit_enemy(enemy.x, enemy.y)
                        # КРОВЬ НА ПОЛУ под врагом
                        self.decals.spawn_blood(
                            enemy.x + random.uniform(-8, 8),
                            enemy.y + random.uniform(-8, 8),
                            size=64)
                        self._bullet_hit(bullet)
                        bullet.alive = False
                        break

            # Столкновение со стенами и объектами
            if bullet.alive:
                map_x = int(bullet.x // self.tile_size)
                map_y = int(bullet.y // self.tile_size)
                if 0 <= map_y < self.map_height and 0 <= map_x < self.map_width:
                    cell = self.map_data[map_y][map_x]
                    base_id = cell['base_id']
                    if base_id in (1, 2, 3, 4, 5, 6, 7):
                        props = cell.get('properties', {})
                        if not props.get('addcollision', True):
                            bullet.alive = True
                            continue
                        mat = self._get_material_for_cell(cell)
                        wall_col = mat.color if mat and mat.color else (200, 200, 200)

                        passes_through = (
                                not props.get('addcollision', True)
                                or (base_id == 7 and props.get('type') == 'key')
                        )
                        if not passes_through:
                            mat = self._get_material_for_cell(cell)
                            wall_col = mat.color if mat and mat.color else (200, 200, 200)

                        # ID=7 двери: если дверь закрыта — она стена, если открыта — пропускаем
                        if base_id == 7:
                            door_id = props.get('id', None)
                            if props.get('type') == 'door':
                                if props.get('open', False):
                                    # Открытая дверь — пуля пролетает
                                    pass
                                else:
                                    # Закрытая — считаем как стену
                                    if props.get('destructible', False):
                                        current_hp = props.get('hp', getattr(self, 'default_wall_hp', 100))
                                        new_hp = current_hp - bullet.damage
                                        props['hp'] = new_hp
                                        if new_hp <= 0:
                                            self.particles.spawn_wall_break(
                                                bullet.x, bullet.y,
                                                texture=mat.texture if mat else None,
                                                color=wall_col,
                                                mode=self.particles.debris_mode)
                                            self.decals.spawn_rubble(
                                                bullet.x, bullet.y, wall_col,
                                                size=96, cell=(map_x, map_y),
                                                wall_texture=mat.texture if mat else None)
                                            cell['base_id'] = 0
                                            if self.use_gpu:
                                                self.gpu_raycaster.mark_map_dirty()
                                            cell['properties'].pop('material', None)
                                            # Удаляем спрайт двери
                                            sprite_key = self.doors.get(door_id, {}).get('sprite_key')
                                            if sprite_key:
                                                self.sprite_manager.remove_by_key(sprite_key)
                                            self.doors.pop(door_id, None)
                                            if self.use_gpu:
                                                self.gpu_raycaster.mark_map_dirty()
                                        else:
                                            self.particles.spawn_hit_wall(
                                                bullet.x, bullet.y, wall_col,
                                                count=10 if self.particles.debris_enabled else 6)
                                    else:
                                        self.particles.spawn_hit_wall(bullet.x, bullet.y, wall_col)
                                    self._bullet_hit(bullet)
                                    bullet.alive = False
                            # elif props.get('type') == 'key':
                            #     # Ключ — просто пропускаем пулю (или спавним искры)
                            #     self.particles.spawn_hit_wall(bullet.x, bullet.y, (255, 215, 0), count=6)
                            #     self._bullet_hit(bullet)
                            #     bullet.alive = False

                        # ID=6 — модель-объект (спрайт .gbj)
                        elif base_id == 6:
                            if props.get('destructible', False):
                                current_hp = props.get('hp', self.default_wall_hp)
                                new_hp = current_hp - bullet.damage
                                props['hp'] = new_hp

                                # Берём текстуру спрайта модели
                                model_key = f"model_{map_x}_{map_y}"
                                sprite = self.sprite_manager.get_by_key(model_key)
                                model_texture = None
                                if sprite is not None:
                                    if hasattr(sprite, 'frame_sets') and sprite.frame_sets:
                                        frame_set = sprite.frame_sets[sprite.current_frame_index]
                                        if frame_set:
                                            model_texture = frame_set[sprite.current_angle_frame]
                                    elif hasattr(sprite, 'frames') and sprite.frames:
                                        model_texture = sprite.frames[0]
                                    elif hasattr(sprite, 'texture'):
                                        model_texture = sprite.texture

                                # Если текстура модели найдена — используем её, иначе mat.texture (fallback)
                                use_texture = model_texture if model_texture is not None else (
                                    mat.texture if mat else None)

                                if new_hp <= 0:
                                    self.particles.spawn_wall_break(
                                        bullet.x, bullet.y,
                                        texture=use_texture,
                                        color=wall_col,
                                        mode=self.particles.debris_mode)
                                    self.decals.spawn_rubble(
                                        bullet.x, bullet.y, wall_col,
                                        size=96, cell=(map_x, map_y),
                                        wall_texture=use_texture)
                                    cell['base_id'] = 0
                                    cell['properties'].pop('material', None)
                                    self.sprite_manager.remove_by_key(model_key)
                                    if self.use_gpu:
                                        self.gpu_raycaster.mark_map_dirty()
                                else:
                                    self.particles.spawn_hit_wall(
                                        bullet.x, bullet.y, wall_col,
                                        count=10 if self.particles.debris_enabled else 6)
                                self._bullet_hit(bullet)
                                bullet.alive = False
                            else:
                                self._bullet_hit(bullet)
                                bullet.alive = False

                        # ID=1–5 — обычные стены
                        else:
                            if props.get('destructible', False):
                                current_hp = props.get('hp', getattr(self, 'default_wall_hp', 100))
                                new_hp = current_hp - bullet.damage
                                props['hp'] = new_hp
                                if new_hp <= 0:
                                    self.particles.spawn_wall_break(
                                        bullet.x, bullet.y,
                                        texture=mat.texture if mat else None,
                                        color=wall_col,
                                        mode=self.particles.debris_mode)
                                    self.decals.spawn_rubble(
                                        bullet.x, bullet.y, wall_col,
                                        size=96, cell=(map_x, map_y),
                                        wall_texture=mat.texture if mat else None)
                                    cell['base_id'] = 0
                                    cell['properties'].pop('material', None)
                                    if self.use_gpu:
                                        self.gpu_raycaster.mark_map_dirty()
                                else:
                                    self.particles.spawn_hit_wall(
                                        bullet.x, bullet.y, wall_col,
                                        count=10 if self.particles.debris_enabled else 6)
                            else:
                                self.particles.spawn_hit_wall(bullet.x, bullet.y, wall_col)
                            self._bullet_hit(bullet)
                            bullet.alive = False

            if not bullet.alive:
                self.bullets.remove(bullet)

    def play_sound_3d(self, sound_key, source_pos=(0,0), max_distance=500.0, doppler_factor=0.0):
        """Воспроизводит звук с учётом позиции источника и ориентации камеры.

        source_pos: (x, y) в мировых координатах (пикселях) или в тайлах? Уточним.
        """
        if sound_key not in self.sound_manager.sounds:
            return None
        sound = self.sound_manager.sounds[sound_key]
        snd3d = Sound3D(sound)
        listener_pos = (self.player.pos.x, self.player.pos.y)
        listener_angle = self.player.angle
        snd3d.play(listener_pos, listener_angle, source_pos, max_distance, doppler_factor)
        return snd3d

    def play_sound_3d_world(self, sound_key, world_x=0, world_y=0, max_distance=500.0, doppler_factor=0.0):
        """Позиция в мировых координатах (пикселях)."""
        return self._play_sound_3d_impl(sound_key, (world_x, world_y), max_distance, doppler_factor)

    def play_sound_3d_tile(self, sound_key, tile_x=0, tile_y=0, max_distance=500.0, doppler_factor=0.0):
        """Позиция в тайлах (умножается на tile_size)."""
        return self._play_sound_3d_impl(sound_key,
                                        (tile_x * self.tile_size, tile_y * self.tile_size),
                                        max_distance, doppler_factor)

    def get_sound_occlusion_factor(self, pos1, pos2):
        """
        Возвращает множитель громкости, учитывающий препятствия на пути звука.
        pos1, pos2 – мировые координаты (x, y).
        """
        if not self.map_data:
            return 1.0

        x1, y1 = pos1
        x2, y2 = pos2
        dx = x2 - x1
        dy = y2 - y1
        dist = math.hypot(dx, dy)
        if dist < 0.1:
            return 1.0

        steps = int(dist / (self.tile_size * 0.5)) + 1
        wall_count = 0
        for i in range(1, steps):
            t = i / steps
            x = x1 + dx * t
            y = y1 + dy * t
            map_x = int(x // self.tile_size)
            map_y = int(y // self.tile_size)
            if 0 <= map_y < self.map_height and 0 <= map_x < self.map_width:
                cell = self.map_data[map_y][map_x]
                base_id = cell['base_id']
                # Стены считаем, если это непрозрачные стены (ID 1-5 и закрытые двери)
                if base_id in (1, 2, 3, 4, 5):
                    wall_count += 1
                elif base_id == 7:
                    props = cell.get('properties', {})
                    if props.get('type') == 'door' and not props.get('open', False):
                        wall_count += 1
        # Каждая стена ослабляет звук на 30%
        return 0.7 ** wall_count

    def play_sound_3d_player_camera(self, sound_key, offset_x=0, offset_y=0, max_distance=500.0, doppler_factor=0.0):
        """Позиция относительно игрока с учётом поворота камеры (offset_x вперёд, offset_y вправо)."""
        angle = self.player.angle
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)
        world_x = self.player.pos.x + offset_x * cos_a - offset_y * sin_a
        world_y = self.player.pos.y + offset_x * sin_a + offset_y * cos_a
        return self._play_sound_3d_impl(sound_key, (world_x, world_y), max_distance, doppler_factor)

    def play_sound_3d_player(self, sound_key, offset_x=0, offset_y=0, max_distance=500.0, doppler_factor=0.0):
        """Позиция относительно игрока без учёта поворота (просто смещение по осям)."""
        world_x = self.player.pos.x + offset_x
        world_y = self.player.pos.y + offset_y
        return self._play_sound_3d_impl(sound_key, (world_x, world_y), max_distance, doppler_factor)

    def _play_sound_3d_impl(self, sound_key, source_pos, max_distance=500.0, doppler_factor=0.0):
        if sound_key not in self.sound_manager.sounds:
            return None
        sound = self.sound_manager.sounds[sound_key]
        snd3d = Sound3D(sound)
        snd3d.engine = self
        snd3d.play((self.player.pos.x, self.player.pos.y), self.player.angle, source_pos, max_distance, doppler_factor)
        self.active_3d_sounds.append(snd3d)
        return snd3d

    def _draw_enemies(self, screen, enemy_image=None):
        """Рисует врагов как спрайты."""
        for enemy in self.enemies:
            if not enemy.alive:
                continue
            if not self._is_sprite_visible(enemy.x, enemy.y):
                continue
            # Вычисляем позицию на экране аналогично спрайтам
            dx = enemy.x - self.player.pos.x
            dy = enemy.y - self.player.pos.y
            dist = math.hypot(dx, dy)
            if dist < 0.1:
                continue

            angle_to_enemy = math.atan2(dy, dx)
            relative_angle = angle_to_enemy - self.player.angle
            while relative_angle < -math.pi:
                relative_angle += 2 * math.pi
            while relative_angle > math.pi:
                relative_angle -= 2 * math.pi

            if abs(relative_angle) > self.half_fov:
                continue

            screen_x = (relative_angle / self.fov + 0.5) * self.width
            size = self.proj_coeff / dist
            if size > self.height:
                size = self.height
            if size < 1:
                size = 1

            # Используем текстуру врага, если есть, иначе цветной квадрат
            tex = enemy.texture
            if tex is None:
                try:
                    tex = load_image(enemy_image or self.enemy_sprite, enemy_image or self.enemy_sprite, size=(64, 64))
                except:
                    tex = pygame.Surface((32, 32))
                    tex.fill((255, 0, 0))

            # Применяем освещение
            light = self.light_tracer.get_light_at_point(pygame.Vector2(enemy.x, enemy.y))
            light = max(light, self.light_tracer.get_light_for_depth(dist) * 0.2)
            shaded = tex.copy()
            shaded.fill((int(255 * light), int(255 * light), int(255 * light)), special_flags=pygame.BLEND_RGB_MULT)
            scaled = pygame.transform.scale(shaded, (int(size), int(size)))
            # Отрисовка по центру
            horizon = self.height // 2 + self._get_pitch_offset()
            screen.blit(scaled, (screen_x - size // 2, horizon - size // 2))

    def _draw_gun_and_crosshair(self, screen):
        """Рисует текущее оружие внизу экрана и прицел в центре."""
        gun = self.gun_manager.get_current_gun()
        if gun:
            tex = gun.get_current_texture(moving=False)
            if tex is None:
                tex = gun.texture
            if tex:
                # Берём размер из самой текстуры — не hardcoded
                gun_w, gun_h = tex.get_size()

                # Если хочешь дополнительно масштабировать относительно экрана:
                # gun_w = int(self.screen_width * 0.25)
                # gun_h = int(gun_h * (gun_w / tex.get_width()))

                x = self.screen_width - gun_w - 20  # отступ 20px от правого края
                y = self.screen_height - gun_h
                screen.blit(tex, (x, y))

        # Прицел — крестик
        cx = self.width // 2
        cy = self.height // 2 + self._get_pitch_offset()
        color = (255, 0, 0)
        pygame.draw.line(screen, color, (cx - 10, cy), (cx + 10, cy), 2)
        pygame.draw.line(screen, color, (cx, cy - 10), (cx, cy + 10), 2)
        pygame.draw.circle(screen, color, (cx, cy), 5, 1)

    def _get_model_cache_key(self, path, rot_x, rot_y, rot_z, scale, color):
        """Создаёт уникальный ключ кэша для модели с заданными параметрами."""
        color_str = '_'.join(map(str, color)) if color else 'default'
        return f"{path}_{rot_x}_{rot_y}_{rot_z}_{scale}_{color_str}".replace('/', '_').replace('\\', '_')

    def prepare_models(self, screen):
        print("prepare_models started")
        cache_dir = "cache"
        if not os.path.exists(cache_dir):
            os.makedirs(cache_dir)

        # Собираем все модели из всех уровней
        all_models = []
        for level in self.levels:
            parser = MapParser()
            layers = parser.parse_layers(level)
            map_data = layers.get('collision', [])
            for row in map_data:
                for cell in row:

                    if cell['base_id'] == 6:
                        props = cell.get('properties', {})
                        path = props.get('path')
                        if not path:
                            continue
                        rot_x = float(props.get('rotx', 0))
                        rot_y = float(props.get('roty', 0))
                        rot_z = float(props.get('rotz', 0))
                        scale = float(props.get('scale', 1.0))
                        color_hex = props.get('color')
                        color = self._hex_to_rgb(color_hex) if color_hex else (200, 100, 100)
                        cache_key = self._get_model_cache_key(path, rot_x, rot_y, rot_z, scale, color)
                        all_models.append({
                            'cache_key': cache_key,
                            'path': path,
                            'rot_x': rot_x,
                            'rot_y': rot_y,
                            'rot_z': rot_z,
                            'scale': scale,
                            'color': color
                        })

        total = len(all_models)
        if total == 0:
            print("No models to cache")
            self._process_models()  # если моделей нет, просто загружаем уровень
            return

        generated = 0
        for idx, model in enumerate(all_models):
            cache_key = model['cache_key']
            # Проверяем, есть ли уже в глобальном кэше
            with self.model_cache_lock:
                in_memory = cache_key in self.global_model_cache
            if in_memory:
                generated += 1
                self.show_loading(screen, generated, total)
                continue

            # Проверяем файловый кэш
            sprites = self._load_sprites_from_cache(cache_key, num_frames=64)
            if sprites:
                with self.model_cache_lock:
                    self.global_model_cache[cache_key] = sprites
                generated += 1
                self.show_loading(screen, generated, total)
                continue

            # Генерируем спрайты
            print(f"Generating sprites for {model['path']}...")
            sprites = obj_to_sprites(
                model['path'],
                num_angles=128,
                sprite_size=(512, 512),
                scale=model['scale'],
                color=model['color'],
                model_rot_x=model['rot_x'],
                model_rot_y=model['rot_y'],
                model_rot_z=model['rot_z']
            )
            if sprites:
                self._save_sprites_to_cache(cache_key, sprites)
                with self.model_cache_lock:
                    self.global_model_cache[cache_key] = sprites
                generated += 1
            else:
                print(f"Failed to generate sprites for {model['path']}")

            self.show_loading(screen, generated, total)

        # После генерации всех моделей загружаем спрайты текущего уровня в сцену
        self._process_models()

        # Финальный экран загрузки (если есть водяной знак)
        if self.watermark:
            self.show_loading(screen, total, total)
            pygame.time.delay(3000)
        self.watermark = False

    def show_loading(self, screen, current, total):
        # screen.fill((10, 10, 30))

        # Логотип – теперь 50% ширины экрана
        if self.watermark:
            wm_width = screen.get_width()
            wm_height = screen.get_height()
            wm = pygame.transform.scale(self.watermark, (wm_width, wm_height))
            screen.blit(wm, (0,0))

        # font = pygame.font.SysFont('Arial', 36)
        # text = font.render(f"Кэширование моделей: {current}/{total}", True, (255, 255, 255))
        # screen.blit(text, (screen.get_width()//2 - text.get_width()//2, screen.get_height()//1.2 + 50))
        # pygame.display.flip()

        # Текст прогресса
        font = pygame.font.SysFont('Arial', 36)
        text = font.render(f"Кэширование моделей: {current}/{total}", True, (255, 255, 255))
        screen.blit(text, (screen.get_width() // 2 - text.get_width() // 2, screen.get_height() // 1.2 + 50))

        pygame.display.flip()

    def handle_mouse(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 3:
                self.mouse_captured = not self.mouse_captured
                pygame.mouse.set_visible(not self.mouse_captured)
                pygame.event.set_grab(self.mouse_captured)
        elif event.type == pygame.MOUSEMOTION and self.mouse_captured:
            dx, dy = event.rel
            self.player.angle += dx * self.mouse_sensitivity
            # Y-shearing по вертикали мыши
            if hasattr(self.player, 'add_pitch'):
                self.player.add_pitch(dy * self.mouse_sensitivity)

    def _load_watermark(self):
        try:
            path = os.path.join(os.path.dirname(__file__), 'material', 'images', 'watermark.png')
            if os.path.exists(path):
                self.watermark = pygame.image.load(path).convert_alpha()
            else:
                # Создаём заглушку
                surf = pygame.Surface((300, 100), pygame.SRCALPHA)
                surf.fill((50, 50, 150, 200))
                font = pygame.font.SysFont('Arial', 36)
                text = font.render("Gradus RC", True, (255, 255, 255))
                surf.blit(text, (10, 10))
                self.watermark = surf
        except:
            self.watermark = None


    def start_with_menu(self, menu_example):
        self.example_menu = menu_example
        # self.use_example = True

    def start_game(self):
        if self.example_game:
            # Запускаем игру
            self.example_game.run()
        else:
            # Если нет, запускаем обычный цикл (пользовательский)
            pass

    def set_game_example(self, game_example):
        self.example_game = game_example

    def play_video(self, filepath, mode="full", x=0, y=0, width=0, height=0, loop=True, alpha_chroma=False, chroma_color=(0,255,0)):
        """
        Воспроизводит видео на экране.
        mode: "full" – полноэкранное, "angle" – в углу (левый верхний, 25% экрана), "custom" – с указанными x,y,width,height.
        alpha_chroma – если True, заменяет chroma_color на прозрачный.
        """
        if self.video_playing:
            self.stop_video()

        self.video_loop = loop
        self.video_mode = mode
        if mode == "full":
            self.video_rect = pygame.Rect(0, 0, self.width, self.height)
        elif mode == "angle":
            w = self.width // 4
            h = self.height // 4
            self.video_rect = pygame.Rect(0, 0, w, h)
        else:
            if width <= 0: width = self.width // 4
            if height <= 0: height = self.height // 4
            width = min(width, self.width)
            height = min(height, self.height)
            self.video_rect = pygame.Rect(x, y, width, height)

        self.video_playing = True
        self.video_thread = threading.Thread(target=self._video_worker, args=(filepath, alpha_chroma, chroma_color), daemon=True)
        self.video_thread.start()

    def stop_video(self):
        self.video_playing = False
        if self.video_thread and self.video_thread.is_alive():
            self.video_thread.join(timeout=0.1)
        self.video_surface = None

    def on_interactive_press(self, action_name, obj):
        """Переопределяется в игре. По умолчанию ничего."""
        pass

    def _video_worker(self, filepath, alpha_chroma, chroma_color):
        try:
            reader = imageio.get_reader(filepath, 'ffmpeg')
            fps = reader.get_meta_data().get('fps', 30)
            frame_delay = 1.0 / fps
            for frame in reader:
                if not self.video_playing:
                    break
                # Конвертируем кадр в pygame Surface
                frame_rgb = frame[:, :, :3]  # игнорируем альфа, если есть
                surf = pygame.surfarray.make_surface(frame_rgb.swapaxes(0, 1))
                if alpha_chroma:
                    # Заменяем цвет на прозрачный
                    surf = surf.convert_alpha()
                    # Пробегаем по пикселям (медленно, но для демонстрации)
                    # Оптимизация: использовать pygame.color_threshold? Можно.
                    # Для простоты используем numpy
                    import numpy as np
                    arr = pygame.surfarray.pixels3d(surf)
                    # Создаём маску для chroma_color
                    mask = (arr[:, :, 0] == chroma_color[0]) & (arr[:, :, 1] == chroma_color[1]) & (arr[:, :, 2] == chroma_color[2])
                    arr[mask] = [0,0,0]  # чёрный
                    # Делаем альфа-канал
                    surf = surf.convert_alpha()
                    arr_alpha = pygame.surfarray.pixels_alpha(surf)
                    arr_alpha[mask] = 0
                    arr_alpha[~mask] = 255
                    del arr, arr_alpha

                # Масштабируем до размера rect
                if self.video_rect.width != surf.get_width() or self.video_rect.height != surf.get_height():
                    surf = pygame.transform.scale(surf, (self.video_rect.width, self.video_rect.height))
                with self.video_lock:
                    self.video_surface = surf
                # Ждём следующий кадр
                pygame.time.delay(int(frame_delay * 1000))
            if self.video_loop and self.video_playing:
                self._video_worker(filepath, alpha_chroma, chroma_color)  # перезапустить
        except Exception as e:
            print(f"Video error: {e}")
        finally:
            self.video_playing = False

    def _draw_video(self, screen):
        if self.video_surface:
            with self.video_lock:
                surf = self.video_surface.copy()
            screen.blit(surf, self.video_rect)

    # ================ MicroAPI ================
    class MicroAPI:
        def __init__(self, engine):
            self.engine = engine

        def set_light_update_hz(self, hz: int, target_fps: int = 60):
            """
            Фиксированная частота обновления света/RTE.
            hz=60 — каждый кадр, hz=30 — каждый 2-й, hz=15 — каждый 4-й.
            target_fps — текущий FPS игры, нужен для расчёта интервала.
            """
            if hz <= 0:
                self._light_update_interval = 1
                return
            interval = max(1, int(round(target_fps / hz)))
            self._light_update_interval = interval
            print(f"[RTE] Light update: {hz} Hz (interval = {interval} frames)")

        def set_rt_quality(self, quality):
            """
            Качество RTE: 'fast' | 'balanced' | 'high' | 'ultra' | 'reference'.
            Влияет на: samples soft shadows, samples AO, радиус AO.
            """
            rt_quality = quality if quality in (
                'fast', 'balanced', 'high', 'ultra', 'reference'
            ) else self.engine.rt_quality or 'balanced'
            return self.engine.set_rt_quality(quality)

        # ===================== КООРДИНАТЫ =====================

        def world_to_tile(self, x, y):
            t = self.engine.tile_size
            return (int(x // t), int(y // t))

        def tile_to_world(self, tx, ty, center=True):
            t = self.engine.tile_size
            return (tx * t + (t // 2 if center else 0),
                    ty * t + (t // 2 if center else 0))

        def get_map_size(self):
            return (self.engine.map_width, self.engine.map_height)

        def is_walkable(self, x, y):
            return self.engine._is_walkable(x, y)

        def get_cell_property(self, tx, ty, key, default=None):
            cell = self.get_cell(tx, ty)
            return default if cell is None else cell.get('properties', {}).get(key, default)

        @staticmethod
        def world_distance(x1, y1, x2, y2):
            return math.hypot(x2 - x1, y2 - y1)

        @staticmethod
        def angle_to(x1, y1, x2, y2):
            return math.atan2(y2 - y1, x2 - x1)

        @staticmethod
        def angle_diff(a, b):
            d = (a - b) % (2 * math.pi)
            return d - 2 * math.pi if d > math.pi else d

        # ===================== RAYCAST / LOS / ПРОЕКЦИЯ =====================

        def raycast(self, x, y, dx, dy, max_dist=None,
                    ignore_walls=False, ignore_sprites=False):
            """
            DDA-луч по сетке + проверка спрайтов/врагов.
            Возврат: dict(hit, type, x, y, dist, cell, sprite, normal)
            """
            e = self.engine
            if max_dist is None:
                max_dist = e.max_depth * e.tile_size
            n = math.hypot(dx, dy) or 1.0
            dx, dy = dx / n, dy / n
            T = e.tile_size

            hit_wall, wall_dist, side = None, max_dist, 0
            if not ignore_walls:
                mpx, mpy = int(x // T), int(y // T)
                ddx = 1e30 if dx == 0 else abs(1.0 / dx)
                ddy = 1e30 if dy == 0 else abs(1.0 / dy)
                step_x = 1 if dx >= 0 else -1
                step_y = 1 if dy >= 0 else -1
                sdx = ((mpx + 1 - x / T) if dx >= 0 else (x / T - mpx)) * ddx
                sdy = ((mpy + 1 - y / T) if dy >= 0 else (y / T - mpy)) * ddy
                for _ in range(int(max_dist / T) + 2):
                    if sdx < sdy:
                        sdx += ddx;
                        mpx += step_x;
                        side = 0
                    else:
                        sdy += ddy;
                        mpy += step_y;
                        side = 1
                    if not (0 <= mpx < e.map_width and 0 <= mpy < e.map_height):
                        break
                    if not e._is_walkable(mpx * T + T // 2, mpy * T + T // 2):
                        hit_wall = e.map_data[mpy][mpx]
                        wall_dist = ((sdx - ddx) if side == 0 else (sdy - ddy)) * T
                        break

            hit_sprite, sprite_dist = None, max_dist
            if not ignore_sprites:
                for sp in list(e.sprite_manager.sprites) + list(e.enemies):
                    sx = getattr(sp, 'x', None)
                    sy = getattr(sp, 'y', None)
                    if sx is None or sy is None:
                        continue
                    vx, vy = sx - x, sy - y
                    t = vx * dx + vy * dy
                    if t < 0 or t > sprite_dist:
                        continue
                    px, py = x + dx * t, y + dy * t
                    d2 = (sx - px) ** 2 + (sy - py) ** 2
                    r = getattr(sp, 'world_radius', None) or 24.0
                    if d2 < r * r:
                        sprite_dist, hit_sprite = t, sp

            if hit_sprite is not None and sprite_dist <= wall_dist:
                return {'hit': True, 'type': 'sprite',
                        'x': x + dx * sprite_dist, 'y': y + dy * sprite_dist,
                        'dist': sprite_dist, 'sprite': hit_sprite,
                        'cell': None, 'normal': (-dx, -dy)}
            if hit_wall is not None:
                return {'hit': True, 'type': 'wall',
                        'x': x + dx * wall_dist, 'y': y + dy * wall_dist,
                        'dist': wall_dist, 'sprite': None, 'cell': hit_wall,
                        'normal': ((-step_x, 0) if side == 0 else (0, -step_y))}
            return {'hit': False, 'type': None,
                    'x': x + dx * max_dist, 'y': y + dy * max_dist,
                    'dist': max_dist, 'cell': None, 'sprite': None,
                    'normal': (0, 0)}

        def has_line_of_sight(self, x1, y1, x2, y2):
            dx, dy = x2 - x1, y2 - y1
            d = math.hypot(dx, dy)
            if d < 0.1:
                return True
            r = self.raycast(x1, y1, dx, dy, max_dist=d - 1, ignore_sprites=True)
            return not (r['hit'] and r['type'] == 'wall')

        def project_world_to_screen(self, wx, wy):
            """
            → (screen_x, horizon_y, size_px) | None (за FOV)
            """
            e = self.engine
            dx, dy = wx - e.player.pos.x, wy - e.player.pos.y
            dist = max(1.0, math.hypot(dx, dy))
            rel = math.atan2(dy, dx) - e.player.angle
            while rel < -math.pi: rel += 2 * math.pi
            while rel > math.pi: rel -= 2 * math.pi
            if abs(rel) > e.half_fov:
                return None
            scr_x = (rel / e.fov + 0.5) * e.width
            size = e.proj_coeff / dist
            horizon = e.height // 2 + e._get_pitch_offset()
            return (scr_x, horizon, size)

        # ===================== ПАКЕТНЫЕ ЗАПРОСЫ =====================

        def query_enemies_in_radius(self, x, y, r):
            r2 = r * r
            return [en for en in self.engine.enemies if en.alive
                    and (en.x - x) ** 2 + (en.y - y) ** 2 <= r2]

        def query_interactives_in_radius(self, x, y, r):
            r2 = r * r
            return [o for o in self.engine.interactive_objects.values()
                    if o.alive and (o.x - x) ** 2 + (o.y - y) ** 2 <= r2]

        def query_tiles_in_radius(self, x, y, r):
            e = self.engine
            T = e.tile_size
            ctx, cty = int(x // T), int(y // T)
            tr = int(r // T) + 1
            out = []
            for ty in range(cty - tr, cty + tr + 1):
                for tx in range(ctx - tr, ctx + tr + 1):
                    if not (0 <= tx < e.map_width and 0 <= ty < e.map_height):
                        continue
                    wx, wy = tx * T + T // 2, ty * T + T // 2
                    if (wx - x) ** 2 + (wy - y) ** 2 <= r * r:
                        out.append((tx, ty, e.map_data[ty][tx]))
            return out

        def get_nearest_enemy(self, x, y, max_dist=None):
            best, bd = None, max_dist if max_dist is not None else float('inf')
            for en in self.engine.enemies:
                if not en.alive:
                    continue
                d = math.hypot(en.x - x, en.y - y)
                if d < bd:
                    best, bd = en, d
            return best

        def get_nearest_interactive(self, x, y, max_dist=None):
            best, bd = None, max_dist if max_dist is not None else float('inf')
            for o in self.engine.interactive_objects.values():
                if not o.alive:
                    continue
                d = math.hypot(o.x - x, o.y - y)
                if d < bd:
                    best, bd = o, d
            return best

        # ===================== ИГРОК =====================

        def get_player_pos(self):
            return (self.engine.player.pos.x, self.engine.player.pos.y)

        def get_player_angle(self):
            return self.engine.player.angle

        def get_player_pitch(self):
            return getattr(self.engine.player, 'pitch', 0.0)

        def set_player_pitch(self, pitch):
            p = self.engine.player
            if not hasattr(p, 'pitch'):
                return 0.0
            old = p.pitch
            p.pitch = pitch
            return old

        def get_player_hp(self):
            return self.engine.player.hp

        def get_player_max_hp(self):
            return self.engine.player.max_hp

        def set_player_hp(self, hp):
            p = self.engine.player
            old = p.hp
            p.hp = max(0, hp)
            if p.hp <= 0 and p.alive:
                p.alive = False
                if p.on_death:
                    p.on_death()
            return old

        def set_player_max_hp(self, hp):
            p = self.engine.player
            old = p.max_hp
            p.max_hp = max(1, hp)
            return old

        def heal_player(self, amount):
            return self.set_player_hp(self.engine.player.hp + amount)

        def kill_player(self):
            self.engine.player.take_damage(self.engine.player.hp + 1)

        def is_player_alive(self):
            return self.engine.player.alive

        def set_player_invulnerable(self, inv=True):
            p = self.engine.player
            old = getattr(p, 'invulnerable', False)
            p.invulnerable = bool(inv)
            return old

        def set_player_noclip(self, enabled=True):
            old = getattr(self.engine, 'noclip', False)
            self.engine.noclip = bool(enabled)
            return old

        def set_player_regen(self, enabled=None, value=None, interval=None):
            p = self.engine.player
            if enabled is not None: p.regen_enabled = bool(enabled)
            if value is not None: p.rv = value
            if interval is not None: p.rs = interval

        def teleport_player(self, x, y, angle=None, pitch=None):
            p = self.engine.player
            p.pos.x, p.pos.y = float(x), float(y)
            if angle is not None:
                p.angle = angle
            if pitch is not None and hasattr(p, 'pitch'):
                p.pitch = pitch

        def get_player_velocity(self):
            v = self.engine.player.vel
            return (v.x, v.y)

        def set_player_velocity(self, vx, vy):
            v = self.engine.player.vel
            old = (v.x, v.y)
            v.x, v.y = float(vx), float(vy)
            return old

        # ===================== ВРАГИ =====================

        def damage_enemy(self, enemy, amount, knockback=0.0, source=None):
            if enemy is None or not enemy.alive:
                return 0
            old = getattr(enemy, 'hp', 0)
            if hasattr(enemy, 'take_damage'):
                enemy.take_damage(amount, source)
            else:
                enemy.hp = old - amount
                if enemy.hp <= 0:
                    enemy.alive = False
            if knockback > 0 and getattr(enemy, 'alive', False):
                px, py = self.get_player_pos()
                dx, dy = enemy.x - px, enemy.y - py
                d = math.hypot(dx, dy) or 1.0
                enemy.x += dx / d * knockback
                enemy.y += dy / d * knockback
            return old - getattr(enemy, 'hp', 0)

        def kill_enemy(self, enemy):
            if enemy and getattr(enemy, 'alive', False):
                self.damage_enemy(enemy, getattr(enemy, 'hp', 1) + 1)

        def set_enemy_hp(self, enemy, hp):
            if not enemy:
                return None
            old = getattr(enemy, 'hp', 0)
            enemy.hp = hp
            if hp <= 0:
                enemy.alive = False
            return old

        def set_enemy_speed(self, enemy, speed):
            if not enemy:
                return None
            old = getattr(enemy, 'speed', 0)
            enemy.speed = float(speed)
            return old

        def set_enemy_state(self, enemy, state):
            """'static' | 'chase' | 'patrol' | 'frozen'"""
            if not enemy:
                return None
            old = getattr(enemy, 'type', None)
            enemy.type = state
            if state == 'frozen':
                enemy._frozen_speed = getattr(enemy, 'speed', 0)
                enemy.speed = 0.0
            elif old == 'frozen' and hasattr(enemy, '_frozen_speed'):
                enemy.speed = enemy._frozen_speed
            return old

        def freeze_enemy(self, enemy, duration):
            if not enemy:
                return
            old_speed = getattr(enemy, 'speed', 0)
            self.set_enemy_state(enemy, 'frozen')

            def _unfreeze():
                if enemy and getattr(enemy, 'alive', False):
                    enemy.speed = old_speed
                    if enemy.type == 'frozen':
                        enemy.type = 'chase'

            self.schedule(duration, _unfreeze)

        def set_enemy_target(self, enemy, x, y):
            if enemy:
                enemy.target = (float(x), float(y))

        def get_enemies_by_type(self, type_name):
            return [e for e in self.engine.enemies
                    if e.alive and getattr(e, 'type', None) == type_name]

        def is_enemy_visible(self, enemy):
            if not enemy:
                return False
            return self.engine._is_sprite_visible(enemy.x, enemy.y)

        # ===================== ОРУЖИЕ / ПУЛИ / HITSCAN =====================

        def spawn_bullet(self, x, y, angle, damage=10, speed=800,
                         owner='script', explosive=False,
                         explosion_radius=0.0, explosion_damage=0.0):
            b = Bullet(x, y, angle, damage=damage, speed=speed, owner=owner,
                       explosive=explosive,
                       explosion_radius=explosion_radius,
                       explosion_damage=explosion_damage)
            self.engine.bullets.append(b)
            return b

        def hitscan(self, x, y, angle, damage=10, max_dist=None, source=None):
            r = self.raycast(x, y, math.cos(angle), math.sin(angle),
                             max_dist=max_dist)
            if not r['hit']:
                return None
            if r['type'] == 'sprite' and r['sprite'] in self.engine.enemies:
                self.damage_enemy(r['sprite'], damage, source=source)
                self.engine.particles.spawn_hit_enemy(r['sprite'].x, r['sprite'].y)
                return r['sprite']
            if r['type'] == 'wall':
                self.engine.particles.spawn_hit_wall(r['x'], r['y'])
            return None

        def give_gun(self, gun):
            self.engine.gun_manager.add_gun(gun)

        def remove_gun(self, key):
            old = self.engine.gun_manager.guns.pop(key, None)
            if self.engine.gun_manager.current_gun_key == key:
                keys = list(self.engine.gun_manager.guns.keys())
                self.engine.gun_manager.current_gun_key = keys[0] if keys else None
            return old is not None

        def switch_gun(self, key):
            if key in self.engine.gun_manager.guns:
                self.engine.gun_manager.switch_gun(key)
                return True
            return False

        def get_current_gun(self):
            return self.engine.gun_manager.get_current_gun()

        def get_gun(self, key):
            return self.engine.gun_manager.guns.get(key)

        def set_gun_ammo(self, key, ammo):
            g = self.engine.gun_manager.guns.get(key)
            if not g:
                return None
            old = g.ammo
            g.ammo = int(ammo)
            return old

        def give_ammo(self, key, amount):
            g = self.engine.gun_manager.guns.get(key)
            if not g:
                return 0
            old = g.ammo
            g.ammo = min(g.max_ammo, g.ammo + int(amount))
            return g.ammo - old

        # ===================== СПАВН =====================

        def spawn_sprite(self, x, y, texture, key=None, scale=1.0,
                         world_radius=None):
            """Билборд. texture — Surface или путь. Возвращает Sprite."""
            if isinstance(texture, str):
                texture = load_image(texture, texture, size=(64, 64))
            if world_radius:
                scale = world_radius / 32.0
            if scale != 1.0 and texture is not None:
                w, h = texture.get_size()
                texture = pygame.transform.scale(texture, (int(w * scale),
                                                           int(h * scale)))
            sp = Sprite(x, y, texture, key=key)
            self.engine.add_sprite(sp)
            return sp

        def spawn_model(self, x, y, model_path, scale=1.0,
                        rot_y=0.0, rot_x=0.0, rot_z=0.0,
                        color=(200, 100, 100), key=None):
            sprites = obj_to_sprites(model_path, num_angles=128, sprite_size=(512, 512),
                                     scale=scale, color=color,
                                     model_rot_x=rot_x, model_rot_y=rot_y,
                                     model_rot_z=rot_z)
            if not sprites:
                return None
            sp = AnimatedModelSprite(x, y, [sprites], key=key,
                                     rot_y=math.radians(rot_y),
                                     rot_x=math.radians(rot_x),
                                     rot_z=math.radians(rot_z))
            self.engine.sprite_manager.add(sp)
            return sp

        def spawn_blood(self, x, y, size=64):
            return self.engine.decals.spawn_blood(x, y, size=size)

        def spawn_transient_light(self, x, y, radius=200.0, intensity=1.5,
                                  color=(255, 240, 180), ttl=0.35):
            self.engine.transient_lights.append([x, y, radius, intensity, color, ttl])

        def spawn_explosion(self, x, y, radius=120.0, damage=100.0,
                            color=(255, 180, 60)):
            ex = Explosion(x, y, radius, damage, color)
            self.engine.explosions.append(ex)
            return ex

        # ===================== КАРТА =====================

        def _set_prop(self, tx, ty, key, value):
            cell = self.get_cell(tx, ty)
            if cell is None:
                return None
            props = cell.setdefault('properties', {})
            old = props.get(key)
            props[key] = value
            if self.engine.use_gpu and self.engine.gpu_raycaster:
                self.engine.gpu_raycaster.mark_map_dirty()
            return old

        def set_cell_material(self, tx, ty, mat_name):
            return self._set_prop(tx, ty, 'material', mat_name)

        def set_cell_texture(self, tx, ty, texture_path):
            return self._set_prop(tx, ty, 'sprite', texture_path)

        def set_cell_height(self, tx, ty, height):
            return self._set_prop(tx, ty, 'height', float(height))

        def set_cell_water(self, tx, ty, enabled=True, reflectivity=0.7):
            self._set_prop(tx, ty, 'water', bool(enabled))
            self._set_prop(tx, ty, 'reflectivity', float(reflectivity))

        def fill_rect(self, tx1, ty1, tx2, ty2, base_id=0, **props):
            x1, x2 = sorted((int(tx1), int(tx2)))
            y1, y2 = sorted((int(ty1), int(ty2)))
            n = 0
            for ty in range(y1, y2 + 1):
                for tx in range(x1, x2 + 1):
                    cell = self.get_cell(tx, ty)
                    if cell is None:
                        continue
                    cell['base_id'] = base_id
                    cell['properties'] = dict(props)
                    n += 1
            if self.engine.use_gpu and self.engine.gpu_raycaster:
                self.engine.gpu_raycaster.mark_map_dirty()
            return n

        def fill_circle(self, cx, cy, radius, base_id=0, **props):
            T = self.engine.tile_size
            cells = self.query_tiles_in_radius(
                cx * T + T // 2, cy * T + T // 2, radius * T)
            n = 0
            for tx, ty, cell in cells:
                cell['base_id'] = base_id
                cell['properties'] = dict(props)
                n += 1
            if self.engine.use_gpu and self.engine.gpu_raycaster:
                self.engine.gpu_raycaster.mark_map_dirty()
            return n

        # ===================== ТАЙМИНГИ / ТРИГГЕРЫ =====================

        def schedule(self, delay, callback, repeat=None):
            """
            Отложенный вызов. repeat=None → один раз; иначе — каждые `repeat` сек.
            """
            entry = {'timer': float(delay), 'callback': callback,
                     'repeat': float(repeat) if repeat else None, 'alive': True}
            self.engine._scheduled_callbacks.append(entry)
            return entry

        def cancel_schedule(self, handle):
            if handle:
                handle['alive'] = False

        def after(self, delay, callback):
            return self.schedule(delay, callback)

        def every(self, interval, callback):
            return self.schedule(interval, callback, repeat=interval)

        def set_time_scale(self, scale):
            old = getattr(self.engine, 'time_scale', 1.0)
            self.engine.time_scale = max(0.0, float(scale))
            return old

        def get_frame_count(self):
            return getattr(self.engine, '_frame_counter', 0)

        def get_elapsed_time(self):
            return getattr(self.engine, '_elapsed_time', 0.0)

        def spawn_trigger(self, x, y, callback, radius=32.0, once=True, tag=None):
            """Невидимая зона: callback(player) при входе."""
            entry = {'x': float(x), 'y': float(y), 'r': float(radius),
                     'callback': callback, 'once': once, 'tag': tag,
                     'triggered': False, 'alive': True}
            self.engine._trigger_zones.append(entry)
            return entry

        def remove_trigger(self, handle):
            if handle:
                handle['alive'] = False

        # ===================== ЗВУК / МУЗЫКА =====================

        def play_sound(self, key, volume=1.0):
            if key in self.engine.sound_manager.sounds:
                s = self.engine.sound_manager.sounds[key]
                if volume != 1.0:
                    s = s.copy()
                    s.set_volume(volume)
                s.play()

        def play_music(self, path, loop=True, volume=1.0, fade_ms=0):
            path = resolve_path(path)
            try:
                pygame.mixer.music.load(path)
                pygame.mixer.music.set_volume(volume)
                pygame.mixer.music.play(-1 if loop else 0, fade_ms=fade_ms)
                return True
            except Exception as e:
                print(f"[Music] {e}")
                return False

        def stop_music(self, fade_ms=0):
            if fade_ms:
                pygame.mixer.music.fadeout(fade_ms)
            else:
                pygame.mixer.music.stop()

        def pause_music(self, paused=True):
            pygame.mixer.music.pause() if paused else pygame.mixer.music.unpause()

        def set_music_volume(self, v):
            pygame.mixer.music.set_volume(max(0.0, min(1.0, v)))

        def stop_3d_sound(self, handle):
            if handle and hasattr(handle, 'stop'):
                handle.stop()
            if handle in self.engine.active_3d_sounds:
                self.engine.active_3d_sounds.remove(handle)

        # ===================== ЭФФЕКТЫ ЭКРАНА =====================

        def flash_screen(self, color=(255, 255, 255), alpha=180, duration=0.15):
            entry = {'color': color, 'alpha': alpha,
                     'timer': float(duration), 'max': float(duration)}
            self.engine._screen_flashes.append(entry)
            return entry

        def set_vignette(self, intensity=0.5, color=(0, 0, 0)):
            self.engine._vignette = {'intensity': float(intensity), 'color': color}

        def clear_vignette(self):
            self.engine._vignette = None

        def set_skybox(self, texture_path=None, color=(20, 20, 30)):
            self.engine._skybox_tex = (
                load_image(texture_path, resolve_path(texture_path))
                if texture_path else None)
            self.engine._skybox_color = color

        def set_floor_texture(self, texture_path):
            self.engine.floor_texture = pygame.image.load(
                resolve_path(texture_path)).convert_alpha()

        def set_ceiling_texture(self, texture_path):
            self.engine.ceiling_texture = pygame.image.load(
                resolve_path(texture_path)).convert_alpha()

        # ===================== HUD =====================

        def show_subtitle(self, text, duration=2.0, color=(255, 255, 255),
                          font='Arial', size=24):
            self.engine.hud.push_subtitle(text, duration, color, font, size)

        def push_notification(self, title, text='', duration=2.5,
                              icon=None, color=(255, 200, 100)):
            self.engine.hud.push_notification(title, text, duration, icon, color)

        def bind_hud(self, draw_fn, layer=100):
            """
            Постоянный HUD-слой. draw_fn(screen, engine) вызывается каждый кадр
            ПОСЛЕ основного HUD. Возвращает handle для unbind_hud.
            """
            entry = {'fn': draw_fn, 'layer': int(layer), 'alive': True}
            self.engine.hud._custom_layers.append(entry)
            self.engine.hud._custom_layers.sort(key=lambda e: e['layer'])
            return entry

        def unbind_hud(self, handle):
            if handle:
                handle['alive'] = False
                try:
                    self.engine.hud._custom_layers.remove(handle)
                except ValueError:
                    pass

        def draw_text_world(self, wx, wy, text, color=(255, 255, 255),
                            font='Arial', size=18, offset_y=0):
            """Мировая 3D-надпись над точкой. Живёт один кадр — вызывай каждый тик."""
            proj = self.project_world_to_screen(wx, wy)
            if proj is None:
                return None
            scr_x, horizon, size = proj
            self.engine.hud._world_labels.append({
                'x': int(scr_x), 'y': int(horizon - size * 0.6) + offset_y,
                'text': str(text), 'color': color, 'font': font, 'size': int(size),
            })
            return True

        # ===================== КАСТОМНЫЙ РЕНДЕР (CPU) =====================

        def register_world_renderer(self, name, render_fn, z_order='sprite'):
            """
            Регистрирует функцию-рендерер для использования в карте и в spawn.

            render_fn(ctx) — вызывается для каждого объекта с данным name.
              ctx = {
                'screen':   pygame.Surface,        # рендер-таргет (render_surface!)
                'engine':   Engine,
                'obj':      объект (has .x, .y, .params),
                'x, y':     мировые координаты,
                'params':   dict произвольных параметров из карты,
                'project':  project_world_to_screen (удобный shortcut),
                'player':   player,
                'dt':       последний dt,
              }

            z_order:
              'floor'  — рисуется до стен (под спрайтами, поверх пола)
              'sprite' — вместе с обычными спрайтами (по умолчанию)
              'overlay'— поверх всего (для вспышек, облаков, тумана)
            """
            if not hasattr(self.engine, '_world_renderers'):
                self.engine._world_renderers = {}
            self.engine._world_renderers[name] = {
                'fn': render_fn, 'z_order': z_order
            }
            print(f"[Render] Зарегистрирован рендерер '{name}' ({z_order})")

        def unregister_world_renderer(self, name):
            if hasattr(self.engine, '_world_renderers'):
                return self.engine._world_renderers.pop(name, None) is not None
            return False

        def spawn_world_renderer(self, x, y, name, key=None, **params):
            """
            Создаёт объект, привязанный к позиции, с указанным рендерером.
            Возвращает handle для remove_world_renderer.
            """
            if not hasattr(self.engine, '_world_renderer_objects'):
                self.engine._world_renderer_objects = []
            handle = {'x': float(x), 'y': float(y), 'name': name,
                      'key': key, 'params': dict(params), 'alive': True,
                      'visible': True}
            self.engine._world_renderer_objects.append(handle)
            return handle

        def remove_world_renderer(self, handle):
            if handle:
                handle['alive'] = False

        def set_world_renderer_visible(self, handle, visible):
            if handle:
                handle['visible'] = bool(visible)

        def set_world_renderer_position(self, handle, x, y):
            if handle:
                handle['x'], handle['y'] = float(x), float(y)

        def set_world_renderer_param(self, handle, key, value):
            if handle:
                handle['params'][key] = value

        # ===================== КАСТОМНЫЙ РЕНДЕР (GPU, заготовка) =====================

        def register_gpu_pass(self, name, fragment_shader_src,
                              uniforms=None, blend_mode='alpha'):
            """
            Регистрирует дополнительный GPU-pass (только если use_gpu=True).
              fragment_shader_src — полный GLSL 330 frag-шейдер с `void main()`
              uniforms  — dict {'u_name': value} для uniform-ов, обновляется каждый кадр
              blend_mode — 'alpha' | 'add' | 'multiply' | 'none'
            Возвращает handle для unregister_gpu_pass.
            """
            if not self.engine.use_gpu:
                print(f"[GPU] pass '{name}' пропущен — GPU выключен")
                return None
            gpu = self.engine.gpu_raycaster
            if not hasattr(gpu, 'add_custom_pass'):
                print(f"[GPU] ВНИМАНИЕ: gpu_raycaster не поддерживает custom_pass "
                      f"(реализуем во 2-й итерации). Pass '{name}' сохранён в очереди.")
                if not hasattr(self.engine, '_pending_gpu_passes'):
                    self.engine._pending_gpu_passes = []
                handle = {'name': name, 'src': fragment_shader_src,
                          'uniforms': uniforms or {}, 'blend': blend_mode,
                          'alive': True, 'pending': True}
                self.engine._pending_gpu_passes.append(handle)
                return handle
            handle = gpu.add_custom_pass(name, fragment_shader_src,
                                         uniforms or {}, blend_mode)
            return handle

        def unregister_gpu_pass(self, handle):
            if not handle:
                return False
            handle['alive'] = False
            if handle.get('pending'):
                return True
            if self.engine.use_gpu and self.engine.gpu_raycaster:
                return self.engine.gpu_raycaster.remove_custom_pass(handle)
            return False

        def update_gpu_uniform(self, handle, name, value):
            if handle and 'uniforms' in handle:
                handle['uniforms'][name] = value

        # Старые функции

        def try_interact(self):
            e = self.engine
            px, py = e.player.pos.x, e.player.pos.y
            best = None
            best_d = 1e9
            for obj in e.interactive_objects.values():
                if not getattr(obj, 'can_press', False):  # ← can_press!
                    continue
                d = math.hypot(obj.x - px, obj.y - py)
                if d <= obj.radius and d < best_d:
                    best = obj
                    best_d = d
            if best is not None and best.on_press:
                e.on_interactive_press(best.on_press, best)
                return True
            return False

        def spawn_explosion(self, x, y, radius=120.0, damage=100.0, color=(255, 180, 60)):
            """Ручной спавн взрыва (для скриптов/трейлера)."""
            e = self.engine
            e.explosions.append(Explosion(x, y, radius, damage, color))

        def set_player_light_mode(self, mode='default', range=400.0, cone_angle=55.0):
            """
            'default'  — свет вокруг игрока (как было)
            'circle'   — конусный свет вперёд (фонарик)
            range      — длина конуса в пикселях
            cone_angle — полный угол раскрытия в градусах
            """
            import math
            e = self.engine
            if mode not in ('default', 'circle'):
                return
            e.player_light_mode = mode
            e.player_light_range = float(range)
            e.player_light_cone = math.cos(math.radians(cone_angle * 0.5))

        def set_fog(self, enabled=True, color=None, start=None, end=None,
                    floor_ceiling=None):
            e = self.engine
            e.fog_enabled = enabled
            if color is not None:        e.fog_color = color
            if start is not None:        e.fog_start = start
            if end is not None:          e.fog_end = end
            if floor_ceiling is not None: e.fog_floor_ceiling = floor_ceiling

        def disable_fog(self):
            self.engine.fog_enabled = False

        def set_rt(self, enabled=None, max_lights=None, reflections=None):
            """Управление Ray Tracing Emulator.
               enabled: True/False — включить soft shadows + reflections
               max_lights: сколько источников света учитывают тени (0..16, default 2)
               reflections: True/False — зеркала отдельно от теней
            """
            e = self.engine
            if enabled is not None:
                e.rt_enabled = bool(enabled)
            if max_lights is not None:
                try:
                    e.rt_max_lights = max(0, min(16, int(max_lights)))
                except (TypeError, ValueError):
                    pass
            if reflections is not None:
                e.rt_reflections = bool(reflections)

        def set_reflection(self, tile_x, tile_y, value):
            """Меняет reflection у материала, привязанного к клетке."""
            cell = self.get_cell(tile_x, tile_y)
            if not cell:
                return
            props = cell.get('properties', {})
            mat_name = props.get('material') or props.get('sprite')
            if not mat_name:
                return
            mat = self.engine.material_lib.get_material(mat_name)
            if mat is None:
                return
            mat.reflection = max(0.0, min(1.0, float(value)))
            if self.engine.use_gpu:
                self.engine.gpu_raycaster.mark_map_dirty()

        def set_enemy_bars(self, hp=None, ammo=None, max_distance=None):
            if hp is not None:
                self.engine.show_enemy_hp = hp
            if ammo is not None:
                self.engine.show_enemy_ammo = ammo
            if max_distance is not None:
                self.engine.enemy_bar_max_distance = max_distance

        def set_graphics_level(self, level):
            """'lite' | 'medium' | 'high' | 'ultra'"""
            self.engine.particles.set_graphics_level(level)

        def set_debris_mode(self, mode):
            """'big' | 'medium' | 'low'"""
            self.engine.particles.debris_mode = mode

        def set_wall_hp(self, tile_x, tile_y, hp=None):
            """Установить HP разрушаемой стены (или сделать её разрушаемой)."""
            cell = self.get_cell(tile_x, tile_y)
            if not cell:
                return
            if hp is None:
                hp = self.engine.default_wall_hp
            cell['properties']['destructible'] = True
            cell['properties']['hp'] = hp

        def get_wall_hp(self, tile_x, tile_y):
            cell = self.get_cell(tile_x, tile_y)
            if not cell:
                return None
            return cell['properties'].get('hp', None)

        def make_indestructible(self, tile_x, tile_y):
            cell = self.get_cell(tile_x, tile_y)
            if cell:
                cell['properties']['destructible'] = False

        def break_wall(self, tile_x, tile_y, mode=None):
            """Принудительно сломать стену с визуальным эффектом."""
            cell = self.get_cell(tile_x, tile_y)
            if not cell or cell['base_id'] not in (1, 2, 3, 4, 5):
                return False
            mat = self.engine._get_material_for_cell(cell)
            cx = tile_x * self.engine.tile_size + self.engine.tile_size // 2
            cy = tile_y * self.engine.tile_size + self.engine.tile_size // 2
            self.engine.particles.spawn_wall_break(
                cx, cy,
                texture=mat.texture if mat else None,
                color=mat.color if mat else (200, 200, 200),
                mode=mode
            )
            # сохраняем данные для восстановления
            original_id = cell['base_id']
            original_hp = cell['properties'].get('hp', self.engine.default_wall_hp)
            self.set_cell_base_id(tile_x, tile_y, 0)
            if self.engine.use_gpu:
                self.engine.gpu_raycaster.mark_map_dirty()
            return (original_id, original_hp)

        def restore_wall(self, tile_x, tile_y, delay=5.0, wall_id=3, hp=None):
            """Восстановить стену через delay секунд."""
            entry = {
                'x': tile_x, 'y': tile_y,
                'timer': delay,
                'id': wall_id,
                'hp': hp if hp is not None else self.engine.default_wall_hp
            }
            self.engine.scheduled_walls.append(entry)
            if self.engine.use_gpu:
                self.engine.gpu_raycaster.mark_map_dirty()

        def cancel_restore(self, tile_x, tile_y):
            """Отменить восстановление стены в клетке."""
            self.engine.scheduled_walls = [
                e for e in self.engine.scheduled_walls
                if not (e['x'] == tile_x and e['y'] == tile_y)
            ]

        def set_minimap(self, enabled=True, **kwargs):
            if not enabled:
                self.engine.minimap = None
                return
            self.engine.minimap = Minimap(self.engine, **kwargs)
            self.engine.minimap_enemy_hide_delay = kwargs.get('enemy_hide_delay', 5.0)

        def set_minimap_mode(self, mode):
            if self.engine.minimap:
                self.engine.minimap.mode = mode

        def set_minimap_custom(self, renderer):
            """renderer(screen, minimap) — полностью свой рендер."""
            if self.engine.minimap:
                self.engine.minimap.custom_renderer = renderer

        def set_minimap_visible_objects(self, enemies=None, billboards=None,
                                        models=None, doors=None, keys=None):
            mm = self.engine.minimap
            if not mm:
                return
            if enemies is not None:    mm.show_enemies = enemies
            if billboards is not None: mm.show_billboards = billboards
            if models is not None:     mm.show_models = models
            if doors is not None:      mm.show_doors = doors
            if keys is not None:       mm.show_keys = keys

        def minimap_show_enemy_now(self, enemy):
            """Мгновенно показать врага на карте (например, при выстреле)."""
            enemy.show_on_minimap = True
            enemy.last_seen_time = 0.0

        def hud_set_visible(self, visible=True):
            self.engine.hud.show_hud = visible

        def hud_set_crosshair(self, visible=True):
            self.engine.hud.show_crosshair = visible

        def hud_shake(self, intensity=8.0, duration=0.3):
            self.engine.hud.shake.trigger(intensity, duration)

        def hud_set_crosshair_spread(self, spread):
            self.engine.hud.crosshair_spread = spread

        def spawn_enemy(self, x=0, y=0, **kwargs):
            tex_path = kwargs.pop('sprite', None) or kwargs.pop('texture', None)
            if tex_path:
                texture = load_image(tex_path, tex_path, size=(64, 64))
                if texture is None:
                    texture = pygame.Surface((32, 32))
                    texture.fill((255, 0, 0))
                kwargs['texture'] = texture
            enemy = EnemyAI(x, y, **kwargs)
            self.engine.enemies.append(enemy)
            if enemy.sound_spawn:
                self.engine.play_sound_3d_world(enemy.sound_spawn, x, y)
            if enemy.effect_spawn:
                self.engine.effects_manager.set_effect(enemy.effect_spawn, alpha=255, intensity=0.5)
                if not enemy.effect_until_death:
                    self.engine.enemy_effect_timers[enemy.key or id(enemy)] = 2.0
            return enemy

        def spawn_enemy_by_tile(self, tile_x=0, tile_y=0, **kwargs):
            return self.spawn_enemy(tile_x * self.engine.tile_size, tile_y * self.engine.tile_size, **kwargs)

        def give_gun(self, gun):
            self.engine.gun_manager.add_gun(gun)

        def particles_set_mode(self, mode):
            """'off' | 'main' | 'optimal' | 'all'"""
            self.engine.particles.set_mode(mode)

        def particles_spawn(self, x, y, count=10, color=(255, 255, 255),
                            speed=100, life=0.5, size=3):
            import random, math
            for _ in range(count):
                ang = random.uniform(0, 2 * math.pi)
                spd = random.uniform(speed * 0.5, speed)
                self.engine.particles.particles.append(Particle(
                    x, y, math.cos(ang) * spd, math.sin(ang) * spd,
                    life=life, color=color, world_size=size, gravity=100
                ))

        def fire_current_gun(self):
            gun = self.engine.gun_manager.fire_current()
            if gun:
                angle = self.engine.player.angle
                bullet = Bullet(self.engine.player.pos.x, self.engine.player.pos.y, angle,
                                damage=gun.damage, speed=800, owner='player', explosive=gun.explosive,
                                explosion_damage=gun.explosion_damage, explosion_radius=gun.explosion_radius)
                self.engine.bullets.append(bullet)
                self.engine.hud.hit_marker(intensity=0.7)
                # вспышка у дула
                muzzle_x = self.engine.player.pos.x + math.cos(angle) * 20
                muzzle_y = self.engine.player.pos.y + math.sin(angle) * 20
                self.engine.particles.spawn_muzzle(muzzle_x, muzzle_y, angle)
                return True
            return False

        def play_sound_3d_world(self, sound_key, x=0, y=0, max_distance=500.0, doppler_factor=0.0):
            return self.engine.play_sound_3d_world(sound_key, x, y, max_distance, doppler_factor)

        def play_sound_3d_tile(self, sound_key, tile_x=0, tile_y=0, max_distance=500.0, doppler_factor=0.0):
            return self.engine.play_sound_3d_tile(sound_key, tile_x, tile_y, max_distance, doppler_factor)

        def play_sound_3d_player_camera(self, sound_key, offset_x=0, offset_y=0, max_distance=500.0, doppler_factor=0.0):
            return self.engine.play_sound_3d_player_camera(sound_key, offset_x, offset_y, max_distance, doppler_factor)

        def play_sound_3d_player(self, sound_key, offset_x=0, offset_y=0, max_distance=500.0, doppler_factor=0.0):
            return self.engine.play_sound_3d_player(sound_key, offset_x, offset_y, max_distance, doppler_factor)

        def set_effect(self, effect_type, alpha=255, intensity=1.0):
            self.engine.effects_manager.set_effect(effect_type, alpha, intensity)

        def clear_effect(self):
            self.engine.effects_manager.clear_effect()

        def _get_model_cache_key(self, path, rot_x, rot_y, rot_z, scale, color):
            """Создаёт уникальный ключ кэша для модели с заданными параметрами."""
            color_str = '_'.join(map(str, color)) if color else 'default'
            return f"{path}_{rot_x}_{rot_y}_{rot_z}_{scale}_{color_str}".replace('/', '_').replace('\\', '_')

        def set_model_rotation_y(self, model_key, rot_deg):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.rot_y = math.radians(rot_deg)

        def set_model_rotation_x(self, model_key, rot_deg):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.rot_x = math.radians(rot_deg)

        def set_model_rotation_z(self, model_key, rot_deg):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.rot_z = math.radians(rot_deg)

        def set_model_rotation(self, model_key, rot_y_deg, rot_x_deg=0, rot_z_deg=0):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.rot_y = math.radians(rot_y_deg)
                sprite.rot_x = math.radians(rot_x_deg)
                sprite.rot_z = math.radians(rot_z_deg)

        def get_cell(self, x, y):
            try:
                if 0 <= y < self.engine.map_height and 0 <= x < self.engine.map_width:
                    return self.engine.map_data[y][x]
            except:
                pass
            return None

        def set_cell_property(self, x, y, key, value):
            cell = self.get_cell(x, y)
            if cell:
                cell['properties'][key] = value

        def set_cell_base_id(self, x, y, new_id):
            cell = self.get_cell(x, y)
            if cell:
                cell['base_id'] = new_id

        def set_cell_visible(self, x, y, visible):
            self.set_cell_property(x, y, 'isvisible', visible)

        def set_cell_collision(self, x, y, collision):
            self.set_cell_property(x, y, 'addcollision', collision)

        def set_player_position(self, x, y):
            self.engine.player.pos.x = x
            self.engine.player.pos.y = y

        def set_player_angle(self, angle):
            self.engine.player.angle = angle

        def set_player_speed(self, speed):
            self.engine.player.speed = speed

        def set_player_rot_speed(self, rot_speed):
            self.engine.player.rot_speed = rot_speed

        def get_light_sources(self):
            return self.engine.light_tracer.light_sources

        def add_light(self, x, y, radius, intensity, color=(255,255,255)):
            source = LightSource(x, y, radius, intensity, color)
            self.engine.light_tracer.add_source(source)
            return source

        def remove_light(self, index):
            if 0 <= index < len(self.engine.light_tracer.light_sources):
                del self.engine.light_tracer.light_sources[index]

        def set_ambient(self, value):
            self.engine.light_tracer.ambient_light = max(0.0, min(1.0, value))

        def set_player_light(self, radius=None, intensity=None, color=None):
            lt = self.engine.light_tracer
            if radius is not None:
                lt.player_light_radius = radius
                lt.player_light_radius_sq = radius ** 2
            if intensity is not None:
                lt.player_light_intensity = intensity
            if color is not None:
                lt.player_light_color = color

        def get_sprites(self):
            return self.engine.sprite_manager.sprites

        def set_sprite_position(self, key, x, y):
            self.engine.set_sprite_position(key, x, y)

        def set_sprite_visible(self, key, visible):
            self.engine.set_sprite_visible(key, visible)

        def remove_sprite(self, key):
            self.engine.sprite_manager.remove_by_key(key)

        # ---- Управление дверями и ключами ----
        def open_door(self, door_id):
            if door_id in self.engine.doors:
                self.engine.doors[door_id]['open'] = True
                x, y = self.engine.doors[door_id]['pos']
                self.set_cell_property(x, y, 'open', True)
                sprite_key = self.engine.doors[door_id].get('sprite_key')
                if sprite_key:
                    self.engine.set_sprite_visible(sprite_key, False)
                if self.engine.use_gpu:
                    self.engine.gpu_raycaster.mark_map_dirty()

        def close_door(self, door_id):
            if door_id in self.engine.doors:
                self.engine.doors[door_id]['open'] = False
                x, y = self.engine.doors[door_id]['pos']
                self.set_cell_property(x, y, 'open', False)
                sprite_key = self.engine.doors[door_id].get('sprite_key')
                if sprite_key:
                    self.engine.set_sprite_visible(sprite_key, True)
                if self.engine.use_gpu:
                    self.engine.gpu_raycaster.mark_map_dirty()

        def is_door_open(self, door_id):
            return self.engine.doors.get(door_id, {}).get('open', False)

        def collect_key(self, key_id):
            if key_id in self.engine.keys:
                self.engine.keys[key_id]['collected'] = True
                sprite_key = self.engine.keys[key_id].get('sprite_key')
                if sprite_key:
                    self.engine.sprite_manager.remove_by_key(sprite_key)

        def has_key(self, key_id):
            return self.engine.keys.get(key_id, {}).get('collected', False)

        # ---- Управление моделями (ID=6) ----
        def get_model(self, model_key):
            """Возвращает спрайт модели по ключу."""
            return self.engine.sprite_manager.get_by_key(model_key)

        def set_model_position(self, model_key, x, y):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.x = x
                sprite.y = y

        def set_model_rotation(self, model_key, rotation_deg):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.rotation = math.radians(rotation_deg)

        def set_model_visible(self, model_key, visible):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.visible = visible

        # Для коллизии моделей – пока заглушка, можно добавить позже
        def set_model_collision(self, model_key, collision):
            # Временно просто печатаем, что функция вызывается
            print(f"set_model_collision called for {model_key} with {collision} (not implemented yet)")

    #################### PhysicsAPI ####################
    class PhysicsAPI:
        """
        Заготовка под будущее обновление.
        Все функции безопасны — ничего не сломают если не пользоваться.
        """

        def __init__(self, engine):
            self.engine = engine
            self.bodies = []  # список объектов с .x, .y, .vx, .vy, .mass
            self.gravity = 0.0
            # ----- Расширение 1.3.5 -----
            self.joints = []  # distance/spring/pin
            self.body_collisions_enabled = False  # opt-in body-vs-body
            self.body_collision_iterations = 4
            self._layers = {}  # name -> bit index (0..31)
            self._layer_matrix = [0xFFFFFFFF] * 32  # маска "с кем можно"
            self._area_triggers = []  # rect/circle области

        # ===================== ЗАПРОСЫ =====================

        def query_rect(self, x, y, w, h):
            """AABB-запрос: все тела, чьи центры внутри прямоугольника."""
            hw, hh = w * 0.5, h * 0.5
            return [b for b in self.bodies
                    if x - hw <= b.x <= x + hw
                    and y - hh <= b.y <= y + hh]

        def get_bodies_in_radius(self, x, y, r):
            """Как query_circle, но принимает радиус напрямую (для полноты API)."""
            r2 = r * r
            return [b for b in self.bodies
                    if (b.x - x) ** 2 + (b.y - y) ** 2 <= r2]

        def raycast_all(self, x, y, dx, dy, max_dist, ignore=None):
            """
            Все пересечения по лучу (ray-vs-circle), отсортированы по дистанции.
            Возврат: [(body, dist), ...]
            """
            norm = math.hypot(dx, dy) or 1.0
            dx, dy = dx / norm, dy / norm
            hits = []
            for b in self.bodies:
                if b is ignore:
                    continue
                bx, by = b.x - x, b.y - y
                t = bx * dx + by * dy
                if t < 0 or t > max_dist:
                    continue
                perp2 = bx * bx + by * by - t * t
                r = getattr(b, 'radius', 8.0)
                if perp2 < r * r:
                    hits.append((b, t))
            hits.sort(key=lambda h: h[1])
            return hits

        def shape_cast(self, x, y, dx, dy, radius, max_dist, ignore=None):
            """
            Swept circle: движем круг радиуса radius по лучу.
            Возврат: (body | None, dist).
            """
            norm = math.hypot(dx, dy) or 1.0
            dx, dy = dx / norm, dy / norm
            best, best_t = None, max_dist
            for b in self.bodies:
                if b is ignore:
                    continue
                r_sum = radius + getattr(b, 'radius', 8.0)
                bx, by = b.x - x, b.y - y
                t = bx * dx + by * dy
                if t < 0 or t > best_t:
                    continue
                perp2 = bx * bx + by * by - t * t
                if perp2 < r_sum * r_sum:
                    best, best_t = b, t
            return (best, best_t)

        def explosion_query(self, x, y, radius):
            """Все тела в радиусе + дистанция, отсортировано. Для кастомных взрывов."""
            out = []
            for b in self.bodies:
                d = math.hypot(b.x - x, b.y - y)
                if d <= radius:
                    out.append((b, d))
            out.sort(key=lambda p: p[1])
            return out

        # ===================== ГЕТТЕРЫ ТЕЛ =====================

        def get_body_position(self, body):
            return (body.x, body.y) if body else None

        def get_body_velocity(self, body):
            if not body:
                return None
            return (getattr(body, 'vx', 0.0), getattr(body, 'vy', 0.0))

        def get_body_mass(self, body):
            return getattr(body, 'mass', 1.0) if body else None

        def get_body_radius(self, body):
            return getattr(body, 'radius', 8.0) if body else None

        def get_body_count(self):
            return len(self.bodies)

        def is_body_sleeping(self, body):
            return getattr(body, 'sleeping', False)

        def is_body_kinematic(self, body):
            return getattr(body, 'kinematic', False)

        def is_body_colliding(self, body):
            return getattr(body, 'collision_enabled', True)

        # ===================== СЕТТЕРЫ ТЕЛ =====================

        def set_body_position(self, body, x, y):
            if not body:
                return None
            old = (body.x, body.y)
            body.x, body.y = float(x), float(y)
            return old

        def set_body_velocity(self, body, vx, vy):
            if not body:
                return None
            old = (getattr(body, 'vx', 0.0), getattr(body, 'vy', 0.0))
            body.vx, body.vy = float(vx), float(vy)
            return old

        def set_body_mass(self, body, mass):
            if not body:
                return None
            old = getattr(body, 'mass', 1.0)
            body.mass = max(1e-3, float(mass))
            return old

        def set_body_radius(self, body, radius):
            if not body:
                return None
            old = getattr(body, 'radius', 8.0)
            body.radius = max(0.1, float(radius))
            return old

        def set_body_friction(self, body, friction):
            """0.0 — ледяной пол, 1.0 — без трения (дефолт)."""
            if not body:
                return None
            old = getattr(body, 'friction', None)
            body.friction = max(0.0, min(1.0, float(friction)))
            return old

        def set_body_restitution(self, body, restitution):
            """0.0 — не отскакивает, 1.0 — абсолютно упругий."""
            if not body:
                return None
            old = getattr(body, 'restitution', 0.3)
            body.restitution = max(0.0, min(1.0, float(restitution)))
            return old

        def set_body_gravity_scale(self, body, scale):
            """Множитель гравитации. 0 — невесомость, -1 — «вверх»."""
            if not body:
                return None
            old = getattr(body, 'gravity_scale', 1.0)
            body.gravity_scale = float(scale)
            return old

        def set_body_kinematic(self, body, kinematic=True):
            """
            Kinematic тело игнорирует гравитацию и wall-коллизии;
            движется только через set_body_position / set_body_velocity.
            """
            if not body:
                return None
            old = getattr(body, 'kinematic', False)
            body.kinematic = bool(kinematic)
            return old

        def set_body_collision_enabled(self, body, enabled=True):
            """Полное отключение коллизий для тела (стены + body-body)."""
            if not body:
                return None
            old = getattr(body, 'collision_enabled', True)
            body.collision_enabled = bool(enabled)
            return old

        def wake_body(self, body):
            if body:
                body.sleeping = False

        def sleep_body(self, body):
            if body:
                body.sleeping = True
                body.vx = 0.0
                body.vy = 0.0

        # ===================== СИЛЫ И ИМПУЛЬСЫ =====================

        def apply_force(self, body, fx, fy):
            """Постоянная сила (ускорение) на один шаг физики."""
            if not body or getattr(body, 'kinematic', False):
                return
            m = max(getattr(body, 'mass', 1.0), 1e-3)
            dt = self.engine.fixed_physics_dt
            body.vx += fx / m * dt
            body.vy += fy / m * dt

        def apply_torque(self, body, torque):
            """Момент силы. Требует поле .angular_vel у тела."""
            if not body:
                return
            if not hasattr(body, 'angular_vel'):
                body.angular_vel = 0.0
            m = max(getattr(body, 'mass', 1.0), 1e-3)
            body.angular_vel += torque / m

        def apply_impulse_at_point(self, body, ix, iy, px, py):
            """
            Импульс в точке мира (px, py).
            Складывает линейный импульс и момент r × F.
            """
            if not body:
                return
            self.apply_impulse(body, ix, iy)
            rx, ry = px - body.x, py - body.y
            self.apply_torque(body, rx * iy - ry * ix)

        def apply_force_at_point(self, body, fx, fy, px, py):
            if not body:
                return
            self.apply_force(body, fx, fy)
            rx, ry = px - body.x, py - body.y
            self.apply_torque(body, rx * fy - ry * fx)

        def apply_force_field(self, x, y, radius, fx, fy,
                              falloff='linear', inverse=False):
            """
            Прикладывает силу ко всем телам в радиусе.

            falloff:
              'linear'  — F = F0 * (1 - d/r)
              'constant'— F = F0 везде внутри радиуса
              'inverse' — F = F0 / (1 + d)
            inverse=True — сила направлена ОТ центра (взрыв/отталкивание),
                           иначе — К центру (притяжение).
            """
            r2 = radius * radius
            for b in self.bodies:
                dx, dy = b.x - x, b.y - y
                d2 = dx * dx + dy * dy
                if d2 > r2 or d2 < 1e-6:
                    continue
                d = math.sqrt(d2)
                if falloff == 'constant':
                    k = 1.0
                elif falloff == 'inverse':
                    k = 1.0 / (1.0 + d)
                else:
                    k = 1.0 - d / radius
                nx, ny = dx / d, dy / d
                sign = 1.0 if inverse else -1.0
                self.apply_force(b, sign * nx * fx * k, sign * ny * fy * k)

        def apply_radial_impulse(self, x, y, radius, strength):
            """Взрывной импульс — как от гранаты. Полезно для кастомного RTE-взрыва."""
            r2 = radius * radius
            for b in self.bodies:
                dx, dy = b.x - x, b.y - y
                d2 = dx * dx + dy * dy
                if d2 > r2 or d2 < 1e-6:
                    continue
                d = math.sqrt(d2)
                k = (1.0 - d / radius) ** 2
                nx, ny = dx / d, dy / d
                self.apply_impulse(b, nx * strength * k, ny * strength * k)

        # ===================== СВЯЗИ (JOINTS) =====================

        def add_distance_joint(self, body_a, body_b, distance):
            """
            Жёсткая связь «верёвка» — тела не сближаются ближе и не удаляются
            дальше заданной дистанции.
            """
            j = {'type': 'distance', 'a': body_a, 'b': body_b,
                 'rest': float(distance), 'alive': True}
            self.joints.append(j)
            return j

        def add_spring_joint(self, body_a, body_b, rest, k=10.0, damping=0.5):
            """
            Пружина. k — жёсткость, damping — затухание скорости сближения.
            """
            j = {'type': 'spring', 'a': body_a, 'b': body_b,
                 'rest': float(rest), 'k': float(k), 'damping': float(damping),
                 'alive': True}
            self.joints.append(j)
            return j

        def add_pin_joint(self, body, x, y):
            """Прибить тело к точке мира (оно не улетит, но может крутиться)."""
            j = {'type': 'pin', 'body': body, 'x': float(x), 'y': float(y),
                 'alive': True}
            self.joints.append(j)
            return j

        def remove_joint(self, joint):
            if joint:
                joint['alive'] = False

        def clear_joints(self):
            self.joints.clear()

        def _step_joints(self, dt):
            for j in self.joints:
                if not j.get('alive', True):
                    continue
                if j['type'] == 'distance':
                    a, b = j['a'], j['b']
                    dx, dy = b.x - a.x, b.y - a.y
                    d = math.hypot(dx, dy) or 1e-6
                    diff = d - j['rest']
                    nx, ny = dx / d, dy / d
                    corr = diff * 0.5
                    if not getattr(a, 'kinematic', False):
                        a.x += nx * corr
                        a.y += ny * corr
                    if not getattr(b, 'kinematic', False):
                        b.x -= nx * corr
                        b.y -= ny * corr

                elif j['type'] == 'spring':
                    a, b = j['a'], j['b']
                    dx, dy = b.x - a.x, b.y - a.y
                    d = math.hypot(dx, dy) or 1e-6
                    nx, ny = dx / d, dy / d
                    # Сила пружины
                    force = (d - j['rest']) * j['k']
                    # Демпфирование по скорости сближения
                    rvx = getattr(b, 'vx', 0) - getattr(a, 'vx', 0)
                    rvy = getattr(b, 'vy', 0) - getattr(a, 'vy', 0)
                    rv_n = rvx * nx + rvy * ny
                    damp = rv_n * j['damping']
                    total = force + damp
                    self.apply_force(a, nx * total, ny * total)
                    self.apply_force(b, -nx * total, -ny * total)

                elif j['type'] == 'pin':
                    body = j['body']
                    if getattr(body, 'kinematic', False):
                        continue
                    body.x = j['x']
                    body.y = j['y']
                    body.vx = 0.0
                    body.vy = 0.0

            self.joints = [j for j in self.joints if j.get('alive', True)]

        # ===================== СЛОИ =====================

        def register_layer(self, name, index):
            """Назначить имя слою (0..31)."""
            idx = int(index)
            if not (0 <= idx < 32):
                raise ValueError("Слой должен быть 0..31")
            self._layers[name] = idx
            return self

        def get_layer_index(self, name_or_index):
            if isinstance(name_or_index, int):
                return name_or_index
            return self._layers.get(name_or_index, 0)

        def set_collision_layer(self, body, layer):
            """
            Слой, к которому принадлежит тело.
            layer: имя ('enemy') или индекс (0..31).
            """
            if not body:
                return None
            idx = self.get_layer_index(layer)
            old = getattr(body, 'collision_layer', 1)
            body.collision_layer = 1 << idx
            return old

        def set_collision_mask(self, body, mask):
            """
            Битовая маска: с какими слоями тело сталкивается.
            mask: имя (тогда один слой), int, или список имён.
            """
            if not body:
                return None
            if isinstance(mask, (list, tuple, set)):
                bits = 0
                for m in mask:
                    bits |= 1 << self.get_layer_index(m)
                value = bits
            elif isinstance(mask, str):
                value = 1 << self.get_layer_index(mask)
            else:
                value = int(mask)
            old = getattr(body, 'collision_mask', 0xFFFFFFFF)
            body.collision_mask = value
            return old

        def set_layer_collision(self, a, b, enabled=True):
            """Матрица «слой X сталкивается со слоем Y?» (симметрично)."""
            la = self.get_layer_index(a)
            lb = self.get_layer_index(b)
            if enabled:
                self._layer_matrix[la] |= (1 << lb)
                self._layer_matrix[lb] |= (1 << la)
            else:
                self._layer_matrix[la] &= ~(1 << lb)
                self._layer_matrix[lb] &= ~(1 << la)

        def _layers_can_collide(self, a, b):
            la = getattr(a, 'collision_layer', 1)
            lb = getattr(b, 'collision_layer', 1)
            ma = getattr(a, 'collision_mask', 0xFFFFFFFF)
            mb = getattr(b, 'collision_mask', 0xFFFFFFFF)
            # Тела сталкиваются, если маски обеих сторон допускают слой другой стороны
            if not (ma & lb) or not (mb & la):
                return False
            # Матрица слоёв для «глобальных» запретов
            la_idx = la.bit_length() - 1
            lb_idx = lb.bit_length() - 1
            if la_idx >= 0 and lb_idx >= 0:
                if not (self._layer_matrix[la_idx] & lb) or \
                        not (self._layer_matrix[lb_idx] & la):
                    return False
            return True

        # ===================== BODY-VS-BODY =====================

        def set_body_collisions(self, enabled=True, iterations=4):
            """
            Включает взаимные столкновения тел (impulse-based).
            enabled=False — отключить (по умолчанию).
            iterations — количество итераций решателя за шаг (больше = точнее).
            """
            old = self.body_collisions_enabled
            self.body_collisions_enabled = bool(enabled)
            self.body_collision_iterations = max(1, int(iterations))
            return old

        def _resolve_body_collisions(self):
            n = len(self.bodies)
            for _ in range(self.body_collision_iterations):
                for i in range(n):
                    a = self.bodies[i]
                    if not getattr(a, 'collision_enabled', True):
                        continue
                    if getattr(a, 'sleeping', False):
                        continue
                    ra = getattr(a, 'radius', 8.0)
                    ma_m = max(getattr(a, 'mass', 1.0), 1e-3)
                    for j in range(i + 1, n):
                        b = self.bodies[j]
                        if not getattr(b, 'collision_enabled', True):
                            continue
                        if getattr(b, 'sleeping', False):
                            continue
                        if not self._layers_can_collide(a, b):
                            continue
                        dx, dy = b.x - a.x, b.y - a.y
                        d2 = dx * dx + dy * dy
                        rb = getattr(b, 'radius', 8.0)
                        min_d = ra + rb
                        if d2 >= min_d * min_d or d2 < 1e-8:
                            continue
                        d = math.sqrt(d2)
                        nx, ny = dx / d, dy / d
                        overlap = min_d - d
                        mb_m = max(getattr(b, 'mass', 1.0), 1e-3)
                        total = ma_m + mb_m

                        # Позиционное выталкивание
                        if not getattr(a, 'kinematic', False):
                            a.x -= nx * overlap * (mb_m / total)
                            a.y -= ny * overlap * (mb_m / total)
                        if not getattr(b, 'kinematic', False):
                            b.x += nx * overlap * (ma_m / total)
                            b.y += ny * overlap * (ma_m / total)

                        # Импульс по нормали
                        if getattr(a, 'kinematic', False) and \
                                getattr(b, 'kinematic', False):
                            continue
                        rvx = getattr(b, 'vx', 0) - getattr(a, 'vx', 0)
                        rvy = getattr(b, 'vy', 0) - getattr(a, 'vy', 0)
                        vn = rvx * nx + rvy * ny
                        if vn > 0:
                            continue
                        e = min(getattr(a, 'restitution', 0.3),
                                getattr(b, 'restitution', 0.3))
                        jmag = -(1 + e) * vn / (1.0 / ma_m + 1.0 / mb_m)
                        if not getattr(a, 'kinematic', False):
                            a.vx -= jmag * nx / ma_m
                            a.vy -= jmag * ny / ma_m
                        if not getattr(b, 'kinematic', False):
                            b.vx += jmag * nx / mb_m
                            b.vy += jmag * ny / mb_m

        # ===================== ТРИГГЕРЫ-ОБЛАСТИ =====================

        def add_trigger_area(self, x, y, w, h, callback, once=True, tag=None):
            """
            Прямоугольная зона. callback(body, phase, area), где phase ∈ {'enter','exit'}.
            Возвращает handle для remove_area_trigger.
            """
            entry = {'shape': 'rect', 'x': float(x), 'y': float(y),
                     'w': float(w), 'h': float(h),
                     'callback': callback, 'once': once, 'tag': tag,
                     'inside': set(), 'alive': True}
            self._area_triggers.append(entry)
            return entry

        def add_trigger_circle(self, x, y, r, callback, once=True, tag=None):
            """Круглая зона."""
            entry = {'shape': 'circle', 'x': float(x), 'y': float(y),
                     'r': float(r),
                     'callback': callback, 'once': once, 'tag': tag,
                     'inside': set(), 'alive': True}
            self._area_triggers.append(entry)
            return entry

        def remove_area_trigger(self, handle):
            if handle:
                handle['alive'] = False

        def get_bodies_in_trigger(self, area):
            if area['shape'] == 'rect':
                return self.query_rect(area['x'], area['y'], area['w'], area['h'])
            r2 = area['r'] * area['r']
            return [b for b in self.bodies
                    if (b.x - area['x']) ** 2 + (b.y - area['y']) ** 2 <= r2]

        def _step_triggers(self):
            for area in self._area_triggers:
                if not area['alive']:
                    continue
                inside_now = set(id(b) for b in self.get_bodies_in_trigger(area))
                entered = inside_now - area['inside']
                exited = area['inside'] - inside_now
                for bid in entered:
                    b = next((bb for bb in self.bodies if id(bb) == bid), None)
                    if b:
                        try:
                            area['callback'](b, 'enter', area)
                        except Exception as e:
                            print(f"[phys trigger] {e}")
                        if area['once']:
                            area['alive'] = False
                            break
                for bid in exited:
                    b = next((bb for bb in self.bodies if id(bb) == bid), None)
                    if b:
                        try:
                            area['callback'](b, 'exit', area)
                        except Exception as e:
                            print(f"[phys trigger] {e}")
                area['inside'] = inside_now
            self._area_triggers = [a for a in self._area_triggers if a['alive']]

        # ===================== СЕРИАЛИЗАЦИЯ =====================

        def get_state(self):
            """Снимок физического мира — для сохранений/реплеев."""
            return {
                'bodies': [{
                    'x': b.x, 'y': b.y,
                    'vx': getattr(b, 'vx', 0.0),
                    'vy': getattr(b, 'vy', 0.0),
                    'mass': getattr(b, 'mass', 1.0),
                    'radius': getattr(b, 'radius', 8.0),
                    'friction': getattr(b, 'friction', None),
                    'restitution': getattr(b, 'restitution', 0.3),
                    'gravity_scale': getattr(b, 'gravity_scale', 1.0),
                    'kinematic': getattr(b, 'kinematic', False),
                    'sleeping': getattr(b, 'sleeping', False),
                } for b in self.bodies],
                'gravity': self.gravity,
                'body_collisions_enabled': self.body_collisions_enabled,
            }

        def set_state(self, state):
            """Восстанавливает состояние. Совпадает по количеству тел."""
            for b, s in zip(self.bodies, state.get('bodies', [])):
                b.x = s['x']
                b.y = s['y']
                b.vx = s.get('vx', 0.0)
                b.vy = s.get('vy', 0.0)
                for key in ('friction', 'restitution', 'gravity_scale',
                            'kinematic', 'sleeping'):
                    if key in s:
                        setattr(b, key, s[key])
            self.gravity = state.get('gravity', 0.0)
            if 'body_collisions_enabled' in state:
                self.body_collisions_enabled = state['body_collisions_enabled']

        def dump_bodies(self):
            """Отладочный вывод всех тел в консоль."""
            for i, b in enumerate(self.bodies):
                print(f"[PHYS] #{i} pos=({b.x:.1f},{b.y:.1f}) "
                      f"vel=({getattr(b, 'vx', 0):.1f},{getattr(b, 'vy', 0):.1f}) "
                      f"m={getattr(b, 'mass', 1.0):.1f} "
                      f"r={getattr(b, 'radius', 8.0):.1f} "
                      f"kin={getattr(b, 'kinematic', False)} "
                      f"sleep={getattr(b, 'sleeping', False)}")



        # Старые функции
        # 1) Настройка
        def set_timestep(self, dt):
            """Секунд на шаг физики. Рекомендуется 1/30 или 1/60."""
            self.engine.fixed_physics_dt = float(dt)

        def set_gravity(self, g):
            """Гравитация по Y (пиксели/сек²)."""
            self.gravity = float(g)

        # 2) Регистрация тела
        def add_body(self, body):
            """body: любой объект с .x, .y, .vx, .vy, .mass. Возвращает его."""
            if not hasattr(body, 'vx'): body.vx = 0.0
            if not hasattr(body, 'vy'): body.vy = 0.0
            if not hasattr(body, 'mass'): body.mass = 1.0
            self.bodies.append(body)
            return body

        def remove_body(self, body):
            if body in self.bodies:
                self.bodies.remove(body)

        # 3) Импульс
        def apply_impulse(self, body, ix, iy):
            """Мгновенный импульс (км/с), делится на массу."""
            body.vx += ix / max(body.mass, 1e-3)
            body.vy += iy / max(body.mass, 1e-3)

        # 4) Запрос в круге
        def query_circle(self, x, y, r):
            """Все тела в радиусе (пиксели)."""
            r2 = r * r
            out = []
            for b in self.bodies:
                dx = b.x - x
                dy = b.y - y
                if dx * dx + dy * dy <= r2:
                    out.append(b)
            return out

        # 5) Луч
        def raycast(self, x, y, dx, dy, max_dist, ignore=None):
            """
            Возвращает (hit_body, dist) или (None, max_dist).
            Простой ray-vs-circle.
            """
            import math
            norm = math.hypot(dx, dy) or 1.0
            dx /= norm;
            dy /= norm
            best = None;
            best_d = max_dist
            for b in self.bodies:
                if b is ignore: continue
                bx = b.x - x;
                by = b.y - y
                t = bx * dx + by * dy
                if t < 0 or t > best_d: continue
                perp2 = bx * bx + by * by - t * t
                r = getattr(b, 'radius', 8.0)
                if perp2 < r * r:
                    best_d = t
                    best = b
            return best, best_d

        def add_interactive(self, obj):
            """Регистрирует InteractiveObject в мире."""
            self.engine.interactive_objects[obj.key] = obj

        def get_object(self, key):
            return self.engine.interactive_objects.get(key)

        def push_object(self, key_or_obj, ix, iy):
            obj = key_or_obj if hasattr(key_or_obj, 'apply_impulse') else self.get_object(key_or_obj)
            if obj:
                obj.apply_impulse(ix, iy)

        def set_gravity_for(self, key, gravity):
            obj = self.get_object(key)
            if obj:
                obj.gravity_scale = float(gravity)

        def set_ceiling_collision(self, enabled):
            self.engine.ceiling_collision = bool(enabled)

        def query_objects_in_circle(self, x, y, r):
            r2 = r * r
            out = []
            for obj in self.engine.interactive_objects.values():
                dx = obj.x - x
                dy = obj.y - y
                if dx * dx + dy * dy <= r2:
                    out.append(obj)
            return out

        def _step(self, dt):
            """Вызывается из Engine.update() раз в fixed-step."""
            # 1) Связи — до физики тел
            if self.joints:
                self._step_joints(dt)

            # 2) Тела
            if self.bodies:
                for b in self.bodies:
                    if getattr(b, 'sleeping', False):
                        continue
                    if getattr(b, 'kinematic', False):
                        # Kinematic не двигается физикой, но может двигаться самим пользователем
                        continue
                    if not getattr(b, 'collision_enabled', True):
                        # без стен — просто свободный полёт
                        b.x += getattr(b, 'vx', 0.0) * dt
                        b.y += getattr(b, 'vy', 0.0) * dt
                        continue

                    # Гравитация с учётом масштаба
                    gscale = getattr(b, 'gravity_scale', 1.0)
                    b.vy += self.gravity * gscale * dt

                    nx = b.x + b.vx * dt
                    ny = b.y + b.vy * dt
                    if self.engine._is_walkable(nx, ny):
                        b.x = nx
                        b.y = ny
                    else:
                        rest = getattr(b, 'restitution', 0.3)
                        b.vx *= -rest
                        b.vy *= -rest
                        b.x += b.vx * dt
                        b.y += b.vy * dt

                    # Трение (только если явно задано)
                    fric = getattr(b, 'friction', None)
                    if fric is not None and fric < 1.0 and dt > 0:
                        f = fric ** dt
                        b.vx *= f
                        b.vy *= f

            # 3) Body-vs-body (opt-in)
            if self.body_collisions_enabled:
                self._resolve_body_collisions()

            # 4) Триггеры-области
            if self._area_triggers:
                self._step_triggers()

    # ================ Основные методы ================
    def deactivate_trigger(self, key):
        self.inactive_triggers.add(key)

    def activate_trigger(self, key):
        self.inactive_triggers.discard(key)

    def is_trigger_active(self, key):
        return key not in self.inactive_triggers

    def add_sprite(self, sprite):
        self.sprite_manager.add(sprite)

    def get_sprite(self, key):
        return self.sprite_manager.get_by_key(key)

    def set_sprite_visible(self, key, visible):
        sprite = self.sprite_manager.get_by_key(key)
        if sprite:
            sprite.visible = visible

    def set_sprite_position(self, key, x, y):
        sprite = self.sprite_manager.get_by_key(key)
        if sprite:
            sprite.x = x
            sprite.y = y

    def show_message(self, text, duration=2.0, rgb=(30,30,30), font="Arial", size=36):
        self.message_text = text
        self.message_timer = duration
        self.message_duration = duration
        self.text_color = rgb
        self.font = pygame.font.SysFont(font, size)

    def _get_default_texture(self, name):
        base_dir = os.path.dirname(__file__)
        path = os.path.join(base_dir, 'material', 'images', name)
        try:
            return pygame.image.load(path).convert_alpha()
        except:
            return None

    def load_level(self, index):
        try:
            if index < 0 or index >= len(self.levels):
                return
            raw_map = self.levels[index]
            parser = MapParser()
            layers = parser.parse_layers(raw_map)

            self.map_data = layers.get('collision', [])
            if not self.map_data:
                self.map_data = []
            self.map_height = len(self.map_data)
            self.map_width = len(self.map_data[0]) if self.map_height > 0 else 0

            self.raycaster.map_data = self.map_data
            self.raycaster.update_dimensions()
            self.light_tracer.map_data = self.map_data

            params = layers.get('_params', {})
            fog_color = params.get('fog_color', None)
            if fog_color:
                self.fog_color = self._hex_to_rgb(fog_color)
                self.fog_enabled = True
            self.fog_start = float(params.get('fog_start', self.fog_start))
            self.fog_end = float(params.get('fog_end', self.fog_end))
            self.spawn = params.get('spawn', None)
            self.floor_color = params.get('floor_color', None)
            self.ceiling_color = params.get('ceiling_color', None)
            try:
                self.ambient = float(params.get('ambient', 0.03))
            except:
                self.ambient = 0.03
            self.light_tracer.ambient_light = self.ambient
            use_lt_val = params.get('use_lt', 'true')
            if isinstance(use_lt_val, (list, tuple)):
                use_lt_val = use_lt_val[0] if use_lt_val else 'true'
            self.use_lt = str(use_lt_val).lower() in ('true', '1', 'yes')
            if self.use_gpu and self.gpu_raycaster is not None:
                try:
                    self.gpu_raycaster.setup_level(
                        map_data=self.map_data,
                        tile_size=self.tile_size,
                        material_lib=self.material_lib,
                        floor_texture=self.floor_texture,
                        ceiling_texture=self.ceiling_texture,
                        floor_color=self._hex_to_rgb(self.floor_color) if self.floor_color else (40, 30, 20),
                        ceiling_color=self._hex_to_rgb(self.ceiling_color) if self.ceiling_color else (20, 20, 40),
                    )
                except Exception as e:
                    print(f"[GPU] setup_level failed: {e}")
                    self.use_gpu = False

            self.doors.clear()
            self.keys.clear()
            self.model_data.clear()
            self.decals.clear()
            self.particles.particles.clear()
            self.particles.debris_particles.clear()
            self.bullets.clear()

            self.light_tracer.light_sources.clear()
            lights_str = params.get('lights', '')
            if lights_str:
                for light_str in lights_str.split(';'):
                    parts = light_str.split(',')
                    if len(parts) >= 4:
                        try:
                            x = float(parts[0]) * self.tile_size
                            y = float(parts[1]) * self.tile_size
                            intensity = float(parts[2])
                            radius = float(parts[3])
                            color = (255, 255, 255)
                            if len(parts) >= 7:
                                r = int(parts[4])
                                g = int(parts[5])
                                b = int(parts[6])
                                color = (r, g, b)
                            self.light_tracer.add_source(LightSource(x, y, radius, intensity, color))
                        except:
                            pass

            # Загрузка билбордов
            bilboards_str = params.get('bilboards', '')
            if bilboards_str:
                for b_str in bilboards_str.split(';'):
                    parts = b_str.split(',')
                    if len(parts) >= 3:
                        try:
                            x = float(parts[0]) * self.tile_size
                            y = float(parts[1]) * self.tile_size
                            key = parts[2].strip()
                            existing = self.sprite_manager.get_by_key(key)
                            if existing:
                                existing.x = x
                                existing.y = y
                            else:
                                tex = load_image(key, f'textures/{key}.png', size=(30,30), default_color=(255,0,255))
                                sprite = Sprite(x, y, tex, key=key)
                                self.sprite_manager.add(sprite)
                        except:
                            pass

            # Обработка ID=7 (двери и ключи) и ID=6 (модели)
            for y, row in enumerate(self.map_data):
                for x, cell in enumerate(row):
                    props = cell.get('properties', {})
                    # В цикле по map_data, где обрабатываются клетки
                    if 'render' in props:
                        name = props['render']
                        params = {k: v for k, v in props.items()
                                  if k not in ('render', 'enemy', 'material', 'sprite')}
                        wx, wy = x * self.tile_size + self.tile_size // 2, \
                                 y * self.tile_size + self.tile_size // 2
                        handle = self.api.spawn_world_renderer(wx, wy, name, **params)
                        # Опционально — регистрируем в _world_renderer_objects с ключом по клетке
                    if cell['base_id'] < 6:
                        prop = cell.get('properties', {})
                        enemy_str = prop.get('enemy')
                        if enemy_str:
                            self._spawn_enemy_from_tag(
                                enemy_str, x, y,
                                prop.get('sprite', prop.get('texture', self.enemy_sprite)),
                                extra_props=prop)
                    if cell['base_id'] == 7:
                        props = cell.get('properties', {})
                        obj_type = props.get('type', 'door')
                        if obj_type == 'door':
                            door_id = props.get('id', f'door_{x}_{y}')
                            cell['properties']['isvisible'] = False
                            if 'height' not in props:
                                cell['properties']['height'] = 0.9
                            if 'material' not in props:
                                cell['properties']['material'] = 'concrete'
                            sprite_key = f"door_sprite_{door_id}"
                            tex_path = props.get('texture', None)
                            if tex_path:
                                try:
                                    tex = pygame.image.load(tex_path).convert_alpha()
                                except:
                                    tex = self._get_default_texture('door.png')
                            else:
                                tex = self._get_default_texture('door.png')
                            if tex is None:
                                tex = pygame.Surface((256,256))
                                tex.fill((150, 100, 50))
                            sprite_x = x * self.tile_size + self.tile_size/2
                            sprite_y = y * self.tile_size + self.tile_size/2
                            sprite = Sprite(sprite_x, sprite_y, tex, key=sprite_key)
                            self.add_sprite(sprite)

                            self.doors[door_id] = {
                                'open': False,
                                'pos': (x, y),
                                'linked_keys': [],
                                'sprite_key': sprite_key
                            }
                            cell['properties']['open'] = False

                        elif obj_type == 'key':
                            key_id = props.get('id', f'key_{x}_{y}')
                            sprite_key = f"key_sprite_{key_id}"
                            tex_path = props.get('texture', None)
                            if tex_path:
                                try:
                                    tex = pygame.image.load(tex_path).convert_alpha()
                                except:
                                    tex = self._get_default_texture('key.png')
                            else:
                                tex = self._get_default_texture('key.png')
                            if tex is None:
                                tex = pygame.Surface((32,32))
                                tex.fill((255, 215, 0))
                            sprite_x = x * self.tile_size + self.tile_size/2
                            sprite_y = y * self.tile_size + self.tile_size/2
                            sprite = Sprite(sprite_x, sprite_y, tex, key=sprite_key)
                            self.add_sprite(sprite)

                            self.keys[key_id] = {
                                'collected': False,
                                'pos': (x, y),
                                'sprite_key': sprite_key,
                                'linked_doors': []
                            }



                    elif cell['base_id'] == 6:
                        props = cell.get('properties', {})
                        if props.get("isvisible", True):
                            path = props.get('path', '')
                            anim_str = props.get('anim', '')
                            anim_speed = float(props.get('anim_speed', 0.5))  # секунд на кадр
                            if path or anim_str:
                                anim_paths = [p.strip() for p in anim_str.split(',')] if anim_str else []
                                if path:
                                    anim_paths.insert(0, path)  # первая модель – основная
                                rotation = float(props.get('rotation', 0))
                                rot_y = float(props.get('roty', rotation))
                                rot_x = float(props.get('rotx', 0))
                                rot_z = float(props.get('rotz', 0))
                                scale = float(props.get('scale', 1.0))
                                pos_x = x * self.tile_size + self.tile_size / 2
                                pos_y = y * self.tile_size + self.tile_size / 2
                                color_hex = props.get('color', None)
                                color = self._hex_to_rgb(color_hex) if color_hex else (200, 100, 100)
                                self.model_data.append({
                                    'path': path,
                                    'anim_paths': anim_paths,
                                    'anim_speed': anim_speed,
                                    'pos': (pos_x, pos_y),
                                    'rot_y': rot_y,
                                    'rot_x': rot_x,
                                    'rot_z': rot_z,
                                    'scale': scale,
                                    'color': color,
                                    'cell_x': x,
                                    'cell_y': y,
                                    'key': f"model_{x}_{y}"
                                })
                                # Создаём InteractiveObject если у клетки есть свойства
                                props = cell.get('properties', {})
                                if props.get('interactive', False) or props.get('pushable', False):
                                # if props.get('pushable', False):
                                    obj_key = f"obj_{x}_{y}"
                                    world_x = x * self.tile_size + self.tile_size / 2
                                    world_y = y * self.tile_size + self.tile_size / 2
                                    from .object.interactive import InteractiveObject
                                    # ОБНУЛЯЕМ клетку — коллизия пойдёт через сам объект, а не через map
                                    cell['base_id'] = 0
                                    self.interactive_objects[obj_key] = InteractiveObject(
                                        world_x, world_y, obj_key, props, cell,
                                        sprite_key=f"model_{x}_{y}")
                                    # в Engine.load_level после создания InteractiveObject
                                    print(f"[IO] {obj_key} pushable={props.get('pushable')} interactive={props.get('interactive')}")
                                print(f"Model data: {self.model_data}")
            # Связываем ключи и двери
            for key_id, key_data in self.keys.items():
                kx, ky = key_data['pos']
                cell = self.map_data[ky][kx]
                link = cell.get('properties', {}).get('link', None)
                if link and link in self.doors:
                    self.doors[link]['linked_keys'].append(key_id)
                    self.keys[key_id]['linked_doors'].append(link)

            self.inactive_triggers.clear()
            self.texture_cache.clear()

            # Удаляем старые спрайты моделей (с ключом "model_*")
            for sprite in self.sprite_manager.sprites[:]:
                if sprite.key and sprite.key.startswith("model_"):
                    self.sprite_manager.remove_by_key(sprite.key)

            # Загружаем модели для текущего уровня
            if self.watermark == False: self._process_models()
            self.mods_manager.call_hook('level_loaded', index)
        except Exception as e:
            print(f"Error in Engine.load_level: {e}")
            raise

    def _spawn_enemy_from_tag(self, enemy_str, tile_x, tile_y, imag, extra_props=None):
        # Отладка — покажет что реально приходит
        print(f"[AI-DEBUG] enemy_str={enemy_str!r}")
        print(f"[AI-DEBUG] extra_props keys={list(extra_props.keys()) if extra_props else None}")

        params = {}
        sep = ';' if ';' in enemy_str else ','
        for part in enemy_str.split(sep):
            part = part.strip()
            if not part:
                continue
            # Поддерживаем оба разделителя: = и :
            if '=' in part and ':' in part:
                part = part.replace(':', '=')
            if '=' in part:
                key, value = part.split('=', 1)
            elif ':' in part:
                key, value = part.split(':', 1)
            else:
                continue
            key = key.strip().lower()
            value = value.strip()
            if value.lower() == 'true':
                value = True
            elif value.lower() == 'false':
                value = False
            else:
                try:
                    value = float(value) if '.' in value else int(value)
                except ValueError:
                    pass
            params[key] = value

        # Подтягиваем из props клетки (парсер мог раскидать по отдельным ключам)
        if extra_props:
            for k in ('hp', 'aim', 'shoot_delay', 'shoot_intensity',
                      'intensity_mode', 'attack_type', 'detect_radius',
                      'attack_radius', 'speed', 'sprite', 'texture',
                      'sound_spawn', 'effect_spawn', 'effect_until_death',
                      'key'):
                if k in extra_props and k not in params:
                    v = extra_props[k]
                    if isinstance(v, str):
                        if v.lower() == 'true':
                            v = True
                        elif v.lower() == 'false':
                            v = False
                        else:
                            try:
                                v = float(v) if '.' in v else int(v)
                            except ValueError:
                                pass
                    params[k] = v

        print(f"[AI-DEBUG] parsed params={params}")

        enemy_type = params.get('type', 'static')
        hp = float(params.get('hp', 100))
        aim = float(params.get('aim', 10))
        shoot_delay = float(params.get('shoot_delay', 1.0))
        shoot_intensity = float(params.get('shoot_intensity', 0))
        intensity_mode = params.get('intensity_mode', 'fast')
        attack_type = params.get('attack_type', 'ranged')
        detect_radius = float(params.get('detect_radius', 5))
        attack_radius = float(params.get('attack_radius', 3))
        speed = float(params.get('speed', 50))
        key = params.get('key', f"enemy_{tile_x}_{tile_y}")
        explicit = params.get('texture') or params.get('sprite')
        if explicit:
            texture = load_image(explicit, explicit, size=(64, 64))
            map_sprite_explicit = True
        else:
            tex_path = params.get('texture', params.get('sprite', imag))
            texture = load_image(tex_path, tex_path, size=(64, 64))
        if texture is None:
            texture = pygame.Surface((32, 32))
            texture.fill((255, 0, 0))

        enemy_type = params.get('type', 'static')
        cls = self.mods_manager.get_enemy_class(enemy_type)
        if cls is None:
            cls = EnemyAI  # стандартный fallback

        enemy = cls(
            x=tile_x * self.tile_size, y=tile_y * self.tile_size,
            hp=hp, aim=aim, shoot_delay=shoot_delay,
            shoot_intensity=shoot_intensity,
            intensity_mode=intensity_mode,
            enemy_type=enemy_type, attack_type=attack_type,
            detect_radius=detect_radius, attack_radius=attack_radius,
            speed=speed, key=key, texture=texture,
            sound_spawn=params.get('sound_spawn'),
            effect_spawn=params.get('effect_spawn'),
            effect_until_death=params.get('effect_until_death', False)
        )
        self.enemies.append(enemy)

    def pre_cache_all_models(self):
        """Генерирует спрайты для всех моделей из всех уровней заранее (в фоне)."""
        for level in self.levels:
            parser = MapParser()
            layers = parser.parse_layers(level)
            map_data = layers.get('collision', [])
            for row in map_data:
                for cell in row:
                    if cell['base_id'] == 6:
                        props = cell.get('properties', {})
                        path = props.get('path')
                        if not path:
                            continue
                        rot_x = float(props.get('rotx', 0))
                        rot_y = float(props.get('roty', 0))
                        rot_z = float(props.get('rotz', 0))
                        scale = float(props.get('scale', 1.0))
                        color_hex = props.get('color')
                        color = self._hex_to_rgb(color_hex) if color_hex else (200, 100, 100)
                        cache_key = self._get_model_cache_key(path, rot_x, rot_y, rot_z, scale, color)
                        with self.model_cache_lock:
                            exists = cache_key in self.global_model_cache
                        if not exists:
                            self._generate_and_store_model(cache_key, path, rot_x, rot_y, rot_z, scale, color)

    def _generate_and_store_model(self, cache_key, path, rot_x, rot_y, rot_z, scale, color):
        try:
            # Проверяем, не появилась ли модель в кэше от другого потока
            with self.model_generate_lock:
                if cache_key in self.global_model_cache:
                    return
                sprites = obj_to_sprites(path, num_angles=128, sprite_size=(512, 512),
                   scale=scale, color=color,
                   model_rot_x=rot_x, model_rot_y=rot_y, model_rot_z=rot_z)
                if sprites:
                    self.global_model_cache[cache_key] = sprites
                    self._save_sprites_to_cache(cache_key, sprites)
        except Exception as e:
            print(f"Model pre-cache failed for {path}: {e}")

    def _cache_models(self):
        try:
            cache_dir = "cache"
            if not os.path.exists(cache_dir):
                os.makedirs(cache_dir)

            for data in self.model_data:
                cache_key = self._get_model_cache_key(
                    data['path'],
                    data.get('rot_x', 0),
                    data.get('rot_y', 0),
                    data.get('rot_z', 0),
                    data['scale'],
                    data['color']
                )
                model_cache_dir = os.path.join(cache_dir, cache_key)
                if os.path.exists(model_cache_dir):
                    existing = [f for f in os.listdir(model_cache_dir) if f.endswith('.png')]
                    if len(existing) >= 64:
                        continue
                if not os.path.exists(model_cache_dir):
                    os.makedirs(model_cache_dir)

                sprites = obj_to_sprites(
                    data['path'],
                    num_angles=128,
                    sprite_size=(512, 512),
                    scale=data['scale'],
                    color=data['color'],
                    model_rot_x=data.get('rot_x', 0),
                    model_rot_y=data.get('rot_y', 0),
                    model_rot_z=data.get('rot_z', 0)
                )
                if not sprites:
                    continue
                for i, surf in enumerate(sprites):
                    pygame.image.save(surf, os.path.join(model_cache_dir, f"frame_{i:02d}.png"))
        except Exception as e:
            print(f"Error in Engine._cache_models: {e}")

    def _load_sprites_from_cache(self, cache_key, num_frames=64):
        try:
            cache_dir = os.path.join("cache", cache_key)
            sprites = []
            for i in range(num_frames):
                path = os.path.join(cache_dir, f"frame_{i:02d}.png")
                if os.path.exists(path):
                    try:
                        surf = pygame.image.load(path).convert_alpha()
                        sprites.append(surf)
                    except:
                        sprites.append(None)
            return [s for s in sprites if s is not None]
        except Exception as e:
            print(f"Error in Engine._load_sprites_from_cache: {e}")
            return []

    def _save_sprites_to_cache(self, cache_key, sprites):
        """Сохраняет спрайты в файловый кэш."""
        try:
            cache_dir = os.path.join("cache", cache_key)
            if not os.path.exists(cache_dir):
                os.makedirs(cache_dir)
            for i, surf in enumerate(sprites):
                pygame.image.save(surf, os.path.join(cache_dir, f"frame_{i:02d}.png"))
        except Exception as e:
            print(f"Error saving sprites to cache: {e}")

    def _process_models(self):
        try:
            for data in self.model_data:
                path = data['path']
                rot_x = data.get('rot_x', 0)
                rot_y = data.get('rot_y', 0)
                rot_z = data.get('rot_z', 0)
                scale = data.get('scale', 1.0)
                color = data.get('color', (200, 100, 100))

                cache_key = self._get_model_cache_key(path, rot_x, rot_y, rot_z, scale, color)

                sprites = None

                # 1. Проверяем глобальный кэш в памяти (с блокировкой)
                with self.model_cache_lock:
                    sprites = self.global_model_cache.get(cache_key)

                # 2. Если нет в памяти, пробуем загрузить из файлового кэша
                if not sprites:
                    sprites = self._load_sprites_from_cache(cache_key, num_frames=64)

                # 3. Если нет нигде, генерируем синхронно (текущий поток)
                if not sprites:
                    with self.model_generate_lock:
                        # Повторно проверяем, вдруг другой поток уже сгенерировал
                        with self.model_cache_lock:
                            sprites = self.global_model_cache.get(cache_key)
                        if not sprites:
                            sprites = obj_to_sprites(
                                path,
                                num_angles=128,
                                sprite_size=(512, 512),
                                scale=scale,
                                color=color,
                                model_rot_x=rot_x,
                                model_rot_y=rot_y,
                                model_rot_z=rot_z
                            )
                            if sprites:
                                self._save_sprites_to_cache(cache_key, sprites)
                                with self.model_cache_lock:
                                    self.global_model_cache[cache_key] = sprites

                if sprites:
                    model_sprite = AnimatedModelSprite(
                        data['pos'][0],
                        data['pos'][1],
                        [sprites],
                        key=data['key'],
                        rot_y=math.radians(rot_y),
                        rot_x=math.radians(rot_x),
                        rot_z=math.radians(rot_z),
                        anim_speed=data.get('anim_speed', 0.5)
                    )
                    self.sprite_manager.add(model_sprite)
                else:
                    print(f"Failed to get sprites for {path}")
            self.model_data.clear()
        except Exception as e:
            print(f"Error in Engine._process_models: {e}")

    def _find_spawn_point(self):
        if self.spawn:
            try:
                parts = self.spawn.split(',')
                x = float(parts[0]) * self.tile_size + self.tile_size/2
                y = float(parts[1]) * self.tile_size + self.tile_size/2
                return x, y
            except:
                pass
        if not self.map_data:
            return 0, 0
        for y, row in enumerate(self.map_data):
            for x, cell in enumerate(row):
                if cell['base_id'] == 0:
                    return x * self.tile_size + self.tile_size/2, \
                           y * self.tile_size + self.tile_size/2
        return 0, 0

    def set_overlay(self, texture_path, alpha=255):
        try:
            surf = pygame.image.load(texture_path).convert_alpha()
            self.overlay_texture = surf
            self.overlay_alpha = max(0, min(255, alpha))
        except:
            self.overlay_texture = None

    def clear_overlay(self):
        self.overlay_texture = None

    def play_sound(self, sound_key):
        self.sound_manager.play_sound(sound_key)

    def set_fullscreen_effect(self, texture_path, duration=2.0):
        try:
            self.effect_texture = pygame.image.load(texture_path).convert_alpha()
            self.effect_timer = duration
        except:
            self.effect_texture = None

    def update(self, dt, keys):
        try:
            dt = dt * getattr(self, 'time_scale', 1.0)
            # Обработка lifecycle модов (reload/unload)
            self.mods_manager.process_lifecycle(self)
            self._last_dt = dt
            self._elapsed_time += dt
            self._frame_counter += 1

            # Scheduled callbacks
            for entry in self._scheduled_callbacks:
                if not entry['alive']:
                    continue
                entry['timer'] -= dt
                while entry['timer'] <= 0:
                    try:
                        entry['callback']()
                    except Exception as e:
                        print(f"[schedule] {e}")
                    if entry['repeat']:
                        entry['timer'] += entry['repeat']
                    else:
                        entry['alive'] = False
                        break
            self._scheduled_callbacks = [e for e in self._scheduled_callbacks if e['alive']]

            # Screen flashes
            for f in self._screen_flashes[:]:
                f['timer'] -= dt
                if f['timer'] <= 0:
                    self._screen_flashes.remove(f)

            # Trigger zones
            ppos = (self.player.pos.x, self.player.pos.y)
            for z in self._trigger_zones:
                if not z['alive']:
                    continue
                d2 = (z['x'] - ppos[0]) ** 2 + (z['y'] - ppos[1]) ** 2
                inside = d2 <= z['r'] * z['r']
                if inside and not z['triggered']:
                    try:
                        z['callback'](self.player)
                        self.mods_manager.call_hook('trigger_enter', z)
                    except Exception as e:
                        print(f"[trigger] {e}")
                    z['triggered'] = True
                elif not inside:
                    z['triggered'] = False
            self._trigger_zones = [z for z in self._trigger_zones if z['alive']]
            # Восстановление сломанных стен
            if self.scheduled_walls:
                for entry in self.scheduled_walls[:]:
                    entry['timer'] -= dt
                    if entry['timer'] <= 0:
                        x, y = entry['x'], entry['y']
                        if 0 <= y < self.map_height and 0 <= x < self.map_width:
                            cell = self.map_data[y][x]
                            cell['base_id'] = entry['id']
                            if entry.get('material'):
                                cell['properties']['material'] = entry['material']
                            if entry.get('hp') is not None:
                                cell['properties']['hp'] = entry['hp']
                                cell['properties']['destructible'] = True
                            # Убираем декали этой клетки
                            self.decals.remove_by_cell(x, y)
                        if self.use_gpu:
                            self.gpu_raycaster.mark_map_dirty()
                        self.scheduled_walls.remove(entry)

            # Обновляем взрывы
            for ex in self.explosions[:]:
                if not ex.damage_applied:
                    ex.apply_damage(self)
                    ex.spawn_particles(self.particles)
                    # Динамический свет на время жизни
                    # При RTE — яркая вспышка, без RTE — обычный свет
                    flash_intensity = 8.0 if self.rt_enabled else 1.5
                    flash_color = (255, 240, 180)  # тёплый белый
                    self.transient_lights.append(
                        [ex.x, ex.y, ex.light_radius * (1.5 if self.rt_enabled else 1.0),
                         flash_intensity, flash_color, ex.max_age]
                    )
                if not ex.update(dt):
                    self.explosions.remove(ex)

            # Обновляем transient lights (уменьшаем ttl)
            for tl in self.transient_lights[:]:
                tl[5] -= dt
                if tl[5] <= 0:
                    self.transient_lights.remove(tl)
            self.physics._step(dt)
            self.player.update(keys, dt)
            self.sprite_manager.update(dt)

            for snd in self.active_3d_sounds:
                snd.update((self.player.pos.x, self.player.pos.y), self.player.angle)
            # if self.video_cap:
            #     ret, frame = self.video_cap.read()
            #     if not ret:
            #         if self.video_loop:
            #             self.video_cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            #             ret, frame = self.video_cap.read()
            #         else:
            #             self.stop_video()
            #             return
            #     # Конвертируем BGR в RGB и в Surface
            #     frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            #     frame = np.rot90(frame)  # если нужно
            #     surf = pygame.surfarray.make_surface(frame)
            #     surf.set_alpha(self.video_alpha)
            #     self.video_frame = surf

            if self.effect_timer > 0:
                self.effect_timer -= dt
                if self.effect_timer <= 0:
                    self.effect_texture = None

            if self.message_timer > 0:
                self.message_timer -= dt
                if self.message_timer <= 0:
                    self.message_text = ""


            self.gun_manager.update(dt)
            self.update_enemies(dt)
            self.update_bullets(dt)
            self.particles.update(dt)
            self.decals.update(dt)

            new_x = self.player.pos.x + self.player.vel.x * dt
            new_y = self.player.pos.y + self.player.vel.y * dt

            final_x = new_x
            final_y = new_y
            PLAYER_R = 14

            for obj in self.interactive_objects.values():
                if not obj.alive:
                    continue

                dx = obj.x - final_x
                dy = obj.y - final_y
                d = math.hypot(dx, dy)
                # min_dist = obj.radius//2 + PLAYER_R
                min_dist = (self.tile_size * 0.9)//1

                if d < min_dist and d > 0.01:
                    # Толкаем ТОЛЬКО если pushable:true
                    if obj.pushable:
                        mass_factor = min(1.0, 20.0 / max(obj.mass, 1.0))
                        push_speed = 300.0 * mass_factor
                        obj.vx = (dx / d) * push_speed
                        obj.vy = (dy / d) * push_speed

                    # В любом случае — выталкиваем игрока наружу
                    final_x = obj.x - (dx / d) * min_dist
                    final_y = obj.y - (dy / d) * min_dist

            # Проверка стен (как было)
            if self._is_walkable(final_x, final_y):
                self.player.pos.x = final_x
                self.player.pos.y = final_y
            else:
                map_x = int(new_x // self.tile_size)
                map_y = int(new_y // self.tile_size)
                if 0 <= map_y < self.map_height and 0 <= map_x < self.map_width:
                    cell = self.map_data[map_y][map_x]
                    if cell['base_id'] == 7:
                        props = cell.get('properties', {})
                        if props.get('type') == 'door':
                            door_id = props.get('id', None)
                            if door_id and not self.doors.get(door_id, {}).get('open', False):
                                self.on_door_blocked(cell)

            cur_map_x = int(self.player.pos.x // self.tile_size)
            cur_map_y = int(self.player.pos.y // self.tile_size)

            if 0 <= cur_map_y < self.map_height and 0 <= cur_map_x < self.map_width:
                cell = self.map_data[cur_map_y][cur_map_x]
                base_id = cell['base_id']

                if base_id == 9:
                    target = cell.get('properties', {}).get('level', None)
                    if target is not None and target != self.current_level:
                        print(f"Teleport to level {target}")
                        self.current_level = target
                        self.load_level(self.current_level)
                        sx, sy = self._find_spawn_point()
                        self.player.pos.x = sx
                        self.player.pos.y = sy

                if base_id == 8:
                    trigger_id = cell.get('properties', {}).get('id', None)
                    if trigger_id is not None:
                        key = ('id', trigger_id)
                    else:
                        key = ('pos', cur_map_x, cur_map_y)
                    if self.is_trigger_active(key):
                        self.on_trigger(cell)

                if base_id == 7:
                    props = cell.get('properties', {})
                    if props.get('type') == 'key':
                        key_id = props.get('id', None)
                        if key_id and key_id in self.keys:
                            if not self.keys[key_id]['collected']:
                                self.keys[key_id]['collected'] = True
                                sprite_key = self.keys[key_id].get('sprite_key')
                                if sprite_key:
                                    self.sprite_manager.remove_by_key(sprite_key)
                                for door_id in self.keys[key_id]['linked_doors']:
                                    self.api.open_door(door_id)
                                self.on_key_pickup(key_id)

            self.light_tracer.update_player_light(self.player.pos, self.player.angle)

            # Обновление интерактивных объектов
            for obj in list(self.interactive_objects.values()):
                obj.update(dt, self)
                if not obj.alive:
                    del self.interactive_objects[obj.key]

            # Толкание игроком
            for obj in self.interactive_objects.values():
                if not obj.pushable:
                    continue
                dx = obj.x - self.player.pos.x
                dy = obj.y - self.player.pos.y
                d = math.hypot(dx, dy)
                if d < (self.tile_size*0.9)//1 and d > 0.01:
                    # Отталкиваем по вектору от игрока
                    push_speed = self.player.speed  # скорость игрока
                    obj.vx += (dx / d) * push_speed * 0.5
                    obj.vy += (dy / d) * push_speed * 0.5

            self.mods_manager.call_hook('update', dt, keys)
            self.hud.update(dt)
        except Exception as e:
            print(f"Error in Engine.update: {e}")

    def on_trigger(self, cell):
        pass

    def on_key_pickup(self, key_id):
        pass

    def on_door_blocked(self, cell):
        self.show_message("Нужен ключ", 2.0)

    def _run_raycaster_thread(self, pos, angle):
        try:
            results = self.raycaster.cast_rays(pos, angle)
            with self._ray_lock:
                self._ray_results = results
        except Exception as e:
            print(f"Raycaster async error: {e}")

    def _draw_overlays(self, screen):
        if self.overlay_texture is not None:
            overlay = self.overlay_texture.copy()
            overlay.set_alpha(self.overlay_alpha)
            screen.blit(overlay, (0, 0))

        if self.message_text:
            if self.font is None:
                self.font = pygame.font.SysFont('Arial', 36)
            lines = self.message_text.split('\n')
            y_offset = self.screen_height // 1.3 - (len(lines) * (self.font.get_height() + 5)) // 2
            for line in lines:
                text_surface = self.font.render(line, True, (255, 255, 255))
                screen.blit(text_surface, (self.screen_width // 2 - text_surface.get_width() // 2, y_offset))
                y_offset += text_surface.get_height() + 5

        if self.show_fps and not self.use_example:
            fps = self.clock.get_fps()
            if self.use_raycaster_async:
                fps = fps * 1.07
            fps_text = self.font_fps.render(f"FPS: {int(fps)}", True, (255, 255, 0))
            screen.blit(fps_text, (self.screen_width - 120, self.screen_height // 10))

        if hasattr(self, 'effects_manager'):
            self.effects_manager.apply(screen)
        if self.minimap is not None:
            self.minimap.draw(screen)
        self.hud.draw(screen)

    def _compute_pitch_offset(self):
        if not self.y_shearing_enabled:
            return 0
        offset = -int(self.player.pitch * self.y_shearing_pixels_per_rad)
        limit = self.height // 2 - 1
        return max(-limit, min(limit, offset))

    def _draw_world_renderers(self, screen, z_order):
        """Вызывается из render() в нужный момент."""
        if not hasattr(self, '_world_renderer_objects'):
            return
        # Сортировка по дистанции — дальние рисуются первыми
        px, py = self.player.pos.x, self.player.pos.y
        objs = [o for o in self._world_renderer_objects
                if o['alive'] and o['visible']
                and getattr(self, '_world_renderers', {}).get(o['name'], {})
                .get('z_order') == z_order]
        objs.sort(key=lambda o: (o['x'] - px) ** 2 + (o['y'] - py) ** 2,
                  reverse=True)
        for o in objs:
            r = self._world_renderers.get(o['name'])
            if not r:
                continue
            # Отсечение по FOV
            if self.project_world_to_screen(o['x'], o['y']) is None \
                    if hasattr(self, 'project_world_to_screen') else False:
                continue
            ctx = {
                'screen': screen, 'engine': self, 'obj': o,
                'x': o['x'], 'y': o['y'], 'params': o['params'],
                'project': self.api.project_world_to_screen,
                'player': self.player, 'dt': self._last_dt,
            }
            try:
                r['fn'](ctx)
            except Exception as e:
                print(f"[Render:{o['name']}] {e}")

    def render(self, screen):
        try:
            self._pitch_offset_cache = self._compute_pitch_offset()
            if self.mcfi_level > 0:
                N = self.mcfi_level

                if self._mcfi_step == 0:
                    # === РЕАЛЬНЫЙ КАДР (полный рендер) ===
                    if self.use_gpu:
                        gpu_surf = self.gpu_raycaster.render(
                            player_pos=self.player.pos,
                            player_angle=self.player.angle,
                            fov=self.fov,
                            max_depth=self.max_depth,
                            pitch_offset=self._pitch_offset_cache,
                            lights=self.light_tracer.light_sources,
                            ambient=self.ambient,
                            fog_enabled=self.fog_enabled,
                            fog_color=self.fog_color,
                            fog_start=self.fog_start,
                            fog_end=self.fog_end,
                            rt_enabled=self.rt_enabled,
                            rt_max_lights=self.rt_max_lights,
                            rt_reflections=self.rt_reflections,
                            rt_quality=self.rt_quality,
                            map_data_ref=self.map_data,
                            proj_coeff=self.proj_coeff,  # ← ЭТУ
                            material_lib=self.material_lib,
                            sprites=self.sprite_manager.sprites + self.enemies,
                            player_light_mode=self.player_light_mode,
                            player_light_range=self.player_light_range,
                            player_light_cone=self.player_light_cone,
                            dynamic_lights=self.transient_lights,
                        )
                        self.render_surface.blit(gpu_surf, (0, 0))
                    else:
                        self._draw_floor_ceiling(self.render_surface)
                        self._draw_world_renderers(self.render_surface, 'floor')
                        if self.map_data:
                            if self.use_raycaster_async:
                                if self._ray_thread is None or not self._ray_thread.is_alive():
                                    self._ray_thread = threading.Thread(
                                        target=self._run_raycaster_thread,
                                        args=(self.player.pos, self.player.angle)
                                    )
                                    self._ray_thread.daemon = True
                                    self._ray_thread.start()
                                with self._ray_lock:
                                    ray_results = self._ray_results if self._ray_results is not None else []
                            else:
                                ray_results = self.raycaster.cast_rays(self.player.pos, self.player.angle)
                            self._draw_walls(self.render_surface, ray_results)
                    self._draw_sprites(self.render_surface)
                    self._draw_enemies(self.render_surface)
                    self._draw_enemy_bars(self.render_surface)
                    self.decals.draw(self.render_surface)
                    self.particles.draw(self.render_surface)
                    self._draw_gun_and_crosshair(self.render_surface)
                    # Сохраняем кадры
                    self._mcfi_real_prev = self._mcfi_real_curr
                    self._mcfi_real_curr = self.render_surface.copy()

                    # Начинаем показ интерполированных кадров
                    self._mcfi_step = 1

                if self._mcfi_step > 0:
                    # === БЛЕНД-КАДР (интерполяция от prev к curr) ===
                    step = self._mcfi_step  # 1..N

                    if self._mcfi_real_curr is not None and self._mcfi_real_prev is not None:
                        # Плавно перетекаем из старого кадра в новый
                        # step=1 -> 33% curr, step=2 -> 66% curr, step=N -> 100% curr
                        curr_alpha = int(255 * step / N)

                        blended = self._mcfi_real_prev.copy()
                        self._mcfi_real_curr.set_alpha(curr_alpha)
                        blended.blit(self._mcfi_real_curr, (0, 0))
                        self._mcfi_real_curr.set_alpha(255)

                        if self.render_scale != 1:
                            scaled = pygame.transform.scale_by(blended, self.render_scale)
                            screen.blit(scaled, (0, 0))
                        else:
                            screen.blit(blended, (0, 0))
                    else:
                        # Нет двух кадров (первый рендер) — показываем текущий
                        if self.render_scale != 1:
                            scaled_surface = pygame.transform.scale_by(self.render_surface, self.render_scale)
                            screen.blit(scaled_surface, (self.hud.shake.offset_x, self.hud.shake.offset_y))
                        else:
                            screen.blit(self.render_surface, (self.hud.shake.offset_x, self.hud.shake.offset_y))

                    self._mcfi_step += 1
                    if self._mcfi_step > N:
                        self._mcfi_step = 0

                self._draw_overlays(screen)
            else:
                # === MCFI выключен — обычный рендер ===
                if self.use_gpu:
                    gpu_surf = self.gpu_raycaster.render(
                        player_pos=self.player.pos,
                        player_angle=self.player.angle,
                        fov=self.fov,
                        max_depth=self.max_depth,
                        pitch_offset=self._pitch_offset_cache,
                        lights=self.light_tracer.light_sources,
                        ambient=self.ambient,
                        fog_enabled=self.fog_enabled,
                        fog_color=self.fog_color,
                        fog_start=self.fog_start,
                        fog_end=self.fog_end,
                        rt_enabled=self.rt_enabled,
                        rt_max_lights=self.rt_max_lights,
                        rt_reflections=self.rt_reflections,
                        rt_quality=self.rt_quality,
                        map_data_ref=self.map_data,
                        proj_coeff=self.proj_coeff,
                        material_lib=self.material_lib,
                        sprites=self.sprite_manager.sprites + self.enemies,
                        player_light_mode=self.player_light_mode,
                        player_light_range=self.player_light_range,
                        player_light_cone=self.player_light_cone,
                        dynamic_lights=self.transient_lights,
                    )
                    self.render_surface.blit(gpu_surf, (0, 0))
                else:
                    self._draw_floor_ceiling(self.render_surface)
                    if self.map_data:
                        if self.use_raycaster_async:
                            if self._ray_thread is None or not self._ray_thread.is_alive():
                                self._ray_thread = threading.Thread(
                                    target=self._run_raycaster_thread,
                                    args=(self.player.pos, self.player.angle)
                                )
                                self._ray_thread.daemon = True
                                self._ray_thread.start()
                            with self._ray_lock:
                                ray_results = self._ray_results if self._ray_results is not None else []
                        else:
                            ray_results = self.raycaster.cast_rays(self.player.pos, self.player.angle)
                        self._draw_walls(self.render_surface, ray_results)
                self._draw_sprites(self.render_surface)
                self._draw_world_renderers(self.render_surface, 'sprite')
                self._draw_enemies(self.render_surface)
                self._draw_enemy_bars(self.render_surface)
                self._draw_world_renderers(self.render_surface, 'overlay')
                self.decals.draw(self.render_surface)
                self.particles.draw(self.render_surface)
                self._draw_gun_and_crosshair(self.render_surface)
                if self.render_scale != 1:
                    scaled_surface = pygame.transform.scale_by(self.render_surface, self.render_scale)
                    screen.blit(scaled_surface, (self.hud.shake.offset_x, self.hud.shake.offset_y))
                else:
                    screen.blit(self.render_surface, (self.hud.shake.offset_x, self.hud.shake.offset_y))
                self._draw_overlays(screen)

            # F1 / F3 — отладочные оверлеи
            if self.show_debug_overlay:
                self._draw_debug_overlay(screen)
            if self.show_debug_user:
                self._draw_user_debug(screen)

            # Vignette
            if self._vignette:
                self._draw_vignette(screen)

            # Screen flashes
            for f in self._screen_flashes:
                a = int(f['alpha'] * (f['timer'] / max(f['max'], 1e-6)))
                s = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
                s.fill((*f['color'], a))
                screen.blit(s, (0, 0))
            self.mods_manager.call_hook('render', screen)
        except Exception as e:
            print(f"Error in Engine.render: {e}")

    def _draw_user_debug(self, screen):
        """F3 — данные для игрока: FPS, позиция, угол, HP."""
        font = pygame.font.SysFont('Consolas', 18)
        lines = [
            f"FPS:    {int(self.clock.get_fps())}",
            f"Pos:    ({self.player.pos.x:.0f}, {self.player.pos.y:.0f})",
            f"Angle:  {math.degrees(self.player.angle) % 360:.1f}°",
            f"HP:     {int(self.player.hp)}/{self.player.max_hp}",
            f"Level:  {self.current_level}",
        ]
        for i, line in enumerate(lines):
            surf = font.render(line, True, (255, 255, 0))
            screen.blit(surf, (10, 100 + i * 22))

    def set_rt_quality(self, quality: str):
        """
        Сменить качество RTE в рантайме.
        'fast' | 'balanced' | 'high' | 'ultra' | 'reference'
        Возвращает True если значение принято.
        """
        if quality not in ('fast', 'balanced', 'high', 'ultra', 'reference'):
            print(f"[RTE] Неизвестное качество: {quality}")
            return False
        self.rt_quality = quality
        if self.use_gpu and self.gpu_raycaster is not None:
            self.gpu_raycaster.set_rt_quality(quality)
        print(f"[RTE] Качество: {quality}")
        return True

    def _draw_debug_overlay(self, screen):
        """F1 — данные для разработчика + панели модов."""
        font = pygame.font.SysFont('Consolas', 16)
        e = self
        lines = [
            f"[GRADUS DEBUG]",
            f"uptime:     {self._elapsed_time:.1f}s",
            f"frame:      {self._frame_counter}",
            f"time_scale: {self.time_scale}",
            f"enemies:    {len(self.enemies)}",
            f"bullets:    {len(self.bullets)}",
            f"sprites:    {len(self.sprite_manager.sprites)}",
            f"bodies:     {self.physics.get_body_count()}",
            f"particles:  {len(self.particles.particles)}",
            f"debris:     {len(self.particles.debris_particles)}",
            f"lights:     {len(self.light_tracer.light_sources)} + "
            f"{len(self.transient_lights)} transient",
            f"GPU:        {'on' if self.use_gpu else 'off'}",
            f"RTE:        {'on' if self.rt_enabled else 'off'}",
            f"mods:       {len(self.mods_manager.loaded)}",
            f"lang:       {self.lang}",
        ]
        # Триггеры/таймеры, если есть
        lines.append(f"timers:     {len(self._scheduled_callbacks)}")
        lines.append(f"triggers:   {len(self._trigger_zones)}")
        lines.append(f"world_rndr: {len(self._world_renderer_objects)}")

        y = 10
        for line in lines:
            surf = font.render(line, True, (100, 255, 100))
            screen.blit(surf, (10, y))
            y += 18

        # Панели от модов (справа сверху)
        panels = [p for p in self._debug_panels if p.get('alive')]
        py = 10
        for p in panels:
            title_f = pygame.font.SysFont('Consolas', 16, bold=True)
            t = title_f.render(f"── {p['title']} ({p['mod']}) ──",
                               True, (255, 200, 100))
            screen.blit(t, (self.screen_width - 400, py))
            py += 20
            try:
                py = p['fn'](screen, self,
                             self.screen_width - 400, py) or py
            except Exception as e:
                err = font.render(f"[panel error] {e}", True, (255, 80, 80))
                screen.blit(err, (self.screen_width - 400, py))
                py += 18
            py += 8

    def _process_key_debug(self, event):
        """F1 / F3 — тумблеры. Вызывать из handle_event."""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_F1:
                self.show_debug_overlay = not self.show_debug_overlay
                return True
            if event.key == pygame.K_F3:
                self.show_debug_user = not self.show_debug_user
                return True
        return False

    def _draw_vignette(self, screen):
        v = self._vignette
        if not v or v['intensity'] <= 0:
            return
        w, h = screen.get_size()
        size = max(w, h) * 0.5
        overlay = pygame.Surface((w, h), pygame.SRCALPHA)
        steps = 24
        for i in range(steps):
            t = i / steps
            r = int(size * (1.0 - t * 0.9))
            a = int(255 * v['intensity'] * (t ** 1.5) * 0.5)
            pygame.draw.circle(overlay, (*v['color'], a), (w // 2, h // 2),
                               r, width=max(2, size // steps))
        screen.blit(overlay, (0, 0))
    # ---------- Вспомогательные методы ----------
    def _draw_floor_ceiling(self, screen):
        apply_light = self.use_lt
        horizon = self.height // 2 + self._get_pitch_offset()

        if self.floor_color and self.ceiling_color:
            top_color = self._hex_to_rgb(self.ceiling_color)
            bottom_color = self._hex_to_rgb(self.floor_color)
            screen.fill(top_color, (0, 0, self.width, max(0, horizon)))
            screen.fill(bottom_color, (0, max(0, horizon), self.width,
                                       self.height - max(0, horizon)))
            return

        if self.floor_texture is not None or self.ceiling_texture is not None:
            tex_width = 64
            tex_height = 64
            floor_tex = self.floor_texture
            ceiling_tex = self.ceiling_texture
            step = 2
            for x in range(0, self.width, step):
                ray_angle = self.player.angle - self.half_fov + (x / self.width) * self.fov
                cos_a = math.cos(ray_angle)
                sin_a = math.sin(ray_angle)
                for y in range(0, self.height, step):
                    if y < self.height // 2:
                        dy = y - horizon
                        if dy == 0:
                            continue
                        distance = horizon / dy if dy > 0 else (self.height - horizon) / -dy
                        world_x = self.player.pos.x + distance * cos_a
                        world_y = self.player.pos.y + distance * sin_a
                        if ceiling_tex:
                            tx = int((world_x / self.tile_size) * tex_width) % tex_width
                            ty = int((world_y / self.tile_size) * tex_height) % tex_height
                            try:
                                color = ceiling_tex.get_at((tx, ty))
                                if apply_light:
                                    shade = max(0.0, 1.0 - distance / self.max_depth * 0.8)
                                    color = tuple(int(c * shade) for c in color[:3])
                                if self.fog_enabled and distance > self.fog_start:
                                    fog_t = min(1.0, (distance - self.fog_start) /
                                                max(1, self.fog_end - self.fog_start))
                                    color = tuple(
                                        int(color[i] * (1 - fog_t) + self.fog_color[i] * fog_t)
                                        for i in range(3)
                                    )
                                pygame.draw.rect(screen, color, (x, y, step, step))
                            except:
                                pass
                    else:
                        dy = y - self.height // 2
                        if dy == 0: dy = 1
                        distance = (self.height // 2) / dy
                        world_x = self.player.pos.x + distance * cos_a
                        world_y = self.player.pos.y + distance * sin_a
                        if floor_tex:
                            tx = int((world_x / self.tile_size) * tex_width) % tex_width
                            ty = int((world_y / self.tile_size) * tex_height) % tex_height
                            try:
                                color = floor_tex.get_at((tx, ty))
                                if apply_light:
                                    shade = max(0.0, 1.0 - distance / self.max_depth * 0.8)
                                    color = tuple(int(c * shade) for c in color[:3])
                                pygame.draw.rect(screen, color, (x, y, step, step))
                            except:
                                pass
            return

        for y in range(self.height):
            if y < self.height // 2:
                t = y / (self.height // 2)
                color = (int(20 + 30 * t), int(20 + 30 * t), int(60 + 40 * t))
            else:
                t = (y - self.height // 2) / (self.height // 2)
                color = (int(40 + 20 * t), int(30 + 20 * t), int(10 + 10 * t))
            pygame.draw.rect(screen, color, (0, y, self.width, 1))

    def _is_sprite_visible(self, sprite_x, sprite_y):
        dx = sprite_x - self.player.pos.x
        dy = sprite_y - self.player.pos.y
        dist = math.hypot(dx, dy)
        if dist < 0.1:
            return True
        step = self.tile_size / 2
        steps = int(dist / step) + 1
        for i in range(steps):
            t = i / steps
            x = self.player.pos.x + dx * t
            y = self.player.pos.y + dy * t
            map_x = int(x // self.tile_size)
            map_y = int(y // self.tile_size)
            if 0 <= map_y < self.map_height and 0 <= map_x < self.map_width:
                cell = self.map_data[map_y][map_x]
                base_id = cell['base_id']
                # Пропускаем ID=7 (двери/ключи) и ID=6 (модели) – они не должны блокировать видимость
                if base_id in (6, 7):
                    continue
                if base_id != 0:
                    props = cell.get('properties', {})

                    # Зеркала НЕ блокируют видимость спрайтов
                    mat_name = props.get('material')
                    if mat_name == 'silver' or mat_name == 'metal' or mat_name == 'gold':
                        continue
                    # Или явная проверка через material_lib.reflection
                    try:
                        mat = self.material_lib.get_material(mat_name) if mat_name else None
                        if mat is not None and getattr(mat, 'reflection', 0.0) > 0.5:
                            continue
                    except Exception:
                        pass

                    alpha_val = props.get('alpha', 1.0)
                    try:
                        alpha_val = float(alpha_val)
                    except (TypeError, ValueError):
                        alpha_val = 1.0
                    if alpha_val < 1.0:
                        continue
                    if not props.get('isvisible', True):
                        continue

                    if base_id == 9 and props.get('isvisible', False):
                        return False
                    elif base_id == 9:
                        continue
                    else:
                        return False
        return True

    def _is_walkable(self, x, y):
        map_x = int(x // self.tile_size)
        map_y = int(y // self.tile_size)
        if map_x < 0 or map_y < 0 or map_x >= self.map_width or map_y >= self.map_height:
            return False
        row = self.map_data[map_y]
        if map_x >= len(row):
            return False
        cell = row[map_x]
        base_id = cell['base_id']
        # Если стена невидима, она проходима
        is_visible = cell.get('properties', {}).get('isvisible', True)
        add_collision = cell.get('properties', {}).get('addcollision', True)
        if base_id in (0, 8, 9) or (base_id in (1, 2, 3, 4, 5, 6) and not add_collision):
            return True
        if base_id == 7:
            props = cell.get('properties', {})
            if props.get('type') == 'key':
                return True
            if props.get('type') == 'door':
                door_id = props.get('id', None)
                if door_id and self.doors.get(door_id, {}).get('open', False):
                    return True
        return False

    def _draw_walls(self, screen, ray_results):
        if not ray_results:
            return
        bar_width = (self.width + self.rays - 1) // self.rays
        if bar_width < 1:
            bar_width = 1

        all_objects = []
        for res in ray_results:
            for depth, cell, wall_x in res.hit_objects:
                if cell is None:
                    continue
                base_id = cell['base_id']
                # Проверяем isVisible (по умолчанию True)
                is_visible = cell.get('properties', {}).get('isvisible', True)
                if not is_visible:
                    continue
                # Пропускаем ID=0, 6, 7, 8, 9 (они не стены)
                if base_id in (0, 2, 6, 7, 8, 9):
                    is_visible = cell.get('properties', {}).get('isvisible', False)
                    if not is_visible:
                        continue
                all_objects.append((depth, cell, res.ray_index, wall_x))

        all_objects.sort(key=lambda x: x[0], reverse=True)

        for depth, cell, ray_index, wall_x in all_objects:
            self._draw_single_wall(screen, ray_index, depth, cell, bar_width, wall_x)

    def _get_material_for_cell(self, cell):
        material_name = cell.get('properties', {}).get('material', None)
        if material_name is None:
            material_name = cell.get('properties', {}).get('sprite', None)
        if material_name is None:
            mat = self.material_lib.get_material(str(cell['base_id']))
        else:
            mat = self.material_lib.get_material(material_name)
        if mat is None:
            mat = self.material_lib.get_default()
        return mat

    def _get_scaled_texture(self, tex, height):
        if tex is None:
            return None
        tex_id = id(tex)
        key = (tex_id, height)
        if key in self.texture_cache:
            return self.texture_cache[key]
        if height <= 0:
            return None
        scaled = pygame.transform.scale(tex, (1, int(height)))
        self.texture_cache[key] = scaled
        return scaled

    def get_texture_column(self, texture, tx):
        key = (id(texture), tx)
        if key not in self.column_cache:
            orig_w, orig_h = texture.get_width(), texture.get_height()
            column = pygame.Surface((1, orig_h))
            for y in range(orig_h):
                color = texture.get_at((tx, y))
                column.set_at((0, y), color)
            self.column_cache[key] = column
        return self.column_cache[key]

    def _draw_single_wall(self, screen, ray_index, depth, cell, bar_width, wall_x):
        if depth <= 0 or depth >= self.max_depth:
            return
        if self.fog_enabled and depth >= self.fog_end:
            h = min(self.height, self.proj_coeff / depth)
            horizon = self.height // 2 + self._get_pitch_offset()
            y = horizon - h // 2
            pygame.draw.rect(screen, self.fog_color,
                             (ray_index * bar_width, int(y), bar_width, int(h)))
            return
        wall_x = wall_x % 1.0
        if wall_x < 0:
            wall_x += 1.0
        height = self.proj_coeff / depth
        if height > self.height:
            height = self.height

        # Если это стена (ID 1-5) и есть isVisible, но мы уже пропустили в _draw_walls
        # Здесь просто рисуем
        custom_height = cell.get('properties', {}).get('height', None)
        # if cell['base_id'] in (1,2,3,4,5):
        #     is_visible = cell.get('properties', {}).get('isvisible', True)
        # elif cell['base_id'] in (7,8,9):
        #     is_visible = cell.get('properties', {}).get('isvisible', False)
        # else:
        #     is_visible = cell.get('properties', {}).get('isvisible', None)
        if custom_height is not None and (cell['base_id'] in (1, 2, 3, 4, 5)):
            wall_height = height * float(custom_height)
            floor_y = self.height // 2 + self._get_pitch_offset()
            if wall_height > self.height:
                wall_height = self.height
            y = floor_y + (height - wall_height)
            if y < floor_y:
                y = floor_y
            if y + wall_height > self.height:
                wall_height = self.height - y
        else:
            wall_height = height
            horizon = self.height // 2 + self._get_pitch_offset()
            y = horizon - wall_height // 2

        mat = self._get_material_for_cell(cell)

        color_hex = cell.get('properties', {}).get('color', None)
        if color_hex:
            hex_str = str(color_hex).lstrip('#')
            r = int(hex_str[0:2], 16)
            g = int(hex_str[2:4], 16)
            b = int(hex_str[4:6], 16)
            color = (r, g, b)
        else:
            color = mat.color
        if color is None:
            color = (200, 200, 200)

        ray_angle = self.player.angle - self.half_fov + (ray_index / self.rays) * self.fov
        hit_x = self.player.pos.x + depth * math.cos(ray_angle)
        hit_y = self.player.pos.y + depth * math.sin(ray_angle)
        point = pygame.math.Vector2(hit_x, hit_y)
        light = self.light_tracer.get_light_at_point(point)
        light = max(light, self.light_tracer.get_light_for_depth(depth) * 0.15)

        x = ray_index * bar_width

        if mat.texture is not None:
            scaled_tex = self._get_scaled_texture(mat.texture, wall_height)
            if scaled_tex is not None:
                orig_tex = mat.texture
                orig_w = orig_tex.get_width()
                orig_h = orig_tex.get_height()
                tx = int(wall_x * orig_w) % orig_w

                column = self.get_texture_column(orig_tex, tx)

                lit_column = column.copy()
                lit_column.fill((int(255 * light), int(255 * light), int(255 * light)),
                                special_flags=pygame.BLEND_RGB_MULT)

                scaled_column = pygame.transform.scale(lit_column, (bar_width, int(wall_height)))
                if self.fog_enabled and depth > self.fog_start:
                    fog_t = min(1.0, (depth - self.fog_start) /
                                max(1, self.fog_end - self.fog_start))
                    fog_alpha = int(255 * fog_t)
                    fog_overlay = pygame.Surface((bar_width, int(wall_height)), pygame.SRCALPHA)
                    fog_overlay.fill((*self.fog_color, fog_alpha))
                    scaled_column.blit(fog_overlay, (0, 0))

                screen.blit(scaled_column, (x, y))
            else:
                color = tuple(int(c * light) for c in color[:3])
                pygame.draw.rect(screen, color, (x, y, bar_width, wall_height))
        else:
            color = tuple(int(c * light) for c in color[:3])
            alpha = mat.alpha if hasattr(mat, 'alpha') else 1.0
            custom_alpha = cell.get('properties', {}).get('alpha', None)
            if custom_alpha is not None:
                alpha = float(custom_alpha)
            if alpha < 1.0:
                surf = pygame.Surface((bar_width, wall_height), pygame.SRCALPHA)
                surf.fill((*color, int(255 * alpha)))
                screen.blit(surf, (int(x), int(y)))
            else:
                pygame.draw.rect(screen, color, (x, y, bar_width, wall_height))

    def _draw_sprites(self, screen):
        sorted_sprites = self.sprite_manager.get_sorted(self.player.pos)
        for sprite in sorted_sprites:
            # Проверяем isVisible у спрайта (если есть ключ и свойство)
            if hasattr(sprite, 'visible') and not sprite.visible:
                continue
            # Для моделей проверяем isVisible через карту (если есть)
            if isinstance(sprite, (ModelSprite, AnimatedModelSprite)):
                # Проверяем, есть ли у модели свойство isvisible в данных карты
                # Для этого нужно хранить в спрайте ссылку на клетку или проверять по позиции
                # Упрощённо: используем атрибут visible, который можно установить через API
                if not sprite.visible:
                    continue

            if isinstance(sprite, AnimatedModelSprite):
                sprite.set_frame_by_angle(self.player.pos, self.player.angle)
                texture = sprite.get_current_texture()
            elif isinstance(sprite, ModelSprite):
                sprite.set_frame_by_angle(self.player.pos, self.player.angle)
                texture = sprite.frames[sprite.current_frame] if sprite.frames else None
            else:
                texture = sprite.texture

            if texture is None:
                continue

            if not self._is_sprite_visible(sprite.x, sprite.y):
                continue
            dx = sprite.x - self.player.pos.x
            dy = sprite.y - self.player.pos.y
            dist = math.hypot(dx, dy)
            if dist < 0.1:
                continue

            angle_to_sprite = math.atan2(dy, dx)
            relative_angle = angle_to_sprite - self.player.angle
            while relative_angle < -math.pi:
                relative_angle += 2 * math.pi
            while relative_angle > math.pi:
                relative_angle -= 2 * math.pi

            if abs(relative_angle) > self.half_fov:
                continue

            screen_x = (relative_angle / self.fov + 0.5) * self.width
            size = self.proj_coeff / dist
            if size > self.height:
                size = self.height
            if size < 1:
                size = 1

            point = pygame.Vector2(sprite.x, sprite.y)
            light = self.light_tracer.get_light_at_point(point)
            light = max(light, self.light_tracer.get_light_for_depth(dist) * 0.2)

            if texture:
                shaded = texture.copy()
                shaded.fill((int(255 * light), int(255 * light), int(255 * light)), special_flags=pygame.BLEND_RGB_MULT)
                scaled = pygame.transform.scale(shaded, (int(size), int(size)))
                if self.fog_enabled and dist > self.fog_start:
                    fog_t = min(1.0, (dist - self.fog_start) /
                                max(1, self.fog_end - self.fog_start))
                    if fog_t >= 0.98:
                        continue  # полностью в тумане — не рисуем
                    fog_overlay = pygame.Surface(scaled.get_size(), pygame.SRCALPHA)
                    fog_overlay.fill((*self.fog_color, int(255 * fog_t)))
                    scaled.blit(fog_overlay, (0, 0))
                horizon = self.height // 2 + self._get_pitch_offset()
                screen.blit(scaled, (screen_x - size // 2, horizon - size // 2))
    def _hex_to_rgb(self, hex_str):
        if hex_str:
            hex_str = str(hex_str).lstrip('#')
            return (int(hex_str[0:2], 16), int(hex_str[2:4], 16), int(hex_str[4:6], 16))
        else:
            return (255, 255, 255)