import time
import random

import pygame
import math
import os
import sys
import numpy as np
import threading

from .config import *
from .player import Player
from .utils.parser import MapParser
from .raycast.core import RayCaster
from .light.tracer import LightTracer, LightSource
from .material.library import MaterialLibrary
from .image.cache import SpriteManager as ImageManager
import imageio
import imageio_ffmpeg
from .sound.mixer import SoundManager
from .sound import Sound3D
from .object.registry import GameObjectRegistry
from .sprite.core import SpriteManager, Sprite, ModelSprite, AnimatedModelSprite
from .image.cache import load_image
from .polygon.obj_to_sprites import obj_to_sprites
from .effects.manager import EffectsManager
from .enemy import EnemyAI
from .gun import GunManager, Bullet
from .hud.core import HUDManager
from .hud.minimap import *
from .effects.particles import ParticleSystem, Particle
from .effects.decals import DecalSystem
from .effects.explosion import Explosion

try:
    from .raycast.core_cy import RayCaster
    _CYTHON_RAYS = True
except ImportError:
    from .raycast.core import RayCaster
    _CYTHON_RAYS = False
try:
    from .render.gpu_renderer import GPURaycaster
    _GPU_OK = True
except ImportError as e:
    print(f"[GPU] not available: {e}")
    _GPU_OK = False

class Engine:
    def __init__(self, clock, width=DEFAULT_WIDTH, height=DEFAULT_HEIGHT,
                 levels=None, current_level=0,
                 fov=DEFAULT_FOV, rays=DEFAULT_RAYS,
                 tile_size=DEFAULT_TILE_SIZE, max_depth=DEFAULT_MAX_DEPTH,
                 proj_coeff=DEFAULT_PROJ_COEFF,
                 player_speed=DEFAULT_PLAYER_SPEED,
                 player_rot_speed=DEFAULT_PLAYER_ROT_SPEED,
                 particles_mode='optimal',
                 graphics_level='high',  # ← новое
                 debris_mode=None,  # ← новое
                 default_wall_hp=100,  # ← новое
                 use_rt=False,
                 rt_level=4,
                 floor_texture=None, ceiling_texture=None,
                 mouse_sensitivity=0.002,render_scale=1,async_raycast=True,mcfi=False,mcfi_level=None,enemy_sprite="assets/enemy_imp.png",show_fps=True,
                 use_example=False):  # <-- добавили параметр
        try:
            print(f"[Engine] RayCaster: {'Cython' if _CYTHON_RAYS else 'Python'} version")
            if mcfi_level is not None:
                self.mcfi_level = mcfi_level
            else:
                self.mcfi_level = 1 if mcfi else 0
            self.frame_blend_enabled = self.mcfi_level > 0
            self._mcfi_step = 0
            self._mcfi_real_prev = None
            self._mcfi_real_curr = None
            self._mcfi_strength = 0.125
            print(f"MCFI level: {self.mcfi_level}, enabled: {self.frame_blend_enabled}")

            self.interactive_objects = {}  # key -> InteractiveObject
            self.ceiling_collision = True
            self.gravity_enabled = True  # глобальный флаг

            self._pitch_offset_cache = 0
            self._particle_tex_cache = {}  # (color, size) -> Surface

            self.explosions = []  # активные взрывы
            self.transient_lights = []  # [(x, y, r, intensity, color, ttl)]
            self.player_light_mode = 'default'  # 'default' | 'circle'
            self.player_light_range = 400.0  # дальность конуса (пиксели)
            self.player_light_cone = 0.55  # cos угла полураскрытия (~55°)
            # Fixed timestep
            self.fixed_physics_dt = 1.0 / 30.0
            self._physics_accumulator = 0.0

            self.show_enemy_hp = True
            self.show_enemy_ammo = False
            self.enemy_bar_max_distance = 800  # не рисуем за этой дистанцией

            self.particles = ParticleSystem(self)
            self.particles.set_mode(particles_mode or "optimal")
            self.particles.set_graphics_level(graphics_level)
            if debris_mode:
                self.particles.debris_mode = debris_mode
            self.default_wall_hp = default_wall_hp
            self.scheduled_walls = []  # отложенный восстановитель стен

            self.decals = DecalSystem(self)

            # Y-shearing
            self.y_shearing_enabled = True
            self.y_shearing_pixels_per_rad = 400  # сколько пикселей на 1 радиан наклона

            self.default_wall_hp = 100
            self.scheduled_walls = []

            self.use_raycaster_async = async_raycast  # включить асинхронный режим
            self._ray_thread = None
            self._ray_results = None
            self.use_example = use_example
            self._ray_lock = threading.Lock()
            self.width = int(width)
            self.height = int(height)
            self.screen_width = int(width)
            self.screen_height = int(height)
            self.render_scale = max(1, int(render_scale))
            self.font_fps = pygame.font.SysFont('Arial', 24)
            self.enemy_sprite = enemy_sprite

            self.hud = HUDManager(self)
            self.minimap = None
            self.minimap_enemy_hide_delay = 5.0
            # Fog
            self.fog_enabled = False
            self.fog_color = (30, 30, 40)
            self.fog_start = 400  # начало проявления тумана (пиксели)
            self.fog_end = 1200  # полный туман
            self.fog_floor_ceiling = True
            self.show_fps = show_fps
            self.clock = clock

            self.active_3d_sounds = []
            self.global_model_cache = {}  # ключ -> список спрайтов
            self.text_color = (30,30,30)

            self.enemies = []
            self.bullets = []
            self.gun_manager = GunManager()
            self.enemy_effect_timers = {}  # key -> timer

            self.column_cache = {}
            self.prev_frame = None
            self.prev_player_pos = None
            self.prev_player_angle = None

            # Рабочие размеры (уменьшенные)
            self.width = max(1, self.screen_width // self.render_scale)
            self.height = max(1, self.screen_height // self.render_scale)

            # Буфер для рендера
            self.render_surface = pygame.Surface((self.width, self.height))
            self.fov = math.radians(fov)
            self.half_fov = self.fov / 2
            self.rays = rays
            self.effects_manager = EffectsManager()
            self.tile_size = tile_size
            self.max_depth = max_depth
            self.proj_coeff = proj_coeff
            if proj_coeff is None or proj_coeff == DEFAULT_PROJ_COEFF:
                self.proj_coeff = (self.height / 2) * tile_size
            else:
                # Если пользователь задал своё значение, масштабируем относительно старой высоты
                self.proj_coeff = proj_coeff * (self.height / self.screen_height)
            self.use_lt = True
            self.overlay_texture = None
            self.overlay_alpha = 255
            self.effect_texture = None
            self.effect_timer = 0
            self.inactive_triggers = set()
            self.model_data = []

            self.message_text = ""
            self.message_timer = 0.0
            self.message_duration = 0.0
            self.font = pygame.font.SysFont("Arial", 36)

            self.doors = {}
            self.keys = {}

            # ---- Водяной знак и экран загрузки (уже есть) ----
            self.watermark = ""
            self.loading_progress = (0, 0)
            self.show_loading_screen = True
            self.example_menu = None
            self.example_game = None
            self._load_watermark()

            self.global_model_cache = {}
            self.model_cache_lock = threading.Lock()
            self.model_generate_lock = threading.Lock()

            # ---- Видео (через imageio, без cv2) ----
            self.video_playing = False
            self.video_surface = None
            self.video_mode = "full"
            self.video_rect = pygame.Rect(0, 0, 0, 0)
            self.video_lock = threading.Lock()
            self.video_thread = None
            self.video_loop = True
            self.model_generate_lock = threading.Lock()
            # ---- Управление мышью (новое) ----
            self.mouse_sensitivity = mouse_sensitivity
            self.mouse_captured = False

            self.physics = self.PhysicsAPI(self)

            # ---- Текстуры пола/потолка ----
            self.floor_texture = None
            self.ceiling_texture = None
            if floor_texture:
                try:
                    self.floor_texture = pygame.image.load(floor_texture).convert_alpha()
                except:
                    self.floor_texture = None
            if ceiling_texture:
                try:
                    self.ceiling_texture = pygame.image.load(ceiling_texture).convert_alpha()
                except:
                    self.ceiling_texture = None

            self.material_lib = MaterialLibrary()
            self.sprite_manager = SpriteManager()
            self.sound_manager = SoundManager()
            self.registry = GameObjectRegistry()

            self.prev_prev_frame = None  # ← добавить
            self._mcfi_is_blend_frame = False

            self.levels = levels if levels else []
            self.current_level = current_level
            self.map_data = None
            self.map_width = 0
            self.map_height = 0

            self.model_cache_lock = threading.Lock()

            self.texture_cache = {}

            self.raycaster = RayCaster(
                map_data=self.map_data,
                tile_size=self.tile_size,
                fov=self.fov,
                rays=self.rays,
                max_depth=self.max_depth,
                proj_coeff=self.proj_coeff,
                material_lib=self.material_lib
            )
            self.rt_enabled = False  # ← True чтобы включить RTE
            self.rt_max_lights = 2  # сколько источников считают тени
            self.rt_reflections = True  # зеркала
            self.use_gpu = False
            self.gpu_raycaster = None
            if _GPU_OK:
                try:
                    # Рендерим в том же разрешении, что render_surface
                    self.gpu_raycaster = GPURaycaster(self.width, self.height)
                    self.use_gpu = True
                    print("[Engine] GPU renderer: enabled")
                except Exception as e:
                    print(f"[Engine] GPU renderer failed: {e}")
            self.light_tracer = LightTracer(map_data=self.map_data, tile_size=self.tile_size)

            self.spawn = None
            self.floor_color = None
            self.ceiling_color = None
            self.ambient = 0.03
            self.level_sprites = []

            if self.levels:
                self.load_level(self.current_level)

            start_x, start_y = self._find_spawn_point()
            self.player = Player(
                x=start_x,
                y=start_y,
                angle=0.0,
                speed=player_speed,
                rot_speed=player_rot_speed
            )

            self.player.on_death = self._on_player_death

            self.mesh_objects = []
            self.api = self.MicroAPI(self)
            self.rt = use_rt
            if self.rt:
                self.api.set_rt(enabled=True,max_lights=rt_level or 4,reflections=True)
        except Exception as e:
            print(f"Error in Engine.__init__: {e}")
            raise

    def _get_pitch_offset(self):
        # """Возвращает сдвиг горизонта в пикселях (в координатах render_surface)."""
        # if not self.y_shearing_enabled:
        #     return 0
        # offset = -int(self.player.pitch * self.y_shearing_pixels_per_rad)
        # limit = self.height // 2 - 1
        # return max(-limit, min(limit, offset))
        return self._pitch_offset_cache

    def _on_player_death(self):
        self.show_message("GAME OVER", duration=5.0)
        print("Игра завершена")

    def _draw_enemy_bars(self, screen):
        """Полоски HP и патронов над врагами."""
        if not self.enemies:
            return
        if not (self.show_enemy_hp or self.show_enemy_ammo):
            return

        px, py = self.player.pos.x, self.player.pos.y
        pa = self.player.angle
        half_fov = self.half_fov
        fov = self.fov
        proj = self.proj_coeff
        horizon = self.height // 2 + self._get_pitch_offset()

        if not hasattr(self, '_enemy_bar_font'):
            self._enemy_bar_font = pygame.font.SysFont('Arial', 14, bold=True)

        for enemy in self.enemies:
            if not enemy.alive:
                continue
            if not self._is_sprite_visible(enemy.x, enemy.y):
                continue
            dx, dy = enemy.x - px, enemy.y - py
            dist = math.hypot(dx, dy)
            if dist < 1 or dist > self.enemy_bar_max_distance:
                continue

            rel = math.atan2(dy, dx) - pa
            while rel < -math.pi: rel += 2 * math.pi
            while rel > math.pi:  rel -= 2 * math.pi
            if abs(rel) > half_fov:
                continue

            screen_x = (rel / fov + 0.5) * self.width
            size = proj / dist
            if size > self.height:
                size = self.height
            if size < 20:
                continue

            # Позиция бара — над головой врага
            bar_w = int(size * 0.7)
            bar_h = max(4, int(size * 0.05))
            bar_x = int(screen_x - bar_w // 2)
            bar_y = int(horizon - size // 2 - bar_h - 6)

            if bar_x < 0 or bar_x + bar_w > self.width:
                continue

            # Фон
            pygame.draw.rect(screen, (20, 20, 20),
                             (bar_x - 1, bar_y - 1, bar_w + 2, bar_h + 2))
            # HP
            if self.show_enemy_hp:
                max_hp = getattr(enemy, 'max_hp', 100) or 100
                hp_ratio = max(0.0, min(1.0, enemy.hp / max_hp))
                hp_w = int(bar_w * hp_ratio)
                if hp_ratio > 0.6:
                    col = (60, 200, 60)
                elif hp_ratio > 0.3:
                    col = (220, 180, 40)
                else:
                    col = (220, 60, 60)
                pygame.draw.rect(screen, col, (bar_x, bar_y, hp_w, bar_h))

                # Число HP рядом
                hp_txt = self._enemy_bar_font.render(
                    f"{int(enemy.hp)}", True, (255, 255, 255))
                screen.blit(hp_txt, (bar_x + bar_w + 4, bar_y - 2))

            # Патроны (если включено)
            if self.show_enemy_ammo:
                gun = getattr(enemy, 'current_gun', None)
                if gun:
                    ammo_txt = self._enemy_bar_font.render(
                        f"{gun.ammo}", True, (255, 220, 100))
                    screen.blit(ammo_txt, (bar_x + bar_w + 4, bar_y + bar_h))

    def enemy_shoot(self, enemy, angle):
        damage = enemy.current_gun.damage if enemy.current_gun else 10
        bullet = Bullet(enemy.x, enemy.y, angle, damage=damage, speed=800, owner=enemy)
        self.bullets.append(bullet)

    def damage_player(self, damage):
        if hasattr(self.player, 'take_damage'):
            self.player.take_damage(damage)
            self.hud.damage_taken(damage)
            self.particles.spawn_hit_player()

    def update_enemies(self, dt):
        for enemy in self.enemies:
            enemy.update(dt, (self.player.pos.x, self.player.pos.y), self)
            enemy.update_visibility(dt, self)
        for enemy in self.enemies:
            if not enemy.alive:
                self.particles.spawn_death(enemy.x, enemy.y)
                # лужа крови под мёртвым
                for _ in range(2):
                    self.decals.spawn_blood(
                        enemy.x + random.uniform(-14, 14),
                        enemy.y + random.uniform(-14, 14),
                        size=80)
        self.enemies = [e for e in self.enemies if e.alive]
        # Управление эффектами врагов
        for key in list(self.enemy_effect_timers.keys()):
            if self.enemy_effect_timers[key] is not None:
                self.enemy_effect_timers[key] -= dt
                if self.enemy_effect_timers[key] <= 0:
                    self.effects_manager.clear_effect()
                    del self.enemy_effect_timers[key]

    def _bullet_hit(self, bullet):
        """Централизованное попадание — сюда весь взрывной код."""
        if getattr(bullet, 'explosive', False):
            self.explosions.append(Explosion(
                bullet.x, bullet.y,
                bullet.explosion_radius,
                bullet.explosion_damage,
            ))
        bullet.alive = False

    def update_bullets(self, dt):
        for bullet in self.bullets[:]:
            bullet.update(dt)

            # Попадание в игрока или врагов
            if bullet.owner != 'player':  # пуля врага
                dist = math.hypot(bullet.x - self.player.pos.x, bullet.y - self.player.pos.y)

                if dist < 20:
                    self.damage_player(bullet.damage)
                    self._bullet_hit(bullet)
                    bullet.alive = False
            else:  # пуля игрока
                for enemy in self.enemies:
                    if not enemy.alive:
                        continue
                    dist = math.hypot(bullet.x - enemy.x, bullet.y - enemy.y)
                    if dist < 20:
                        enemy.take_damage(bullet.damage, bullet.owner)
                        self.particles.spawn_hit_enemy(enemy.x, enemy.y)
                        # КРОВЬ НА ПОЛУ под врагом
                        self.decals.spawn_blood(
                            enemy.x + random.uniform(-8, 8),
                            enemy.y + random.uniform(-8, 8),
                            size=64)
                        self._bullet_hit(bullet)
                        bullet.alive = False
                        break

            # Столкновение со стенами и объектами
            if bullet.alive:
                map_x = int(bullet.x // self.tile_size)
                map_y = int(bullet.y // self.tile_size)
                if 0 <= map_y < self.map_height and 0 <= map_x < self.map_width:
                    cell = self.map_data[map_y][map_x]
                    base_id = cell['base_id']
                    if base_id in (1, 2, 3, 4, 5, 6, 7):
                        props = cell.get('properties', {})
                        if not props.get('addcollision', True):
                            bullet.alive = True
                            continue
                        mat = self._get_material_for_cell(cell)
                        wall_col = mat.color if mat and mat.color else (200, 200, 200)

                        passes_through = (
                                not props.get('addcollision', True)
                                or (base_id == 7 and props.get('type') == 'key')
                        )
                        if not passes_through:
                            mat = self._get_material_for_cell(cell)
                            wall_col = mat.color if mat and mat.color else (200, 200, 200)

                        # ID=7 двери: если дверь закрыта — она стена, если открыта — пропускаем
                        if base_id == 7:
                            door_id = props.get('id', None)
                            if props.get('type') == 'door':
                                if props.get('open', False):
                                    # Открытая дверь — пуля пролетает
                                    pass
                                else:
                                    # Закрытая — считаем как стену
                                    if props.get('destructible', False):
                                        current_hp = props.get('hp', getattr(self, 'default_wall_hp', 100))
                                        new_hp = current_hp - bullet.damage
                                        props['hp'] = new_hp
                                        if new_hp <= 0:
                                            self.particles.spawn_wall_break(
                                                bullet.x, bullet.y,
                                                texture=mat.texture if mat else None,
                                                color=wall_col,
                                                mode=self.particles.debris_mode)
                                            self.decals.spawn_rubble(
                                                bullet.x, bullet.y, wall_col,
                                                size=96, cell=(map_x, map_y),
                                                wall_texture=mat.texture if mat else None)
                                            cell['base_id'] = 0
                                            if self.use_gpu:
                                                self.gpu_raycaster.mark_map_dirty()
                                            cell['properties'].pop('material', None)
                                            # Удаляем спрайт двери
                                            sprite_key = self.doors.get(door_id, {}).get('sprite_key')
                                            if sprite_key:
                                                self.sprite_manager.remove_by_key(sprite_key)
                                            self.doors.pop(door_id, None)
                                            if self.use_gpu:
                                                self.gpu_raycaster.mark_map_dirty()
                                        else:
                                            self.particles.spawn_hit_wall(
                                                bullet.x, bullet.y, wall_col,
                                                count=10 if self.particles.debris_enabled else 6)
                                    else:
                                        self.particles.spawn_hit_wall(bullet.x, bullet.y, wall_col)
                                    self._bullet_hit(bullet)
                                    bullet.alive = False
                            # elif props.get('type') == 'key':
                            #     # Ключ — просто пропускаем пулю (или спавним искры)
                            #     self.particles.spawn_hit_wall(bullet.x, bullet.y, (255, 215, 0), count=6)
                            #     self._bullet_hit(bullet)
                            #     bullet.alive = False

                        # ID=6 — модель-объект (спрайт .gbj)
                        elif base_id == 6:
                            if props.get('destructible', False):
                                current_hp = props.get('hp', self.default_wall_hp)
                                new_hp = current_hp - bullet.damage
                                props['hp'] = new_hp

                                # Берём текстуру спрайта модели
                                model_key = f"model_{map_x}_{map_y}"
                                sprite = self.sprite_manager.get_by_key(model_key)
                                model_texture = None
                                if sprite is not None:
                                    if hasattr(sprite, 'frame_sets') and sprite.frame_sets:
                                        frame_set = sprite.frame_sets[sprite.current_frame_index]
                                        if frame_set:
                                            model_texture = frame_set[sprite.current_angle_frame]
                                    elif hasattr(sprite, 'frames') and sprite.frames:
                                        model_texture = sprite.frames[0]
                                    elif hasattr(sprite, 'texture'):
                                        model_texture = sprite.texture

                                # Если текстура модели найдена — используем её, иначе mat.texture (fallback)
                                use_texture = model_texture if model_texture is not None else (
                                    mat.texture if mat else None)

                                if new_hp <= 0:
                                    self.particles.spawn_wall_break(
                                        bullet.x, bullet.y,
                                        texture=use_texture,
                                        color=wall_col,
                                        mode=self.particles.debris_mode)
                                    self.decals.spawn_rubble(
                                        bullet.x, bullet.y, wall_col,
                                        size=96, cell=(map_x, map_y),
                                        wall_texture=use_texture)
                                    cell['base_id'] = 0
                                    cell['properties'].pop('material', None)
                                    self.sprite_manager.remove_by_key(model_key)
                                    if self.use_gpu:
                                        self.gpu_raycaster.mark_map_dirty()
                                else:
                                    self.particles.spawn_hit_wall(
                                        bullet.x, bullet.y, wall_col,
                                        count=10 if self.particles.debris_enabled else 6)
                                self._bullet_hit(bullet)
                                bullet.alive = False
                            else:
                                self._bullet_hit(bullet)
                                bullet.alive = False

                        # ID=1–5 — обычные стены
                        else:
                            if props.get('destructible', False):
                                current_hp = props.get('hp', getattr(self, 'default_wall_hp', 100))
                                new_hp = current_hp - bullet.damage
                                props['hp'] = new_hp
                                if new_hp <= 0:
                                    self.particles.spawn_wall_break(
                                        bullet.x, bullet.y,
                                        texture=mat.texture if mat else None,
                                        color=wall_col,
                                        mode=self.particles.debris_mode)
                                    self.decals.spawn_rubble(
                                        bullet.x, bullet.y, wall_col,
                                        size=96, cell=(map_x, map_y),
                                        wall_texture=mat.texture if mat else None)
                                    cell['base_id'] = 0
                                    cell['properties'].pop('material', None)
                                    if self.use_gpu:
                                        self.gpu_raycaster.mark_map_dirty()
                                else:
                                    self.particles.spawn_hit_wall(
                                        bullet.x, bullet.y, wall_col,
                                        count=10 if self.particles.debris_enabled else 6)
                            else:
                                self.particles.spawn_hit_wall(bullet.x, bullet.y, wall_col)
                            self._bullet_hit(bullet)
                            bullet.alive = False

            if not bullet.alive:
                self.bullets.remove(bullet)

    def play_sound_3d(self, sound_key, source_pos=(0,0), max_distance=500.0, doppler_factor=0.0):
        """Воспроизводит звук с учётом позиции источника и ориентации камеры.

        source_pos: (x, y) в мировых координатах (пикселях) или в тайлах? Уточним.
        """
        if sound_key not in self.sound_manager.sounds:
            return None
        sound = self.sound_manager.sounds[sound_key]
        snd3d = Sound3D(sound)
        listener_pos = (self.player.pos.x, self.player.pos.y)
        listener_angle = self.player.angle
        snd3d.play(listener_pos, listener_angle, source_pos, max_distance, doppler_factor)
        return snd3d

    def play_sound_3d_world(self, sound_key, world_x=0, world_y=0, max_distance=500.0, doppler_factor=0.0):
        """Позиция в мировых координатах (пикселях)."""
        return self._play_sound_3d_impl(sound_key, (world_x, world_y), max_distance, doppler_factor)

    def play_sound_3d_tile(self, sound_key, tile_x=0, tile_y=0, max_distance=500.0, doppler_factor=0.0):
        """Позиция в тайлах (умножается на tile_size)."""
        return self._play_sound_3d_impl(sound_key,
                                        (tile_x * self.tile_size, tile_y * self.tile_size),
                                        max_distance, doppler_factor)

    def get_sound_occlusion_factor(self, pos1, pos2):
        """
        Возвращает множитель громкости, учитывающий препятствия на пути звука.
        pos1, pos2 – мировые координаты (x, y).
        """
        if not self.map_data:
            return 1.0

        x1, y1 = pos1
        x2, y2 = pos2
        dx = x2 - x1
        dy = y2 - y1
        dist = math.hypot(dx, dy)
        if dist < 0.1:
            return 1.0

        steps = int(dist / (self.tile_size * 0.5)) + 1
        wall_count = 0
        for i in range(1, steps):
            t = i / steps
            x = x1 + dx * t
            y = y1 + dy * t
            map_x = int(x // self.tile_size)
            map_y = int(y // self.tile_size)
            if 0 <= map_y < self.map_height and 0 <= map_x < self.map_width:
                cell = self.map_data[map_y][map_x]
                base_id = cell['base_id']
                # Стены считаем, если это непрозрачные стены (ID 1-5 и закрытые двери)
                if base_id in (1, 2, 3, 4, 5):
                    wall_count += 1
                elif base_id == 7:
                    props = cell.get('properties', {})
                    if props.get('type') == 'door' and not props.get('open', False):
                        wall_count += 1
        # Каждая стена ослабляет звук на 30%
        return 0.7 ** wall_count

    def play_sound_3d_player_camera(self, sound_key, offset_x=0, offset_y=0, max_distance=500.0, doppler_factor=0.0):
        """Позиция относительно игрока с учётом поворота камеры (offset_x вперёд, offset_y вправо)."""
        angle = self.player.angle
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)
        world_x = self.player.pos.x + offset_x * cos_a - offset_y * sin_a
        world_y = self.player.pos.y + offset_x * sin_a + offset_y * cos_a
        return self._play_sound_3d_impl(sound_key, (world_x, world_y), max_distance, doppler_factor)

    def play_sound_3d_player(self, sound_key, offset_x=0, offset_y=0, max_distance=500.0, doppler_factor=0.0):
        """Позиция относительно игрока без учёта поворота (просто смещение по осям)."""
        world_x = self.player.pos.x + offset_x
        world_y = self.player.pos.y + offset_y
        return self._play_sound_3d_impl(sound_key, (world_x, world_y), max_distance, doppler_factor)

    def _play_sound_3d_impl(self, sound_key, source_pos, max_distance=500.0, doppler_factor=0.0):
        if sound_key not in self.sound_manager.sounds:
            return None
        sound = self.sound_manager.sounds[sound_key]
        snd3d = Sound3D(sound)
        snd3d.engine = self
        snd3d.play((self.player.pos.x, self.player.pos.y), self.player.angle, source_pos, max_distance, doppler_factor)
        self.active_3d_sounds.append(snd3d)
        return snd3d

    def _draw_enemies(self, screen, enemy_image=None):
        """Рисует врагов как спрайты."""
        for enemy in self.enemies:
            if not enemy.alive:
                continue
            if not self._is_sprite_visible(enemy.x, enemy.y):
                continue
            # Вычисляем позицию на экране аналогично спрайтам
            dx = enemy.x - self.player.pos.x
            dy = enemy.y - self.player.pos.y
            dist = math.hypot(dx, dy)
            if dist < 0.1:
                continue

            angle_to_enemy = math.atan2(dy, dx)
            relative_angle = angle_to_enemy - self.player.angle
            while relative_angle < -math.pi:
                relative_angle += 2 * math.pi
            while relative_angle > math.pi:
                relative_angle -= 2 * math.pi

            if abs(relative_angle) > self.half_fov:
                continue

            screen_x = (relative_angle / self.fov + 0.5) * self.width
            size = self.proj_coeff / dist
            if size > self.height:
                size = self.height
            if size < 1:
                size = 1

            # Используем текстуру врага, если есть, иначе цветной квадрат
            tex = enemy.texture
            if tex is None:
                try:
                    tex = load_image(enemy_image or self.enemy_sprite, enemy_image or self.enemy_sprite, size=(64, 64))
                except:
                    tex = pygame.Surface((32, 32))
                    tex.fill((255, 0, 0))

            # Применяем освещение
            light = self.light_tracer.get_light_at_point(pygame.Vector2(enemy.x, enemy.y))
            light = max(light, self.light_tracer.get_light_for_depth(dist) * 0.2)
            shaded = tex.copy()
            shaded.fill((int(255 * light), int(255 * light), int(255 * light)), special_flags=pygame.BLEND_RGB_MULT)
            scaled = pygame.transform.scale(shaded, (int(size), int(size)))
            # Отрисовка по центру
            horizon = self.height // 2 + self._get_pitch_offset()
            screen.blit(scaled, (screen_x - size // 2, horizon - size // 2))

    def _draw_gun_and_crosshair(self, screen):
        """Рисует текущее оружие внизу экрана и прицел в центре."""
        gun = self.gun_manager.get_current_gun()
        if gun:
            tex = gun.get_current_texture(moving=False)
            if tex is None:
                tex = gun.texture
            if tex:
                # Берём размер из самой текстуры — не hardcoded
                gun_w, gun_h = tex.get_size()

                # Если хочешь дополнительно масштабировать относительно экрана:
                # gun_w = int(self.screen_width * 0.25)
                # gun_h = int(gun_h * (gun_w / tex.get_width()))

                x = self.screen_width - gun_w - 20  # отступ 20px от правого края
                y = self.screen_height - gun_h
                screen.blit(tex, (x, y))

        # Прицел — крестик
        cx = self.width // 2
        cy = self.height // 2 + self._get_pitch_offset()
        color = (255, 0, 0)
        pygame.draw.line(screen, color, (cx - 10, cy), (cx + 10, cy), 2)
        pygame.draw.line(screen, color, (cx, cy - 10), (cx, cy + 10), 2)
        pygame.draw.circle(screen, color, (cx, cy), 5, 1)

    def _get_model_cache_key(self, path, rot_x, rot_y, rot_z, scale, color):
        """Создаёт уникальный ключ кэша для модели с заданными параметрами."""
        color_str = '_'.join(map(str, color)) if color else 'default'
        return f"{path}_{rot_x}_{rot_y}_{rot_z}_{scale}_{color_str}".replace('/', '_').replace('\\', '_')

    def prepare_models(self, screen):
        print("prepare_models started")
        cache_dir = "cache"
        if not os.path.exists(cache_dir):
            os.makedirs(cache_dir)

        # Собираем все модели из всех уровней
        all_models = []
        for level in self.levels:
            parser = MapParser()
            layers = parser.parse_layers(level)
            map_data = layers.get('collision', [])
            for row in map_data:
                for cell in row:

                    if cell['base_id'] == 6:
                        props = cell.get('properties', {})
                        path = props.get('path')
                        if not path:
                            continue
                        rot_x = float(props.get('rotx', 0))
                        rot_y = float(props.get('roty', 0))
                        rot_z = float(props.get('rotz', 0))
                        scale = float(props.get('scale', 1.0))
                        color_hex = props.get('color')
                        color = self._hex_to_rgb(color_hex) if color_hex else (200, 100, 100)
                        cache_key = self._get_model_cache_key(path, rot_x, rot_y, rot_z, scale, color)
                        all_models.append({
                            'cache_key': cache_key,
                            'path': path,
                            'rot_x': rot_x,
                            'rot_y': rot_y,
                            'rot_z': rot_z,
                            'scale': scale,
                            'color': color
                        })

        total = len(all_models)
        if total == 0:
            print("No models to cache")
            self._process_models()  # если моделей нет, просто загружаем уровень
            return

        generated = 0
        for idx, model in enumerate(all_models):
            cache_key = model['cache_key']
            # Проверяем, есть ли уже в глобальном кэше
            with self.model_cache_lock:
                in_memory = cache_key in self.global_model_cache
            if in_memory:
                generated += 1
                self.show_loading(screen, generated, total)
                continue

            # Проверяем файловый кэш
            sprites = self._load_sprites_from_cache(cache_key, num_frames=64)
            if sprites:
                with self.model_cache_lock:
                    self.global_model_cache[cache_key] = sprites
                generated += 1
                self.show_loading(screen, generated, total)
                continue

            # Генерируем спрайты
            print(f"Generating sprites for {model['path']}...")
            sprites = obj_to_sprites(
                model['path'],
                num_angles=128,
                sprite_size=(512, 512),
                scale=model['scale'],
                color=model['color'],
                model_rot_x=model['rot_x'],
                model_rot_y=model['rot_y'],
                model_rot_z=model['rot_z']
            )
            if sprites:
                self._save_sprites_to_cache(cache_key, sprites)
                with self.model_cache_lock:
                    self.global_model_cache[cache_key] = sprites
                generated += 1
            else:
                print(f"Failed to generate sprites for {model['path']}")

            self.show_loading(screen, generated, total)

        # После генерации всех моделей загружаем спрайты текущего уровня в сцену
        self._process_models()

        # Финальный экран загрузки (если есть водяной знак)
        if self.watermark:
            self.show_loading(screen, total, total)
            pygame.time.delay(3000)
        self.watermark = False

    def show_loading(self, screen, current, total):
        # screen.fill((10, 10, 30))

        # Логотип – теперь 50% ширины экрана
        if self.watermark:
            wm_width = screen.get_width()
            wm_height = screen.get_height()
            wm = pygame.transform.scale(self.watermark, (wm_width, wm_height))
            screen.blit(wm, (0,0))

        # font = pygame.font.SysFont('Arial', 36)
        # text = font.render(f"Кэширование моделей: {current}/{total}", True, (255, 255, 255))
        # screen.blit(text, (screen.get_width()//2 - text.get_width()//2, screen.get_height()//1.2 + 50))
        # pygame.display.flip()

        # Текст прогресса
        font = pygame.font.SysFont('Arial', 36)
        text = font.render(f"Кэширование моделей: {current}/{total}", True, (255, 255, 255))
        screen.blit(text, (screen.get_width() // 2 - text.get_width() // 2, screen.get_height() // 1.2 + 50))

        pygame.display.flip()

    def handle_mouse(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 3:
                self.mouse_captured = not self.mouse_captured
                pygame.mouse.set_visible(not self.mouse_captured)
                pygame.event.set_grab(self.mouse_captured)
        elif event.type == pygame.MOUSEMOTION and self.mouse_captured:
            dx, dy = event.rel
            self.player.angle += dx * self.mouse_sensitivity
            # Y-shearing по вертикали мыши
            if hasattr(self.player, 'add_pitch'):
                self.player.add_pitch(dy * self.mouse_sensitivity)

    def _load_watermark(self):
        try:
            path = os.path.join(os.path.dirname(__file__), 'material', 'images', 'watermark.png')
            if os.path.exists(path):
                self.watermark = pygame.image.load(path).convert_alpha()
            else:
                # Создаём заглушку
                surf = pygame.Surface((300, 100), pygame.SRCALPHA)
                surf.fill((50, 50, 150, 200))
                font = pygame.font.SysFont('Arial', 36)
                text = font.render("Gradus RC", True, (255, 255, 255))
                surf.blit(text, (10, 10))
                self.watermark = surf
        except:
            self.watermark = None


    def start_with_menu(self, menu_example):
        self.example_menu = menu_example
        # self.use_example = True

    def start_game(self):
        if self.example_game:
            # Запускаем игру
            self.example_game.run()
        else:
            # Если нет, запускаем обычный цикл (пользовательский)
            pass

    def set_game_example(self, game_example):
        self.example_game = game_example

    def play_video(self, filepath, mode="full", x=0, y=0, width=0, height=0, loop=True, alpha_chroma=False, chroma_color=(0,255,0)):
        """
        Воспроизводит видео на экране.
        mode: "full" – полноэкранное, "angle" – в углу (левый верхний, 25% экрана), "custom" – с указанными x,y,width,height.
        alpha_chroma – если True, заменяет chroma_color на прозрачный.
        """
        if self.video_playing:
            self.stop_video()

        self.video_loop = loop
        self.video_mode = mode
        if mode == "full":
            self.video_rect = pygame.Rect(0, 0, self.width, self.height)
        elif mode == "angle":
            w = self.width // 4
            h = self.height // 4
            self.video_rect = pygame.Rect(0, 0, w, h)
        else:
            if width <= 0: width = self.width // 4
            if height <= 0: height = self.height // 4
            width = min(width, self.width)
            height = min(height, self.height)
            self.video_rect = pygame.Rect(x, y, width, height)

        self.video_playing = True
        self.video_thread = threading.Thread(target=self._video_worker, args=(filepath, alpha_chroma, chroma_color), daemon=True)
        self.video_thread.start()

    def stop_video(self):
        self.video_playing = False
        if self.video_thread and self.video_thread.is_alive():
            self.video_thread.join(timeout=0.1)
        self.video_surface = None

    def on_interactive_press(self, action_name, obj):
        """Переопределяется в игре. По умолчанию ничего."""
        pass

    def _video_worker(self, filepath, alpha_chroma, chroma_color):
        try:
            reader = imageio.get_reader(filepath, 'ffmpeg')
            fps = reader.get_meta_data().get('fps', 30)
            frame_delay = 1.0 / fps
            for frame in reader:
                if not self.video_playing:
                    break
                # Конвертируем кадр в pygame Surface
                frame_rgb = frame[:, :, :3]  # игнорируем альфа, если есть
                surf = pygame.surfarray.make_surface(frame_rgb.swapaxes(0, 1))
                if alpha_chroma:
                    # Заменяем цвет на прозрачный
                    surf = surf.convert_alpha()
                    # Пробегаем по пикселям (медленно, но для демонстрации)
                    # Оптимизация: использовать pygame.color_threshold? Можно.
                    # Для простоты используем numpy
                    import numpy as np
                    arr = pygame.surfarray.pixels3d(surf)
                    # Создаём маску для chroma_color
                    mask = (arr[:, :, 0] == chroma_color[0]) & (arr[:, :, 1] == chroma_color[1]) & (arr[:, :, 2] == chroma_color[2])
                    arr[mask] = [0,0,0]  # чёрный
                    # Делаем альфа-канал
                    surf = surf.convert_alpha()
                    arr_alpha = pygame.surfarray.pixels_alpha(surf)
                    arr_alpha[mask] = 0
                    arr_alpha[~mask] = 255
                    del arr, arr_alpha

                # Масштабируем до размера rect
                if self.video_rect.width != surf.get_width() or self.video_rect.height != surf.get_height():
                    surf = pygame.transform.scale(surf, (self.video_rect.width, self.video_rect.height))
                with self.video_lock:
                    self.video_surface = surf
                # Ждём следующий кадр
                pygame.time.delay(int(frame_delay * 1000))
            if self.video_loop and self.video_playing:
                self._video_worker(filepath, alpha_chroma, chroma_color)  # перезапустить
        except Exception as e:
            print(f"Video error: {e}")
        finally:
            self.video_playing = False

    def _draw_video(self, screen):
        if self.video_surface:
            with self.video_lock:
                surf = self.video_surface.copy()
            screen.blit(surf, self.video_rect)

    # ================ MicroAPI ================
    class MicroAPI:
        def __init__(self, engine):
            self.engine = engine

        def try_interact(self):
            e = self.engine
            px, py = e.player.pos.x, e.player.pos.y
            best = None
            best_d = 1e9
            for obj in e.interactive_objects.values():
                if not getattr(obj, 'can_press', False):  # ← can_press!
                    continue
                d = math.hypot(obj.x - px, obj.y - py)
                if d <= obj.radius and d < best_d:
                    best = obj
                    best_d = d
            if best is not None and best.on_press:
                e.on_interactive_press(best.on_press, best)
                return True
            return False

        def spawn_explosion(self, x, y, radius=120.0, damage=100.0, color=(255, 180, 60)):
            """Ручной спавн взрыва (для скриптов/трейлера)."""
            e = self.engine
            e.explosions.append(Explosion(x, y, radius, damage, color))

        def set_player_light_mode(self, mode='default', range=400.0, cone_angle=55.0):
            """
            'default'  — свет вокруг игрока (как было)
            'circle'   — конусный свет вперёд (фонарик)
            range      — длина конуса в пикселях
            cone_angle — полный угол раскрытия в градусах
            """
            import math
            e = self.engine
            if mode not in ('default', 'circle'):
                return
            e.player_light_mode = mode
            e.player_light_range = float(range)
            e.player_light_cone = math.cos(math.radians(cone_angle * 0.5))

        def set_fog(self, enabled=True, color=None, start=None, end=None,
                    floor_ceiling=None):
            e = self.engine
            e.fog_enabled = enabled
            if color is not None:        e.fog_color = color
            if start is not None:        e.fog_start = start
            if end is not None:          e.fog_end = end
            if floor_ceiling is not None: e.fog_floor_ceiling = floor_ceiling

        def disable_fog(self):
            self.engine.fog_enabled = False

        def set_rt(self, enabled=None, max_lights=None, reflections=None):
            """Управление Ray Tracing Emulator.
               enabled: True/False — включить soft shadows + reflections
               max_lights: сколько источников света учитывают тени (0..16, default 2)
               reflections: True/False — зеркала отдельно от теней
            """
            e = self.engine
            if enabled is not None:
                e.rt_enabled = bool(enabled)
            if max_lights is not None:
                try:
                    e.rt_max_lights = max(0, min(16, int(max_lights)))
                except (TypeError, ValueError):
                    pass
            if reflections is not None:
                e.rt_reflections = bool(reflections)

        def set_reflection(self, tile_x, tile_y, value):
            """Меняет reflection у материала, привязанного к клетке."""
            cell = self.get_cell(tile_x, tile_y)
            if not cell:
                return
            props = cell.get('properties', {})
            mat_name = props.get('material') or props.get('sprite')
            if not mat_name:
                return
            mat = self.engine.material_lib.get_material(mat_name)
            if mat is None:
                return
            mat.reflection = max(0.0, min(1.0, float(value)))
            if self.engine.use_gpu:
                self.engine.gpu_raycaster.mark_map_dirty()

        def set_enemy_bars(self, hp=None, ammo=None, max_distance=None):
            if hp is not None:
                self.engine.show_enemy_hp = hp
            if ammo is not None:
                self.engine.show_enemy_ammo = ammo
            if max_distance is not None:
                self.engine.enemy_bar_max_distance = max_distance

        def set_graphics_level(self, level):
            """'lite' | 'medium' | 'high' | 'ultra'"""
            self.engine.particles.set_graphics_level(level)

        def set_debris_mode(self, mode):
            """'big' | 'medium' | 'low'"""
            self.engine.particles.debris_mode = mode

        def set_wall_hp(self, tile_x, tile_y, hp=None):
            """Установить HP разрушаемой стены (или сделать её разрушаемой)."""
            cell = self.get_cell(tile_x, tile_y)
            if not cell:
                return
            if hp is None:
                hp = self.engine.default_wall_hp
            cell['properties']['destructible'] = True
            cell['properties']['hp'] = hp

        def get_wall_hp(self, tile_x, tile_y):
            cell = self.get_cell(tile_x, tile_y)
            if not cell:
                return None
            return cell['properties'].get('hp', None)

        def make_indestructible(self, tile_x, tile_y):
            cell = self.get_cell(tile_x, tile_y)
            if cell:
                cell['properties']['destructible'] = False

        def break_wall(self, tile_x, tile_y, mode=None):
            """Принудительно сломать стену с визуальным эффектом."""
            cell = self.get_cell(tile_x, tile_y)
            if not cell or cell['base_id'] not in (1, 2, 3, 4, 5):
                return False
            mat = self.engine._get_material_for_cell(cell)
            cx = tile_x * self.engine.tile_size + self.engine.tile_size // 2
            cy = tile_y * self.engine.tile_size + self.engine.tile_size // 2
            self.engine.particles.spawn_wall_break(
                cx, cy,
                texture=mat.texture if mat else None,
                color=mat.color if mat else (200, 200, 200),
                mode=mode
            )
            # сохраняем данные для восстановления
            original_id = cell['base_id']
            original_hp = cell['properties'].get('hp', self.engine.default_wall_hp)
            self.set_cell_base_id(tile_x, tile_y, 0)
            if self.engine.use_gpu:
                self.engine.gpu_raycaster.mark_map_dirty()
            return (original_id, original_hp)

        def restore_wall(self, tile_x, tile_y, delay=5.0, wall_id=3, hp=None):
            """Восстановить стену через delay секунд."""
            entry = {
                'x': tile_x, 'y': tile_y,
                'timer': delay,
                'id': wall_id,
                'hp': hp if hp is not None else self.engine.default_wall_hp
            }
            self.engine.scheduled_walls.append(entry)
            if self.engine.use_gpu:
                self.engine.gpu_raycaster.mark_map_dirty()

        def cancel_restore(self, tile_x, tile_y):
            """Отменить восстановление стены в клетке."""
            self.engine.scheduled_walls = [
                e for e in self.engine.scheduled_walls
                if not (e['x'] == tile_x and e['y'] == tile_y)
            ]

        def set_minimap(self, enabled=True, **kwargs):
            if not enabled:
                self.engine.minimap = None
                return
            self.engine.minimap = Minimap(self.engine, **kwargs)
            self.engine.minimap_enemy_hide_delay = kwargs.get('enemy_hide_delay', 5.0)

        def set_minimap_mode(self, mode):
            if self.engine.minimap:
                self.engine.minimap.mode = mode

        def set_minimap_custom(self, renderer):
            """renderer(screen, minimap) — полностью свой рендер."""
            if self.engine.minimap:
                self.engine.minimap.custom_renderer = renderer

        def set_minimap_visible_objects(self, enemies=None, billboards=None,
                                        models=None, doors=None, keys=None):
            mm = self.engine.minimap
            if not mm:
                return
            if enemies is not None:    mm.show_enemies = enemies
            if billboards is not None: mm.show_billboards = billboards
            if models is not None:     mm.show_models = models
            if doors is not None:      mm.show_doors = doors
            if keys is not None:       mm.show_keys = keys

        def minimap_show_enemy_now(self, enemy):
            """Мгновенно показать врага на карте (например, при выстреле)."""
            enemy.show_on_minimap = True
            enemy.last_seen_time = 0.0

        def hud_set_visible(self, visible=True):
            self.engine.hud.show_hud = visible

        def hud_set_crosshair(self, visible=True):
            self.engine.hud.show_crosshair = visible

        def hud_shake(self, intensity=8.0, duration=0.3):
            self.engine.hud.shake.trigger(intensity, duration)

        def hud_set_crosshair_spread(self, spread):
            self.engine.hud.crosshair_spread = spread

        def spawn_enemy(self, x=0, y=0, **kwargs):
            tex_path = kwargs.pop('sprite', None) or kwargs.pop('texture', None)
            if tex_path:
                texture = load_image(tex_path, tex_path, size=(64, 64))
                if texture is None:
                    texture = pygame.Surface((32, 32))
                    texture.fill((255, 0, 0))
                kwargs['texture'] = texture
            enemy = EnemyAI(x, y, **kwargs)
            self.engine.enemies.append(enemy)
            if enemy.sound_spawn:
                self.engine.play_sound_3d_world(enemy.sound_spawn, x, y)
            if enemy.effect_spawn:
                self.engine.effects_manager.set_effect(enemy.effect_spawn, alpha=255, intensity=0.5)
                if not enemy.effect_until_death:
                    self.engine.enemy_effect_timers[enemy.key or id(enemy)] = 2.0
            return enemy

        def spawn_enemy_by_tile(self, tile_x=0, tile_y=0, **kwargs):
            return self.spawn_enemy(tile_x * self.engine.tile_size, tile_y * self.engine.tile_size, **kwargs)

        def give_gun(self, gun):
            self.engine.gun_manager.add_gun(gun)

        def particles_set_mode(self, mode):
            """'off' | 'main' | 'optimal' | 'all'"""
            self.engine.particles.set_mode(mode)

        def particles_spawn(self, x, y, count=10, color=(255, 255, 255),
                            speed=100, life=0.5, size=3):
            import random, math
            for _ in range(count):
                ang = random.uniform(0, 2 * math.pi)
                spd = random.uniform(speed * 0.5, speed)
                self.engine.particles.particles.append(Particle(
                    x, y, math.cos(ang) * spd, math.sin(ang) * spd,
                    life=life, color=color, world_size=size, gravity=100
                ))

        def fire_current_gun(self):
            gun = self.engine.gun_manager.fire_current()
            if gun:
                angle = self.engine.player.angle
                bullet = Bullet(self.engine.player.pos.x, self.engine.player.pos.y, angle,
                                damage=gun.damage, speed=800, owner='player', explosive=gun.explosive,
                                explosion_damage=gun.explosion_damage, explosion_radius=gun.explosion_radius)
                self.engine.bullets.append(bullet)
                self.engine.hud.hit_marker(intensity=0.7)
                # вспышка у дула
                muzzle_x = self.engine.player.pos.x + math.cos(angle) * 20
                muzzle_y = self.engine.player.pos.y + math.sin(angle) * 20
                self.engine.particles.spawn_muzzle(muzzle_x, muzzle_y, angle)
                return True
            return False

        def play_sound_3d_world(self, sound_key, x=0, y=0, max_distance=500.0, doppler_factor=0.0):
            return self.engine.play_sound_3d_world(sound_key, x, y, max_distance, doppler_factor)

        def play_sound_3d_tile(self, sound_key, tile_x=0, tile_y=0, max_distance=500.0, doppler_factor=0.0):
            return self.engine.play_sound_3d_tile(sound_key, tile_x, tile_y, max_distance, doppler_factor)

        def play_sound_3d_player_camera(self, sound_key, offset_x=0, offset_y=0, max_distance=500.0, doppler_factor=0.0):
            return self.engine.play_sound_3d_player_camera(sound_key, offset_x, offset_y, max_distance, doppler_factor)

        def play_sound_3d_player(self, sound_key, offset_x=0, offset_y=0, max_distance=500.0, doppler_factor=0.0):
            return self.engine.play_sound_3d_player(sound_key, offset_x, offset_y, max_distance, doppler_factor)

        def set_effect(self, effect_type, alpha=255, intensity=1.0):
            self.engine.effects_manager.set_effect(effect_type, alpha, intensity)

        def clear_effect(self):
            self.engine.effects_manager.clear_effect()

        def _get_model_cache_key(self, path, rot_x, rot_y, rot_z, scale, color):
            """Создаёт уникальный ключ кэша для модели с заданными параметрами."""
            color_str = '_'.join(map(str, color)) if color else 'default'
            return f"{path}_{rot_x}_{rot_y}_{rot_z}_{scale}_{color_str}".replace('/', '_').replace('\\', '_')

        def set_model_rotation_y(self, model_key, rot_deg):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.rot_y = math.radians(rot_deg)

        def set_model_rotation_x(self, model_key, rot_deg):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.rot_x = math.radians(rot_deg)

        def set_model_rotation_z(self, model_key, rot_deg):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.rot_z = math.radians(rot_deg)

        def set_model_rotation(self, model_key, rot_y_deg, rot_x_deg=0, rot_z_deg=0):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.rot_y = math.radians(rot_y_deg)
                sprite.rot_x = math.radians(rot_x_deg)
                sprite.rot_z = math.radians(rot_z_deg)

        def get_cell(self, x, y):
            try:
                if 0 <= y < self.engine.map_height and 0 <= x < self.engine.map_width:
                    return self.engine.map_data[y][x]
            except:
                pass
            return None

        def set_cell_property(self, x, y, key, value):
            cell = self.get_cell(x, y)
            if cell:
                cell['properties'][key] = value

        def set_cell_base_id(self, x, y, new_id):
            cell = self.get_cell(x, y)
            if cell:
                cell['base_id'] = new_id

        def set_cell_visible(self, x, y, visible):
            self.set_cell_property(x, y, 'isvisible', visible)

        def set_cell_collision(self, x, y, collision):
            self.set_cell_property(x, y, 'addcollision', collision)

        def set_player_position(self, x, y):
            self.engine.player.pos.x = x
            self.engine.player.pos.y = y

        def set_player_angle(self, angle):
            self.engine.player.angle = angle

        def set_player_speed(self, speed):
            self.engine.player.speed = speed

        def set_player_rot_speed(self, rot_speed):
            self.engine.player.rot_speed = rot_speed

        def get_light_sources(self):
            return self.engine.light_tracer.light_sources

        def add_light(self, x, y, radius, intensity, color=(255,255,255)):
            source = LightSource(x, y, radius, intensity, color)
            self.engine.light_tracer.add_source(source)
            return source

        def remove_light(self, index):
            if 0 <= index < len(self.engine.light_tracer.light_sources):
                del self.engine.light_tracer.light_sources[index]

        def set_ambient(self, value):
            self.engine.light_tracer.ambient_light = max(0.0, min(1.0, value))

        def set_player_light(self, radius=None, intensity=None, color=None):
            lt = self.engine.light_tracer
            if radius is not None:
                lt.player_light_radius = radius
                lt.player_light_radius_sq = radius ** 2
            if intensity is not None:
                lt.player_light_intensity = intensity
            if color is not None:
                lt.player_light_color = color

        def get_sprites(self):
            return self.engine.sprite_manager.sprites

        def set_sprite_position(self, key, x, y):
            self.engine.set_sprite_position(key, x, y)

        def set_sprite_visible(self, key, visible):
            self.engine.set_sprite_visible(key, visible)

        def remove_sprite(self, key):
            self.engine.sprite_manager.remove_by_key(key)

        # ---- Управление дверями и ключами ----
        def open_door(self, door_id):
            if door_id in self.engine.doors:
                self.engine.doors[door_id]['open'] = True
                x, y = self.engine.doors[door_id]['pos']
                self.set_cell_property(x, y, 'open', True)
                sprite_key = self.engine.doors[door_id].get('sprite_key')
                if sprite_key:
                    self.engine.set_sprite_visible(sprite_key, False)
                if self.engine.use_gpu:
                    self.engine.gpu_raycaster.mark_map_dirty()

        def close_door(self, door_id):
            if door_id in self.engine.doors:
                self.engine.doors[door_id]['open'] = False
                x, y = self.engine.doors[door_id]['pos']
                self.set_cell_property(x, y, 'open', False)
                sprite_key = self.engine.doors[door_id].get('sprite_key')
                if sprite_key:
                    self.engine.set_sprite_visible(sprite_key, True)
                if self.engine.use_gpu:
                    self.engine.gpu_raycaster.mark_map_dirty()

        def is_door_open(self, door_id):
            return self.engine.doors.get(door_id, {}).get('open', False)

        def collect_key(self, key_id):
            if key_id in self.engine.keys:
                self.engine.keys[key_id]['collected'] = True
                sprite_key = self.engine.keys[key_id].get('sprite_key')
                if sprite_key:
                    self.engine.sprite_manager.remove_by_key(sprite_key)

        def has_key(self, key_id):
            return self.engine.keys.get(key_id, {}).get('collected', False)

        # ---- Управление моделями (ID=6) ----
        def get_model(self, model_key):
            """Возвращает спрайт модели по ключу."""
            return self.engine.sprite_manager.get_by_key(model_key)

        def set_model_position(self, model_key, x, y):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.x = x
                sprite.y = y

        def set_model_rotation(self, model_key, rotation_deg):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.rotation = math.radians(rotation_deg)

        def set_model_visible(self, model_key, visible):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.visible = visible

        # Для коллизии моделей – пока заглушка, можно добавить позже
        def set_model_collision(self, model_key, collision):
            # Временно просто печатаем, что функция вызывается
            print(f"set_model_collision called for {model_key} with {collision} (not implemented yet)")

    #################### PhysicsAPI ####################
    class PhysicsAPI:
        """
        Заготовка под будущее обновление.
        Все функции безопасны — ничего не сломают если не пользоваться.
        """

        def __init__(self, engine):
            self.engine = engine
            self.bodies = []  # список объектов с .x, .y, .vx, .vy, .mass
            self.gravity = 0.0

        # 1) Настройка
        def set_timestep(self, dt):
            """Секунд на шаг физики. Рекомендуется 1/30 или 1/60."""
            self.engine.fixed_physics_dt = float(dt)

        def set_gravity(self, g):
            """Гравитация по Y (пиксели/сек²)."""
            self.gravity = float(g)

        # 2) Регистрация тела
        def add_body(self, body):
            """body: любой объект с .x, .y, .vx, .vy, .mass. Возвращает его."""
            if not hasattr(body, 'vx'): body.vx = 0.0
            if not hasattr(body, 'vy'): body.vy = 0.0
            if not hasattr(body, 'mass'): body.mass = 1.0
            self.bodies.append(body)
            return body

        def remove_body(self, body):
            if body in self.bodies:
                self.bodies.remove(body)

        # 3) Импульс
        def apply_impulse(self, body, ix, iy):
            """Мгновенный импульс (км/с), делится на массу."""
            body.vx += ix / max(body.mass, 1e-3)
            body.vy += iy / max(body.mass, 1e-3)

        # 4) Запрос в круге
        def query_circle(self, x, y, r):
            """Все тела в радиусе (пиксели)."""
            r2 = r * r
            out = []
            for b in self.bodies:
                dx = b.x - x
                dy = b.y - y
                if dx * dx + dy * dy <= r2:
                    out.append(b)
            return out

        # 5) Луч
        def raycast(self, x, y, dx, dy, max_dist, ignore=None):
            """
            Возвращает (hit_body, dist) или (None, max_dist).
            Простой ray-vs-circle.
            """
            import math
            norm = math.hypot(dx, dy) or 1.0
            dx /= norm;
            dy /= norm
            best = None;
            best_d = max_dist
            for b in self.bodies:
                if b is ignore: continue
                bx = b.x - x;
                by = b.y - y
                t = bx * dx + by * dy
                if t < 0 or t > best_d: continue
                perp2 = bx * bx + by * by - t * t
                r = getattr(b, 'radius', 8.0)
                if perp2 < r * r:
                    best_d = t
                    best = b
            return best, best_d

        def add_interactive(self, obj):
            """Регистрирует InteractiveObject в мире."""
            self.engine.interactive_objects[obj.key] = obj

        def get_object(self, key):
            return self.engine.interactive_objects.get(key)

        def push_object(self, key_or_obj, ix, iy):
            obj = key_or_obj if hasattr(key_or_obj, 'apply_impulse') else self.get_object(key_or_obj)
            if obj:
                obj.apply_impulse(ix, iy)

        def set_gravity_for(self, key, gravity):
            obj = self.get_object(key)
            if obj:
                obj.gravity_scale = float(gravity)

        def set_ceiling_collision(self, enabled):
            self.engine.ceiling_collision = bool(enabled)

        def query_objects_in_circle(self, x, y, r):
            r2 = r * r
            out = []
            for obj in self.engine.interactive_objects.values():
                dx = obj.x - x
                dy = obj.y - y
                if dx * dx + dy * dy <= r2:
                    out.append(obj)
            return out

        def _step(self, dt):
            """Вызывается из Engine.update() раз в fixed-step."""
            if not self.bodies:
                return
            for b in self.bodies:
                b.vy += self.gravity * dt
                nx = b.x + b.vx * dt
                ny = b.y + b.vy * dt
                if self.engine._is_walkable(nx, ny):
                    b.x = nx;
                    b.y = ny
                else:
                    b.vx *= -0.3
                    b.vy *= -0.3
                    b.x += b.vx * dt
                    b.y += b.vy * dt

    # ================ Основные методы ================
    def deactivate_trigger(self, key):
        self.inactive_triggers.add(key)

    def activate_trigger(self, key):
        self.inactive_triggers.discard(key)

    def is_trigger_active(self, key):
        return key not in self.inactive_triggers

    def add_sprite(self, sprite):
        self.sprite_manager.add(sprite)

    def get_sprite(self, key):
        return self.sprite_manager.get_by_key(key)

    def set_sprite_visible(self, key, visible):
        sprite = self.sprite_manager.get_by_key(key)
        if sprite:
            sprite.visible = visible

    def set_sprite_position(self, key, x, y):
        sprite = self.sprite_manager.get_by_key(key)
        if sprite:
            sprite.x = x
            sprite.y = y

    def show_message(self, text, duration=2.0, rgb=(30,30,30), font="Arial", size=36):
        self.message_text = text
        self.message_timer = duration
        self.message_duration = duration
        self.text_color = rgb
        self.font = pygame.font.SysFont(font, size)

    def _get_default_texture(self, name):
        base_dir = os.path.dirname(__file__)
        path = os.path.join(base_dir, 'material', 'images', name)
        try:
            return pygame.image.load(path).convert_alpha()
        except:
            return None

    def load_level(self, index):
        try:
            if index < 0 or index >= len(self.levels):
                return
            raw_map = self.levels[index]
            parser = MapParser()
            layers = parser.parse_layers(raw_map)

            self.map_data = layers.get('collision', [])
            if not self.map_data:
                self.map_data = []
            self.map_height = len(self.map_data)
            self.map_width = len(self.map_data[0]) if self.map_height > 0 else 0

            self.raycaster.map_data = self.map_data
            self.raycaster.update_dimensions()
            self.light_tracer.map_data = self.map_data

            params = layers.get('_params', {})
            fog_color = params.get('fog_color', None)
            if fog_color:
                self.fog_color = self._hex_to_rgb(fog_color)
                self.fog_enabled = True
            self.fog_start = float(params.get('fog_start', self.fog_start))
            self.fog_end = float(params.get('fog_end', self.fog_end))
            self.spawn = params.get('spawn', None)
            self.floor_color = params.get('floor_color', None)
            self.ceiling_color = params.get('ceiling_color', None)
            try:
                self.ambient = float(params.get('ambient', 0.03))
            except:
                self.ambient = 0.03
            self.light_tracer.ambient_light = self.ambient
            use_lt_val = params.get('use_lt', 'true')
            if isinstance(use_lt_val, (list, tuple)):
                use_lt_val = use_lt_val[0] if use_lt_val else 'true'
            self.use_lt = str(use_lt_val).lower() in ('true', '1', 'yes')
            if self.use_gpu and self.gpu_raycaster is not None:
                try:
                    self.gpu_raycaster.setup_level(
                        map_data=self.map_data,
                        tile_size=self.tile_size,
                        material_lib=self.material_lib,
                        floor_texture=self.floor_texture,
                        ceiling_texture=self.ceiling_texture,
                        floor_color=self._hex_to_rgb(self.floor_color) if self.floor_color else (40, 30, 20),
                        ceiling_color=self._hex_to_rgb(self.ceiling_color) if self.ceiling_color else (20, 20, 40),
                    )
                except Exception as e:
                    print(f"[GPU] setup_level failed: {e}")
                    self.use_gpu = False

            self.doors.clear()
            self.keys.clear()
            self.model_data.clear()
            self.decals.clear()
            self.particles.particles.clear()
            self.particles.debris_particles.clear()
            self.bullets.clear()

            self.light_tracer.light_sources.clear()
            lights_str = params.get('lights', '')
            if lights_str:
                for light_str in lights_str.split(';'):
                    parts = light_str.split(',')
                    if len(parts) >= 4:
                        try:
                            x = float(parts[0]) * self.tile_size
                            y = float(parts[1]) * self.tile_size
                            intensity = float(parts[2])
                            radius = float(parts[3])
                            color = (255, 255, 255)
                            if len(parts) >= 7:
                                r = int(parts[4])
                                g = int(parts[5])
                                b = int(parts[6])
                                color = (r, g, b)
                            self.light_tracer.add_source(LightSource(x, y, radius, intensity, color))
                        except:
                            pass

            # Загрузка билбордов
            bilboards_str = params.get('bilboards', '')
            if bilboards_str:
                for b_str in bilboards_str.split(';'):
                    parts = b_str.split(',')
                    if len(parts) >= 3:
                        try:
                            x = float(parts[0]) * self.tile_size
                            y = float(parts[1]) * self.tile_size
                            key = parts[2].strip()
                            existing = self.sprite_manager.get_by_key(key)
                            if existing:
                                existing.x = x
                                existing.y = y
                            else:
                                tex = load_image(key, f'textures/{key}.png', size=(30,30), default_color=(255,0,255))
                                sprite = Sprite(x, y, tex, key=key)
                                self.sprite_manager.add(sprite)
                        except:
                            pass

            # Обработка ID=7 (двери и ключи) и ID=6 (модели)
            for y, row in enumerate(self.map_data):
                for x, cell in enumerate(row):
                    if cell['base_id'] < 6:
                        prop = cell.get('properties', {})
                        enemy_str = prop.get('enemy')
                        if enemy_str:
                            self._spawn_enemy_from_tag(
                                enemy_str, x, y,
                                prop.get('sprite', prop.get('texture', self.enemy_sprite)),
                                extra_props=prop)
                    if cell['base_id'] == 7:
                        props = cell.get('properties', {})
                        obj_type = props.get('type', 'door')
                        if obj_type == 'door':
                            door_id = props.get('id', f'door_{x}_{y}')
                            cell['properties']['isvisible'] = False
                            if 'height' not in props:
                                cell['properties']['height'] = 0.9
                            if 'material' not in props:
                                cell['properties']['material'] = 'concrete'
                            sprite_key = f"door_sprite_{door_id}"
                            tex_path = props.get('texture', None)
                            if tex_path:
                                try:
                                    tex = pygame.image.load(tex_path).convert_alpha()
                                except:
                                    tex = self._get_default_texture('door.png')
                            else:
                                tex = self._get_default_texture('door.png')
                            if tex is None:
                                tex = pygame.Surface((256,256))
                                tex.fill((150, 100, 50))
                            sprite_x = x * self.tile_size + self.tile_size/2
                            sprite_y = y * self.tile_size + self.tile_size/2
                            sprite = Sprite(sprite_x, sprite_y, tex, key=sprite_key)
                            self.add_sprite(sprite)

                            self.doors[door_id] = {
                                'open': False,
                                'pos': (x, y),
                                'linked_keys': [],
                                'sprite_key': sprite_key
                            }
                            cell['properties']['open'] = False

                        elif obj_type == 'key':
                            key_id = props.get('id', f'key_{x}_{y}')
                            sprite_key = f"key_sprite_{key_id}"
                            tex_path = props.get('texture', None)
                            if tex_path:
                                try:
                                    tex = pygame.image.load(tex_path).convert_alpha()
                                except:
                                    tex = self._get_default_texture('key.png')
                            else:
                                tex = self._get_default_texture('key.png')
                            if tex is None:
                                tex = pygame.Surface((32,32))
                                tex.fill((255, 215, 0))
                            sprite_x = x * self.tile_size + self.tile_size/2
                            sprite_y = y * self.tile_size + self.tile_size/2
                            sprite = Sprite(sprite_x, sprite_y, tex, key=sprite_key)
                            self.add_sprite(sprite)

                            self.keys[key_id] = {
                                'collected': False,
                                'pos': (x, y),
                                'sprite_key': sprite_key,
                                'linked_doors': []
                            }



                    elif cell['base_id'] == 6:
                        props = cell.get('properties', {})
                        if props.get("isvisible", True):
                            path = props.get('path', '')
                            anim_str = props.get('anim', '')
                            anim_speed = float(props.get('anim_speed', 0.5))  # секунд на кадр
                            if path or anim_str:
                                anim_paths = [p.strip() for p in anim_str.split(',')] if anim_str else []
                                if path:
                                    anim_paths.insert(0, path)  # первая модель – основная
                                rotation = float(props.get('rotation', 0))
                                rot_y = float(props.get('roty', rotation))
                                rot_x = float(props.get('rotx', 0))
                                rot_z = float(props.get('rotz', 0))
                                scale = float(props.get('scale', 1.0))
                                pos_x = x * self.tile_size + self.tile_size / 2
                                pos_y = y * self.tile_size + self.tile_size / 2
                                color_hex = props.get('color', None)
                                color = self._hex_to_rgb(color_hex) if color_hex else (200, 100, 100)
                                self.model_data.append({
                                    'path': path,
                                    'anim_paths': anim_paths,
                                    'anim_speed': anim_speed,
                                    'pos': (pos_x, pos_y),
                                    'rot_y': rot_y,
                                    'rot_x': rot_x,
                                    'rot_z': rot_z,
                                    'scale': scale,
                                    'color': color,
                                    'cell_x': x,
                                    'cell_y': y,
                                    'key': f"model_{x}_{y}"
                                })
                                # Создаём InteractiveObject если у клетки есть свойства
                                props = cell.get('properties', {})
                                if props.get('interactive', False) or props.get('pushable', False):
                                # if props.get('pushable', False):
                                    obj_key = f"obj_{x}_{y}"
                                    world_x = x * self.tile_size + self.tile_size / 2
                                    world_y = y * self.tile_size + self.tile_size / 2
                                    from .object.interactive import InteractiveObject
                                    # ОБНУЛЯЕМ клетку — коллизия пойдёт через сам объект, а не через map
                                    cell['base_id'] = 0
                                    self.interactive_objects[obj_key] = InteractiveObject(
                                        world_x, world_y, obj_key, props, cell,
                                        sprite_key=f"model_{x}_{y}")
                                    # в Engine.load_level после создания InteractiveObject
                                    print(f"[IO] {obj_key} pushable={props.get('pushable')} interactive={props.get('interactive')}")
                                print(f"Model data: {self.model_data}")
            # Связываем ключи и двери
            for key_id, key_data in self.keys.items():
                kx, ky = key_data['pos']
                cell = self.map_data[ky][kx]
                link = cell.get('properties', {}).get('link', None)
                if link and link in self.doors:
                    self.doors[link]['linked_keys'].append(key_id)
                    self.keys[key_id]['linked_doors'].append(link)

            self.inactive_triggers.clear()
            self.texture_cache.clear()

            # Удаляем старые спрайты моделей (с ключом "model_*")
            for sprite in self.sprite_manager.sprites[:]:
                if sprite.key and sprite.key.startswith("model_"):
                    self.sprite_manager.remove_by_key(sprite.key)

            # Загружаем модели для текущего уровня
            if self.watermark == False: self._process_models()
        except Exception as e:
            print(f"Error in Engine.load_level: {e}")
            raise

    def _spawn_enemy_from_tag(self, enemy_str, tile_x, tile_y, imag, extra_props=None):
        # Отладка — покажет что реально приходит
        print(f"[AI-DEBUG] enemy_str={enemy_str!r}")
        print(f"[AI-DEBUG] extra_props keys={list(extra_props.keys()) if extra_props else None}")

        params = {}
        sep = ';' if ';' in enemy_str else ','
        for part in enemy_str.split(sep):
            part = part.strip()
            if not part:
                continue
            # Поддерживаем оба разделителя: = и :
            if '=' in part and ':' in part:
                part = part.replace(':', '=')
            if '=' in part:
                key, value = part.split('=', 1)
            elif ':' in part:
                key, value = part.split(':', 1)
            else:
                continue
            key = key.strip().lower()
            value = value.strip()
            if value.lower() == 'true':
                value = True
            elif value.lower() == 'false':
                value = False
            else:
                try:
                    value = float(value) if '.' in value else int(value)
                except ValueError:
                    pass
            params[key] = value

        # Подтягиваем из props клетки (парсер мог раскидать по отдельным ключам)
        if extra_props:
            for k in ('hp', 'aim', 'shoot_delay', 'shoot_intensity',
                      'intensity_mode', 'attack_type', 'detect_radius',
                      'attack_radius', 'speed', 'sprite', 'texture',
                      'sound_spawn', 'effect_spawn', 'effect_until_death',
                      'key'):
                if k in extra_props and k not in params:
                    v = extra_props[k]
                    if isinstance(v, str):
                        if v.lower() == 'true':
                            v = True
                        elif v.lower() == 'false':
                            v = False
                        else:
                            try:
                                v = float(v) if '.' in v else int(v)
                            except ValueError:
                                pass
                    params[k] = v

        print(f"[AI-DEBUG] parsed params={params}")

        enemy_type = params.get('type', 'static')
        hp = float(params.get('hp', 100))
        aim = float(params.get('aim', 10))
        shoot_delay = float(params.get('shoot_delay', 1.0))
        shoot_intensity = float(params.get('shoot_intensity', 0))
        intensity_mode = params.get('intensity_mode', 'fast')
        attack_type = params.get('attack_type', 'ranged')
        detect_radius = float(params.get('detect_radius', 5))
        attack_radius = float(params.get('attack_radius', 3))
        speed = float(params.get('speed', 50))
        key = params.get('key', f"enemy_{tile_x}_{tile_y}")
        tex_path = params.get('texture', params.get('sprite', imag))
        texture = load_image(tex_path, tex_path, size=(64, 64))
        if texture is None:
            texture = pygame.Surface((32, 32))
            texture.fill((255, 0, 0))

        enemy = EnemyAI(
            x=tile_x * self.tile_size, y=tile_y * self.tile_size,
            hp=hp, aim=aim, shoot_delay=shoot_delay,
            shoot_intensity=shoot_intensity,
            intensity_mode=intensity_mode,
            enemy_type=enemy_type, attack_type=attack_type,
            detect_radius=detect_radius, attack_radius=attack_radius,
            speed=speed, key=key, texture=texture,
            sound_spawn=params.get('sound_spawn'),
            effect_spawn=params.get('effect_spawn'),
            effect_until_death=params.get('effect_until_death', False)
        )
        self.enemies.append(enemy)

    def pre_cache_all_models(self):
        """Генерирует спрайты для всех моделей из всех уровней заранее (в фоне)."""
        for level in self.levels:
            parser = MapParser()
            layers = parser.parse_layers(level)
            map_data = layers.get('collision', [])
            for row in map_data:
                for cell in row:
                    if cell['base_id'] == 6:
                        props = cell.get('properties', {})
                        path = props.get('path')
                        if not path:
                            continue
                        rot_x = float(props.get('rotx', 0))
                        rot_y = float(props.get('roty', 0))
                        rot_z = float(props.get('rotz', 0))
                        scale = float(props.get('scale', 1.0))
                        color_hex = props.get('color')
                        color = self._hex_to_rgb(color_hex) if color_hex else (200, 100, 100)
                        cache_key = self._get_model_cache_key(path, rot_x, rot_y, rot_z, scale, color)
                        with self.model_cache_lock:
                            exists = cache_key in self.global_model_cache
                        if not exists:
                            self._generate_and_store_model(cache_key, path, rot_x, rot_y, rot_z, scale, color)

    def _generate_and_store_model(self, cache_key, path, rot_x, rot_y, rot_z, scale, color):
        try:
            # Проверяем, не появилась ли модель в кэше от другого потока
            with self.model_generate_lock:
                if cache_key in self.global_model_cache:
                    return
                sprites = obj_to_sprites(path, num_angles=128, sprite_size=(512, 512),
                   scale=scale, color=color,
                   model_rot_x=rot_x, model_rot_y=rot_y, model_rot_z=rot_z)
                if sprites:
                    self.global_model_cache[cache_key] = sprites
                    self._save_sprites_to_cache(cache_key, sprites)
        except Exception as e:
            print(f"Model pre-cache failed for {path}: {e}")

    def _cache_models(self):
        try:
            cache_dir = "cache"
            if not os.path.exists(cache_dir):
                os.makedirs(cache_dir)

            for data in self.model_data:
                cache_key = self._get_model_cache_key(
                    data['path'],
                    data.get('rot_x', 0),
                    data.get('rot_y', 0),
                    data.get('rot_z', 0),
                    data['scale'],
                    data['color']
                )
                model_cache_dir = os.path.join(cache_dir, cache_key)
                if os.path.exists(model_cache_dir):
                    existing = [f for f in os.listdir(model_cache_dir) if f.endswith('.png')]
                    if len(existing) >= 64:
                        continue
                if not os.path.exists(model_cache_dir):
                    os.makedirs(model_cache_dir)

                sprites = obj_to_sprites(
                    data['path'],
                    num_angles=128,
                    sprite_size=(512, 512),
                    scale=data['scale'],
                    color=data['color'],
                    model_rot_x=data.get('rot_x', 0),
                    model_rot_y=data.get('rot_y', 0),
                    model_rot_z=data.get('rot_z', 0)
                )
                if not sprites:
                    continue
                for i, surf in enumerate(sprites):
                    pygame.image.save(surf, os.path.join(model_cache_dir, f"frame_{i:02d}.png"))
        except Exception as e:
            print(f"Error in Engine._cache_models: {e}")

    def _load_sprites_from_cache(self, cache_key, num_frames=64):
        try:
            cache_dir = os.path.join("cache", cache_key)
            sprites = []
            for i in range(num_frames):
                path = os.path.join(cache_dir, f"frame_{i:02d}.png")
                if os.path.exists(path):
                    try:
                        surf = pygame.image.load(path).convert_alpha()
                        sprites.append(surf)
                    except:
                        sprites.append(None)
            return [s for s in sprites if s is not None]
        except Exception as e:
            print(f"Error in Engine._load_sprites_from_cache: {e}")
            return []

    def _save_sprites_to_cache(self, cache_key, sprites):
        """Сохраняет спрайты в файловый кэш."""
        try:
            cache_dir = os.path.join("cache", cache_key)
            if not os.path.exists(cache_dir):
                os.makedirs(cache_dir)
            for i, surf in enumerate(sprites):
                pygame.image.save(surf, os.path.join(cache_dir, f"frame_{i:02d}.png"))
        except Exception as e:
            print(f"Error saving sprites to cache: {e}")

    def _process_models(self):
        try:
            for data in self.model_data:
                path = data['path']
                rot_x = data.get('rot_x', 0)
                rot_y = data.get('rot_y', 0)
                rot_z = data.get('rot_z', 0)
                scale = data.get('scale', 1.0)
                color = data.get('color', (200, 100, 100))

                cache_key = self._get_model_cache_key(path, rot_x, rot_y, rot_z, scale, color)

                sprites = None

                # 1. Проверяем глобальный кэш в памяти (с блокировкой)
                with self.model_cache_lock:
                    sprites = self.global_model_cache.get(cache_key)

                # 2. Если нет в памяти, пробуем загрузить из файлового кэша
                if not sprites:
                    sprites = self._load_sprites_from_cache(cache_key, num_frames=64)

                # 3. Если нет нигде, генерируем синхронно (текущий поток)
                if not sprites:
                    with self.model_generate_lock:
                        # Повторно проверяем, вдруг другой поток уже сгенерировал
                        with self.model_cache_lock:
                            sprites = self.global_model_cache.get(cache_key)
                        if not sprites:
                            sprites = obj_to_sprites(
                                path,
                                num_angles=128,
                                sprite_size=(512, 512),
                                scale=scale,
                                color=color,
                                model_rot_x=rot_x,
                                model_rot_y=rot_y,
                                model_rot_z=rot_z
                            )
                            if sprites:
                                self._save_sprites_to_cache(cache_key, sprites)
                                with self.model_cache_lock:
                                    self.global_model_cache[cache_key] = sprites

                if sprites:
                    model_sprite = AnimatedModelSprite(
                        data['pos'][0],
                        data['pos'][1],
                        [sprites],
                        key=data['key'],
                        rot_y=math.radians(rot_y),
                        rot_x=math.radians(rot_x),
                        rot_z=math.radians(rot_z),
                        anim_speed=data.get('anim_speed', 0.5)
                    )
                    self.sprite_manager.add(model_sprite)
                else:
                    print(f"Failed to get sprites for {path}")
            self.model_data.clear()
        except Exception as e:
            print(f"Error in Engine._process_models: {e}")

    def _find_spawn_point(self):
        if self.spawn:
            try:
                parts = self.spawn.split(',')
                x = float(parts[0]) * self.tile_size + self.tile_size/2
                y = float(parts[1]) * self.tile_size + self.tile_size/2
                return x, y
            except:
                pass
        if not self.map_data:
            return 0, 0
        for y, row in enumerate(self.map_data):
            for x, cell in enumerate(row):
                if cell['base_id'] == 0:
                    return x * self.tile_size + self.tile_size/2, \
                           y * self.tile_size + self.tile_size/2
        return 0, 0

    def set_overlay(self, texture_path, alpha=255):
        try:
            surf = pygame.image.load(texture_path).convert_alpha()
            self.overlay_texture = surf
            self.overlay_alpha = max(0, min(255, alpha))
        except:
            self.overlay_texture = None

    def clear_overlay(self):
        self.overlay_texture = None

    def play_sound(self, sound_key):
        self.sound_manager.play_sound(sound_key)

    def set_fullscreen_effect(self, texture_path, duration=2.0):
        try:
            self.effect_texture = pygame.image.load(texture_path).convert_alpha()
            self.effect_timer = duration
        except:
            self.effect_texture = None

    def update(self, dt, keys):
        try:
            # Восстановление сломанных стен
            if self.scheduled_walls:
                for entry in self.scheduled_walls[:]:
                    entry['timer'] -= dt
                    if entry['timer'] <= 0:
                        x, y = entry['x'], entry['y']
                        if 0 <= y < self.map_height and 0 <= x < self.map_width:
                            cell = self.map_data[y][x]
                            cell['base_id'] = entry['id']
                            if entry.get('material'):
                                cell['properties']['material'] = entry['material']
                            if entry.get('hp') is not None:
                                cell['properties']['hp'] = entry['hp']
                                cell['properties']['destructible'] = True
                            # Убираем декали этой клетки
                            self.decals.remove_by_cell(x, y)
                        if self.use_gpu:
                            self.gpu_raycaster.mark_map_dirty()
                        self.scheduled_walls.remove(entry)

            # Обновляем взрывы
            for ex in self.explosions[:]:
                if not ex.damage_applied:
                    ex.apply_damage(self)
                    ex.spawn_particles(self.particles)
                    # Динамический свет на время жизни
                    # При RTE — яркая вспышка, без RTE — обычный свет
                    flash_intensity = 8.0 if self.rt_enabled else 1.5
                    flash_color = (255, 240, 180)  # тёплый белый
                    self.transient_lights.append(
                        [ex.x, ex.y, ex.light_radius * (1.5 if self.rt_enabled else 1.0),
                         flash_intensity, flash_color, ex.max_age]
                    )
                if not ex.update(dt):
                    self.explosions.remove(ex)

            # Обновляем transient lights (уменьшаем ttl)
            for tl in self.transient_lights[:]:
                tl[5] -= dt
                if tl[5] <= 0:
                    self.transient_lights.remove(tl)
            self.physics._step(dt)
            self.player.update(keys, dt)
            self.sprite_manager.update(dt)

            for snd in self.active_3d_sounds:
                snd.update((self.player.pos.x, self.player.pos.y), self.player.angle)
            # if self.video_cap:
            #     ret, frame = self.video_cap.read()
            #     if not ret:
            #         if self.video_loop:
            #             self.video_cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            #             ret, frame = self.video_cap.read()
            #         else:
            #             self.stop_video()
            #             return
            #     # Конвертируем BGR в RGB и в Surface
            #     frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            #     frame = np.rot90(frame)  # если нужно
            #     surf = pygame.surfarray.make_surface(frame)
            #     surf.set_alpha(self.video_alpha)
            #     self.video_frame = surf

            if self.effect_timer > 0:
                self.effect_timer -= dt
                if self.effect_timer <= 0:
                    self.effect_texture = None

            if self.message_timer > 0:
                self.message_timer -= dt
                if self.message_timer <= 0:
                    self.message_text = ""


            self.gun_manager.update(dt)
            self.update_enemies(dt)
            self.update_bullets(dt)
            self.particles.update(dt)
            self.decals.update(dt)

            new_x = self.player.pos.x + self.player.vel.x * dt
            new_y = self.player.pos.y + self.player.vel.y * dt

            final_x = new_x
            final_y = new_y
            PLAYER_R = 14

            for obj in self.interactive_objects.values():
                if not obj.alive:
                    continue

                dx = obj.x - final_x
                dy = obj.y - final_y
                d = math.hypot(dx, dy)
                min_dist = obj.radius + PLAYER_R

                if d < min_dist and d > 0.01:
                    # Толкаем ТОЛЬКО если pushable:true
                    if obj.pushable:
                        mass_factor = min(1.0, 20.0 / max(obj.mass, 1.0))
                        push_speed = 300.0 * mass_factor
                        obj.vx = (dx / d) * push_speed
                        obj.vy = (dy / d) * push_speed

                    # В любом случае — выталкиваем игрока наружу
                    final_x = obj.x - (dx / d) * min_dist
                    final_y = obj.y - (dy / d) * min_dist

            # Проверка стен (как было)
            if self._is_walkable(final_x, final_y):
                self.player.pos.x = final_x
                self.player.pos.y = final_y
            else:
                map_x = int(new_x // self.tile_size)
                map_y = int(new_y // self.tile_size)
                if 0 <= map_y < self.map_height and 0 <= map_x < self.map_width:
                    cell = self.map_data[map_y][map_x]
                    if cell['base_id'] == 7:
                        props = cell.get('properties', {})
                        if props.get('type') == 'door':
                            door_id = props.get('id', None)
                            if door_id and not self.doors.get(door_id, {}).get('open', False):
                                self.on_door_blocked(cell)

            cur_map_x = int(self.player.pos.x // self.tile_size)
            cur_map_y = int(self.player.pos.y // self.tile_size)

            if 0 <= cur_map_y < self.map_height and 0 <= cur_map_x < self.map_width:
                cell = self.map_data[cur_map_y][cur_map_x]
                base_id = cell['base_id']

                if base_id == 9:
                    target = cell.get('properties', {}).get('level', None)
                    if target is not None and target != self.current_level:
                        print(f"Teleport to level {target}")
                        self.current_level = target
                        self.load_level(self.current_level)
                        sx, sy = self._find_spawn_point()
                        self.player.pos.x = sx
                        self.player.pos.y = sy

                if base_id == 8:
                    trigger_id = cell.get('properties', {}).get('id', None)
                    if trigger_id is not None:
                        key = ('id', trigger_id)
                    else:
                        key = ('pos', cur_map_x, cur_map_y)
                    if self.is_trigger_active(key):
                        self.on_trigger(cell)

                if base_id == 7:
                    props = cell.get('properties', {})
                    if props.get('type') == 'key':
                        key_id = props.get('id', None)
                        if key_id and key_id in self.keys:
                            if not self.keys[key_id]['collected']:
                                self.keys[key_id]['collected'] = True
                                sprite_key = self.keys[key_id].get('sprite_key')
                                if sprite_key:
                                    self.sprite_manager.remove_by_key(sprite_key)
                                for door_id in self.keys[key_id]['linked_doors']:
                                    self.api.open_door(door_id)
                                self.on_key_pickup(key_id)

            self.light_tracer.update_player_light(self.player.pos, self.player.angle)

            # Обновление интерактивных объектов
            for obj in list(self.interactive_objects.values()):
                obj.update(dt, self)
                if not obj.alive:
                    del self.interactive_objects[obj.key]

            # Толкание игроком
            for obj in self.interactive_objects.values():
                if not obj.pushable:
                    continue
                dx = obj.x - self.player.pos.x
                dy = obj.y - self.player.pos.y
                d = math.hypot(dx, dy)
                if d < obj.radius + 16 and d > 0.01:
                    # Отталкиваем по вектору от игрока
                    push_speed = self.player.speed  # скорость игрока
                    obj.vx += (dx / d) * push_speed * 0.5
                    obj.vy += (dy / d) * push_speed * 0.5

            self.hud.update(dt)
        except Exception as e:
            print(f"Error in Engine.update: {e}")

    def on_trigger(self, cell):
        pass

    def on_key_pickup(self, key_id):
        pass

    def on_door_blocked(self, cell):
        self.show_message("Нужен ключ", 2.0)

    def _run_raycaster_thread(self, pos, angle):
        try:
            results = self.raycaster.cast_rays(pos, angle)
            with self._ray_lock:
                self._ray_results = results
        except Exception as e:
            print(f"Raycaster async error: {e}")

    def _draw_overlays(self, screen):
        if self.overlay_texture is not None:
            overlay = self.overlay_texture.copy()
            overlay.set_alpha(self.overlay_alpha)
            screen.blit(overlay, (0, 0))

        if self.message_text:
            if self.font is None:
                self.font = pygame.font.SysFont('Arial', 36)
            lines = self.message_text.split('\n')
            y_offset = self.screen_height // 1.3 - (len(lines) * (self.font.get_height() + 5)) // 2
            for line in lines:
                text_surface = self.font.render(line, True, (255, 255, 255))
                screen.blit(text_surface, (self.screen_width // 2 - text_surface.get_width() // 2, y_offset))
                y_offset += text_surface.get_height() + 5

        if self.show_fps and not self.use_example:
            fps = self.clock.get_fps()
            if self.use_raycaster_async:
                fps = fps * 1.07
            fps_text = self.font_fps.render(f"FPS: {int(fps)}", True, (255, 255, 0))
            screen.blit(fps_text, (self.screen_width - 120, self.screen_height // 10))

        if hasattr(self, 'effects_manager'):
            self.effects_manager.apply(screen)
        if self.minimap is not None:
            self.minimap.draw(screen)
        self.hud.draw(screen)

    def _compute_pitch_offset(self):
        if not self.y_shearing_enabled:
            return 0
        offset = -int(self.player.pitch * self.y_shearing_pixels_per_rad)
        limit = self.height // 2 - 1
        return max(-limit, min(limit, offset))
    def render(self, screen):
        try:
            self._pitch_offset_cache = self._compute_pitch_offset()
            if self.mcfi_level > 0:
                N = self.mcfi_level

                if self._mcfi_step == 0:
                    # === РЕАЛЬНЫЙ КАДР (полный рендер) ===
                    if self.use_gpu:
                        gpu_surf = self.gpu_raycaster.render(
                            player_pos=self.player.pos,
                            player_angle=self.player.angle,
                            fov=self.fov,
                            max_depth=self.max_depth,
                            pitch_offset=self._pitch_offset_cache,
                            lights=self.light_tracer.light_sources,
                            ambient=self.ambient,
                            fog_enabled=self.fog_enabled,
                            fog_color=self.fog_color,
                            fog_start=self.fog_start,
                            fog_end=self.fog_end,
                            rt_enabled=self.rt_enabled,
                            rt_max_lights=self.rt_max_lights,
                            rt_reflections=self.rt_reflections,
                            map_data_ref=self.map_data,
                            proj_coeff=self.proj_coeff,  # ← ЭТУ
                            material_lib=self.material_lib,
                            sprites=self.sprite_manager.sprites + self.enemies + self.decals.decals,
                            player_light_mode=self.player_light_mode,
                            player_light_range=self.player_light_range,
                            player_light_cone=self.player_light_cone,
                            dynamic_lights=self.transient_lights,
                        )
                        self.render_surface.blit(gpu_surf, (0, 0))
                    else:
                        self._draw_floor_ceiling(self.render_surface)
                        if self.map_data:
                            if self.use_raycaster_async:
                                if self._ray_thread is None or not self._ray_thread.is_alive():
                                    self._ray_thread = threading.Thread(
                                        target=self._run_raycaster_thread,
                                        args=(self.player.pos, self.player.angle)
                                    )
                                    self._ray_thread.daemon = True
                                    self._ray_thread.start()
                                with self._ray_lock:
                                    ray_results = self._ray_results if self._ray_results is not None else []
                            else:
                                ray_results = self.raycaster.cast_rays(self.player.pos, self.player.angle)
                            self._draw_walls(self.render_surface, ray_results)
                    self._draw_sprites(self.render_surface)
                    self._draw_enemies(self.render_surface)
                    self._draw_enemy_bars(self.render_surface)
                    self.decals.draw(self.render_surface)
                    self.particles.draw(self.render_surface)
                    self._draw_gun_and_crosshair(self.render_surface)
                    # Сохраняем кадры
                    self._mcfi_real_prev = self._mcfi_real_curr
                    self._mcfi_real_curr = self.render_surface.copy()

                    # Начинаем показ интерполированных кадров
                    self._mcfi_step = 1

                if self._mcfi_step > 0:
                    # === БЛЕНД-КАДР (интерполяция от prev к curr) ===
                    step = self._mcfi_step  # 1..N

                    if self._mcfi_real_curr is not None and self._mcfi_real_prev is not None:
                        # Плавно перетекаем из старого кадра в новый
                        # step=1 -> 33% curr, step=2 -> 66% curr, step=N -> 100% curr
                        curr_alpha = int(255 * step / N)

                        blended = self._mcfi_real_prev.copy()
                        self._mcfi_real_curr.set_alpha(curr_alpha)
                        blended.blit(self._mcfi_real_curr, (0, 0))
                        self._mcfi_real_curr.set_alpha(255)

                        if self.render_scale != 1:
                            scaled = pygame.transform.scale_by(blended, self.render_scale)
                            screen.blit(scaled, (0, 0))
                        else:
                            screen.blit(blended, (0, 0))
                    else:
                        # Нет двух кадров (первый рендер) — показываем текущий
                        if self.render_scale != 1:
                            scaled_surface = pygame.transform.scale_by(self.render_surface, self.render_scale)
                            screen.blit(scaled_surface, (self.hud.shake.offset_x, self.hud.shake.offset_y))
                        else:
                            screen.blit(self.render_surface, (self.hud.shake.offset_x, self.hud.shake.offset_y))

                    self._mcfi_step += 1
                    if self._mcfi_step > N:
                        self._mcfi_step = 0

                self._draw_overlays(screen)
            else:
                # === MCFI выключен — обычный рендер ===
                if self.use_gpu:
                    gpu_surf = self.gpu_raycaster.render(
                        player_pos=self.player.pos,
                        player_angle=self.player.angle,
                        fov=self.fov,
                        max_depth=self.max_depth,
                        pitch_offset=self._pitch_offset_cache,
                        lights=self.light_tracer.light_sources,
                        ambient=self.ambient,
                        fog_enabled=self.fog_enabled,
                        fog_color=self.fog_color,
                        fog_start=self.fog_start,
                        fog_end=self.fog_end,
                        rt_enabled=self.rt_enabled,
                        rt_max_lights=self.rt_max_lights,
                        rt_reflections=self.rt_reflections,
                        map_data_ref=self.map_data,
                        proj_coeff=self.proj_coeff,
                        material_lib=self.material_lib,
                        sprites=self.sprite_manager.sprites + self.enemies + self.decals.decals,
                        player_light_mode=self.player_light_mode,
                        player_light_range=self.player_light_range,
                        player_light_cone=self.player_light_cone,
                        dynamic_lights=self.transient_lights,
                    )
                    self.render_surface.blit(gpu_surf, (0, 0))
                else:
                    self._draw_floor_ceiling(self.render_surface)
                    if self.map_data:
                        if self.use_raycaster_async:
                            if self._ray_thread is None or not self._ray_thread.is_alive():
                                self._ray_thread = threading.Thread(
                                    target=self._run_raycaster_thread,
                                    args=(self.player.pos, self.player.angle)
                                )
                                self._ray_thread.daemon = True
                                self._ray_thread.start()
                            with self._ray_lock:
                                ray_results = self._ray_results if self._ray_results is not None else []
                        else:
                            ray_results = self.raycaster.cast_rays(self.player.pos, self.player.angle)
                        self._draw_walls(self.render_surface, ray_results)
                self._draw_sprites(self.render_surface)
                self._draw_enemies(self.render_surface)
                self._draw_enemy_bars(self.render_surface)
                self.decals.draw(self.render_surface)
                self.particles.draw(self.render_surface)
                self._draw_gun_and_crosshair(self.render_surface)

                if self.render_scale != 1:
                    scaled_surface = pygame.transform.scale_by(self.render_surface, self.render_scale)
                    screen.blit(scaled_surface, (self.hud.shake.offset_x, self.hud.shake.offset_y))
                else:
                    screen.blit(self.render_surface, (self.hud.shake.offset_x, self.hud.shake.offset_y))

                self._draw_overlays(screen)

        except Exception as e:
            print(f"Error in Engine.render: {e}")

    # ---------- Вспомогательные методы ----------
    def _draw_floor_ceiling(self, screen):
        apply_light = self.use_lt
        horizon = self.height // 2 + self._get_pitch_offset()

        if self.floor_color and self.ceiling_color:
            top_color = self._hex_to_rgb(self.ceiling_color)
            bottom_color = self._hex_to_rgb(self.floor_color)
            screen.fill(top_color, (0, 0, self.width, max(0, horizon)))
            screen.fill(bottom_color, (0, max(0, horizon), self.width,
                                       self.height - max(0, horizon)))
            return

        if self.floor_texture is not None or self.ceiling_texture is not None:
            tex_width = 64
            tex_height = 64
            floor_tex = self.floor_texture
            ceiling_tex = self.ceiling_texture
            step = 2
            for x in range(0, self.width, step):
                ray_angle = self.player.angle - self.half_fov + (x / self.width) * self.fov
                cos_a = math.cos(ray_angle)
                sin_a = math.sin(ray_angle)
                for y in range(0, self.height, step):
                    if y < self.height // 2:
                        dy = y - horizon
                        if dy == 0:
                            continue
                        distance = horizon / dy if dy > 0 else (self.height - horizon) / -dy
                        world_x = self.player.pos.x + distance * cos_a
                        world_y = self.player.pos.y + distance * sin_a
                        if ceiling_tex:
                            tx = int((world_x / self.tile_size) * tex_width) % tex_width
                            ty = int((world_y / self.tile_size) * tex_height) % tex_height
                            try:
                                color = ceiling_tex.get_at((tx, ty))
                                if apply_light:
                                    shade = max(0.0, 1.0 - distance / self.max_depth * 0.8)
                                    color = tuple(int(c * shade) for c in color[:3])
                                if self.fog_enabled and distance > self.fog_start:
                                    fog_t = min(1.0, (distance - self.fog_start) /
                                                max(1, self.fog_end - self.fog_start))
                                    color = tuple(
                                        int(color[i] * (1 - fog_t) + self.fog_color[i] * fog_t)
                                        for i in range(3)
                                    )
                                pygame.draw.rect(screen, color, (x, y, step, step))
                            except:
                                pass
                    else:
                        dy = y - self.height // 2
                        if dy == 0: dy = 1
                        distance = (self.height // 2) / dy
                        world_x = self.player.pos.x + distance * cos_a
                        world_y = self.player.pos.y + distance * sin_a
                        if floor_tex:
                            tx = int((world_x / self.tile_size) * tex_width) % tex_width
                            ty = int((world_y / self.tile_size) * tex_height) % tex_height
                            try:
                                color = floor_tex.get_at((tx, ty))
                                if apply_light:
                                    shade = max(0.0, 1.0 - distance / self.max_depth * 0.8)
                                    color = tuple(int(c * shade) for c in color[:3])
                                pygame.draw.rect(screen, color, (x, y, step, step))
                            except:
                                pass
            return

        for y in range(self.height):
            if y < self.height // 2:
                t = y / (self.height // 2)
                color = (int(20 + 30 * t), int(20 + 30 * t), int(60 + 40 * t))
            else:
                t = (y - self.height // 2) / (self.height // 2)
                color = (int(40 + 20 * t), int(30 + 20 * t), int(10 + 10 * t))
            pygame.draw.rect(screen, color, (0, y, self.width, 1))

    def _is_sprite_visible(self, sprite_x, sprite_y):
        dx = sprite_x - self.player.pos.x
        dy = sprite_y - self.player.pos.y
        dist = math.hypot(dx, dy)
        if dist < 0.1:
            return True
        step = self.tile_size / 2
        steps = int(dist / step) + 1
        for i in range(steps):
            t = i / steps
            x = self.player.pos.x + dx * t
            y = self.player.pos.y + dy * t
            map_x = int(x // self.tile_size)
            map_y = int(y // self.tile_size)
            if 0 <= map_y < self.map_height and 0 <= map_x < self.map_width:
                cell = self.map_data[map_y][map_x]
                base_id = cell['base_id']
                # Пропускаем ID=7 (двери/ключи) и ID=6 (модели) – они не должны блокировать видимость
                if base_id in (6, 7):
                    continue
                if base_id != 0:
                    props = cell.get('properties', {})

                    # Зеркала НЕ блокируют видимость спрайтов
                    mat_name = props.get('material')
                    if mat_name == 'silver' or mat_name == 'metal' or mat_name == 'gold':
                        continue
                    # Или явная проверка через material_lib.reflection
                    try:
                        mat = self.material_lib.get_material(mat_name) if mat_name else None
                        if mat is not None and getattr(mat, 'reflection', 0.0) > 0.5:
                            continue
                    except Exception:
                        pass

                    alpha_val = props.get('alpha', 1.0)
                    try:
                        alpha_val = float(alpha_val)
                    except (TypeError, ValueError):
                        alpha_val = 1.0
                    if alpha_val < 1.0:
                        continue
                    if not props.get('isvisible', True):
                        continue

                    if base_id == 9 and props.get('isvisible', False):
                        return False
                    elif base_id == 9:
                        continue
                    else:
                        return False
        return True

    def _is_walkable(self, x, y):
        map_x = int(x // self.tile_size)
        map_y = int(y // self.tile_size)
        if map_x < 0 or map_y < 0 or map_x >= self.map_width or map_y >= self.map_height:
            return False
        row = self.map_data[map_y]
        if map_x >= len(row):
            return False
        cell = row[map_x]
        base_id = cell['base_id']
        # Если стена невидима, она проходима
        is_visible = cell.get('properties', {}).get('isvisible', True)
        add_collision = cell.get('properties', {}).get('addcollision', True)
        if base_id in (0, 8, 9) or (base_id in (1, 2, 3, 4, 5, 6) and not add_collision):
            return True
        if base_id == 7:
            props = cell.get('properties', {})
            if props.get('type') == 'key':
                return True
            if props.get('type') == 'door':
                door_id = props.get('id', None)
                if door_id and self.doors.get(door_id, {}).get('open', False):
                    return True
        return False

    def _draw_walls(self, screen, ray_results):
        if not ray_results:
            return
        bar_width = (self.width + self.rays - 1) // self.rays
        if bar_width < 1:
            bar_width = 1

        all_objects = []
        for res in ray_results:
            for depth, cell, wall_x in res.hit_objects:
                if cell is None:
                    continue
                base_id = cell['base_id']
                # Проверяем isVisible (по умолчанию True)
                is_visible = cell.get('properties', {}).get('isvisible', True)
                if not is_visible:
                    continue
                # Пропускаем ID=0, 6, 7, 8, 9 (они не стены)
                if base_id in (0, 2, 6, 7, 8, 9):
                    is_visible = cell.get('properties', {}).get('isvisible', False)
                    if not is_visible:
                        continue
                all_objects.append((depth, cell, res.ray_index, wall_x))

        all_objects.sort(key=lambda x: x[0], reverse=True)

        for depth, cell, ray_index, wall_x in all_objects:
            self._draw_single_wall(screen, ray_index, depth, cell, bar_width, wall_x)

    def _get_material_for_cell(self, cell):
        material_name = cell.get('properties', {}).get('material', None)
        if material_name is None:
            material_name = cell.get('properties', {}).get('sprite', None)
        if material_name is None:
            mat = self.material_lib.get_material(str(cell['base_id']))
        else:
            mat = self.material_lib.get_material(material_name)
        if mat is None:
            mat = self.material_lib.get_default()
        return mat

    def _get_scaled_texture(self, tex, height):
        if tex is None:
            return None
        tex_id = id(tex)
        key = (tex_id, height)
        if key in self.texture_cache:
            return self.texture_cache[key]
        if height <= 0:
            return None
        scaled = pygame.transform.scale(tex, (1, int(height)))
        self.texture_cache[key] = scaled
        return scaled

    def get_texture_column(self, texture, tx):
        key = (id(texture), tx)
        if key not in self.column_cache:
            orig_w, orig_h = texture.get_width(), texture.get_height()
            column = pygame.Surface((1, orig_h))
            for y in range(orig_h):
                color = texture.get_at((tx, y))
                column.set_at((0, y), color)
            self.column_cache[key] = column
        return self.column_cache[key]

    def _draw_single_wall(self, screen, ray_index, depth, cell, bar_width, wall_x):
        if depth <= 0 or depth >= self.max_depth:
            return
        if self.fog_enabled and depth >= self.fog_end:
            h = min(self.height, self.proj_coeff / depth)
            horizon = self.height // 2 + self._get_pitch_offset()
            y = horizon - h // 2
            pygame.draw.rect(screen, self.fog_color,
                             (ray_index * bar_width, int(y), bar_width, int(h)))
            return
        wall_x = wall_x % 1.0
        if wall_x < 0:
            wall_x += 1.0
        height = self.proj_coeff / depth
        if height > self.height:
            height = self.height

        # Если это стена (ID 1-5) и есть isVisible, но мы уже пропустили в _draw_walls
        # Здесь просто рисуем
        custom_height = cell.get('properties', {}).get('height', None)
        # if cell['base_id'] in (1,2,3,4,5):
        #     is_visible = cell.get('properties', {}).get('isvisible', True)
        # elif cell['base_id'] in (7,8,9):
        #     is_visible = cell.get('properties', {}).get('isvisible', False)
        # else:
        #     is_visible = cell.get('properties', {}).get('isvisible', None)
        if custom_height is not None and (cell['base_id'] in (1, 2, 3, 4, 5)):
            wall_height = height * float(custom_height)
            floor_y = self.height // 2 + self._get_pitch_offset()
            if wall_height > self.height:
                wall_height = self.height
            y = floor_y + (height - wall_height)
            if y < floor_y:
                y = floor_y
            if y + wall_height > self.height:
                wall_height = self.height - y
        else:
            wall_height = height
            horizon = self.height // 2 + self._get_pitch_offset()
            y = horizon - wall_height // 2

        mat = self._get_material_for_cell(cell)

        color_hex = cell.get('properties', {}).get('color', None)
        if color_hex:
            hex_str = str(color_hex).lstrip('#')
            r = int(hex_str[0:2], 16)
            g = int(hex_str[2:4], 16)
            b = int(hex_str[4:6], 16)
            color = (r, g, b)
        else:
            color = mat.color
        if color is None:
            color = (200, 200, 200)

        ray_angle = self.player.angle - self.half_fov + (ray_index / self.rays) * self.fov
        hit_x = self.player.pos.x + depth * math.cos(ray_angle)
        hit_y = self.player.pos.y + depth * math.sin(ray_angle)
        point = pygame.math.Vector2(hit_x, hit_y)
        light = self.light_tracer.get_light_at_point(point)
        light = max(light, self.light_tracer.get_light_for_depth(depth) * 0.15)

        x = ray_index * bar_width

        if mat.texture is not None:
            scaled_tex = self._get_scaled_texture(mat.texture, wall_height)
            if scaled_tex is not None:
                orig_tex = mat.texture
                orig_w = orig_tex.get_width()
                orig_h = orig_tex.get_height()
                tx = int(wall_x * orig_w) % orig_w

                column = self.get_texture_column(orig_tex, tx)

                lit_column = column.copy()
                lit_column.fill((int(255 * light), int(255 * light), int(255 * light)),
                                special_flags=pygame.BLEND_RGB_MULT)

                scaled_column = pygame.transform.scale(lit_column, (bar_width, int(wall_height)))
                if self.fog_enabled and depth > self.fog_start:
                    fog_t = min(1.0, (depth - self.fog_start) /
                                max(1, self.fog_end - self.fog_start))
                    fog_alpha = int(255 * fog_t)
                    fog_overlay = pygame.Surface((bar_width, int(wall_height)), pygame.SRCALPHA)
                    fog_overlay.fill((*self.fog_color, fog_alpha))
                    scaled_column.blit(fog_overlay, (0, 0))

                screen.blit(scaled_column, (x, y))
            else:
                color = tuple(int(c * light) for c in color[:3])
                pygame.draw.rect(screen, color, (x, y, bar_width, wall_height))
        else:
            color = tuple(int(c * light) for c in color[:3])
            alpha = mat.alpha if hasattr(mat, 'alpha') else 1.0
            custom_alpha = cell.get('properties', {}).get('alpha', None)
            if custom_alpha is not None:
                alpha = float(custom_alpha)
            if alpha < 1.0:
                surf = pygame.Surface((bar_width, wall_height), pygame.SRCALPHA)
                surf.fill((*color, int(255 * alpha)))
                screen.blit(surf, (int(x), int(y)))
            else:
                pygame.draw.rect(screen, color, (x, y, bar_width, wall_height))

    def _draw_sprites(self, screen):
        sorted_sprites = self.sprite_manager.get_sorted(self.player.pos)
        for sprite in sorted_sprites:
            # Проверяем isVisible у спрайта (если есть ключ и свойство)
            if hasattr(sprite, 'visible') and not sprite.visible:
                continue
            # Для моделей проверяем isVisible через карту (если есть)
            if isinstance(sprite, (ModelSprite, AnimatedModelSprite)):
                # Проверяем, есть ли у модели свойство isvisible в данных карты
                # Для этого нужно хранить в спрайте ссылку на клетку или проверять по позиции
                # Упрощённо: используем атрибут visible, который можно установить через API
                if not sprite.visible:
                    continue

            if isinstance(sprite, AnimatedModelSprite):
                sprite.set_frame_by_angle(self.player.pos, self.player.angle)
                texture = sprite.get_current_texture()
            elif isinstance(sprite, ModelSprite):
                sprite.set_frame_by_angle(self.player.pos, self.player.angle)
                texture = sprite.frames[sprite.current_frame] if sprite.frames else None
            else:
                texture = sprite.texture

            if texture is None:
                continue

            if not self._is_sprite_visible(sprite.x, sprite.y):
                continue
            dx = sprite.x - self.player.pos.x
            dy = sprite.y - self.player.pos.y
            dist = math.hypot(dx, dy)
            if dist < 0.1:
                continue

            angle_to_sprite = math.atan2(dy, dx)
            relative_angle = angle_to_sprite - self.player.angle
            while relative_angle < -math.pi:
                relative_angle += 2 * math.pi
            while relative_angle > math.pi:
                relative_angle -= 2 * math.pi

            if abs(relative_angle) > self.half_fov:
                continue

            screen_x = (relative_angle / self.fov + 0.5) * self.width
            size = self.proj_coeff / dist
            if size > self.height:
                size = self.height
            if size < 1:
                size = 1

            point = pygame.Vector2(sprite.x, sprite.y)
            light = self.light_tracer.get_light_at_point(point)
            light = max(light, self.light_tracer.get_light_for_depth(dist) * 0.2)

            if texture:
                shaded = texture.copy()
                shaded.fill((int(255 * light), int(255 * light), int(255 * light)), special_flags=pygame.BLEND_RGB_MULT)
                scaled = pygame.transform.scale(shaded, (int(size), int(size)))
                if self.fog_enabled and dist > self.fog_start:
                    fog_t = min(1.0, (dist - self.fog_start) /
                                max(1, self.fog_end - self.fog_start))
                    if fog_t >= 0.98:
                        continue  # полностью в тумане — не рисуем
                    fog_overlay = pygame.Surface(scaled.get_size(), pygame.SRCALPHA)
                    fog_overlay.fill((*self.fog_color, int(255 * fog_t)))
                    scaled.blit(fog_overlay, (0, 0))
                horizon = self.height // 2 + self._get_pitch_offset()
                screen.blit(scaled, (screen_x - size // 2, horizon - size // 2))
    def _hex_to_rgb(self, hex_str):
        if hex_str:
            hex_str = str(hex_str).lstrip('#')
            return (int(hex_str[0:2], 16), int(hex_str[2:4], 16), int(hex_str[4:6], 16))
        else:
            return (255, 255, 255)