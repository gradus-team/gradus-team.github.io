import time

import pygame
import math
import os
import cv2
import sys
import numpy as np
import threading

from scipy.ndimage import watershed_ift

from .config import *
from .player import Player
from .utils.parser import MapParser
from .raycast.core import RayCaster
from .light.tracer import LightTracer, LightSource
from .material.library import MaterialLibrary
from .image.cache import SpriteManager as ImageManager
import imageio
import imageio_ffmpeg
from .sound.mixer import SoundManager
from .object.registry import GameObjectRegistry
from .sprite.core import SpriteManager, Sprite, ModelSprite, AnimatedModelSprite
from .image.cache import load_image
from .polygon.obj_to_sprites import obj_to_sprites
from .effects.manager import EffectsManager

class Engine:
    def __init__(self, width=DEFAULT_WIDTH, height=DEFAULT_HEIGHT,
                 levels=None, current_level=0,
                 fov=DEFAULT_FOV, rays=DEFAULT_RAYS,
                 tile_size=DEFAULT_TILE_SIZE, max_depth=DEFAULT_MAX_DEPTH,
                 proj_coeff=DEFAULT_PROJ_COEFF,
                 player_speed=DEFAULT_PLAYER_SPEED,
                 player_rot_speed=DEFAULT_PLAYER_ROT_SPEED,
                 floor_texture=None, ceiling_texture=None,
                 mouse_sensitivity=0.002):  # <-- добавили параметр
        try:
            self.width = int(width)
            self.height = int(height)
            self.fov = math.radians(fov)
            self.half_fov = self.fov / 2
            self.rays = rays
            self.effects_manager = EffectsManager()
            self.tile_size = tile_size
            self.max_depth = max_depth
            self.proj_coeff = proj_coeff
            self.use_lt = True
            self.overlay_texture = None
            self.overlay_alpha = 255
            self.effect_texture = None
            self.effect_timer = 0
            self.inactive_triggers = set()
            self.model_data = []

            self.message_text = ""
            self.message_timer = 0.0
            self.message_duration = 0.0
            self.font = None

            self.doors = {}
            self.keys = {}

            # ---- Водяной знак и экран загрузки (уже есть) ----
            self.watermark = ""
            self.loading_progress = (0, 0)
            self.show_loading_screen = True
            self.example_menu = None
            self.example_game = None
            self.use_example = False
            self._load_watermark()

            # ---- Видео (через imageio, без cv2) ----
            self.video_playing = False
            self.video_surface = None
            self.video_mode = "full"
            self.video_rect = pygame.Rect(0, 0, 0, 0)
            self.video_lock = threading.Lock()
            self.video_thread = None
            self.video_loop = True

            # ---- Управление мышью (новое) ----
            self.mouse_sensitivity = mouse_sensitivity
            self.mouse_captured = False

            # ---- Текстуры пола/потолка ----
            self.floor_texture = None
            self.ceiling_texture = None
            if floor_texture:
                try:
                    self.floor_texture = pygame.image.load(floor_texture).convert_alpha()
                except:
                    self.floor_texture = None
            if ceiling_texture:
                try:
                    self.ceiling_texture = pygame.image.load(ceiling_texture).convert_alpha()
                except:
                    self.ceiling_texture = None

            self.material_lib = MaterialLibrary()
            self.sprite_manager = SpriteManager()
            self.sound_manager = SoundManager()
            self.registry = GameObjectRegistry()

            self.levels = levels if levels else []
            self.current_level = current_level
            self.map_data = None
            self.map_width = 0
            self.map_height = 0

            self.texture_cache = {}

            self.raycaster = RayCaster(
                map_data=self.map_data,
                tile_size=self.tile_size,
                fov=self.fov,
                rays=self.rays,
                max_depth=self.max_depth,
                proj_coeff=self.proj_coeff,
                material_lib=self.material_lib
            )
            self.light_tracer = LightTracer(map_data=self.map_data, tile_size=self.tile_size)

            self.spawn = None
            self.floor_color = None
            self.ceiling_color = None
            self.ambient = 0.03
            self.level_sprites = []

            if self.levels:
                self.load_level(self.current_level)

            start_x, start_y = self._find_spawn_point()
            self.player = Player(
                x=start_x,
                y=start_y,
                angle=0.0,
                speed=player_speed,
                rot_speed=player_rot_speed
            )


            self.mesh_objects = []
            self.api = self.MicroAPI(self)
        except Exception as e:
            print(f"Error in Engine.__init__: {e}")
            raise

    def prepare_models(self, screen):
        print("prepare_models started")
        cache_dir = "cache"
        if not os.path.exists(cache_dir):
            os.makedirs(cache_dir)

        total = len(self.model_data)
        if total == 0:
            print("No models to cache")
            return

        for idx, data in enumerate(self.model_data):
            model_name = os.path.splitext(os.path.basename(data['path']))[0]
            model_cache_dir = os.path.join(cache_dir, model_name)
            if os.path.exists(model_cache_dir):
                existing = [f for f in os.listdir(model_cache_dir) if f.endswith('.png')]
                if len(existing) >= 64:
                    self.show_loading(screen, idx + 1, total)
                    continue
            if not os.path.exists(model_cache_dir):
                os.makedirs(model_cache_dir)

            sprites = obj_to_sprites(
                data['path'],
                num_angles=64,
                sprite_size=(512, 512),  # или 512 для качества
                scale=data['scale'],
                color=data['color']
            )
            if sprites:
                for i, surf in enumerate(sprites):
                    pygame.image.save(surf, os.path.join(model_cache_dir, f"frame_{i:02d}.png"))
            self.show_loading(screen, idx + 1, total)

        # Загружаем спрайты в менеджер
        self._process_models()

        # Показываем финальную заставку 3 секунды
        if self.watermark:
            self.show_loading(screen, total, total)
            print(f"Screen: {screen}, Total: {total}")
            pygame.time.delay(3000)
        self.watermark = False

    def show_loading(self, screen, current, total):
        # screen.fill((10, 10, 30))

        # Логотип – теперь 50% ширины экрана
        if self.watermark:
            wm_width = screen.get_width()
            wm_height = screen.get_height()
            wm = pygame.transform.scale(self.watermark, (wm_width, wm_height))
            screen.blit(wm, (0,0))

        # font = pygame.font.SysFont('Arial', 36)
        # text = font.render(f"Кэширование моделей: {current}/{total}", True, (255, 255, 255))
        # screen.blit(text, (screen.get_width()//2 - text.get_width()//2, screen.get_height()//1.2 + 50))
        # pygame.display.flip()

        # Текст прогресса
        font = pygame.font.SysFont('Arial', 36)
        text = font.render(f"Кэширование моделей: {current}/{total}", True, (255, 255, 255))
        screen.blit(text, (screen.get_width() // 2 - text.get_width() // 2, screen.get_height() // 1.2 + 50))

        pygame.display.flip()

    def handle_mouse(self, event):
        """Обрабатывает события мыши для управления камерой."""
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 3:  # правая кнопка
                self.mouse_captured = not self.mouse_captured
                pygame.mouse.set_visible(not self.mouse_captured)
                pygame.event.set_grab(self.mouse_captured)
        elif event.type == pygame.MOUSEMOTION and self.mouse_captured:
            dx, dy = event.rel
            self.player.angle += dx * self.mouse_sensitivity

    def _load_watermark(self):
        try:
            path = os.path.join(os.path.dirname(__file__), 'material', 'images', 'watermark.png')
            if os.path.exists(path):
                self.watermark = pygame.image.load(path).convert_alpha()
            else:
                # Создаём заглушку
                surf = pygame.Surface((300, 100), pygame.SRCALPHA)
                surf.fill((50, 50, 150, 200))
                font = pygame.font.SysFont('Arial', 36)
                text = font.render("Gradus RC", True, (255, 255, 255))
                surf.blit(text, (10, 10))
                self.watermark = surf
        except:
            self.watermark = None


    def start_with_menu(self, menu_example):
        self.example_menu = menu_example
        self.use_example = True

    def start_game(self):
        if self.example_game:
            # Запускаем игру
            self.example_game.run()
        else:
            # Если нет, запускаем обычный цикл (пользовательский)
            pass

    def set_game_example(self, game_example):
        self.example_game = game_example

    def play_video(self, filepath, mode="full", x=0, y=0, width=0, height=0, loop=True, alpha_chroma=False, chroma_color=(0,255,0)):
        """
        Воспроизводит видео на экране.
        mode: "full" – полноэкранное, "angle" – в углу (левый верхний, 25% экрана), "custom" – с указанными x,y,width,height.
        alpha_chroma – если True, заменяет chroma_color на прозрачный.
        """
        if self.video_playing:
            self.stop_video()

        self.video_loop = loop
        self.video_mode = mode
        if mode == "full":
            self.video_rect = pygame.Rect(0, 0, self.width, self.height)
        elif mode == "angle":
            w = self.width // 4
            h = self.height // 4
            self.video_rect = pygame.Rect(0, 0, w, h)
        else:
            if width <= 0: width = self.width // 4
            if height <= 0: height = self.height // 4
            width = min(width, self.width)
            height = min(height, self.height)
            self.video_rect = pygame.Rect(x, y, width, height)

        self.video_playing = True
        self.video_thread = threading.Thread(target=self._video_worker, args=(filepath, alpha_chroma, chroma_color), daemon=True)
        self.video_thread.start()

    def stop_video(self):
        self.video_playing = False
        if self.video_thread and self.video_thread.is_alive():
            self.video_thread.join(timeout=0.1)
        self.video_surface = None

    def _video_worker(self, filepath, alpha_chroma, chroma_color):
        try:
            reader = imageio.get_reader(filepath, 'ffmpeg')
            fps = reader.get_meta_data().get('fps', 30)
            frame_delay = 1.0 / fps
            for frame in reader:
                if not self.video_playing:
                    break
                # Конвертируем кадр в pygame Surface
                frame_rgb = frame[:, :, :3]  # игнорируем альфа, если есть
                surf = pygame.surfarray.make_surface(frame_rgb.swapaxes(0, 1))
                if alpha_chroma:
                    # Заменяем цвет на прозрачный
                    surf = surf.convert_alpha()
                    # Пробегаем по пикселям (медленно, но для демонстрации)
                    # Оптимизация: использовать pygame.color_threshold? Можно.
                    # Для простоты используем numpy
                    import numpy as np
                    arr = pygame.surfarray.pixels3d(surf)
                    # Создаём маску для chroma_color
                    mask = (arr[:, :, 0] == chroma_color[0]) & (arr[:, :, 1] == chroma_color[1]) & (arr[:, :, 2] == chroma_color[2])
                    arr[mask] = [0,0,0]  # чёрный
                    # Делаем альфа-канал
                    surf = surf.convert_alpha()
                    arr_alpha = pygame.surfarray.pixels_alpha(surf)
                    arr_alpha[mask] = 0
                    arr_alpha[~mask] = 255
                    del arr, arr_alpha

                # Масштабируем до размера rect
                if self.video_rect.width != surf.get_width() or self.video_rect.height != surf.get_height():
                    surf = pygame.transform.scale(surf, (self.video_rect.width, self.video_rect.height))
                with self.video_lock:
                    self.video_surface = surf
                # Ждём следующий кадр
                pygame.time.delay(int(frame_delay * 1000))
            if self.video_loop and self.video_playing:
                self._video_worker(filepath, alpha_chroma, chroma_color)  # перезапустить
        except Exception as e:
            print(f"Video error: {e}")
        finally:
            self.video_playing = False

    def _draw_video(self, screen):
        if self.video_surface:
            with self.video_lock:
                surf = self.video_surface.copy()
            screen.blit(surf, self.video_rect)

    # ================ MicroAPI ================
    class MicroAPI:
        def __init__(self, engine):
            self.engine = engine

        def set_effect(self, effect_type, alpha=255, intensity=1.0):
            self.engine.effects_manager.set_effect(effect_type, alpha, intensity)

        def clear_effect(self):
            self.engine.effects_manager.clear_effect()

        def set_model_rotation_y(self, model_key, rot_deg):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.rot_y = math.radians(rot_deg)

        def set_model_rotation_x(self, model_key, rot_deg):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.rot_x = math.radians(rot_deg)

        def set_model_rotation_z(self, model_key, rot_deg):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.rot_z = math.radians(rot_deg)

        def set_model_rotation(self, model_key, rot_y_deg, rot_x_deg=0, rot_z_deg=0):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.rot_y = math.radians(rot_y_deg)
                sprite.rot_x = math.radians(rot_x_deg)
                sprite.rot_z = math.radians(rot_z_deg)

        def get_cell(self, x, y):
            try:
                if 0 <= y < self.engine.map_height and 0 <= x < self.engine.map_width:
                    return self.engine.map_data[y][x]
            except:
                pass
            return None

        def set_cell_property(self, x, y, key, value):
            cell = self.get_cell(x, y)
            if cell:
                cell['properties'][key] = value

        def set_cell_base_id(self, x, y, new_id):
            cell = self.get_cell(x, y)
            if cell:
                cell['base_id'] = new_id

        def set_cell_visible(self, x, y, visible):
            self.set_cell_property(x, y, 'isvisible', visible)

        def set_cell_collision(self, x, y, collision):
            self.set_cell_property(x, y, 'addcollision', collision)

        def set_player_position(self, x, y):
            self.engine.player.pos.x = x
            self.engine.player.pos.y = y

        def set_player_angle(self, angle):
            self.engine.player.angle = angle

        def set_player_speed(self, speed):
            self.engine.player.speed = speed

        def set_player_rot_speed(self, rot_speed):
            self.engine.player.rot_speed = rot_speed

        def get_light_sources(self):
            return self.engine.light_tracer.light_sources

        def add_light(self, x, y, radius, intensity, color=(255,255,255)):
            source = LightSource(x, y, radius, intensity, color)
            self.engine.light_tracer.add_source(source)
            return source

        def remove_light(self, index):
            if 0 <= index < len(self.engine.light_tracer.light_sources):
                del self.engine.light_tracer.light_sources[index]

        def set_ambient(self, value):
            self.engine.light_tracer.ambient_light = max(0.0, min(1.0, value))

        def set_player_light(self, radius=None, intensity=None, color=None):
            if radius is not None:
                self.engine.light_tracer.player_light_radius = radius
            if intensity is not None:
                self.engine.light_tracer.player_light_intensity = intensity
            if color is not None:
                self.engine.light_tracer.player_light_color = color

        def get_sprites(self):
            return self.engine.sprite_manager.sprites

        def set_sprite_position(self, key, x, y):
            self.engine.set_sprite_position(key, x, y)

        def set_sprite_visible(self, key, visible):
            self.engine.set_sprite_visible(key, visible)

        def remove_sprite(self, key):
            self.engine.sprite_manager.remove_by_key(key)

        # ---- Управление дверями и ключами ----
        def open_door(self, door_id):
            if door_id in self.engine.doors:
                self.engine.doors[door_id]['open'] = True
                x, y = self.engine.doors[door_id]['pos']
                self.set_cell_property(x, y, 'open', True)
                sprite_key = self.engine.doors[door_id].get('sprite_key')
                if sprite_key:
                    self.engine.set_sprite_visible(sprite_key, False)

        def close_door(self, door_id):
            if door_id in self.engine.doors:
                self.engine.doors[door_id]['open'] = False
                x, y = self.engine.doors[door_id]['pos']
                self.set_cell_property(x, y, 'open', False)
                sprite_key = self.engine.doors[door_id].get('sprite_key')
                if sprite_key:
                    self.engine.set_sprite_visible(sprite_key, True)

        def is_door_open(self, door_id):
            return self.engine.doors.get(door_id, {}).get('open', False)

        def collect_key(self, key_id):
            if key_id in self.engine.keys:
                self.engine.keys[key_id]['collected'] = True
                sprite_key = self.engine.keys[key_id].get('sprite_key')
                if sprite_key:
                    self.engine.sprite_manager.remove_by_key(sprite_key)

        def has_key(self, key_id):
            return self.engine.keys.get(key_id, {}).get('collected', False)

        # ---- Управление моделями (ID=6) ----
        def get_model(self, model_key):
            """Возвращает спрайт модели по ключу."""
            return self.engine.sprite_manager.get_by_key(model_key)

        def set_model_position(self, model_key, x, y):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.x = x
                sprite.y = y

        def set_model_rotation(self, model_key, rotation_deg):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.rotation = math.radians(rotation_deg)

        def set_model_visible(self, model_key, visible):
            sprite = self.get_model(model_key)
            if sprite:
                sprite.visible = visible

        # Для коллизии моделей – пока заглушка, можно добавить позже
        def set_model_collision(self, model_key, collision):
            # Временно просто печатаем, что функция вызывается
            print(f"set_model_collision called for {model_key} with {collision} (not implemented yet)")

    # ================ Основные методы ================
    def deactivate_trigger(self, key):
        self.inactive_triggers.add(key)

    def activate_trigger(self, key):
        self.inactive_triggers.discard(key)

    def is_trigger_active(self, key):
        return key not in self.inactive_triggers

    def add_sprite(self, sprite):
        self.sprite_manager.add(sprite)

    def get_sprite(self, key):
        return self.sprite_manager.get_by_key(key)

    def set_sprite_visible(self, key, visible):
        sprite = self.sprite_manager.get_by_key(key)
        if sprite:
            sprite.visible = visible

    def set_sprite_position(self, key, x, y):
        sprite = self.sprite_manager.get_by_key(key)
        if sprite:
            sprite.x = x
            sprite.y = y

    def show_message(self, text, duration=2.0):
        self.message_text = text
        self.message_timer = duration
        self.message_duration = duration

    def _get_default_texture(self, name):
        base_dir = os.path.dirname(__file__)
        path = os.path.join(base_dir, 'material', 'images', name)
        try:
            return pygame.image.load(path).convert_alpha()
        except:
            return None

    def load_level(self, index):
        try:
            if index < 0 or index >= len(self.levels):
                return
            raw_map = self.levels[index]
            parser = MapParser()
            layers = parser.parse_layers(raw_map)

            self.map_data = layers.get('collision', [])
            if not self.map_data:
                self.map_data = []
            self.map_height = len(self.map_data)
            self.map_width = len(self.map_data[0]) if self.map_height > 0 else 0

            self.raycaster.map_data = self.map_data
            self.raycaster.update_dimensions()
            self.light_tracer.map_data = self.map_data

            params = layers.get('_params', {})
            self.spawn = params.get('spawn', None)
            self.floor_color = params.get('floor_color', None)
            self.ceiling_color = params.get('ceiling_color', None)
            try:
                self.ambient = float(params.get('ambient', 0.03))
            except:
                self.ambient = 0.03
            self.light_tracer.ambient_light = self.ambient
            self.use_lt = params.get('use_lt', 'true').lower() in ('true', '1', 'yes')

            self.doors.clear()
            self.keys.clear()
            self.model_data.clear()

            self.light_tracer.light_sources.clear()
            lights_str = params.get('lights', '')
            if lights_str:
                for light_str in lights_str.split(';'):
                    parts = light_str.split(',')
                    if len(parts) >= 4:
                        try:
                            x = float(parts[0]) * self.tile_size
                            y = float(parts[1]) * self.tile_size
                            intensity = float(parts[2])
                            radius = float(parts[3])
                            color = (255, 255, 255)
                            if len(parts) >= 7:
                                r = int(parts[4])
                                g = int(parts[5])
                                b = int(parts[6])
                                color = (r, g, b)
                            self.light_tracer.add_source(LightSource(x, y, radius, intensity, color))
                        except:
                            pass

            # Загрузка билбордов
            bilboards_str = params.get('bilboards', '')
            if bilboards_str:
                for b_str in bilboards_str.split(';'):
                    parts = b_str.split(',')
                    if len(parts) >= 3:
                        try:
                            x = float(parts[0]) * self.tile_size
                            y = float(parts[1]) * self.tile_size
                            key = parts[2].strip()
                            existing = self.sprite_manager.get_by_key(key)
                            if existing:
                                existing.x = x
                                existing.y = y
                            else:
                                tex = load_image(key, f'textures/{key}.png', size=(30,30), default_color=(255,0,255))
                                sprite = Sprite(x, y, tex, key=key)
                                self.sprite_manager.add(sprite)
                        except:
                            pass

            # Обработка ID=7 (двери и ключи) и ID=6 (модели)
            for y, row in enumerate(self.map_data):
                for x, cell in enumerate(row):
                    if cell['base_id'] == 7:
                        props = cell.get('properties', {})
                        obj_type = props.get('type', 'door')
                        if obj_type == 'door':
                            door_id = props.get('id', f'door_{x}_{y}')
                            cell['properties']['isvisible'] = False
                            if 'height' not in props:
                                cell['properties']['height'] = 0.9
                            if 'material' not in props:
                                cell['properties']['material'] = 'concrete'
                            sprite_key = f"door_sprite_{door_id}"
                            tex_path = props.get('texture', None)
                            if tex_path:
                                try:
                                    tex = pygame.image.load(tex_path).convert_alpha()
                                except:
                                    tex = self._get_default_texture('door.png')
                            else:
                                tex = self._get_default_texture('door.png')
                            if tex is None:
                                tex = pygame.Surface((256,256))
                                tex.fill((150, 100, 50))
                            sprite_x = x * self.tile_size + self.tile_size/2
                            sprite_y = y * self.tile_size + self.tile_size/2
                            sprite = Sprite(sprite_x, sprite_y, tex, key=sprite_key)
                            self.add_sprite(sprite)

                            self.doors[door_id] = {
                                'open': False,
                                'pos': (x, y),
                                'linked_keys': [],
                                'sprite_key': sprite_key
                            }
                            cell['properties']['open'] = False

                        elif obj_type == 'key':
                            key_id = props.get('id', f'key_{x}_{y}')
                            sprite_key = f"key_sprite_{key_id}"
                            tex_path = props.get('texture', None)
                            if tex_path:
                                try:
                                    tex = pygame.image.load(tex_path).convert_alpha()
                                except:
                                    tex = self._get_default_texture('key.png')
                            else:
                                tex = self._get_default_texture('key.png')
                            if tex is None:
                                tex = pygame.Surface((32,32))
                                tex.fill((255, 215, 0))
                            sprite_x = x * self.tile_size + self.tile_size/2
                            sprite_y = y * self.tile_size + self.tile_size/2
                            sprite = Sprite(sprite_x, sprite_y, tex, key=sprite_key)
                            self.add_sprite(sprite)

                            self.keys[key_id] = {
                                'collected': False,
                                'pos': (x, y),
                                'sprite_key': sprite_key,
                                'linked_doors': []
                            }



                    elif cell['base_id'] == 6:
                        props = cell.get('properties', {})
                        if props.get("isvisible", True):
                            path = props.get('path', '')
                            anim_str = props.get('anim', '')
                            anim_speed = float(props.get('anim_speed', 0.5))  # секунд на кадр
                            if path or anim_str:
                                anim_paths = [p.strip() for p in anim_str.split(',')] if anim_str else []
                                if path:
                                    anim_paths.insert(0, path)  # первая модель – основная
                                rotation = float(props.get('rotation', 0))
                                rot_y = float(props.get('roty', rotation))
                                rot_x = float(props.get('rotx', 0))
                                rot_z = float(props.get('rotz', 0))
                                scale = float(props.get('scale', 1.0))
                                pos_x = x * self.tile_size + self.tile_size / 2
                                pos_y = y * self.tile_size + self.tile_size / 2
                                color_hex = props.get('color', None)
                                color = self._hex_to_rgb(color_hex) if color_hex else (200, 100, 100)
                                self.model_data.append({
                                    'path': path,
                                    'anim_paths': anim_paths,
                                    'anim_speed': anim_speed,
                                    'pos': (pos_x, pos_y),
                                    'rot_y': rot_y,
                                    'rot_x': rot_x,
                                    'rot_z': rot_z,
                                    'scale': scale,
                                    'color': color,
                                    'cell_x': x,
                                    'cell_y': y,
                                    'key': f"model_{x}_{y}"
                                })
                                print(f"Model data: {self.model_data}")
            # Связываем ключи и двери
            for key_id, key_data in self.keys.items():
                kx, ky = key_data['pos']
                cell = self.map_data[ky][kx]
                link = cell.get('properties', {}).get('link', None)
                if link and link in self.doors:
                    self.doors[link]['linked_keys'].append(key_id)
                    self.keys[key_id]['linked_doors'].append(link)

            self.inactive_triggers.clear()
            self.texture_cache.clear()
            # Удаляем старые спрайты моделей (с ключом "model_*")
            for sprite in self.sprite_manager.sprites[:]:
                if sprite.key and sprite.key.startswith("model_"):
                    self.sprite_manager.remove_by_key(sprite.key)

            # Загружаем модели для текущего уровня
            if self.watermark == False: self._process_models()
        except Exception as e:
            print(f"Error in Engine.load_level: {e}")
            raise

    def _cache_models(self):
        try:
            cache_dir = "cache"
            if not os.path.exists(cache_dir):
                os.makedirs(cache_dir)

            for idx, data in enumerate(self.model_data):
                model_name = os.path.splitext(os.path.basename(data['path']))[0]
                model_cache_dir = os.path.join(cache_dir, model_name)
                if os.path.exists(model_cache_dir):
                    existing = [f for f in os.listdir(model_cache_dir) if f.endswith('.png')]
                    if len(existing) >= 64:
                        continue
                if not os.path.exists(model_cache_dir):
                    os.makedirs(model_cache_dir)

                sprites = obj_to_sprites(
                    data['path'],
                    num_angles=64,
                    sprite_size=(512, 512),
                    scale=data['scale'],
                    color=data['color'],
                    model_rot_x=data.get('rot_x', 0),
                    model_rot_y=data.get('rot_y', 0),
                    model_rot_z=data.get('rot_z', 0)
                )
                if not sprites:
                    continue
                for i, surf in enumerate(sprites):
                    pygame.image.save(surf, os.path.join(model_cache_dir, f"frame_{i:02d}.png"))

                # ---- Отображение прогресса (если есть доступ к экрану) ----
                # Здесь можно вызвать self.show_loading(screen, idx+1, total)
                # Но экран передаётся только в render, поэтому пока оставим заглушку
                # Для реального прогресса нужно передавать screen в _cache_models, что неудобно.
                # Лучше вызывать show_loading из main, показывая прогресс вручную.
        except Exception as e:
            print(f"Error in Engine._cache_models: {e}")

    def _load_sprites_from_cache(self, model_name, num_frames=64):
        try:
            cache_dir = os.path.join("cache", model_name)
            sprites = []
            for i in range(num_frames):
                path = os.path.join(cache_dir, f"frame_{i:02d}.png")
                if os.path.exists(path):
                    try:
                        surf = pygame.image.load(path).convert_alpha()
                        sprites.append(surf)
                    except:
                        sprites.append(None)
            return [s for s in sprites if s is not None]
        except Exception as e:
            print(f"Error in Engine._load_sprites_from_cache: {e}")
            return []

    def _process_models(self):
        try:
            for data in self.model_data:
                model_name = os.path.splitext(os.path.basename(data['path']))[0]
                anim_paths = data.get('anim_paths', [])
                anim_speed = data.get('anim_speed', 0.5)

                # Если есть анимация, генерируем спрайты для каждой модели
                all_frame_sets = []
                all_paths = anim_paths if anim_paths else [data['path']]
                for i, p in enumerate(all_paths):
                    # Загружаем или генерируем спрайты для этой модели
                    sprites = self._load_sprites_from_cache(os.path.splitext(os.path.basename(p))[0], num_frames=64)
                    if not sprites:
                        sprites = obj_to_sprites(p, num_angles=64, sprite_size=(512, 512), scale=data['scale'],
                                                 color=data['color'], model_rot_x=data.get('rot_x', 0),
    model_rot_y=data.get('rot_y', 0),
    model_rot_z=data.get('rot_z', 0))
                        if sprites:
                            # сохраняем в кэш
                            cache_dir = os.path.join("cache", os.path.splitext(os.path.basename(p))[0])
                            if not os.path.exists(cache_dir):
                                os.makedirs(cache_dir)
                            for j, surf in enumerate(sprites):
                                pygame.image.save(surf, os.path.join(cache_dir, f"frame_{j:02d}.png"))
                    if sprites:
                        all_frame_sets.append(sprites)

                if all_frame_sets:
                    rot_y = math.radians(data.get('rot_y', 0))
                    rot_x = math.radians(data.get('rot_x', 0))
                    rot_z = math.radians(data.get('rot_z', 0))
                    model_sprite = AnimatedModelSprite(
                        data['pos'][0],
                        data['pos'][1],
                        all_frame_sets,
                        key=data['key'],
                        rot_y=rot_y,
                        rot_x=rot_x,
                        rot_z=rot_z,
                        anim_speed=anim_speed
                    )
                    self.sprite_manager.add(model_sprite)
                else:
                    print(f"Failed to get sprites for {data['path']}")
            self.model_data.clear()
        except Exception as e:
            print(f"Error in Engine._process_models: {e}")

    def _find_spawn_point(self):
        if self.spawn:
            try:
                parts = self.spawn.split(',')
                x = float(parts[0]) * self.tile_size + self.tile_size/2
                y = float(parts[1]) * self.tile_size + self.tile_size/2
                return x, y
            except:
                pass
        if not self.map_data:
            return 0, 0
        for y, row in enumerate(self.map_data):
            for x, cell in enumerate(row):
                if cell['base_id'] == 0:
                    return x * self.tile_size + self.tile_size/2, \
                           y * self.tile_size + self.tile_size/2
        return 0, 0

    def set_overlay(self, texture_path, alpha=255):
        try:
            surf = pygame.image.load(texture_path).convert_alpha()
            self.overlay_texture = surf
            self.overlay_alpha = max(0, min(255, alpha))
        except:
            self.overlay_texture = None

    def clear_overlay(self):
        self.overlay_texture = None

    def play_sound(self, sound_key):
        self.sound_manager.play_sound(sound_key)

    def set_fullscreen_effect(self, texture_path, duration=2.0):
        try:
            self.effect_texture = pygame.image.load(texture_path).convert_alpha()
            self.effect_timer = duration
        except:
            self.effect_texture = None

    def update(self, dt, keys):
        try:
            self.player.update(keys, dt)
            self.sprite_manager.update(dt)

            # if self.video_cap:
            #     ret, frame = self.video_cap.read()
            #     if not ret:
            #         if self.video_loop:
            #             self.video_cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            #             ret, frame = self.video_cap.read()
            #         else:
            #             self.stop_video()
            #             return
            #     # Конвертируем BGR в RGB и в Surface
            #     frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            #     frame = np.rot90(frame)  # если нужно
            #     surf = pygame.surfarray.make_surface(frame)
            #     surf.set_alpha(self.video_alpha)
            #     self.video_frame = surf

            if self.effect_timer > 0:
                self.effect_timer -= dt
                if self.effect_timer <= 0:
                    self.effect_texture = None

            if self.message_timer > 0:
                self.message_timer -= dt
                if self.message_timer <= 0:
                    self.message_text = ""

            new_x = self.player.pos.x + self.player.vel.x * dt
            new_y = self.player.pos.y + self.player.vel.y * dt

            if self._is_walkable(new_x, new_y):
                self.player.pos.x = new_x
                self.player.pos.y = new_y
            else:
                map_x = int(new_x // self.tile_size)
                map_y = int(new_y // self.tile_size)
                if 0 <= map_y < self.map_height and 0 <= map_x < self.map_width:
                    cell = self.map_data[map_y][map_x]
                    if cell['base_id'] == 7:
                        props = cell.get('properties', {})
                        if props.get('type') == 'door':
                            door_id = props.get('id', None)
                            if door_id and not self.doors.get(door_id, {}).get('open', False):
                                self.on_door_blocked(cell)

            cur_map_x = int(self.player.pos.x // self.tile_size)
            cur_map_y = int(self.player.pos.y // self.tile_size)

            if 0 <= cur_map_y < self.map_height and 0 <= cur_map_x < self.map_width:
                cell = self.map_data[cur_map_y][cur_map_x]
                base_id = cell['base_id']

                if base_id == 9:
                    target = cell.get('properties', {}).get('level', None)
                    if target is not None and target != self.current_level:
                        print(f"Teleport to level {target}")
                        self.current_level = target
                        self.load_level(self.current_level)
                        sx, sy = self._find_spawn_point()
                        self.player.pos.x = sx
                        self.player.pos.y = sy

                if base_id == 8:
                    trigger_id = cell.get('properties', {}).get('id', None)
                    if trigger_id is not None:
                        key = ('id', trigger_id)
                    else:
                        key = ('pos', cur_map_x, cur_map_y)
                    if self.is_trigger_active(key):
                        self.on_trigger(cell)

                if base_id == 7:
                    props = cell.get('properties', {})
                    if props.get('type') == 'key':
                        key_id = props.get('id', None)
                        if key_id and key_id in self.keys:
                            if not self.keys[key_id]['collected']:
                                self.keys[key_id]['collected'] = True
                                sprite_key = self.keys[key_id].get('sprite_key')
                                if sprite_key:
                                    self.sprite_manager.remove_by_key(sprite_key)
                                for door_id in self.keys[key_id]['linked_doors']:
                                    self.api.open_door(door_id)
                                self.on_key_pickup(key_id)

            self.light_tracer.update_player_light(self.player.pos, self.player.angle)
        except Exception as e:
            print(f"Error in Engine.update: {e}")

    def on_trigger(self, cell):
        pass

    def on_key_pickup(self, key_id):
        pass

    def on_door_blocked(self, cell):
        self.show_message("Нужен ключ", 2.0)

    def render(self, screen):
        try:
            self._draw_floor_ceiling(screen)
            if self.map_data:
                ray_results = self.raycaster.cast_rays(self.player.pos, self.player.angle)
                self._draw_walls(screen, ray_results)
            self._draw_sprites(screen)

            if self.overlay_texture is not None:
                overlay = self.overlay_texture.copy()
                overlay.set_alpha(self.overlay_alpha)
                screen.blit(overlay, (0, 0))

            self.effects_manager.apply(screen)

            if self.message_text:
                if self.font is None:
                    self.font = pygame.font.SysFont('Arial', 36)
                text_surf = self.font.render(self.message_text, True, (255, 255, 255))
                shadow = self.font.render(self.message_text, True, (0, 0, 0))
                rect = text_surf.get_rect(center=(self.width // 2, self.height // 2 + 100))
                screen.blit(shadow, (rect.x + 2, rect.y + 2))
                screen.blit(text_surf, rect)

            # Водяной знак НЕ рисуем в игре
        except Exception as e:
            print(f"Error in Engine.render: {e}")

    # ---------- Вспомогательные методы ----------
    def _draw_floor_ceiling(self, screen):
        apply_light = self.use_lt

        if self.floor_color and self.ceiling_color:
            top_color = self._hex_to_rgb(self.ceiling_color)
            bottom_color = self._hex_to_rgb(self.floor_color)
            screen.fill(top_color, (0, 0, self.width, self.height // 2))
            screen.fill(bottom_color, (0, self.height // 2, self.width, self.height // 2))
            return

        if self.floor_texture is not None or self.ceiling_texture is not None:
            tex_width = 64
            tex_height = 64
            floor_tex = self.floor_texture
            ceiling_tex = self.ceiling_texture
            step = 2
            for x in range(0, self.width, step):
                ray_angle = self.player.angle - self.half_fov + (x / self.width) * self.fov
                cos_a = math.cos(ray_angle)
                sin_a = math.sin(ray_angle)
                for y in range(0, self.height // 2 + 1, step):
                    if y < self.height // 2:
                        dy = y - self.height // 2
                        if dy == 0: dy = 1
                        distance = (self.height // 2) / dy
                        world_x = self.player.pos.x + distance * cos_a
                        world_y = self.player.pos.y + distance * sin_a
                        if ceiling_tex:
                            tx = int((world_x / self.tile_size) * tex_width) % tex_width
                            ty = int((world_y / self.tile_size) * tex_height) % tex_height
                            try:
                                color = ceiling_tex.get_at((tx, ty))
                                if apply_light:
                                    shade = max(0.0, 1.0 - distance / self.max_depth * 0.8)
                                    color = tuple(int(c * shade) for c in color[:3])
                                pygame.draw.rect(screen, color, (x, y, step, step))
                            except:
                                pass
                    else:
                        dy = y - self.height // 2
                        if dy == 0: dy = 1
                        distance = (self.height // 2) / dy
                        world_x = self.player.pos.x + distance * cos_a
                        world_y = self.player.pos.y + distance * sin_a
                        if floor_tex:
                            tx = int((world_x / self.tile_size) * tex_width) % tex_width
                            ty = int((world_y / self.tile_size) * tex_height) % tex_height
                            try:
                                color = floor_tex.get_at((tx, ty))
                                if apply_light:
                                    shade = max(0.0, 1.0 - distance / self.max_depth * 0.8)
                                    color = tuple(int(c * shade) for c in color[:3])
                                pygame.draw.rect(screen, color, (x, y, step, step))
                            except:
                                pass
            return

        for y in range(self.height):
            if y < self.height // 2:
                t = y / (self.height // 2)
                color = (int(20 + 30 * t), int(20 + 30 * t), int(60 + 40 * t))
            else:
                t = (y - self.height // 2) / (self.height // 2)
                color = (int(40 + 20 * t), int(30 + 20 * t), int(10 + 10 * t))
            pygame.draw.rect(screen, color, (0, y, self.width, 1))

    def _is_sprite_visible(self, sprite_x, sprite_y):
        dx = sprite_x - self.player.pos.x
        dy = sprite_y - self.player.pos.y
        dist = math.hypot(dx, dy)
        if dist < 0.1:
            return True
        step = self.tile_size / 2
        steps = int(dist / step) + 1
        for i in range(steps):
            t = i / steps
            x = self.player.pos.x + dx * t
            y = self.player.pos.y + dy * t
            map_x = int(x // self.tile_size)
            map_y = int(y // self.tile_size)
            if 0 <= map_y < self.map_height and 0 <= map_x < self.map_width:
                cell = self.map_data[map_y][map_x]
                base_id = cell['base_id']
                # Пропускаем ID=7 (двери/ключи) и ID=6 (модели) – они не должны блокировать видимость
                if base_id in (6, 7):
                    continue
                if base_id != 0:
                    if base_id == 9 and cell.get('properties', {}).get('isvisible', False):
                        return False
                    elif base_id == 9:
                        continue
                    else:
                        return False
        return True

    def _is_walkable(self, x, y):
        map_x = int(x // self.tile_size)
        map_y = int(y // self.tile_size)
        if map_x < 0 or map_y < 0 or map_x >= self.map_width or map_y >= self.map_height:
            return False
        cell = self.map_data[map_y][map_x]
        base_id = cell['base_id']
        # Если стена невидима, она проходима
        is_visible = cell.get('properties', {}).get('isvisible', True)
        if base_id in (0, 8, 9) or (base_id in (1, 2, 3, 4, 5, 6) and not is_visible):
            return True
        if base_id == 7:
            props = cell.get('properties', {})
            if props.get('type') == 'key':
                return True
            if props.get('type') == 'door':
                door_id = props.get('id', None)
                if door_id and self.doors.get(door_id, {}).get('open', False):
                    return True
        return False

    def _draw_walls(self, screen, ray_results):
        if not ray_results:
            return
        bar_width = (self.width + self.rays - 1) // self.rays
        if bar_width < 1:
            bar_width = 1

        all_objects = []
        for res in ray_results:
            for depth, cell, wall_x in res.hit_objects:
                if cell is None:
                    continue
                base_id = cell['base_id']
                # Проверяем isVisible (по умолчанию True)
                is_visible = cell.get('properties', {}).get('isvisible', True)
                if not is_visible:
                    continue
                # Пропускаем ID=0, 6, 7, 8, 9 (они не стены)
                if base_id in (0, 2, 6, 7, 8, 9):
                    continue
                all_objects.append((depth, cell, res.ray_index, wall_x))

        all_objects.sort(key=lambda x: x[0], reverse=True)

        for depth, cell, ray_index, wall_x in all_objects:
            self._draw_single_wall(screen, ray_index, depth, cell, bar_width, wall_x)

    def _get_material_for_cell(self, cell):
        material_name = cell.get('properties', {}).get('material', None)
        if material_name is None:
            material_name = cell.get('properties', {}).get('sprite', None)
        if material_name is None:
            mat = self.material_lib.get_material(str(cell['base_id']))
        else:
            mat = self.material_lib.get_material(material_name)
        if mat is None:
            mat = self.material_lib.get_default()
        return mat

    def _get_scaled_texture(self, tex, height):
        if tex is None:
            return None
        tex_id = id(tex)
        key = (tex_id, height)
        if key in self.texture_cache:
            return self.texture_cache[key]
        if height <= 0:
            return None
        scaled = pygame.transform.scale(tex, (1, int(height)))
        self.texture_cache[key] = scaled
        return scaled

    def _draw_single_wall(self, screen, ray_index, depth, cell, bar_width, wall_x):
        if depth <= 0 or depth >= self.max_depth:
            return
        wall_x = wall_x % 1.0
        if wall_x < 0:
            wall_x += 1.0
        height = self.proj_coeff / depth
        if height > self.height:
            height = self.height

        # Если это стена (ID 1-5) и есть isVisible, но мы уже пропустили в _draw_walls
        # Здесь просто рисуем
        custom_height = cell.get('properties', {}).get('height', None)
        if custom_height is not None and cell['base_id'] in (1, 2, 3, 4, 5):
            wall_height = height * float(custom_height)
            floor_y = self.height // 2
            if wall_height > self.height:
                wall_height = self.height
            y = floor_y + (height - wall_height)
            if y < floor_y:
                y = floor_y
            if y + wall_height > self.height:
                wall_height = self.height - y
        else:
            wall_height = height
            y = self.height // 2 - wall_height // 2

        mat = self._get_material_for_cell(cell)

        color_hex = cell.get('properties', {}).get('color', None)
        if color_hex:
            hex_str = color_hex.lstrip('#')
            r = int(hex_str[0:2], 16)
            g = int(hex_str[2:4], 16)
            b = int(hex_str[4:6], 16)
            color = (r, g, b)
        else:
            color = mat.color
        if color is None:
            color = (200, 200, 200)

        ray_angle = self.player.angle - self.half_fov + (ray_index / self.rays) * self.fov
        hit_x = self.player.pos.x + depth * math.cos(ray_angle)
        hit_y = self.player.pos.y + depth * math.sin(ray_angle)
        point = pygame.math.Vector2(hit_x, hit_y)
        light = self.light_tracer.get_light_at_point(point)
        light = max(light, self.light_tracer.get_light_for_depth(depth) * 0.15)

        x = ray_index * bar_width

        if mat.texture is not None:
            scaled_tex = self._get_scaled_texture(mat.texture, wall_height)
            if scaled_tex is not None:
                orig_tex = mat.texture
                orig_w = orig_tex.get_width()
                orig_h = orig_tex.get_height()
                tx = int(wall_x * orig_w) % orig_w
                column = pygame.Surface((1, orig_h))
                for ty in range(orig_h):
                    try:
                        col = orig_tex.get_at((tx, ty))
                        col = (int(col[0] * light), int(col[1] * light), int(col[2] * light))
                        column.set_at((0, ty), col)
                    except:
                        pass
                scaled_column = pygame.transform.scale(column, (bar_width, int(wall_height)))
                screen.blit(scaled_column, (x, y))
            else:
                color = tuple(int(c * light) for c in color[:3])
                pygame.draw.rect(screen, color, (x, y, bar_width, wall_height))
        else:
            color = tuple(int(c * light) for c in color[:3])
            alpha = mat.alpha if hasattr(mat, 'alpha') else 1.0
            custom_alpha = cell.get('properties', {}).get('alpha', None)
            if custom_alpha is not None:
                alpha = float(custom_alpha)
            if alpha < 1.0:
                surf = pygame.Surface((bar_width, wall_height), pygame.SRCALPHA)
                surf.fill((*color, int(255 * alpha)))
                screen.blit(surf, (int(x), int(y)))
            else:
                pygame.draw.rect(screen, color, (x, y, bar_width, wall_height))

    def _draw_sprites(self, screen):
        sorted_sprites = self.sprite_manager.get_sorted(self.player.pos)
        for sprite in sorted_sprites:
            # Проверяем isVisible у спрайта (если есть ключ и свойство)
            if hasattr(sprite, 'visible') and not sprite.visible:
                continue
            # Для моделей проверяем isVisible через карту (если есть)
            if isinstance(sprite, (ModelSprite, AnimatedModelSprite)):
                # Проверяем, есть ли у модели свойство isvisible в данных карты
                # Для этого нужно хранить в спрайте ссылку на клетку или проверять по позиции
                # Упрощённо: используем атрибут visible, который можно установить через API
                if not sprite.visible:
                    continue

            if isinstance(sprite, AnimatedModelSprite):
                sprite.set_frame_by_angle(self.player.pos, self.player.angle)
                texture = sprite.get_current_texture()
            elif isinstance(sprite, ModelSprite):
                sprite.set_frame_by_angle(self.player.pos, self.player.angle)
                texture = sprite.frames[sprite.current_frame] if sprite.frames else None
            else:
                texture = sprite.texture

            if texture is None:
                continue

            if not self._is_sprite_visible(sprite.x, sprite.y):
                continue
            dx = sprite.x - self.player.pos.x
            dy = sprite.y - self.player.pos.y
            dist = math.hypot(dx, dy)
            if dist < 0.1:
                continue

            angle_to_sprite = math.atan2(dy, dx)
            relative_angle = angle_to_sprite - self.player.angle
            while relative_angle < -math.pi:
                relative_angle += 2 * math.pi
            while relative_angle > math.pi:
                relative_angle -= 2 * math.pi

            if abs(relative_angle) > self.half_fov:
                continue

            screen_x = (relative_angle / self.fov + 0.5) * self.width
            size = self.proj_coeff / dist
            if size > self.height:
                size = self.height
            if size < 1:
                size = 1

            point = pygame.Vector2(sprite.x, sprite.y)
            light = self.light_tracer.get_light_at_point(point)
            light = max(light, self.light_tracer.get_light_for_depth(dist) * 0.2)

            if texture:
                shaded = texture.copy()
                shaded.fill((int(255 * light), int(255 * light), int(255 * light)), special_flags=pygame.BLEND_RGB_MULT)
                scaled = pygame.transform.scale(shaded, (int(size), int(size)))
                screen.blit(scaled, (screen_x - size // 2, self.height // 2 - size // 2))

    def _hex_to_rgb(self, hex_str):
        hex_str = hex_str.lstrip('#')
        return (int(hex_str[0:2], 16), int(hex_str[2:4], 16), int(hex_str[4:6], 16))