# gradus_rc/polygon/sprite_renderer.py
import pygame
import math
from .mesh import MeshObject, MeshManager


def render_model_to_sprites(mesh_obj, engine, num_angles=16, sprite_size=(256, 256)):
    """
    Рендерит 3D-модель в спрайты с разных углов.
    Возвращает список спрайтов (Surface) для каждого угла.
    """
    sprites = []
    # Сохраняем исходную позицию игрока
    original_pos = engine.player.pos.copy()
    original_angle = engine.player.angle

    # Создаём временную поверхность для рендеринга
    temp_surf = pygame.Surface(sprite_size, pygame.SRCALPHA)

    # Масштабируем модель так, чтобы она помещалась в спрайт
    # Для этого находим bounding box модели
    if not mesh_obj.vertices:
        return []

    min_x = min(v[0] for v in mesh_obj.vertices)
    max_x = max(v[0] for v in mesh_obj.vertices)
    min_y = min(v[1] for v in mesh_obj.vertices)
    max_y = max(v[1] for v in mesh_obj.vertices)
    min_z = min(v[2] for v in mesh_obj.vertices)
    max_z = max(v[2] for v in mesh_obj.vertices)

    # Размер модели в локальных координатах
    model_width = max(max_x - min_x, max_z - min_z)
    model_height = max_y - min_y
    max_dim = max(model_width, model_height)
    if max_dim == 0:
        max_dim = 1

    # Целевой размер в пикселях (чтобы модель занимала ~80% спрайта)
    target_size = min(sprite_size) * 0.7
    scale_factor = target_size / (max_dim * mesh_obj.scale * mesh_obj.tile_size)
    # Но мы не можем менять масштаб mesh_obj напрямую, поэтому временно подменим

    # Создаём временный mesh с изменённым масштабом
    # Для простоты будем использовать существующий mesh_obj, но временно изменим его scale
    original_scale = mesh_obj.scale
    mesh_obj.scale = original_scale * scale_factor

    # Позиция модели (центр спрайта)
    center_x = sprite_size[0] // 2
    center_y = sprite_size[1] // 2

    for i in range(num_angles):
        angle = (i / num_angles) * 2 * math.pi
        # Устанавливаем угол поворота модели
        mesh_obj.rotation = angle

        # Подменяем позицию игрока на фиксированную точку, смотрящую на модель
        # Ставим камеру на расстоянии, чтобы модель помещалась в спрайт
        distance = max_dim * 3.0  # расстояние в мировых единицах
        engine.player.pos.x = mesh_obj.x + distance * math.sin(angle)
        engine.player.pos.y = mesh_obj.y + distance * math.cos(angle)
        engine.player.angle = angle + math.pi  # смотрим на модель

        # Очищаем поверхность
        temp_surf.fill((0, 0, 0, 0))

        # Рендерим модель на поверхность используя MeshManager
        # Для этого нам нужно временно подменить engine.width и height
        orig_width = engine.width
        orig_height = engine.height
        engine.width = sprite_size[0]
        engine.height = sprite_size[1]

        # Рендерим модель
        # Создаём временный менеджер с одним mesh
        temp_manager = MeshManager(engine)
        temp_manager.add_mesh(mesh_obj)
        temp_manager.render(temp_surf)

        # Восстанавливаем размеры
        engine.width = orig_width
        engine.height = orig_height

        # Сохраняем спрайт
        sprites.append(temp_surf.copy())

    # Восстанавливаем исходные параметры
    mesh_obj.scale = original_scale
    engine.player.pos.x = original_pos.x
    engine.player.pos.y = original_pos.y
    engine.player.angle = original_angle

    return sprites