import os
import math
import pygame

class MeshObject:
    def __init__(self, filepath, x, y, rotation=0.0, scale=1.0, tile_size=64):
        self.x = x
        self.y = y
        self.rotation = math.radians(rotation)
        self.scale = scale
        self.tile_size = tile_size
        self.vertices = []
        self.faces = []
        self.color = (200, 100, 100)
        if os.path.exists(filepath):
            self.load_obj(filepath)
        else:
            print(f"Mesh file not found: {filepath}")

    def load_obj(self, filepath):
        with open(filepath, 'r') as f:
            vertices = []
            faces = []
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                parts = line.split()
                if parts[0] == 'v':
                    x = float(parts[1])
                    y = float(parts[2])
                    z = float(parts[3])
                    vertices.append((x, y, z))
                elif parts[0] == 'f':
                    face_indices = []
                    for part in parts[1:]:
                        idx_str = part.split('/')[0]
                        if idx_str:
                            try:
                                idx = int(idx_str) - 1
                                face_indices.append(idx)
                            except ValueError:
                                pass
                    if len(face_indices) >= 3:
                        if len(face_indices) == 3:
                            faces.append(tuple(face_indices))
                        elif len(face_indices) == 4:
                            faces.append((face_indices[0], face_indices[1], face_indices[2]))
                            faces.append((face_indices[0], face_indices[2], face_indices[3]))
            self.vertices = vertices
            self.faces = faces
            print(f"Loaded {len(self.vertices)} vertices, {len(self.faces)} faces")

    def render_to_sprites(self, num_angles=16, sprite_size=(256, 256)):
        if not self.vertices:
            print("No vertices, returning empty")
            return []
        sprites = []
        for i in range(num_angles):
            angle = (i / num_angles) * 2 * math.pi
            surf = pygame.Surface(sprite_size, pygame.SRCALPHA)
            surf.fill((0, 0, 0, 0))

            cos_a = math.cos(angle)
            sin_a = math.sin(angle)
            pts = []
            for v in self.vertices:
                sx = v[0] * self.scale * self.tile_size
                sy = v[1] * self.scale * self.tile_size
                sz = v[2] * self.scale * self.tile_size
                x_rot = sx * cos_a - sz * sin_a
                z_rot = sx * sin_a + sz * cos_a
                pts.append((x_rot, sy, z_rot))

            if not pts:
                continue

            # Bounding box
            min_x = min(p[0] for p in pts)
            max_x = max(p[0] for p in pts)
            min_y = min(p[1] for p in pts)
            max_y = max(p[1] for p in pts)

            # Масштабирование для вписывания в спрайт
            # Если модель имеет нулевой размер, используем 1
            width = max_x - min_x
            height = max_y - min_y
            if width == 0:
                width = 1
            if height == 0:
                height = 1

            scale_fit = min(
                (sprite_size[0] * 0.8) / width,
                (sprite_size[1] * 0.8) / height,
                10.0  # ограничим, чтобы не слишком увеличивать
            )

            cx = (min_x + max_x) / 2
            cy = (min_y + max_y) / 2

            # Рисуем треугольники
            for face in self.faces:
                if len(face) < 3:
                    continue
                try:
                    p1 = pts[face[0]]
                    p2 = pts[face[1]]
                    p3 = pts[face[2]]
                except IndexError:
                    continue

                def to_screen(p):
                    x = (p[0] - cx) * scale_fit + sprite_size[0] / 2
                    y = (p[1] - cy) * scale_fit + sprite_size[1] / 2
                    return (int(x), int(y))

                # Рисуем треугольник с небольшим контуром для чёткости
                color = self.color
                pygame.draw.polygon(surf, color, [to_screen(p1), to_screen(p2), to_screen(p3)])
                # Добавляем контур (чтобы было видно грани)
                pygame.draw.polygon(surf, (0, 0, 0, 100), [to_screen(p1), to_screen(p2), to_screen(p3)], 1)

            # Если ничего не нарисовалось (модель пуста), создаём заглушку
            if surf.get_locked():
                surf.unlock()
            # Проверяем, есть ли на поверхности хоть один пиксель
            if surf.get_width() > 0 and surf.get_height() > 0:
                # Проверяем, что поверхность не полностью прозрачна
                rect = surf.get_bounding_rect()
                if rect.width == 0 or rect.height == 0:
                    # Модель не отобразилась, рисуем заглушку
                    pygame.draw.rect(surf, (255, 0, 0, 200), (50, 50, 156, 156))
            sprites.append(surf)

        print(f"Generated {len(sprites)} sprites")
        return sprites