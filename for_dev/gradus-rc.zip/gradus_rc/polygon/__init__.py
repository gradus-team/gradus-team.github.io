from .mesh import MeshObject
from .obj_to_sprites import obj_to_sprites