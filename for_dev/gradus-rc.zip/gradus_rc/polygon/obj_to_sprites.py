import os
import math
import pygame
import numpy as np

try:
    import trimesh
except ImportError:
    trimesh = None

try:
    import pywavefront
except ImportError:
    pywavefront = None

def obj_to_sprites(filepath, num_angles=32, sprite_size=(256, 256), scale=1.0, color=(200, 100, 100), tilt_angle=30,
                   model_rot_x=0.0, model_rot_y=0.0, model_rot_z=0.0):
    """
    Рендерит .obj в спрайты с разных горизонтальных углов.
    model_rot_x, model_rot_y, model_rot_z – повороты модели вокруг осей X, Y, Z (в градусах).
    """
    if not os.path.exists(filepath):
        print(f"File not found: {filepath}")
        return []

    print(f"Generating sprites with rotX={model_rot_x}, rotY={model_rot_y}, rotZ={model_rot_z}")

    vertices = None
    faces = None
    normals = None

    # --- Загрузка модели (как раньше, без изменений) ---
    if trimesh is not None:
        try:
            mesh = trimesh.load(filepath)
            if hasattr(mesh, 'vertices') and hasattr(mesh, 'faces') and len(mesh.faces) > 0:
                vertices = np.array(mesh.vertices)
                faces = np.array(mesh.faces)
                if hasattr(mesh, 'face_normals') and len(mesh.face_normals) > 0:
                    normals = np.array(mesh.face_normals)
                else:
                    normals = []
                    for f in faces:
                        v1 = vertices[f[0]]
                        v2 = vertices[f[1]]
                        v3 = vertices[f[2]]
                        edge1 = v2 - v1
                        edge2 = v3 - v1
                        normal = np.cross(edge1, edge2)
                        norm = np.linalg.norm(normal)
                        if norm > 0:
                            normal = normal / norm
                        else:
                            normal = np.array([0,0,1])
                        normals.append(normal)
                    normals = np.array(normals)
                print(f"trimesh loaded: {len(vertices)} vertices, {len(faces)} faces")
            else:
                raise ValueError("No faces found")
        except Exception as e:
            print(f"trimesh failed: {e}")
            vertices = None
            faces = None

    if vertices is None and pywavefront is not None:
        try:
            scene = pywavefront.Wavefront(filepath, collect_faces=True)
            if scene.vertices and scene.meshes:
                verts = scene.vertices
                vertices = np.array([(verts[i], verts[i+1], verts[i+2]) for i in range(0, len(verts), 3)])
                faces = []
                for mesh_name, mesh in scene.meshes.items():
                    f_indices = mesh.faces
                    for i in range(0, len(f_indices), 3):
                        faces.append((f_indices[i], f_indices[i+1], f_indices[i+2]))
                faces = np.array(faces)
                normals = []
                for f in faces:
                    v1 = vertices[f[0]]
                    v2 = vertices[f[1]]
                    v3 = vertices[f[2]]
                    edge1 = v2 - v1
                    edge2 = v3 - v1
                    normal = np.cross(edge1, edge2)
                    norm = np.linalg.norm(normal)
                    if norm > 0:
                        normal = normal / norm
                    else:
                        normal = np.array([0,0,1])
                    normals.append(normal)
                normals = np.array(normals)
                print(f"pywavefront loaded: {len(vertices)} vertices, {len(faces)} faces")
        except Exception as e:
            print(f"pywavefront failed: {e}")

    if vertices is None or faces is None:
        print("No valid .obj parser found or file corrupted")
        return []

    # Центрируем модель
    center = np.mean(vertices, axis=0)

    # --- Углы в радианах ---
    rx = math.radians(model_rot_x)
    ry = math.radians(model_rot_y)
    rz = math.radians(model_rot_z)
    tilt = math.radians(tilt_angle)

    # --- Матрицы поворота (X, Y, Z) ---
    # --- Углы в радианах ---
    rx = math.radians(model_rot_x + 210)  # rotX теперь будет влиять на горизонтальный поворот (вокруг Y)
    ry = math.radians(model_rot_y)  # rotY теперь будет влиять на вертикальный поворот (вокруг X)
    rz = math.radians(model_rot_z)

    # Матрицы поворота
    # rotX → поворачиваем вокруг Y
    rot_x_effect = np.array([[math.cos(rx), 0, math.sin(rx)],
                             [0, 1, 0],
                             [-math.sin(rx), 0, math.cos(rx)]])
    # rotY → поворачиваем вокруг X
    rot_y_effect = np.array([[1, 0, 0],
                             [0, math.cos(ry), -math.sin(ry)],
                             [0, math.sin(ry), math.cos(ry)]])
    # rotZ остаётся вокруг Z
    rot_z_effect = np.array([[math.cos(rz), -math.sin(rz), 0],
                             [math.sin(rz), math.cos(rz), 0],
                             [0, 0, 1]])

    # Порядок: сначала rotX_effect (как rotX), затем rotY_effect, затем rotZ_effect
    rot_model = rot_z_effect @ rot_y_effect @ rot_x_effect

    # Наклон камеры (вокруг X)
    rot_tilt = np.array([[1, 0, 0],
                         [0, math.cos(tilt), -math.sin(tilt)],
                         [0, math.sin(tilt), math.cos(tilt)]])

    sprites = []
    for i in range(num_angles):
        angle = (i / num_angles) * 2 * math.pi
        surf = pygame.Surface(sprite_size, pygame.SRCALPHA)
        surf.fill((0, 0, 0, 0))

        # Ракурс (поворот вокруг Y)
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)
        rot_view = np.array([[cos_a, 0, sin_a],
                             [0, 1, 0],
                             [-sin_a, 0, cos_a]])

        # Общая матрица: модель -> наклон камеры -> ракурс
        rot_mat = rot_view @ rot_tilt @ rot_model

        # Применяем к вершинам
        transformed = []
        for v in vertices:
            v_centered = v - center
            v_rot = rot_mat.dot(v_centered)
            v_scaled = v_rot * scale
            transformed.append(v_scaled)

        # Сбор треугольников (с отсечением по нормали)
        tri_data = []
        for idx, f in enumerate(faces):
            p1 = transformed[f[0]]
            p2 = transformed[f[1]]
            p3 = transformed[f[2]]
            cx = (p1[0] + p2[0] + p3[0]) / 3
            cy = (p1[1] + p2[1] + p3[1]) / 3
            cz = (p1[2] + p2[2] + p3[2]) / 3
            normal = normals[idx] if idx < len(normals) else np.array([0,0,1])
            n_rot = rot_mat.dot(normal)
            if n_rot[2] < 0:   # грань смотрит от камеры
                continue
            tri_data.append((cz, p1, p2, p3, n_rot))

        tri_data.sort(key=lambda x: x[0], reverse=True)

        all_pts = []
        for _, p1, p2, p3, _ in tri_data:
            all_pts.extend([p1, p2, p3])
        if not all_pts:
            continue
        min_x = min(p[0] for p in all_pts)
        max_x = max(p[0] for p in all_pts)
        min_y = min(p[1] for p in all_pts)
        max_y = max(p[1] for p in all_pts)

        margin = 0.1
        fit_w = sprite_size[0] * (1 - 2 * margin)
        fit_h = sprite_size[1] * (1 - 2 * margin)
        scale_fit = min(
            fit_w / (max_x - min_x + 0.1) if max_x != min_x else 1,
            fit_h / (max_y - min_y + 0.1) if max_y != min_y else 1
        )
        if scale_fit < 0.1:
            scale_fit = 0.1

        cx_screen = (min_x + max_x) / 2
        cy_screen = (min_y + max_y) / 2

        for _, p1, p2, p3, normal in tri_data:
            def to_screen(p):
                x = (p[0] - cx_screen) * scale_fit + sprite_size[0] / 2
                y = (p[1] - cy_screen) * scale_fit + sprite_size[1] / 2
                return (int(x), int(y))

            light_dir = np.array([0, 0, 1])
            n = normal / np.linalg.norm(normal)
            diff = np.dot(n, light_dir)
            intensity = 0.3 + 0.7 * max(0, diff)
            colored = tuple(int(c * intensity) for c in color)

            pygame.draw.polygon(surf, colored, [to_screen(p1), to_screen(p2), to_screen(p3)])

        sprites.append(surf)

    return sprites