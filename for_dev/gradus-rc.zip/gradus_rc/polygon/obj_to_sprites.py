import os
import math
import time

import pygame
import numpy as np

try:
    import trimesh
except ImportError:
    trimesh = None

try:
    import pywavefront
except ImportError:
    pywavefront = None

def _parse_obj_manual(filepath):
    vertices = []
    faces = []
    face_colors = []
    with open(filepath, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split()
            if parts[0] == 'v':
                vertices.append((float(parts[1]), float(parts[2]), float(parts[3])))
            elif parts[0] == 'f':
                color = None
                indices = []
                for p in parts[1:]:
                    if len(p) == 6 and all(c in '0123456789ABCDEFabcdef' for c in p):
                        r = int(p[0:2], 16) / 255.0
                        g = int(p[2:4], 16) / 255.0
                        b = int(p[4:6], 16) / 255.0
                        color = (r, g, b)
                    else:
                        idx = int(p.split('/')[0]) - 1
                        indices.append(idx)
                if len(indices) == 3:
                    faces.append(tuple(indices))
                    face_colors.append(color)
                elif len(indices) == 4:
                    faces.append((indices[0], indices[1], indices[2]))
                    face_colors.append(color)
                    faces.append((indices[0], indices[2], indices[3]))
                    face_colors.append(color)
    return vertices, faces, face_colors

def obj_to_sprites(filepath, num_angles=64, sprite_size=(512, 512), scale=1.0, color=(200, 100, 100), tilt_angle=30,
                   model_rot_x=0.0, model_rot_y=0.0, model_rot_z=0.0):
    if not os.path.exists(filepath):
        print(f"File not found: {filepath}")
        return []

    # Нормализуем общий цвет, если он в диапазоне 0..255
    if color and isinstance(color, tuple) and max(color) > 1.0:
        color = tuple(c / 255.0 for c in color)

    print(f"Generating sprites with rotX={model_rot_x}, rotY={model_rot_y}, rotZ={model_rot_z}")

    vertices = None
    faces = None
    face_colors = None
    normals = None

    # Для .gbj используем ручной парсер
    if 'gbj' in filepath.lower():
        try:
            vertices_list, faces_list, face_colors_list = _parse_obj_manual(filepath)
            if vertices_list and faces_list:
                vertices = np.array(vertices_list)
                faces = np.array(faces_list)
                face_colors = face_colors_list
                normals = []
                for f in faces:
                    v1 = vertices[f[0]]
                    v2 = vertices[f[1]]
                    v3 = vertices[f[2]]
                    edge1 = v2 - v1
                    edge2 = v3 - v1
                    normal = np.cross(edge1, edge2)
                    norm = np.linalg.norm(normal)
                    if norm > 0:
                        normal = normal / norm
                    else:
                        normal = np.array([0,0,1])
                    normals.append(normal)
                normals = np.array(normals)
                print(f"Manual parser loaded: {len(vertices)} vertices, {len(faces)} faces")
            else:
                print("Manual parser returned empty data")
                return []
        except Exception as e:
            print(f"Manual parse failed: {e}")
            return []
    else:
        # Для .obj используем trimesh или pywavefront
        if trimesh is not None:
            try:
                mesh = trimesh.load(filepath)
                if hasattr(mesh, 'vertices') and hasattr(mesh, 'faces') and len(mesh.faces) > 0:
                    vertices = np.array(mesh.vertices)
                    faces = np.array(mesh.faces)
                    if hasattr(mesh, 'face_normals') and len(mesh.face_normals) > 0:
                        normals = np.array(mesh.face_normals)
                    else:
                        normals = []
                        for f in faces:
                            v1 = vertices[f[0]]
                            v2 = vertices[f[1]]
                            v3 = vertices[f[2]]
                            edge1 = v2 - v1
                            edge2 = v3 - v1
                            normal = np.cross(edge1, edge2)
                            norm = np.linalg.norm(normal)
                            if norm > 0:
                                normal = normal / norm
                            else:
                                normal = np.array([0,0,1])
                            normals.append(normal)
                        normals = np.array(normals)
                    face_colors = None
                    print(f"trimesh loaded: {len(vertices)} vertices, {len(faces)} faces")
            except Exception as e:
                print(f"trimesh failed: {e}")
                vertices = None
                faces = None

        if vertices is None and pywavefront is not None:
            try:
                scene = pywavefront.Wavefront(filepath, collect_faces=True)
                if scene.vertices and scene.meshes:
                    verts = scene.vertices
                    vertices = np.array([(verts[i], verts[i+1], verts[i+2]) for i in range(0, len(verts), 3)])
                    faces = []
                    for mesh_name, mesh in scene.meshes.items():
                        f_indices = mesh.faces
                        for i in range(0, len(f_indices), 3):
                            faces.append((f_indices[i], f_indices[i+1], f_indices[i+2]))
                    faces = np.array(faces)
                    normals = []
                    for f in faces:
                        v1 = vertices[f[0]]
                        v2 = vertices[f[1]]
                        v3 = vertices[f[2]]
                        edge1 = v2 - v1
                        edge2 = v3 - v1
                        normal = np.cross(edge1, edge2)
                        norm = np.linalg.norm(normal)
                        if norm > 0:
                            normal = normal / norm
                        else:
                            normal = np.array([0,0,1])
                        normals.append(normal)
                    normals = np.array(normals)
                    face_colors = None
                    print(f"pywavefront loaded: {len(vertices)} vertices, {len(faces)} faces")
            except Exception as e:
                print(f"pywavefront failed: {e}")
                vertices = None
                faces = None

        if vertices is None:
            try:
                vertices_list, faces_list, face_colors_list = _parse_obj_manual(filepath)
                if vertices_list and faces_list:
                    vertices = np.array(vertices_list)
                    faces = np.array(faces_list)
                    face_colors = face_colors_list
                    normals = []
                    for f in faces:
                        v1 = vertices[f[0]]
                        v2 = vertices[f[1]]
                        v3 = vertices[f[2]]
                        edge1 = v2 - v1
                        edge2 = v3 - v1
                        normal = np.cross(edge1, edge2)
                        norm = np.linalg.norm(normal)
                        if norm > 0:
                            normal = normal / norm
                        else:
                            normal = np.array([0,0,1])
                        normals.append(normal)
                    normals = np.array(normals)
                    print(f"Manual parser loaded: {len(vertices)} vertices, {len(faces)} faces")
            except Exception as e:
                print(f"Manual parse failed: {e}")
                vertices = None
                faces = None

    if vertices is None or faces is None:
        print("No valid .obj parser found or file corrupted")
        return []

    center = np.mean(vertices, axis=0)

    # --- Повороты модели (как в старом рабочем коде) ---
    rx = math.radians(model_rot_x)  # сдвиг, который был раньше
    ry = math.radians(model_rot_y)
    rz = math.radians(model_rot_z)

    print(f"Angles for {filepath}: rx={math.degrees(rx):.1f}, ry={math.degrees(ry):.1f}, rz={math.degrees(rz):.1f}")
    tilt = math.radians(tilt_angle)

    rot_x_effect = np.array([[math.cos(rx), 0, math.sin(rx)],
                             [0, 1, 0],
                             [-math.sin(rx), 0, math.cos(rx)]])
    rot_y_effect = np.array([[1, 0, 0],
                             [0, math.cos(ry), -math.sin(ry)],
                             [0, math.sin(ry), math.cos(ry)]])
    rot_z_effect = np.array([[math.cos(rz), -math.sin(rz), 0],
                             [math.sin(rz), math.cos(rz), 0],
                             [0, 0, 1]])

    rot_model = rot_z_effect @ rot_y_effect @ rot_x_effect

    rot_tilt = np.array([[1, 0, 0],
                         [0, math.cos(tilt), -math.sin(tilt)],
                         [0, math.sin(tilt), math.cos(tilt)]])

    sprites = []
    for i in range(num_angles):
        if 'gbj' in filepath.lower():
            angle = - (i / num_angles) * 2 * math.pi
        else:
            angle = (i / num_angles) * 2 * math.pi
        surf = pygame.Surface(sprite_size, pygame.SRCALPHA)
        surf.fill((0, 0, 0, 0))

        cos_a = math.cos(angle)
        sin_a = math.sin(angle)
        rot_view = np.array([[cos_a, 0, sin_a],
                             [0, 1, 0],
                             [-sin_a, 0, cos_a]])

        rot_mat = rot_view @ rot_tilt @ rot_model

        transformed = []
        for v in vertices:
            v_centered = v - center
            v_rot = rot_mat.dot(v_centered)
            v_scaled = v_rot * scale
            transformed.append(v_scaled)

        tri_data = []
        for idx, f in enumerate(faces):
            p1 = transformed[f[0]]
            p2 = transformed[f[1]]
            p3 = transformed[f[2]]
            normal = normals[idx] if idx < len(normals) else np.array([0,0,1])
            n_rot = rot_mat.dot(normal)
            if n_rot[2] < 0:
                continue
            cz = (p1[2] + p2[2] + p3[2]) / 3
            tri_data.append((cz, p1, p2, p3, idx, n_rot))

        tri_data.sort(key=lambda x: x[0], reverse=True)

        all_pts = []
        for _, p1, p2, p3, _, _ in tri_data:
            all_pts.extend([p1, p2, p3])
        if not all_pts:
            sprites.append(pygame.Surface(sprite_size, pygame.SRCALPHA))
            continue
        min_x = min(p[0] for p in all_pts)
        max_x = max(p[0] for p in all_pts)
        min_y = min(p[1] for p in all_pts)
        max_y = max(p[1] for p in all_pts)

        margin = 0.1
        fit_w = sprite_size[0] * (1 - 2 * margin)
        fit_h = sprite_size[1] * (1 - 2 * margin)
        scale_fit = min(
            fit_w / (max_x - min_x + 0.1) if max_x != min_x else 1,
            fit_h / (max_y - min_y + 0.1) if max_y != min_y else 1
        )
        if scale_fit < 0.1:
            scale_fit = 0.1

        cx_screen = (min_x + max_x) / 2
        cy_screen = (min_y + max_y) / 2

        light_dir = np.array([0, 0, 1])
        for _, p1, p2, p3, idx, n_rot in tri_data:
            def to_screen(p):
                x = (p[0] - cx_screen) * scale_fit + sprite_size[0] / 2
                y = (p[1] - cy_screen) * scale_fit + sprite_size[1] / 2
                return (int(x), int(y))

            # Цвет грани
            if face_colors is not None and idx < len(face_colors) and face_colors[idx] is not None:
                base_color = face_colors[idx]
            else:
                base_color = color

            # Освещение
            n = n_rot / np.linalg.norm(n_rot) if np.linalg.norm(n_rot) > 0 else np.array([0,0,1])
            diff = np.dot(n, light_dir)
            intensity = 0.3 + 0.7 * max(0, diff)
            col = tuple(int(c * intensity * 255) for c in base_color)

            pygame.draw.polygon(surf, col, [to_screen(p1), to_screen(p2), to_screen(p3)])

        sprites.append(surf)

    return sprites