import pygame
import math

class LightSource:
    def __init__(self, x, y, radius, intensity=1.0, color=(255,255,255)):
        self.x = x
        self.y = y
        self.radius = radius
        self.intensity = intensity
        self.color = color

class LightTracer:
    def __init__(self, map_data, tile_size):
        self.ambient_light = 0.03   # по умолчанию почти темно
        self.map_data = map_data
        self.tile_size = tile_size
        self.light_sources = []
        self.player_light_pos = None
        self.player_light_angle = 0.0
        self.player_light_radius = 200
        self.player_light_radius_sq = 200 ** 2
        self.player_light_intensity = 0.7   # тусклый
        self.player_light_color = (255, 200, 100)  # желтоватый

    def update_player_light(self, pos, angle, radius=200, intensity=0.3, color=(255,200,100)):
        self.player_light_pos = pos
        self.player_light_angle = angle
        self.player_light_radius = radius
        self.player_light_intensity = intensity
        self.player_light_color = color

    def add_source(self, source):
        self.light_sources.append(source)

    def get_light_at_point(self, point):
        total = 0.0
        px, py = point.x, point.y
        for src in self.light_sources:
            dx = px - src.x
            dy = py - src.y
            dist_sq = dx * dx + dy * dy
            src.radius_sq = src.radius * src.radius
            if dist_sq < src.radius_sq:
                dist = math.sqrt(dist_sq)
                light = (1.0 - dist / src.radius) * src.intensity
                if light > total:
                    total = light
        if self.player_light_pos:
            dx = px - self.player_light_pos.x
            dy = py - self.player_light_pos.y
            dist_sq = dx * dx + dy * dy
            if dist_sq < self.player_light_radius_sq:
                dist = math.sqrt(dist_sq)
                # Угол можно опустить для скорости, если не критично
                light = (1.0 - dist / self.player_light_radius) * self.player_light_intensity
                if light > total:
                    total = light
        return min(1.0, total)

    def get_light_for_depth(self, depth):
        return max(0.0, 1.0 - depth / 1000.0)