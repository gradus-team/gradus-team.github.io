import pygame
import math

class LightSource:
    def __init__(self, x, y, radius, intensity=1.0, color=(255,255,255)):
        self.x = x
        self.y = y
        self.radius = radius
        self.intensity = intensity
        self.color = color

class LightTracer:
    def __init__(self, map_data, tile_size):
        self.ambient_light = 0.03   # по умолчанию почти темно
        self.map_data = map_data
        self.tile_size = tile_size
        self.light_sources = []
        self.player_light_pos = None
        self.player_light_angle = 0.0
        self.player_light_radius = 200
        self.player_light_intensity = 0.7   # тусклый
        self.player_light_color = (255, 200, 100)  # желтоватый

    def update_player_light(self, pos, angle, radius=200, intensity=0.3, color=(255,200,100)):
        self.player_light_pos = pos
        self.player_light_angle = angle
        self.player_light_radius = radius
        self.player_light_intensity = intensity
        self.player_light_color = color

    def add_source(self, source):
        self.light_sources.append(source)

    def get_light_at_point(self, point):
        total = self.ambient_light  # базовое освещение (почти ноль)
        if self.player_light_pos:
            dx = point.x - self.player_light_pos.x
            dy = point.y - self.player_light_pos.y
            dist = math.hypot(dx, dy)
            if dist < self.player_light_radius:
                angle_to_point = math.atan2(dy, dx)
                angle_diff = angle_to_point - self.player_light_angle
                angle_diff = (angle_diff + math.pi) % (2 * math.pi) - math.pi
                if abs(angle_diff) < math.radians(40):
                    factor = 1.0 - (abs(angle_diff) / math.radians(40))
                    light = (1.0 - dist / self.player_light_radius) * self.player_light_intensity * factor
                    total = max(total, light)
        for src in self.light_sources:
            dx = point.x - src.x
            dy = point.y - src.y
            dist = math.hypot(dx, dy)
            if dist < src.radius:
                light = (1.0 - dist / src.radius) * src.intensity
                total = max(total, light)
        return min(1.0, total)

    def get_light_for_depth(self, depth):
        return max(0.0, 1.0 - depth / 1000.0)