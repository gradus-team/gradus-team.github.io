import math

class Gun:
    def __init__(self, name='gun', damage=10, fire_rate=0.5, ammo=12,
                 max_ammo=12, texture=None, key=None,
                 animation_fire=None, animation_walk=None,
                 walk_frame_delay=0.2, reload_speed=4.0):
        self.name = name
        self.damage = damage
        self.fire_rate = fire_rate
        self.ammo = ammo
        self.reload = reload_speed
        self.am_size = ammo
        self.max_ammo = max_ammo
        self.texture = texture
        self.key = key
        self.animation_fire = animation_fire or []
        self.animation_walk = animation_walk or []
        self.fire_anim_timer = 0.0
        self.fire_frame_index = 0
        self.walk_anim_timer = 0.0
        self.walk_frame_index = 0
        self.walk_frame_delay = walk_frame_delay
        self.fire_timer = 0.0
        self._fire_playing = False

    def can_fire(self):
        return self.ammo > 0 and self.fire_timer <= 0

    def fire(self):
        if not self.can_fire():
            return False
        self.ammo -= 1
        self.fire_timer = self.fire_rate
        if self.animation_fire:
            self._fire_playing = True
            self.fire_frame_index = 0
            self.fire_anim_timer = 0.0
        if self.ammo == 0:
            self.fire_timer = self.reload
            if self.max_ammo > self.am_size:
                self.max_ammo -= self.am_size
                self.ammo = self.am_size
            elif self.max_ammo > 0:
                self.ammo = self.max_ammo
                self.max_ammo = 0
            else:
                self.fire_timer = self.reload
                self.max_ammo = self.am_size * 4
                self.ammo = self.am_size

        return True

    def update(self, dt):
        if self.fire_timer > 0:
            self.fire_timer -= dt
        if self._fire_playing:
            self.fire_anim_timer += dt
            if self.fire_anim_timer >= 0.1:
                self.fire_anim_timer = 0.0
                self.fire_frame_index += 1
                if self.fire_frame_index >= len(self.animation_fire):
                    self.fire_frame_index = 0
                    self._fire_playing = False
        self.walk_anim_timer += dt
        if self.walk_anim_timer >= self.walk_frame_delay:
            self.walk_anim_timer = 0.0
            self.walk_frame_index = (self.walk_frame_index + 1) % max(1, len(self.animation_walk))

    def get_current_texture(self, moving=False):
        if self._fire_playing and self.animation_fire:
            return self.animation_fire[self.fire_frame_index]
        if moving and self.animation_walk:
            return self.animation_walk[self.walk_frame_index]
        return self.texture

class Bullet:
    def __init__(self, x, y, angle, damage=10, speed=500, owner=None):
        self.x = x
        self.y = y
        self.angle = angle
        self.damage = damage
        self.speed = speed
        self.owner = owner  # 'player' или EnemyAI
        self.alive = True

    def update(self, dt):
        self.x += math.cos(self.angle) * self.speed * dt
        self.y += math.sin(self.angle) * self.speed * dt

class GunManager:
    def __init__(self):
        self.guns = {}
        self.current_gun_key = None

    def add_gun(self, gun):
        self.guns[gun.key] = gun
        if self.current_gun_key is None:
            self.current_gun_key = gun.key

    def switch_gun(self, key):
        if key in self.guns:
            self.current_gun_key = key

    def get_current_gun(self):
        return self.guns.get(self.current_gun_key)

    def update(self, dt):
        for gun in self.guns.values():
            gun.update(dt)

    def fire_current(self):
        gun = self.get_current_gun()
        if gun and gun.fire():
            return gun
        return None