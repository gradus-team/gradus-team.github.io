import heapq


def astar(start, goal, walkable_fn, max_iter=500):
    """
    A* по 8 направлениям.
    start, goal — (x, y) в тайлах.
    walkable_fn(x, y) — bool, проходима ли клетка.
    Возвращает список (x, y) от start до goal (не включая start), или [].
    """
    if start == goal:
        return []
    if not walkable_fn(*goal):
        return []

    open_set = [(0, start)]
    came_from = {}
    g_score = {start: 0}
    neighbors = [(1, 0), (-1, 0), (0, 1), (0, -1),
                 (1, 1), (1, -1), (-1, 1), (-1, -1)]
    iterations = 0

    while open_set and iterations < max_iter:
        iterations += 1
        _, current = heapq.heappop(open_set)

        if current == goal:
            path = [current]
            while current in came_from:
                current = came_from[current]
                path.append(current)
            path.reverse()
            return path[1:]  # без стартовой клетки

        cx, cy = current
        for ddx, ddy in neighbors:
            nx, ny = cx + ddx, cy + ddy
            # диагональ — проверяем обе смежные клетки, чтобы не резать углы
            if ddx != 0 and ddy != 0:
                if not (walkable_fn(cx + ddx, cy) and
                        walkable_fn(cx, cy + ddy)):
                    continue
            if not walkable_fn(nx, ny):
                continue

            step = 1.414 if (ddx and ddy) else 1.0
            new_g = g_score[current] + step
            if new_g < g_score.get((nx, ny), float('inf')):
                came_from[(nx, ny)] = current
                g_score[(nx, ny)] = new_g
                h = abs(nx - goal[0]) + abs(ny - goal[1])
                heapq.heappush(open_set, (new_g + h, (nx, ny)))

    return []