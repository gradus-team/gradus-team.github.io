import pygame
import random

def _create_texture(width=64, height=64, color_func=None):
    """Вспомогательная функция для генерации текстуры."""
    surf = pygame.Surface((width, height))
    for x in range(width):
        for y in range(height):
            color = color_func(x, y) if color_func else (255, 255, 255)
            surf.set_at((x, y), color)
    return surf

def generate_brick():
    """Кирпичная кладка."""
    def color_func(x, y):
        brick_h = 16
        brick_w = 32
        offset = (y // brick_h) % 2 * (brick_w // 2)
        px = (x + offset) % brick_w
        py = y % brick_h
        if px < 1 or px > brick_w-2 or py < 1 or py > brick_h-2:
            return (80, 40, 40)  # шов
        r = 150 + random.randint(-20, 20) % 30
        g = 60 + random.randint(-10, 10) % 20
        b = 60 + random.randint(-10, 10) % 20
        return (r, g, b)
    return _create_texture(64, 64, color_func)

def generate_granite():
    """Гранит – мелкая зернистость."""
    def color_func(x, y):
        base = (160, 160, 160)
        noise = random.randint(-30, 30)
        return (base[0]+noise, base[1]+noise, base[2]+noise)
    return _create_texture(64, 64, color_func)

def generate_earth():
    """Земля – коричневая с пятнами."""
    def color_func(x, y):
        r = 120 + random.randint(-20, 20) % 30
        g = 80 + random.randint(-20, 20) % 30
        b = 40 + random.randint(-20, 20) % 30
        return (r, g, b)
    return _create_texture(64, 64, color_func)

def generate_wood():
    """Доски – вертикальные полосы."""
    def color_func(x, y):
        base = 180 + random.randint(-20, 20) % 30
        if x % 16 < 2:
            return (base-40, base-60, base-80)  # тёмная полоса
        return (base, base-20, base-40)
    return _create_texture(64, 64, color_func)

def generate_glass():
    """Стекло – прозрачное с голубизной."""
    def color_func(x, y):
        return (150, 200, 255, 128)
    surf = _create_texture(64, 64, color_func)
    surf.set_alpha(128)
    return surf

def generate_concrete():
    """Бетон – серый с шумом."""
    def color_func(x, y):
        base = 180 + random.randint(-40, 40) % 50
        return (base, base, base)
    return _create_texture(64, 64, color_func)