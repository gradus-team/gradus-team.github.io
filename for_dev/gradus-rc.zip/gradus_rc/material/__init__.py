from .library import MaterialLibrary, Material
from .default_textures import *