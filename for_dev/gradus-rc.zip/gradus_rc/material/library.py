import pygame
import os
from .default_textures import generate_brick, generate_granite, generate_earth, generate_wood, generate_glass, generate_concrete

class Material:
    def __init__(self, color=(255,255,255), texture=None, reflection=0.0, alpha=1.0):
        self.color = color
        self.texture = texture
        self.reflection = reflection
        self.alpha = alpha

class MaterialLibrary:
    def __init__(self):
        self.materials = {}
        self._init_defaults()
        path = os.path.dirname(__file__)
        self._load_textures_from_disk(f"{path}/images")

    def _init_defaults(self):
        # (name, color, texture, alpha, reflection)
        materials = [
            ('brick', (180, 80, 80), generate_brick(), 1.0, 0.0),
            ('granite', (160, 160, 160), generate_granite(), 1.0, 0.0),
            ('earth', (120, 80, 40), generate_earth(), 1.0, 0.0),
            ('wood', (180, 140, 80), generate_wood(), 1.0, 0.0),
            ('glass', (200, 200, 200), generate_glass(), 0.15, 0.4),
            ('concrete', (180, 180, 180), generate_concrete(), 1.0, 0.0),
            ('metal', (200, 200, 220), None, 1.0, 0.55),
            ('plaster', (240, 230, 210), None, 1.0, 0.0),
            ('marble', (220, 210, 200), None, 1.0, 0.15),
            ('obsidian', (50, 50, 60), None, 1.0, 0.45),
            ('gold', (255, 215, 0), None, 1.0, 0.65),
            ('silver', (192, 192, 192), None, 1.0, 0.75),
            ('copper', (184, 115, 51), None, 1.0, 0.6),
            ('sand', (194, 178, 128), None, 1.0, 0.0),
            ('snow', (255, 250, 250), None, 1.0, 0.05),
            ('water', (0, 105, 148), None, 0.6, 0.7),
            ('lava', (255, 69, 0), None, 1.0, 0.0),
        ]
        for name, color, texture, alpha, refl in materials:
            self.add_material(name, Material(
                color=color, texture=texture, alpha=alpha, reflection=refl))

        self.add_material('1', self.get_material('concrete'))
        self.add_material('2', self.get_material('glass'))
        self.add_material('3', self.get_material('brick'))
        self.add_material('4', self.get_material('wood'))
        self.add_material('5', self.get_material('metal'))

    def _load_textures_from_disk(self, path):
        # Папка gradus_rc/material/images/
        try:
            images_dir = os.path.join(path, "")
            if not os.path.exists(images_dir):
                return
            for filename in os.listdir(images_dir):
                if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                    name = os.path.splitext(filename)[0].lower()
                    # Если материал с таким именем есть, заменяем текстуру
                    if name in self.materials:
                        try:
                            surf = pygame.image.load(os.path.join(images_dir, filename)).convert_alpha()
                            self.materials[name].texture = surf
                        except:
                            pass
        except Exception as e: print(f"Ошибка в MaterialLibrary/_load_textures_from_disk(): {e}")

    def add_material(self, name, material):
        self.materials[name] = material

    def get_material(self, name):
        return self.materials.get(name, None)

    def get_default(self):
        return Material(color=(200, 200, 200))