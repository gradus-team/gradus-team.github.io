# gradus_rc/image/cache.py
import pygame
import os

class SpriteManager:
    """Кэширует изображения, при отсутствии возвращает заглушку."""
    def __init__(self):
        self.cache = {}

    # gradus_rc/image/cache.py
    def load_image(self, key, path, size=None, default_color=(255, 0, 255)):
        if key in self.cache:
            return self.cache[key]

        # Пытаемся загрузить
        try:
            image = pygame.image.load(path).convert_alpha()
            if size:
                image = pygame.transform.scale(image, size)
            self.cache[key] = image
            print(image or None)
            return image
        except Exception as e:
            print(f"load_image: не удалось загрузить {path}: {e}, использую заглушку")

        # Заглушка
        if size is None:
            size = (64, 64)
        surf = pygame.Surface(size)
        surf.fill(default_color)
        self.cache[key] = surf
        return surf

def load_image(key, path, size=None, default_color=(255, 0, 255)):
    """Утилита для быстрой загрузки (создаёт временный менеджер)."""
    mgr = SpriteManager()
    return mgr.load_image(key, path, size, default_color)