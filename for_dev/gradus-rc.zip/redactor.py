import pygame
import math
import os

# ---------- Вспомогательные функции ----------
def normalize(v):
    length = math.sqrt(v[0]**2 + v[1]**2 + v[2]**2)
    return (v[0]/length, v[1]/length, v[2]/length) if length else (0,0,1)

def cross(a, b):
    return (a[1]*b[2] - a[2]*b[1],
            a[2]*b[0] - a[0]*b[2],
            a[0]*b[1] - a[1]*b[0])

def dot(a, b):
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]

def sub(a, b):
    return (a[0]-b[0], a[1]-b[1], a[2]-b[2])

def add(a, b):
    return (a[0]+b[0], a[1]+b[1], a[2]+b[2])

def mul(v, s):
    return (v[0]*s, v[1]*s, v[2]*s)

# ---------- Класс редактора ----------
class ObjEditor:
    def __init__(self, width=1024, height=768):
        self.width = width
        self.height = height
        self.vertices = []
        self.faces = []                 # список (v1, v2, v3)
        self.face_colors = []           # цвет каждой грани (r,g,b)
        self.face_ids = []              # для пиксельного выбора

        # Параметры модели
        self.model_pos = [0.0, 0.0]
        self.model_rotation = 0.0
        self.model_scale = 1.0
        self.default_color = (0.5, 0.5, 0.8)

        # Камера
        self.cam_distance = 5.0
        self.cam_angle_h = 0.0
        self.cam_angle_v = 20.0

        # Мышь
        self.mouse_captured = False
        self.mouse_sensitivity = 0.2

        # UI
        self.ui_buttons = []
        self.dropdown_open = False
        self.dropdown_options = ["Куб", "Сфера", "Цилиндр", "Плоскость"]
        self.dropdown_selected = 0
        self.selected_face = -1
        self.message = ""

        # Pygame
        pygame.init()
        self.screen = pygame.display.set_mode((self.width, self.height))
        self.id_surface = pygame.Surface((self.width, self.height))
        pygame.display.set_caption("Gradus OBJ Editor")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont('Arial', 18)
        self.small_font = pygame.font.SysFont('Arial', 14)

        # Начальная модель
        self.add_cube(1.0)
        self._init_ui()

    # ---------- Примитивы ----------
    def add_cube(self, size=1.0):
        half = size/2
        v = [(-half,-half,-half),( half,-half,-half),( half, half,-half),(-half, half,-half),
             (-half,-half, half),( half,-half, half),( half, half, half),(-half, half, half)]
        base = len(self.vertices)
        self.vertices.extend(v)
        faces = [(0,1,2),(0,2,3),(4,6,5),(4,7,6),(0,4,5),(0,5,1),(3,2,6),(3,6,7),(0,3,7),(0,7,4),(1,5,6),(1,6,2)]
        for f in faces:
            self.faces.append((base+f[0], base+f[1], base+f[2]))
            self.face_colors.append(self.default_color)
            self.face_ids.append(len(self.faces)-1)
        self.message = "Куб добавлен"

    def add_sphere(self, radius=1.0, segments=12):
        base = len(self.vertices)
        verts = []
        for i in range(segments+1):
            theta = i*math.pi/segments
            for j in range(segments+1):
                phi = j*2*math.pi/segments
                verts.append((radius*math.sin(theta)*math.cos(phi),
                              radius*math.cos(theta),
                              radius*math.sin(theta)*math.sin(phi)))
        self.vertices.extend(verts)
        for i in range(segments):
            for j in range(segments):
                a = i*(segments+1)+j; b=a+1; c=(i+1)*(segments+1)+j; d=c+1
                self.faces.append((base+a, base+b, base+c))
                self.faces.append((base+b, base+d, base+c))
                self.face_colors.append(self.default_color)
                self.face_colors.append(self.default_color)
                self.face_ids.append(len(self.faces)-1)
                self.face_ids.append(len(self.faces)-1)
        self.message = "Сфера добавлена"

    def add_cylinder(self, radius=0.8, height=1.5, segments=12):
        base = len(self.vertices)
        verts = []
        for i in range(segments+1):
            theta = i*2*math.pi/segments
            verts.append((radius*math.cos(theta), -height/2, radius*math.sin(theta)))
        for i in range(segments+1):
            theta = i*2*math.pi/segments
            verts.append((radius*math.cos(theta), height/2, radius*math.sin(theta)))
        self.vertices.extend(verts)
        for i in range(segments):
            a=i; b=(i+1)%segments; c=a+(segments+1); d=b+(segments+1)
            self.faces.append((base+a, base+b, base+c))
            self.faces.append((base+b, base+d, base+c))
            self.face_colors.append(self.default_color)
            self.face_colors.append(self.default_color)
            self.face_ids.append(len(self.faces)-1)
            self.face_ids.append(len(self.faces)-1)
        top_center = (0, height/2, 0)
        bottom_center = (0, -height/2, 0)
        tc = len(self.vertices); self.vertices.append(top_center)
        bc = len(self.vertices); self.vertices.append(bottom_center)
        for i in range(segments):
            a = i+(segments+1); b=(i+1)%segments+(segments+1)
            self.faces.append((base+a, base+b, tc))
            self.face_colors.append(self.default_color)
            self.face_ids.append(len(self.faces)-1)
        for i in range(segments):
            a = i; b=(i+1)%segments
            self.faces.append((base+a, bc, base+b))
            self.face_colors.append(self.default_color)
            self.face_ids.append(len(self.faces)-1)
        self.message = "Цилиндр добавлен"

    def add_plane(self, size=2.0):
        half = size/2
        base = len(self.vertices)
        self.vertices.extend([(-half,0,-half),( half,0,-half),( half,0, half),(-half,0, half)])
        self.faces.append((base+0, base+1, base+2))
        self.faces.append((base+0, base+2, base+3))
        self.face_colors.append(self.default_color)
        self.face_colors.append(self.default_color)
        self.face_ids.append(len(self.faces)-1)
        self.face_ids.append(len(self.faces)-1)
        self.message = "Плоскость добавлена"

    def extrude_face(self, face_idx, amount=0.3):
        if face_idx < 0 or face_idx >= len(self.faces):
            return
        face = self.faces[face_idx]
        v0 = self.vertices[face[0]]
        v1 = self.vertices[face[1]]
        v2 = self.vertices[face[2]]
        u = sub(v1, v0); v = sub(v2, v0)
        normal = normalize(cross(u, v))
        offset = mul(normal, amount)
        new_verts = []
        new_indices = []
        for idx in face:
            new_verts.append(add(self.vertices[idx], offset))
            new_indices.append(len(self.vertices)+len(new_verts)-1)
        base = len(self.vertices)
        self.vertices.extend(new_verts)
        old = face
        new = tuple(new_indices)
        for i in range(3):
            j = (i+1)%3
            a_old = old[i]; b_old = old[j]
            a_new = new[i]; b_new = new[j]
            self.faces.append((a_old, b_old, a_new))
            self.faces.append((b_old, b_new, a_new))
            self.face_colors.append(self.default_color)
            self.face_colors.append(self.default_color)
            self.face_ids.append(len(self.faces)-1)
            self.face_ids.append(len(self.faces)-1)
        self.faces[face_idx] = new
        self.face_colors[face_idx] = self.default_color
        self.face_ids[face_idx] = face_idx
        self.message = "Грань вытянута"

    def save_obj(self, filename):
        with open(filename, 'w') as f:
            f.write("# Gradus OBJ\n")
            for v in self.vertices:
                f.write(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")
            for face in self.faces:
                if len(face)==3:
                    f.write(f"f {face[0]+1} {face[1]+1} {face[2]+1}\n")
                elif len(face)==4:
                    f.write(f"f {face[0]+1} {face[1]+1} {face[2]+1} {face[3]+1}\n")
        self.message = f"Сохранено: {filename}"

    def load_obj(self, filename):
        if not os.path.exists(filename):
            self.message = "Файл не найден"
            return
        self.vertices.clear(); self.faces.clear(); self.face_colors.clear(); self.face_ids.clear()
        with open(filename, 'r') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'): continue
                parts = line.split()
                if parts[0]=='v':
                    self.vertices.append((float(parts[1]), float(parts[2]), float(parts[3])))
                elif parts[0]=='f':
                    idx = [int(p.split('/')[0])-1 for p in parts[1:]]
                    if len(idx)==3:
                        self.faces.append(tuple(idx))
                        self.face_colors.append(self.default_color)
                        self.face_ids.append(len(self.faces)-1)
                    elif len(idx)==4:
                        self.faces.append((idx[0],idx[1],idx[2]))
                        self.face_colors.append(self.default_color)
                        self.face_ids.append(len(self.faces)-1)
                        self.faces.append((idx[0],idx[2],idx[3]))
                        self.face_colors.append(self.default_color)
                        self.face_ids.append(len(self.faces)-1)
        self.message = f"Загружено: {len(self.vertices)} в, {len(self.faces)} г"

    # ---------- UI ----------
    def _init_ui(self):
        btn_y = 10
        btn_w, btn_h = 80, 28
        btn_x = 10
        # Кнопки
        labels = [("Добавить",'add'), ("Вытянуть",'extrude'), ("Сохранить",'save'), ("Загрузить",'load'), ("Удалить",'delete')]
        for label, action in labels:
            rect = pygame.Rect(btn_x, btn_y, btn_w, btn_h)
            self.ui_buttons.append({"rect": rect, "label": label, "action": action})
            btn_x += btn_w + 10

        # Кнопки цвета
        color_btn_y = btn_y + btn_h + 20
        color_btn_x = 10
        color_labels = ["R+1","R+10","R+100","G+1","G+10","G+100","B+1","B+10","B+100"]
        for lbl in color_labels:
            rect = pygame.Rect(color_btn_x, color_btn_y, 50, 28)
            self.ui_buttons.append({"rect": rect, "label": lbl, "action": lbl})
            color_btn_x += 55
            if color_btn_x > 250:
                color_btn_x = 10
                color_btn_y += 35

        self.dropdown_rect = pygame.Rect(90, 10, 100, 28)

        self.info_y = self.height - 40

    def _draw_ui(self):
        for btn in self.ui_buttons:
            pygame.draw.rect(self.screen, (60,60,90), btn["rect"])
            pygame.draw.rect(self.screen, (100,100,150), btn["rect"], 2)
            txt = self.small_font.render(btn["label"], True, (255,255,255))
            self.screen.blit(txt, (btn["rect"].x+4, btn["rect"].y+5))

        # Выпадающее меню
        pygame.draw.rect(self.screen, (40,40,70), self.dropdown_rect)
        pygame.draw.rect(self.screen, (150,150,200), self.dropdown_rect, 2)
        txt = self.small_font.render(self.dropdown_options[self.dropdown_selected], True, (255,255,255))
        self.screen.blit(txt, (self.dropdown_rect.x+5, self.dropdown_rect.y+5))
        if self.dropdown_open:
            for i, opt in enumerate(self.dropdown_options):
                rect = pygame.Rect(self.dropdown_rect.x, self.dropdown_rect.y + (i+1)*self.dropdown_rect.h,
                                   self.dropdown_rect.w, self.dropdown_rect.h)
                pygame.draw.rect(self.screen, (50,50,80), rect)
                pygame.draw.rect(self.screen, (100,100,150), rect, 1)
                txt = self.small_font.render(opt, True, (220,220,220))
                self.screen.blit(txt, (rect.x+5, rect.y+5))

        info = f"Вершин:{len(self.vertices)} Граней:{len(self.faces)} Выбрана:{self.selected_face}  {self.message}"
        info_txt = self.small_font.render(info, True, (180,180,180))
        self.screen.blit(info_txt, (10, self.info_y))

    def _handle_ui_click(self, pos):
        # Кнопки
        for btn in self.ui_buttons:
            if btn["rect"].collidepoint(pos):
                action = btn["action"]
                if action == 'add':
                    self.dropdown_open = not self.dropdown_open
                    return
                elif action == 'extrude':
                    if self.selected_face>=0:
                        self.extrude_face(self.selected_face, 0.3)
                    else:
                        self.message = "Сначала выберите грань"
                    return
                elif action == 'save':
                    path = input("Путь сохранения (Enter для model.obj): ") or "model.obj"
                    self.save_obj(path)
                    return
                elif action == 'load':
                    path = input("Путь загрузки (Enter для model.obj): ") or "model.obj"
                    self.load_obj(path)
                    return
                elif action == 'delete':
                    if self.selected_face>=0 and self.selected_face<len(self.faces):
                        del self.faces[self.selected_face]
                        del self.face_colors[self.selected_face]
                        del self.face_ids[self.selected_face]
                        self.selected_face = -1
                        self.message = "Грань удалена"
                    return
                elif action.startswith('R'):
                    step = int(action.split('+')[1]) if '+' in action else 0
                    if step:
                        if self.selected_face == -1:
                            for i in range(len(self.face_colors)):
                                c = self.face_colors[i]
                                self.face_colors[i] = (min(1.0, c[0]+step/255.0), c[1], c[2])
                        else:
                            c = self.face_colors[self.selected_face]
                            self.face_colors[self.selected_face] = (min(1.0, c[0]+step/255.0), c[1], c[2])
                    return
                elif action.startswith('G'):
                    step = int(action.split('+')[1]) if '+' in action else 0
                    if step:
                        if self.selected_face == -1:
                            for i in range(len(self.face_colors)):
                                c = self.face_colors[i]
                                self.face_colors[i] = (c[0], min(1.0, c[1]+step/255.0), c[2])
                        else:
                            c = self.face_colors[self.selected_face]
                            self.face_colors[self.selected_face] = (c[0], min(1.0, c[1]+step/255.0), c[2])
                    return
                elif action.startswith('B'):
                    step = int(action.split('+')[1]) if '+' in action else 0
                    if step:
                        if self.selected_face == -1:
                            for i in range(len(self.face_colors)):
                                c = self.face_colors[i]
                                self.face_colors[i] = (c[0], c[1], min(1.0, c[2]+step/255.0))
                        else:
                            c = self.face_colors[self.selected_face]
                            self.face_colors[self.selected_face] = (c[0], c[1], min(1.0, c[2]+step/255.0))
                    return
                # Обработка выбора из выпадающего меню
                if self.dropdown_open:
                    for i, opt in enumerate(self.dropdown_options):
                        rect = pygame.Rect(self.dropdown_rect.x, self.dropdown_rect.y + (i+1)*self.dropdown_rect.h,
                                           self.dropdown_rect.w, self.dropdown_rect.h)
                        if rect.collidepoint(pos):
                            self.dropdown_selected = i
                            self.dropdown_open = False
                            if i == 0: self.add_cube(1.0)
                            elif i == 1: self.add_sphere(1.0,12)
                            elif i == 2: self.add_cylinder(0.8,1.5,12)
                            elif i == 3: self.add_plane(2.0)
                            return
                return

        # Закрываем выпадающее меню при клике вне него
        if self.dropdown_open:
            if not self.dropdown_rect.collidepoint(pos):
                self.dropdown_open = False

    # ---------- Рендеринг ----------
    def render_model(self, surface, id_surface=None):
        # Камера
        cam_h = math.radians(self.cam_angle_h)
        cam_v = math.radians(self.cam_angle_v)
        d = self.cam_distance
        cam_x = d * math.cos(cam_v) * math.sin(cam_h)
        cam_y = d * math.sin(cam_v)
        cam_z = d * math.cos(cam_v) * math.cos(cam_h)

        rot = math.radians(self.model_rotation)
        cos_r = math.cos(rot); sin_r = math.sin(rot)

        projected = []
        for v in self.vertices:
            sx = v[0]*self.model_scale
            sy = v[1]*self.model_scale
            sz = v[2]*self.model_scale
            rx = sx*cos_r - sz*sin_r
            rz = sx*sin_r + sz*cos_r
            ry = sy
            wx = rx + self.model_pos[0]
            wy = ry + self.model_pos[1]
            wz = rz
            dx = wx - cam_x
            dy = wy - cam_y
            dz = wz - cam_z
            x1 = dx*math.cos(cam_h) + dz*math.sin(cam_h)
            z1 = -dx*math.sin(cam_h) + dz*math.cos(cam_h)
            y1 = dy
            x2 = x1
            y2 = y1*math.cos(cam_v) - z1*math.sin(cam_v)
            z2 = y1*math.sin(cam_v) + z1*math.cos(cam_v)
            if z2 <= 0: continue
            fov_scale = 2000 / (z2 + 0.1)
            screen_x = surface.get_width()//2 + x2*fov_scale
            screen_y = surface.get_height()//2 - y2*fov_scale
            projected.append((screen_x, screen_y, z2, (wx, wy, wz)))

        if len(projected) < 3: return
        light_dir = (0.5, 0.5, 1.0)

        for idx, face in enumerate(self.faces):
            if len(face)<3: continue
            try:
                p1 = projected[face[0]]
                p2 = projected[face[1]]
                p3 = projected[face[2]]
            except IndexError: continue
            if None in (p1,p2,p3): continue

            v1 = p1[3]; v2 = p2[3]; v3 = p3[3]
            u = (v2[0]-v1[0], v2[1]-v1[1], v2[2]-v1[2])
            v = (v3[0]-v1[0], v3[1]-v1[1], v3[2]-v1[2])
            normal = normalize(cross(u,v))
            intensity = max(0, dot(normal, light_dir))
            intensity = 0.3 + 0.7 * intensity

            color = self.face_colors[idx] if idx < len(self.face_colors) else self.default_color
            r = int(color[0]*intensity*255)
            g = int(color[1]*intensity*255)
            b = int(color[2]*intensity*255)
            pts = [(p1[0],p1[1]), (p2[0],p2[1]), (p3[0],p3[1])]
            pygame.draw.polygon(surface, (r,g,b), pts)

            if id_surface is not None:
                id_val = self.face_ids[idx] if idx < len(self.face_ids) else idx
                r_id = id_val & 0xFF
                g_id = (id_val >> 8) & 0xFF
                b_id = (id_val >> 16) & 0xFF
                pygame.draw.polygon(id_surface, (r_id, g_id, b_id), pts)

            if self.selected_face == idx:
                pygame.draw.polygon(surface, (255,0,0), pts, 2)

    # ---------- Основной цикл ----------
    def run(self):
        running = True
        while running:
            self.screen.fill((20,20,40))
            self.id_surface.fill((0,0,0))
            self.render_model(self.screen, self.id_surface)
            self._draw_ui()
            pygame.display.flip()
            self.clock.tick(60)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        # Проверяем UI клик
                        ui_clicked = False
                        for btn in self.ui_buttons:
                            if btn["rect"].collidepoint(event.pos):
                                self._handle_ui_click(event.pos)
                                ui_clicked = True
                                break
                        if not ui_clicked:
                            # Пиксельный выбор грани
                            try:
                                pixel = self.id_surface.get_at(event.pos)
                                id_val = pixel[0] | (pixel[1] << 8) | (pixel[2] << 16)
                                if id_val in self.face_ids:
                                    idx = self.face_ids.index(id_val)
                                    self.selected_face = idx
                                    self.message = f"Выбрана грань {idx}"
                                else:
                                    self.selected_face = -1
                                    self.message = "Грань не найдена"
                            except:
                                pass
                    if event.button == 3:
                        self.mouse_captured = True
                        pygame.mouse.set_visible(False)
                        pygame.event.set_grab(True)
                    if event.button == 4:
                        self.model_scale *= 1.05
                    if event.button == 5:
                        self.model_scale *= 0.95
                if event.type == pygame.MOUSEBUTTONUP:
                    if event.button == 3:
                        self.mouse_captured = False
                        pygame.mouse.set_visible(True)
                        pygame.event.set_grab(False)
                if event.type == pygame.MOUSEMOTION and self.mouse_captured:
                    dx, dy = event.rel
                    self.cam_angle_h += dx * self.mouse_sensitivity
                    self.cam_angle_v += dy * self.mouse_sensitivity
                    self.cam_angle_v = max(-89, min(89, self.cam_angle_v))
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        self.model_pos = [0,0]; self.model_rotation=0; self.model_scale=1
                        self.message = "Сброшено"
        pygame.quit()

if __name__ == "__main__":
    editor = ObjEditor()
    editor.run()