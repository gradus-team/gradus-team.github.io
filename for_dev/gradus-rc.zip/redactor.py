import pygame
import math
import os

class MeshObject:
    """Отдельный 3D-объект с вершинами, гранями и цветами."""
    def __init__(self, name="object"):
        self.name = name
        self.vertices = []   # список (x,y,z)
        self.faces = []      # список (v1,v2,v3) индексы вершин этого объекта
        self.colors = []     # цвет каждой грани (r,g,b) 0..1

    def add_vertices(self, verts):
        base = len(self.vertices)
        self.vertices.extend(verts)
        return base

    def add_face(self, face_indices, color=(0.5,0.5,0.8)):
        self.faces.append(tuple(face_indices))
        self.colors.append(color)

    def move(self, dx, dy, dz):
        self.vertices = [(v[0]+dx, v[1]+dy, v[2]+dz) for v in self.vertices]

    def scale(self, factor):
        self.vertices = [(v[0]*factor, v[1]*factor, v[2]*factor) for v in self.vertices]

    def paint_face(self, face_idx, color):
        if 0 <= face_idx < len(self.colors):
            self.colors[face_idx] = color

    def paint_all(self, color):
        self.colors = [color] * len(self.faces)

    def extrude_face(self, face_idx, amount=0.3):
        if face_idx < 0 or face_idx >= len(self.faces):
            return False
        face = self.faces[face_idx]
        v0 = self.vertices[face[0]]
        v1 = self.vertices[face[1]]
        v2 = self.vertices[face[2]]
        u = (v1[0]-v0[0], v1[1]-v0[1], v1[2]-v0[2])
        v = (v2[0]-v0[0], v2[1]-v0[1], v2[2]-v0[2])
        normal = (
            u[1]*v[2] - u[2]*v[1],
            u[2]*v[0] - u[0]*v[2],
            u[0]*v[1] - u[1]*v[0]
        )
        length = math.sqrt(normal[0]**2 + normal[1]**2 + normal[2]**2)
        if length > 0:
            normal = (normal[0]/length, normal[1]/length, normal[2]/length)
        else:
            normal = (0,0,1)
        offset = [d * amount for d in normal]
        new_verts = []
        for idx in face:
            old = self.vertices[idx]
            new = (old[0]+offset[0], old[1]+offset[1], old[2]+offset[2])
            new_verts.append(new)
        new_base = self.add_vertices(new_verts)
        new_indices = [new_base + i for i in range(len(new_verts))]
        old_indices = list(face)
        for i in range(3):
            j = (i+1)%3
            a_old = old_indices[i]
            b_old = old_indices[j]
            a_new = new_indices[i]
            b_new = new_indices[j]
            self.add_face((a_old, b_old, a_new), (0.5,0.5,0.8))
            self.add_face((b_old, b_new, a_new), (0.5,0.5,0.8))
        # Заменяем выбранную грань на новую (верхнюю)
        self.faces[face_idx] = tuple(new_indices)
        self.colors[face_idx] = (1.0, 0.8, 0.2)  # выделяем
        return True

    def delete_face(self, face_idx):
        if 0 <= face_idx < len(self.faces):
            del self.faces[face_idx]
            del self.colors[face_idx]
            return True
        return False


class ObjEditor:
    def __init__(self, width=1024, height=768):
        pygame.init()
        self.width = width
        self.height = height
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption("Gradus OBJ Editor (Pygame)")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont('Arial', 20)
        self.small_font = pygame.font.SysFont('Arial', 16)

        self.objects = []               # список MeshObject
        self.current_object_index = -1  # индекс активного объекта
        self.selected_face_index = -1   # индекс выбранной грани в активном объекте

        # Камера
        self.camera_rot_x = 20.0
        self.camera_rot_y = 30.0
        self.camera_distance = 5.0
        self.camera_target = [0.0, 0.0, 0.0]

        # Мышь
        self.dragging = False
        self.last_mouse = (0, 0)

        # GUI
        self.buttons = []
        self.create_buttons()

        self.current_color = (1.0, 0.5, 0.5)
        self.paint_mode = 'face'   # 'face' или 'object'
        self.show_help = True

        # Создаём начальный объект (куб)
        self.add_object("cube")
        self.message = "Редактор готов. Добавляйте объекты кнопками."
        self.dirty = True

    def create_buttons(self):
        """Создаёт кнопки в сетке."""
        btn_w, btn_h = 130, 30
        margin = 10
        x, y = margin, margin
        actions = [
            ("Куб", lambda: self.add_primitive('cube'), ()),
            ("Сфера", lambda: self.add_primitive('sphere'), ()),
            ("Цилиндр", lambda: self.add_primitive('cylinder'), ()),
            ("Плоскость", lambda: self.add_primitive('plane'), ()),
            ("Сохранить", self.save_all, ("model.gbj",)),
            ("Загрузить", self.load_all, ("model.gbj",)),
            ("Экструзия", self.extrude_selected, ()),
            ("Удалить грань", self.delete_selected_face, ()),
            ("Окрасить грань", self.set_paint_face, ()),
            ("Окрасить объект", self.set_paint_object, ()),
            # Цвета
            ("Красный", lambda: self.set_color((1,0,0)), ()),
            ("Зелёный", lambda: self.set_color((0,1,0)), ()),
            ("Синий", lambda: self.set_color((0,0,1)), ()),
            ("Жёлтый", lambda: self.set_color((1,1,0)), ()),
            ("Фиолетовый", lambda: self.set_color((1,0,1)), ()),
            ("Оранжевый", lambda: self.set_color((1,0.5,0)), ()),
            ("Белый", lambda: self.set_color((1,1,1)), ()),
            ("Чёрный", lambda: self.set_color((0,0,0)), ()),
            ("Окрасить", self.paint_selected, ()),
            ("Масштаб+", self.scale_selected, (1.1,)),
            ("Масштаб-", self.scale_selected, (0.9,)),
            ("X+", lambda: self.move_selected(0.2,0,0), ()),
            ("X-", lambda: self.move_selected(-0.2,0,0), ()),
            ("Y+", lambda: self.move_selected(0,0.2,0), ()),
            ("Y-", lambda: self.move_selected(0,-0.2,0), ()),
            ("Z+", lambda: self.move_selected(0,0,0.2), ()),
            ("Z-", lambda: self.move_selected(0,0,-0.2), ()),
        ]
        for text, func, args in actions:
            if x + btn_w > self.width - margin:
                x = margin
                y += btn_h + margin
            self.buttons.append({
                'rect': pygame.Rect(x, y, btn_w, btn_h),
                'text': text,
                'func': func,
                'args': args
            })
            x += btn_w + margin

    def add_object(self, name):
        obj = MeshObject(name)
        self.objects.append(obj)
        self.current_object_index = len(self.objects) - 1
        self.selected_face_index = -1
        return obj

    def add_primitive(self, prim_type):
        obj = self.add_object(prim_type)
        if prim_type == 'cube':
            self._make_cube(obj)
        elif prim_type == 'sphere':
            self._make_sphere(obj)
        elif prim_type == 'cylinder':
            self._make_cylinder(obj)
        elif prim_type == 'plane':
            self._make_plane(obj)
        self.message = f"Объект '{prim_type}' добавлен (объект {self.current_object_index})"
        self.dirty = True

    def _make_cube(self, obj, size=1.0):
        half = size / 2
        v = [
            (-half, -half, -half), ( half, -half, -half),
            ( half,  half, -half), (-half,  half, -half),
            (-half, -half,  half), ( half, -half,  half),
            ( half,  half,  half), (-half,  half,  half)
        ]
        base = obj.add_vertices(v)
        faces = [
            (0,1,2), (0,2,3), (4,6,5), (4,7,6),
            (0,4,5), (0,5,1), (3,2,6), (3,6,7),
            (0,3,7), (0,7,4), (1,5,6), (1,6,2)
        ]
        for f in faces:
            obj.add_face((base+f[0], base+f[1], base+f[2]), (0.5,0.5,0.8))

    def _make_sphere(self, obj, radius=1.0, segments=12):
        base = obj.add_vertices([])
        verts = []
        for i in range(segments+1):
            theta = i * math.pi / segments
            for j in range(segments+1):
                phi = j * 2 * math.pi / segments
                x = radius * math.sin(theta) * math.cos(phi)
                y = radius * math.cos(theta)
                z = radius * math.sin(theta) * math.sin(phi)
                verts.append((x,y,z))
        base = obj.add_vertices(verts)
        for i in range(segments):
            for j in range(segments):
                a = i*(segments+1)+j
                b = a+1
                c = (i+1)*(segments+1)+j
                d = c+1
                obj.add_face((base+a, base+b, base+c), (0.5,0.8,0.5))
                obj.add_face((base+b, base+d, base+c), (0.5,0.8,0.5))

    def _make_cylinder(self, obj, radius=0.8, height=1.5, segments=12):
        base = obj.add_vertices([])
        bottom = []
        top = []
        for i in range(segments+1):
            theta = i * 2 * math.pi / segments
            x = radius * math.cos(theta)
            z = radius * math.sin(theta)
            bottom.append((x, -height/2, z))
            top.append((x, height/2, z))
        all_verts = bottom + top
        base = obj.add_vertices(all_verts)
        for i in range(segments):
            a = i
            b = (i+1)%segments
            c = a + (segments+1)
            d = b + (segments+1)
            obj.add_face((base+a, base+b, base+c), (0.8,0.5,0.5))
            obj.add_face((base+b, base+d, base+c), (0.8,0.5,0.5))
        top_center = (0, height/2, 0)
        bottom_center = (0, -height/2, 0)
        top_idx = obj.add_vertices([top_center])
        bottom_idx = obj.add_vertices([bottom_center])
        for i in range(segments):
            a = i
            b = (i+1)%segments
            obj.add_face((base+a, base+b, top_idx), (0.8,0.5,0.8))
            obj.add_face((base+a, bottom_idx, base+b), (0.8,0.5,0.8))

    def _make_plane(self, obj, size=2.0):
        half = size/2
        base = obj.add_vertices([
            (-half,0,-half), (half,0,-half), (half,0,half), (-half,0,half)
        ])
        obj.add_face((base+0, base+1, base+2), (0.6,0.6,0.6))
        obj.add_face((base+0, base+2, base+3), (0.6,0.6,0.6))

    def set_paint_face(self):
        self.paint_mode = 'face'
        self.message = "Режим окраски: грань"

    def set_paint_object(self):
        self.paint_mode = 'object'
        self.message = "Режим окраски: объект"

    def set_color(self, color):
        self.current_color = color
        self.message = f"Цвет выбран: {color}"

    def paint_selected(self):
        if self.current_object_index < 0 or self.current_object_index >= len(self.objects):
            self.message = "Нет активного объекта"
            return
        obj = self.objects[self.current_object_index]
        if self.paint_mode == 'face':
            if self.selected_face_index >= 0 and self.selected_face_index < len(obj.faces):
                obj.paint_face(self.selected_face_index, self.current_color)
                self.message = f"Грань {self.selected_face_index} окрашена"
            else:
                self.message = "Сначала выберите грань"
        else:
            obj.paint_all(self.current_color)
            self.message = "Объект окрашен"
        self.dirty = True

    def extrude_selected(self):
        if self.current_object_index < 0:
            return
        obj = self.objects[self.current_object_index]
        if self.selected_face_index < 0 or self.selected_face_index >= len(obj.faces):
            self.message = "Выберите грань для экструзии"
            return
        if obj.extrude_face(self.selected_face_index):
            self.message = "Грань вытянута"
        else:
            self.message = "Ошибка экструзии"
        self.dirty = True

    def delete_selected_face(self):
        if self.current_object_index < 0:
            return
        obj = self.objects[self.current_object_index]
        if self.selected_face_index < 0 or self.selected_face_index >= len(obj.faces):
            self.message = "Выберите грань для удаления"
            return
        if obj.delete_face(self.selected_face_index):
            self.selected_face_index = -1
            self.message = "Грань удалена"
        else:
            self.message = "Ошибка удаления"
        self.dirty = True

    def scale_selected(self, factor):
        if self.current_object_index < 0:
            return
        obj = self.objects[self.current_object_index]
        obj.scale(factor)
        self.message = f"Масштаб объекта изменён (x{factor})"
        self.dirty = True

    def move_selected(self, dx, dy, dz):
        if self.current_object_index < 0:
            return
        obj = self.objects[self.current_object_index]
        obj.move(dx, dy, dz)
        self.message = f"Объект смещён на ({dx},{dy},{dz})"
        self.dirty = True

    def save_all(self, filename):
        ext = os.path.splitext(filename)[1].lower()
        # Объединяем все объекты в один список вершин и граней
        all_vertices = []
        all_faces = []
        all_colors = []
        for obj in self.objects:
            base = len(all_vertices)
            all_vertices.extend(obj.vertices)
            for i, face in enumerate(obj.faces):
                new_face = tuple(idx + base for idx in face)
                all_faces.append(new_face)
                all_colors.append(obj.colors[i])
        with open(filename, 'w') as f:
            for v in all_vertices:
                f.write(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")
            for i, face in enumerate(all_faces):
                r,g,b = all_colors[i]
                hex_color = f"{int(r*255):02X}{int(g*255):02X}{int(b*255):02X}"
                f.write(f"f {face[0]+1} {face[1]+1} {face[2]+1} {hex_color}\n")
        self.message = f"Сохранено в {filename}"

    def load_all(self, filename):
        if not os.path.exists(filename):
            self.message = "Файл не найден"
            return
        self.objects.clear()
        obj = MeshObject("loaded")
        with open(filename, 'r') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                parts = line.split()
                if parts[0] == 'v':
                    obj.vertices.append((float(parts[1]), float(parts[2]), float(parts[3])))
                elif parts[0] == 'f':
                    color = (0.5,0.5,0.8)
                    indices = []
                    for p in parts[1:]:
                        if len(p) == 6 and all(c in '0123456789ABCDEFabcdef' for c in p):
                            r = int(p[0:2],16)/255.0
                            g = int(p[2:4],16)/255.0
                            b = int(p[4:6],16)/255.0
                            color = (r,g,b)
                        else:
                            indices.append(int(p.split('/')[0])-1)
                    if len(indices) == 3:
                        obj.faces.append(tuple(indices))
                        obj.colors.append(color)
        self.objects.append(obj)
        self.current_object_index = 0
        self.selected_face_index = -1
        self.message = f"Загружено: {len(obj.vertices)} вершин, {len(obj.faces)} граней"
        self.dirty = True

    def render(self):
        self.screen.fill((30,30,50))
        # Собираем все грани со всех объектов для отрисовки
        all_vertices = []
        all_faces = []
        all_colors = []
        for obj in self.objects:
            base = len(all_vertices)
            all_vertices.extend(obj.vertices)
            for i, face in enumerate(obj.faces):
                all_faces.append(tuple(idx + base for idx in face))
                all_colors.append(obj.colors[i])

        if all_vertices:
            # Проекция (как раньше)
            rot_x = math.radians(self.camera_rot_x)
            rot_y = math.radians(self.camera_rot_y)
            cos_x, sin_x = math.cos(rot_x), math.sin(rot_x)
            cos_y, sin_y = math.cos(rot_y), math.sin(rot_y)

            cx = sum(v[0] for v in all_vertices) / len(all_vertices)
            cy = sum(v[1] for v in all_vertices) / len(all_vertices)
            cz = sum(v[2] for v in all_vertices) / len(all_vertices)

            projected = []
            for v in all_vertices:
                x = v[0] - cx + self.camera_target[0]
                y = v[1] - cy + self.camera_target[1]
                z = v[2] - cz + self.camera_target[2]
                y1 = y * cos_x - z * sin_x
                z1 = y * sin_x + z * cos_x
                x2 = x * cos_y + z1 * sin_y
                z2 = -x * sin_y + z1 * cos_y
                scale = 200 / (self.camera_distance + 1)
                screen_x = self.width // 2 + x2 * scale
                screen_y = self.height // 2 - y1 * scale
                projected.append((screen_x, screen_y, z2))

            # Освещение
            light_dir = (0.5, 0.5, -0.7)
            len_l = math.sqrt(sum(d*d for d in light_dir))
            light_dir = tuple(d/len_l for d in light_dir)

            face_data = []
            for i, face in enumerate(all_faces):
                if len(face) == 3:
                    p1 = projected[face[0]]
                    p2 = projected[face[1]]
                    p3 = projected[face[2]]
                    depth = (p1[2]+p2[2]+p3[2])/3
                    v0 = all_vertices[face[0]]
                    v1 = all_vertices[face[1]]
                    v2 = all_vertices[face[2]]
                    u = (v1[0]-v0[0], v1[1]-v0[1], v1[2]-v0[2])
                    v = (v2[0]-v0[0], v2[1]-v0[1], v2[2]-v0[2])
                    normal = (
                        u[1]*v[2]-u[2]*v[1],
                        u[2]*v[0]-u[0]*v[2],
                        u[0]*v[1]-u[1]*v[0]
                    )
                    len_n = math.sqrt(sum(n*n for n in normal))
                    if len_n > 0:
                        normal = tuple(n/len_n for n in normal)
                    else:
                        normal = (0,0,1)
                    intensity = max(0, normal[0]*light_dir[0] + normal[1]*light_dir[1] + normal[2]*light_dir[2])
                    intensity = 0.3 + 0.7 * intensity
                    face_data.append((depth, i, p1, p2, p3, intensity))
            face_data.sort(key=lambda x: x[0], reverse=True)
            for depth, face_idx, p1, p2, p3, intensity in face_data:
                base_color = all_colors[face_idx]
                col = tuple(int(c*255*intensity) for c in base_color)
                pygame.draw.polygon(self.screen, col, [(p1[0],p1[1]), (p2[0],p2[1]), (p3[0],p3[1])])

            # Выделение выбранной грани текущего объекта
            if self.current_object_index >= 0 and self.selected_face_index >= 0:
                obj = self.objects[self.current_object_index]
                if self.selected_face_index < len(obj.faces):
                    face = obj.faces[self.selected_face_index]
                    # Находим глобальные индексы вершин
                    base_global = 0
                    for o in self.objects:
                        if o is obj:
                            break
                        base_global += len(o.vertices)
                    global_face = [idx + base_global for idx in face]
                    if all(idx < len(projected) for idx in global_face):
                        pts = [projected[idx][:2] for idx in global_face]
                        pygame.draw.polygon(self.screen, (255,0,0), pts, 2)

        # Кнопки
        for btn in self.buttons:
            rect = btn['rect']
            pygame.draw.rect(self.screen, (60,60,80), rect)
            pygame.draw.rect(self.screen, (100,100,140), rect, 2)
            text_surf = self.small_font.render(btn['text'], True, (255,255,255))
            self.screen.blit(text_surf, (rect.x + (rect.w - text_surf.get_width())//2,
                                         rect.y + (rect.h - text_surf.get_height())//2))

        # Статус
        status = f"Объектов: {len(self.objects)} | Активный: {self.current_object_index} | Граней в объекте: {len(self.objects[self.current_object_index].faces) if self.current_object_index>=0 else 0} | {self.message}"
        status_surf = self.font.render(status, True, (200,200,200))
        self.screen.blit(status_surf, (10, self.height - 30))

        if self.show_help:
            help_text = [
                "Мышь: левая кнопка - вращать, колёсико - зум, правая - выбрать грань активного объекта",
                "Клавиши: C-куб, F-сфера, Y-цилиндр, P-плоскость, E-экструзия, Delete-удалить грань",
                "Ctrl+S - сохранить, Ctrl+O - загрузить, R - сброс камеры, H - справка"
            ]
            y = self.height - 80
            for line in help_text:
                txt = self.small_font.render(line, True, (180,180,200))
                self.screen.blit(txt, (10, y))
                y += 20

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    # Проверяем кнопки
                    handled = False
                    for btn in self.buttons:
                        if btn['rect'].collidepoint(event.pos):
                            btn['func'](*btn['args'])
                            handled = True
                            break
                    if not handled:
                        self.dragging = True
                        self.last_mouse = event.pos
                elif event.button == 3:
                    if self.current_object_index >= 0:
                        obj = self.objects[self.current_object_index]
                        if obj.faces:
                            self.selected_face_index = (self.selected_face_index + 1) % len(obj.faces)
                            self.dirty = True
                            self.message = f"Выбрана грань {self.selected_face_index} в объекте {self.current_object_index}"
                elif event.button == 4:
                    self.camera_distance = max(0.5, self.camera_distance - 0.3)
                    self.dirty = True
                elif event.button == 5:
                    self.camera_distance += 0.3
                    self.dirty = True
            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                self.dragging = False
            if event.type == pygame.MOUSEMOTION and self.dragging:
                dx, dy = event.rel
                self.camera_rot_y -= dx * 0.5
                self.camera_rot_x -= dy * 0.5
                self.camera_rot_x = max(-90, min(90, self.camera_rot_x))
                self.dirty = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return False
                elif event.key == pygame.K_c:
                    self.add_primitive('cube')
                elif event.key == pygame.K_f:
                    self.add_primitive('sphere')
                elif event.key == pygame.K_y:
                    self.add_primitive('cylinder')
                elif event.key == pygame.K_p:
                    self.add_primitive('plane')
                elif event.key == pygame.K_e:
                    self.extrude_selected()
                elif event.key == pygame.K_DELETE:
                    self.delete_selected_face()
                elif event.key == pygame.K_r:
                    self.camera_rot_x = 20
                    self.camera_rot_y = 30
                    self.camera_distance = 5.0
                    self.camera_target = [0,0,0]
                    self.dirty = True
                    self.message = "Камера сброшена"
                elif event.key == pygame.K_h:
                    self.show_help = not self.show_help
                if event.key == pygame.K_s and event.mod & pygame.KMOD_CTRL:
                    self.save_all("models/model.gbj")
                if event.key == pygame.K_o and event.mod & pygame.KMOD_CTRL:
                    self.load_all("models/model.gbj")
        return True

    def run(self):
        running = True
        while running:
            running = self.handle_events()
            if self.dirty:
                self.render()
                pygame.display.flip()
                self.dirty = False
            self.clock.tick(60)
        pygame.quit()

if __name__ == "__main__":
    editor = ObjEditor()
    editor.run()