"""
Example mod для Gradus RC.
"""

from gradus_rc import Sprite


# Текстура врага — заполняется в on_load.
# Хранится глобально, чтобы __init__ каждого дракона её не перезагружал.
_DRAGON_TEX = None


class DragonEnemy:
    """Кастомный враг. По поведению — летит к игроку."""

    def __init__(self, x, y, hp=200, speed=18, **kwargs):
        self.x = x
        self.y = y
        self.hp = hp
        self.max_hp = hp
        self.alive = True
        self.speed = speed or 18
        # Приоритет: текстура из карты (kwargs['texture']) → наша _DRAGON_TEX
        self.texture = _DRAGON_TEX
        self._hit_timer = 0.0
        print(f"[dragon] init at {x},{y} tex={self.texture}")

    def update(self, dt, player_pos, engine):
        import math
        dx = player_pos[0] - self.x
        dy = player_pos[1] - self.y
        d = math.hypot(dx, dy) or 1.0
        speed = self.speed
        self.x += dx / d * speed * dt
        self.y += dy / d * speed * dt

    def update_visibility(self, dt, engine):
        pass

    def take_damage(self, dmg, source=None):
        self.hp -= dmg
        if self.hp <= 0:
            self.alive = False


def on_load(engine):
    global _DRAGON_TEX

    api.log("Загружаю example_mod")

    # 1. Грузим текстуру ОДИН РАЗ. Файл лежит в mods/example/assets/dragon.png
    _DRAGON_TEX = api.load_image('dragon.png', size=(64, 64))
    api.log(f"dragon.png загружена: {_DRAGON_TEX}")

    # 2. Регистрируем врага
    api.register_enemy('dragon', DragonEnemy)

    def on_update(dt, keys):
        pass

    api.add_hook('update', on_update)
    api.log("Готово. Враг 'dragon' доступен из карты.")