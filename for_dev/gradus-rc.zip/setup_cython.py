from setuptools import setup
from Cython.Build import cythonize

setup(
    name='gradus_rc_cy',
    ext_modules=cythonize(
        ['gradus_rc/raycast/core_cy.pyx'],
        compiler_directives={
            'language_level': '3',
            'boundscheck': False,
            'wraparound': False,
            'cdivision': True,
            'initializedcheck': False,
        },
    ),
)