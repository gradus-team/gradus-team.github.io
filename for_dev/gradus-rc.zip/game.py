import pygame
import math
from gradus_rc import Engine, LightSource, Sprite, load_image
from gradus_rc import MenuExample, GameExample
from gradus_rc.enemy import EnemyAI
from gradus_rc.gun import Gun, Bullet, GunManager

# ---------- ПЯТЬ УРОВНЕЙ (16x16) ----------
LEVEL1 = """
[COLLISION]
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1
1 0 1 1 1 0 0 1 0 1 1 1 0 0 0 1
1 0 0 0 1 0 0 0 0 0 0 1 0 0 0 1
1 0 0 0 1 0 0<enemy:type=chase,sprite:assets/enemy_demon.png,hp=50,aim=10,shoot_delay=1.0,shoot_intensity=20,attack_type=ranged,detect_radius=6,attack_radius=4,speed=60> 0 0 0 0 1 0 0 1
1 0 1 1 1 0 0 0 0 0 0 1 0 0 1
1 0 0 0 0 0 0 1 1 1 0 1 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 1
1 0 1 0 0 0 0 1 0 0 0 0 0 0 1
1 0 1 0 0 0 0 1 0 1 1 1 0 0 1
1 0 1 0 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 0 0 0 0 1 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 1
1 1 1 1 1 0 0 0 0 0 0 0 0 0 1
1 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 0 0 0 0 0 0 0 0 0 0 6<path:models/model.gbj> 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 9<level:1,isvisible:1,material:glass> 1
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1

[SPAWN=0.5,0.5]
[AMBIENT=0.15]
[FLOOR_COLOR=333333]
[CEILING_COLOR=111111]
[LIGHTS=2.5,2.5,0.5,200;7.5,4.5,0.6,250;12.5,12.5,0.7,300]
"""

LEVEL2 = """
[COLLISION]
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
1 0 0 0 1 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 0 0 0 0 0 0 0 0 0 1
1 0 1 0 1 0 1 1 1 0 1 1 1 0 0 1
1 0 1 0 0 0 0 0 1 0 0 0 1 0 0 1
1 0 1 1 1 0 1 0 1 0 1 0 1 0 0 1
1 0 0 0 1 0 1 0 0 0 1 0 0 0 0 1
1 1 1 0 1 0 1 1 1 0 1 1 1 0 0 1
1 0 0 0 1 0 0 0 0 0 0 0 0 0 0 1
1 <enemy:type=chase,hp=40,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 0 1 1 1 0 1 0 0 0 0 0 0 1
1 0 0 0 0 0 0 0 1 0 0 0 0 0 0 1
1 0 0<enemy:type=chase,hp=80,aim=15,shoot_delay=0.8,shoot_intensity=30,attack_type=ranged,detect_radius=7,attack_radius=5,speed=70> 0 0 0 1 0 0 0 0 0 1
1 0 0 0 0 0 0 1 0 0 0 0 0 0 1
1 1 1 1 1 0 0 1 0 0 0 0 0 0 1
1 0 0 0 0 0 0 0 0 0 <enemy:type=chase,hp=40,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 6<path:models/model.gbj> 0 1
1 0 <enemy:type=chase,hp=40,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 0 0 0 0 0 0 0 0 0 9<level:2,isvisible:1,material:glass> 1
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1

[SPAWN=0.5,0.5]
[AMBIENT=0.15]
[FLOOR_COLOR=333333]
[CEILING_COLOR=111111]
[LIGHTS=2.5,2.5,0.5,200;7.5,4.5,0.6,250;12.5,12.5,0.7,300]
"""

LEVEL3 = """
[COLLISION]
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
1 0 0 0 0 0 1 0 0 0 0 0 0 0 0 1
1 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1
1 0 0 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 1 0 0 0 0 0 1 0 0 0 0 1
1 0 0 0 1 1 1 1 1 0 1 0 0 0 0 1
1 0 0 0 0 0 0 0 1 0 0 0 0 0 0 1
1 0 1 1 1 0 0 0 1 1 1 0 0 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 0 0 1
1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1
1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1
1 0 0<enemy:type=patrol,hp=100,aim=5,shoot_delay=1.2,shoot_intensity=10,attack_type=melee,detect_radius=5,attack_radius=3,speed=50> 0 0 0 1 0 0 0 0 0 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
1 1 1 1 0 0 0 0 0 0 0 0 0 6<path:models/model.gbj> 0 1
1 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 0 0 0 0 0 0 0 0 0 0 0 0 9<level:3,isvisible:1,material:glass> 1
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1

[SPAWN=0.5,0.5]
[AMBIENT=0.15]
[FLOOR_COLOR=333333]
[CEILING_COLOR=111111]
[LIGHTS=2.5,2.5,0.5,200;7.5,4.5,0.6,250;12.5,12.5,0.7,300]
"""

LEVEL4 = """
[COLLISION]
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
1 0 0 0 0 0 1 0 0 0 0 0 0 0 0 1
1 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1
1 0 0 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 1 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 0 0 0 0 1 0 0 0 0 1
1 0 0 0 1 1 1 1 1 0 1 0 <enemy:type=chase,hp=80,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 0 1
1 0 0 0 0 0 0 0 1 0 0 0 0 0 0 1
1 0 1 1 1 0 0 0 1 1 1 0 0 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1
1 0 0 0 0 0 0 1 0 <enemy:type=chase,hp=80,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 0 0 0 0 1
1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1
1 0 0 0 0 0 0 0<enemy:type=patrol,hp=40,aim=5,shoot_delay=1.5,shoot_intensity=5,attack_type=melee,detect_radius=4,attack_radius=2,speed=40> 0 0 0 0 <enemy:type=chase,hp=150,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
1 1 1 1 0 0 <enemy:type=chase,hp=80,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 0 0 0 0 0 6<path:models/model.gbj> 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 9<level:4,isvisible:1,material:glass> 1
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1

[SPAWN=0.5,0.5]
[AMBIENT=0.15]
[FLOOR_COLOR=333333]
[CEILING_COLOR=111111]
[LIGHTS=2.5,2.5,0.5,200;7.5,4.5,0.6,250;12.5,12.5,0.7,300]
"""

LEVEL5 = """
[COLLISION]
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1
1 0 1 1 1 0 0 1 0 1 1 1 0 0 0 1
1 0 0 0 1 0 0 0 0 0 0 1 0 0 0 1
1 0 0 0 1 0 0<enemy:type=chase,hp=150,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 0 0 0 1 0 0 1
1 0 1 1 1 0 0 0 0 0 0 1 0 0 1
1 0 0 0 0 0 0 1 1 1 0 1 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 1
1 0 1 0 0 0 0 1 0 0 0 <enemy:type=chase,hp=150,aim=25,shoot_delay=0.5,shoot_intensity=50,attack_type=ranged,detect_radius=10,attack_radius=8,speed=90> 0 0 1
1 0 1 0 0 0 0 1 0 1 1 1 0 0 1
1 0 1 0 0<enemy:type=patrol,hp=120,aim=10,shoot_delay=0.9,shoot_intensity=20,attack_type=ranged,detect_radius=8,attack_radius=6,speed=70> 0 0 0 0 1 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 0 1
1 1 1 1 1 0 0 0 0 0 0 0 0 0 1
1 0 0 0 0 0 0 0 0 0 0 0 6<path:models/model.gbj> 0 1
1 0 0 0 0 0 0 0 0 0 0 0 0 9<level:1,isvisible:1,material:glass> 1
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1

[SPAWN=0.5,0.5]
[AMBIENT=0.15]
[FLOOR_COLOR=333333]
[CEILING_COLOR=111111]
[LIGHTS=2.5,2.5,0.5,200;7.5,4.5,0.6,250;12.5,12.5,0.7,300]
"""

# ---------- Класс движка ----------
class MyDoomEngine(Engine):
    def __init__(self, clock, *args, **kwargs):
        super().__init__(clock, *args, **kwargs)
        self.i = pygame.display.Info()
        # Дробовик
        self.shotgun = Gun(
            name='shotgun',
            damage=39,
            fire_rate=0.8,
            ammo=6,
            max_ammo=24,
            texture=load_image('shotgun', 'assets/shotgun.png', size=(self.i.current_w//3,self.i.current_h//3)),
            animation_fire=[load_image('shotgun_fire', 'assets/shotgun_fire.png', size=(self.i.current_w//3,self.i.current_h//3))],
            key='shotgun'
        )
        print("Размер текстуры дробовика:", self.shotgun.texture.get_size())
        self.api.set_player_light(
            radius=300,  # радиус света (в пикселях)
            intensity=1.0,  # интенсивность (0..1)
            color=(255, 255, 255)  # цвет (можно RGB-кортеж)
        )
        self.gun_manager.add_gun(self.shotgun)
        self.gun_manager.switch_gun('shotgun')
        # Смерть игрока
        self.player.on_death = self._on_player_death
        self.game_over = False

    def _on_player_death(self):
        self.game_over = True
        self.show_message("GAME OVER", duration=3.0)

    def enemy_shoot(self, enemy, angle):
        damage = enemy.current_gun.damage if enemy.current_gun else 10
        bullet = Bullet(enemy.x, enemy.y, angle, damage=damage, speed=300, owner=enemy)
        self.bullets.append(bullet)

    def handle_event(self, event):
        pass  # можно добавить обработку скримера

# ---------- Игровой цикл ----------
class DoomGameExample(GameExample):
    def __init__(self, engine_class, levels, current_level, width, height, player_speed=48.0, **kwargs):
        super().__init__(engine_class, levels, current_level, width, height, player_speed, **kwargs)
        # self.enemy_sprite = "assets/enemy_imp.png"  # путь к спрайтув
        self.sm5l = True #show_message_5_level
        self.l1 = True
        self.l2 = True
        self.l3 = True
        self.l4 = True
        self.engine.font = pygame.font.SysFont('Arial', 18)
    def run(self):
        font_hp = pygame.font.SysFont('Arial', 36)
        font_ammo = pygame.font.SysFont('Arial', 36)
        font_fps = pygame.font.SysFont('Arial', 36)  # добавьте
        clock = pygame.time.Clock()
        running = True
        while running:
            if self.engine.current_level == 0 and self.l1:
                self.engine.show_message("Ищи порталы ввиде голубых стен и убивай врагов \n(Стрельба - ЛКМ, движение WASD, для захвата курсора нажмите ПКМ)", 10, size=24)
                self.l1 = False
            elif self.engine.current_level == 1 and self.l2:
                self.engine.show_message("У врагов разное количество ХП. Если закончатся патроны - они автоматически пополнятся\nСовет: Пробуйте стрелять зажимом", 10, size=24)
                self.l2 = False
            elif self.engine.current_level == 2 and self.l3:
                self.engine.show_message("Совет: Если у вас мало ХП, попробуйте постоять за \n    стенами и подождать пока оно восстановится", 10, size=24)
                self.l3 = False
            elif self.engine.current_level == 3 and self.l4:
                self.engine.show_message("Вы почти у цели. Совет: Не торопитесь на этом уровне, здесь много врагов\n    Пытайтесь убить их постепенно", 10, size=24)
                self.l4 = False
            elif self.engine.current_level == 4 and self.sm5l:
                self.engine.show_message("Финальный уровень (5), давай", 10, size=24)
                self.sm5l = False
                self.l1 = True
                self.l2 = True
                self.l3 = True
                self.l4 = True
            elif self.engine.current_level == 0 and not self.sm5l:
                self.sm5l = True
            dt = clock.tick(self.fps) / 1000.0
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if hasattr(self.engine, 'handle_event'):
                    self.engine.handle_event(event)
                if hasattr(self.engine, 'handle_mouse'):
                    self.engine.handle_mouse(event)

            keys = pygame.key.get_pressed()
            if keys[pygame.K_SPACE] or pygame.mouse.get_pressed()[0]:
                self.engine.api.fire_current_gun()
            if keys[pygame.K_ESCAPE]:
                running = False

            self.engine.update(dt, keys)
            self.engine.render(self.screen)

            # HUD (HP и патроны) показываем только если есть враги или оружие
            if (self.engine.enemies or self.engine.gun_manager.guns):
                if self.engine.player.alive:
                    hp_text = font_hp.render(f"HP: {self.engine.player.hp}", True, (255, 0, 0))
                    self.screen.blit(hp_text, (10, 10))
                    gun = self.engine.gun_manager.get_current_gun()
                    if gun:
                        ammo_text = font_ammo.render(f"Ammo: {gun.ammo}/{gun.max_ammo}", True, (255, 255, 0))
                        self.screen.blit(ammo_text, (10, 40))

            # Вывод FPS
            if self.show_fps:
                fps = clock.get_fps()
                if self.engine.use_raycaster_async: fps = fps * 1.07
                fps_text = font_fps.render(f"FPS: {int(fps)}", True, (255, 255, 0))
                self.screen.blit(fps_text, (self.width - 120, self.height - 40))

            if self.engine.game_over and self.engine.message_timer <= 0:
                running = False

            pygame.display.flip()
        pygame.quit()

# ---------- Главная функция ----------
def main():
    pygame.init()
    info = pygame.display.Info()
    WIDTH, HEIGHT = info.current_w, info.current_h
    screen = pygame.display.set_mode((WIDTH, HEIGHT))

    menu = MenuExample(width=WIDTH, height=HEIGHT, button_align='center')
    settings = None

    while menu.running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                menu.running = False
            result = menu.handle_event(event)
            if isinstance(result, dict):
                settings = result
                break
        menu.render(screen)
        pygame.display.flip()
    if settings:
        levels = [LEVEL1, LEVEL2, LEVEL3, LEVEL4, LEVEL5]
        game = DoomGameExample(
            engine_class=MyDoomEngine,
            levels=levels,
            current_level=0,
            width=WIDTH,
            height=HEIGHT,
            player_speed=48.0,
            tile_size=64,
            proj_coeff=50000,
            **settings
        )
        game.api.spawn_enemy_by_tile(tile_x=5, tile_y=2, enemy_type='chase', hp=100, aim=15,
                                       sprite='assets/enemy_demon.png')
        game.run()

if __name__ == "__main__":
    main()