import pygame
from gradus_rc import Engine, LightSource, Sprite, load_image
from gradus_rc import GameExample,MenuExample

LEVEL1 = """
[COLLISION]
1 1 1 1 1 1 1
1 0 0 6<path:models/man.obj,roty:150.0,rotx:0,scale:5.0,color:FFFFFF> 1 9<level:1,isvisible:1,color:441199> 1
1 0 0 0 1 7<type:door,id:door1,link:key1> 1
1 0 0 2 0 0 1
1 0 0 7<type:key,id:key1,link:door1> 0 0 1
1 1 1 1 1 1 1 1

[FLOOR_COLOR=999999]
[CEILING_COLOR=441199]
[SPAWN=0.5,0.5]
[AMBIENT=0.03]
[LIGHTS=2.5,2.5,0.4,200;4.5,3.5,0.6,220]
"""

LEVEL2 = """
[COLLISION]
0 0 0 0 1 1 1 1 1 1 1 1 1
0 6<path:models/cube.obj,rotY:0,scale:5.0,color:FFFFFF> 0 0 1 0 0 0 0 0 0 8<repeatable:0,id:1> 1
0 0 0 0 1 1 1 0 1 0 1 7<type:key,id:key2,link:door2> 1
0 6<path:models/remodel.obj,rotY:0,scale:5.0,color:FFFFFF> 0 0 7<type:door,id:door2,link:key2> 0 1 0 1 0 1 6<path:models/man.obj,rotx:95,roty:150.0,scale:5.0,color:FFFFFF> 1
0 0 0 0 1 0 1 0 1 0 1 1 1
0 6<path:models/model.obj,rotY:0,scale:5.0,color:FFFFFF> 0 0 1 0 0 0 1 0 0 0 1
0 0 0 0 1 1 1 1 1 1 1 1 1

[FLOOR_COLOR=999999]
[CEILING_COLOR=FF00FF]
[SPAWN=5.0,0.5]
[BILBOARDS=3.5,2.5,tree; 5.5,3.5,tree]
[AMBIENT=0.05]
[LIGHTS=5.5,3,1.0,400]
"""

class MyEngine(Engine):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.sound_manager.load_all({
            'scream': 'scream.wav'
        })
        self.CLEAR_EVENT = pygame.USEREVENT + 10

    def on_trigger(self, cell):
        trigger_id = cell.get('properties', {}).get('id', 0)
        if trigger_id == 1:
            self.deactivate_trigger(('id', trigger_id))
            self.set_overlay('scary_face.jfif', 200)
            self.play_sound('scream')
            pygame.time.set_timer(self.CLEAR_EVENT, 1000)

    def handle_event(self, event):
        if event.type == self.CLEAR_EVENT:
            self.clear_overlay()
            self.sound_manager.stop_sound('scream')
            pygame.time.set_timer(self.CLEAR_EVENT, 0)


def main():
    pygame.init()
    WIDTH, HEIGHT = 800, 600
    # engine = MyEngine(
    #     levels=[LEVEL1, LEVEL2],
    #     current_level=0,
    #     width=WIDTH,
    #     height=HEIGHT,
    #     fov=60,
    #     rays=800,
    #     tile_size=64,
    #     max_depth=1000,
    #     proj_coeff=20000,
    #     player_speed=48.0,
    #     player_rot_speed=3.0,
    #     render_scale=1
    # )
    screen = pygame.display.set_mode((WIDTH, HEIGHT))

    menu = MenuExample(width=WIDTH, height=HEIGHT, button_align='left')
    settings = None

    while menu.running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                menu.running = False
            result = menu.handle_event(event)
            if isinstance(result, dict):   # пользователь нажал "Играть"
                settings = result
                break
        menu.render(screen)
        pygame.display.flip()

    if settings:
        game = GameExample(
            engine_class=MyEngine,        # ваш класс движка с кастомными триггерами
            levels=[LEVEL1, LEVEL2],
            current_level=0,
            width=WIDTH,
            height=HEIGHT,
            player_speed=48.0,
            **settings                    # передаём настройки из меню
        )
        game.run()

if __name__ == "__main__":
    main()