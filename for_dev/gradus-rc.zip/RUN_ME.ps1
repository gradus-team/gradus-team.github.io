# Gradus RC - Cython build script
# Run from project root:  .\RUN_ME.ps1

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "=========================================="
Write-Host "  Gradus RC - Cython build for cast_rays"
Write-Host "=========================================="
Write-Host ""

$python = "python"

# Check Python
try {
    $pyver = & $python --version 2>&1
    Write-Host "[1/4] Python: $pyver"
} catch {
    Write-Host "[!] Python not found in PATH."
    exit 1
}

# Check Cython
Write-Host "[2/4] Checking Cython..."
$cy = & $python -c "import Cython; print(Cython.__version__)" 2>$null
if (-not $cy) {
    Write-Host "      Installing cython and setuptools..."
    & $python -m pip install --upgrade pip
    & $python -m pip install cython setuptools
} else {
    Write-Host "      Cython version: $cy"
}

# Build
Write-Host "[3/4] Compiling core_cy.pyx..."
& $python "setup_cython.py" build_ext --inplace
if ($LASTEXITCODE -ne 0) {
    Write-Host "[!] Build failed!"
    exit 1
}

# Cleanup
Write-Host "[4/4] Cleaning up..."
Get-ChildItem -Path "gradus_rc\raycast" -Filter "*.c" -ErrorAction SilentlyContinue | Remove-Item -ErrorAction SilentlyContinue
Get-ChildItem -Path "gradus_rc\raycast" -Filter "*.html" -ErrorAction SilentlyContinue | Remove-Item -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force "build" -ErrorAction SilentlyContinue

# Verify
$built = Get-ChildItem -Path "gradus_rc\raycast" -File | Where-Object {
    $_.Name -like "core_cy*.pyd" -or $_.Name -like "core_cy*.so"
}
if ($built) {
    Write-Host ""
    Write-Host "=========================================="
    Write-Host "  Done! Module: $($built.Name)"
    Write-Host "=========================================="
    Write-Host "Run game.py as usual."
    Write-Host "Look for:  [Engine] RayCaster: Cython version"
} else {
    Write-Host "[!] Module not found after build."
    exit 1
}